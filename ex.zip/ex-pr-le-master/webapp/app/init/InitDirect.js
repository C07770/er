Ext.define('eRecon_web.init.InitDirect', {
    requires: ['Ext.direct.Manager']
}, function () {

    function addProvider(providerConfig) {
        var provider;
        // 5 min for Java-side debugging. Might be appropriate for production as well.
        providerConfig.timeout = 1 * 60 * 1000;
        provider = Ext.Direct.addProvider(providerConfig);
        // VERY IMPORTANT: this is for debugging purposes, set validateCalls to false if this causes problems
        Djn.RemoteCallSupport.addCallValidation(provider);
        Djn.RemoteCallSupport.validateCalls = true;
    }

    var relativeURL = 'djn/directprovider';
    
    Clear.direct.config.PROVIDER_BASE_URL= relativeURL;
    Clear.direct.config.REMOTING_API.url = relativeURL;
    addProvider(Clear.direct.config.REMOTING_API);
    
    eRecon_web.direct.config.PROVIDER_BASE_URL = relativeURL;
    eRecon_web.direct.config.REMOTING_API.url = relativeURL;
    addProvider(eRecon_web.direct.config.REMOTING_API);
});

Ext.define('eRecon_web.store.legalVehicle.LVReportStore',{
	extend: 'eRecon_web.store.legalVehicle.generated._LVReportStore'
});
	

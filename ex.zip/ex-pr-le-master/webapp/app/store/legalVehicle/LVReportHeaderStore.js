Ext.define('eRecon_web.store.legalVehicle.LVReportHeaderStore',{
	extend: 'eRecon_web.store.legalVehicle.generated._LVReportHeaderStore'
});
	

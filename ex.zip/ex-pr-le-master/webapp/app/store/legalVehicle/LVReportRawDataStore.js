Ext.define('eRecon_web.store.legalVehicle.LVReportRawDataStore',{
	extend: 'eRecon_web.store.legalVehicle.generated._LVReportRawDataStore',
	pageSize: 100
});
	

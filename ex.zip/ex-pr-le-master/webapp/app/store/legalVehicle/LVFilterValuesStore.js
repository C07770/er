Ext.define('eRecon_web.store.legalVehicle.LVFilterValuesStore',{
	extend: 'eRecon_web.store.legalVehicle.generated._LVFilterValuesStore'
});
	

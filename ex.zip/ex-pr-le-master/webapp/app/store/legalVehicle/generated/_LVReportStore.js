Ext.define('eRecon_web.store.legalVehicle.generated._LVReportStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.legalVehicle.LVReportModel'],
	model:'eRecon_web.model.legalVehicle.LVReportModel',
		
	api: {
		create:eRecon_web.direct.action.LegalVehicleService.getLVReportData_insertItems,
		read : eRecon_web.direct.action.LegalVehicleService.getLVReportData,
		update:eRecon_web.direct.action.LegalVehicleService.getLVReportData_updateItems,
		destroy:eRecon_web.direct.action.LegalVehicleService.getLVReportData_deleteItems
    }

});
	

Ext.define('eRecon_web.store.legalVehicle.generated._LVReportRawDataStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.dashboard.DetailedDataModel'],
	model:'eRecon_web.model.dashboard.DetailedDataModel',
		
	api: {
		create:eRecon_web.direct.action.LegalVehicleService.getLVReportRawData_insertItems,
		read : eRecon_web.direct.action.LegalVehicleService.getLVReportRawData,
		update:eRecon_web.direct.action.LegalVehicleService.getLVReportRawData_updateItems,
		destroy:eRecon_web.direct.action.LegalVehicleService.getLVReportRawData_deleteItems
    }

});
	

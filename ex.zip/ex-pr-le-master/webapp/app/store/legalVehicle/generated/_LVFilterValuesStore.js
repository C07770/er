Ext.define('eRecon_web.store.legalVehicle.generated._LVFilterValuesStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.legalVehicle.LVFilterValuesModel'],
	model:'eRecon_web.model.legalVehicle.LVFilterValuesModel',
		
	api: {
		create:eRecon_web.direct.action.LegalVehicleService.getFilterValues_insertItems,
		read : eRecon_web.direct.action.LegalVehicleService.getFilterValues,
		update:eRecon_web.direct.action.LegalVehicleService.getFilterValues_updateItems,
		destroy:eRecon_web.direct.action.LegalVehicleService.getFilterValues_deleteItems
    }

});
	

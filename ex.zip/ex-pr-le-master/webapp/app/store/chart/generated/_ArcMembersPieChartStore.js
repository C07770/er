Ext.define('eRecon_web.store.chart.generated._ArcMembersPieChartStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.chart.ArcMembersPieChartModel'],
	model:'eRecon_web.model.chart.ArcMembersPieChartModel',
		
	api: {
		create:eRecon_web.direct.action.DashboardService.getAllArcMembersChartDetails_insertItems,
		read : eRecon_web.direct.action.DashboardService.getAllArcMembersChartDetails,
		update:eRecon_web.direct.action.DashboardService.getAllArcMembersChartDetails_updateItems,
		destroy:eRecon_web.direct.action.DashboardService.getAllArcMembersChartDetails_deleteItems
    }

});
	

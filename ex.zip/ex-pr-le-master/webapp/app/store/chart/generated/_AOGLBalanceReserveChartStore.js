Ext.define('eRecon_web.store.chart.generated._AOGLBalanceReserveChartStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.chart.AOGLBalanceChartModel'],
	model:'eRecon_web.model.chart.AOGLBalanceChartModel',
		
	api: {
		create:eRecon_web.direct.action.DashboardService.getAllAOGLBalanceReserveChartDetails_insertItems,
		read : eRecon_web.direct.action.DashboardService.getAllAOGLBalanceReserveChartDetails,
		update:eRecon_web.direct.action.DashboardService.getAllAOGLBalanceReserveChartDetails_updateItems,
		destroy:eRecon_web.direct.action.DashboardService.getAllAOGLBalanceReserveChartDetails_deleteItems
    }

});
	

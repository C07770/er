Ext.define('eRecon_web.store.chart.generated._AllTabsPieChartStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.chart.PieChartModel'],
	model:'eRecon_web.model.chart.PieChartModel',
		
	api: {
		create:eRecon_web.direct.action.DashboardService.getAllTabsChartInfo_insertItems,
		read : eRecon_web.direct.action.DashboardService.getAllTabsChartInfo,
		update:eRecon_web.direct.action.DashboardService.getAllTabsChartInfo_updateItems,
		destroy:eRecon_web.direct.action.DashboardService.getAllTabsChartInfo_deleteItems
    }

});
	

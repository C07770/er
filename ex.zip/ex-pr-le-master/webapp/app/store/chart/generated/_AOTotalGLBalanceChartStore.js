Ext.define('eRecon_web.store.chart.generated._AOTotalGLBalanceChartStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.chart.AOTotalGLBalanceChartModel'],
	model:'eRecon_web.model.chart.AOTotalGLBalanceChartModel',
		
	api: {
		create:eRecon_web.direct.action.DashboardService.getAllAOTotalGLBalanceChartDetails_insertItems,
		read : eRecon_web.direct.action.DashboardService.getAllAOTotalGLBalanceChartDetails,
		update:eRecon_web.direct.action.DashboardService.getAllAOTotalGLBalanceChartDetails_updateItems,
		destroy:eRecon_web.direct.action.DashboardService.getAllAOTotalGLBalanceChartDetails_deleteItems
    }

});
	

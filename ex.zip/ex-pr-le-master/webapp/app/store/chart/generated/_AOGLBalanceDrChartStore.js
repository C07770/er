Ext.define('eRecon_web.store.chart.generated._AOGLBalanceDrChartStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.chart.AOGLBalanceChartModel'],
	model:'eRecon_web.model.chart.AOGLBalanceChartModel',
		
	api: {
		create:eRecon_web.direct.action.DashboardService.getAllAOGLBalanceDrChartDetails_insertItems,
		read : eRecon_web.direct.action.DashboardService.getAllAOGLBalanceDrChartDetails,
		update:eRecon_web.direct.action.DashboardService.getAllAOGLBalanceDrChartDetails_updateItems,
		destroy:eRecon_web.direct.action.DashboardService.getAllAOGLBalanceDrChartDetails_deleteItems
    }

});

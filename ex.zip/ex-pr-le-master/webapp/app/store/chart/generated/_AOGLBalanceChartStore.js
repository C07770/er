Ext.define('eRecon_web.store.chart.generated._AOGLBalanceChartStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.chart.AOGLBalanceChartModel'],
	model:'eRecon_web.model.chart.AOGLBalanceChartModel',
		
	api: {
		create:eRecon_web.direct.action.DashboardService.getAllAOGLBalanceChartDetails_insertItems,
		read : eRecon_web.direct.action.DashboardService.getAllAOGLBalanceChartDetails,
		update:eRecon_web.direct.action.DashboardService.getAllAOGLBalanceChartDetails_updateItems,
		destroy:eRecon_web.direct.action.DashboardService.getAllAOGLBalanceChartDetails_deleteItems
    }

});
	

Ext.define('eRecon_web.store.chart.AOAttestationSummaryValuesForAgreedChartStore',{
	extend: 'eRecon_web.store.chart.generated._AOAttestationSummaryValuesForAgreedChartStore'
});
	

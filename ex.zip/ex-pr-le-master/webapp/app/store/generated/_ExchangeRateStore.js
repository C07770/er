Ext.define('eRecon_web.store.generated._ExchangeRateStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.ExchangeRateModel'],
	model:'eRecon_web.model.ExchangeRateModel',
		
	api: {
		create:eRecon_web.direct.action.ExchangeRateService.getExchangeRate_insertItems,
		read : eRecon_web.direct.action.ExchangeRateService.getExchangeRate,
		update:eRecon_web.direct.action.ExchangeRateService.getExchangeRate_updateItems,
		destroy:eRecon_web.direct.action.ExchangeRateService.getExchangeRate_deleteItems
    }

});
	

Ext.define('eRecon_web.store.generated._LemAdjustmentsPopupStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.LemAdjustmentsPopupModel'],
	model:'eRecon_web.model.LemAdjustmentsPopupModel',
		
	api: {
		create:eRecon_web.direct.action.LemAdjustmentsService.getLemAdjustmentsAgingDetails_insertItems,
		read : eRecon_web.direct.action.LemAdjustmentsService.getLemAdjustmentsAgingDetails,
		update:eRecon_web.direct.action.LemAdjustmentsService.getLemAdjustmentsAgingDetails_updateItems,
		destroy:eRecon_web.direct.action.LemAdjustmentsService.getLemAdjustmentsAgingDetails_deleteItems
    }

});
	

Ext.define('eRecon_web.store.generated._TransferDetailStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.TransferDetailModel'],
	model:'eRecon_web.model.TransferDetailModel',
		
	api: {
		create:eRecon_web.direct.action.TransferService.getTransferDetail_insertItems,
		read : eRecon_web.direct.action.TransferService.getTransferDetail,
		update:eRecon_web.direct.action.TransferService.getTransferDetail_updateItems,
		destroy:eRecon_web.direct.action.TransferService.getTransferDetail_deleteItems
    }

});
	

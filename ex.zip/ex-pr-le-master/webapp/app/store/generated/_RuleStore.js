Ext.define('eRecon_web.store.generated._RuleStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.RuleModel'],
	model:'eRecon_web.model.RuleModel',
		
	api: {
		create:eRecon_web.direct.action.RulesMaintenanceService.getRules_insertItems,
		read : eRecon_web.direct.action.RulesMaintenanceService.getRules,
		update:eRecon_web.direct.action.RulesMaintenanceService.getRules_updateItems,
		destroy:eRecon_web.direct.action.RulesMaintenanceService.getRules_deleteItems
    }

});
	

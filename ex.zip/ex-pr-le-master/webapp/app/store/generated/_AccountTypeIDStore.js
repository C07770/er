Ext.define('eRecon_web.store.generated._AccountTypeIDStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.AccountTypeIDModel'],
	model:'eRecon_web.model.AccountTypeIDModel',
		
	api: {
		create:eRecon_web.direct.action.AccountTypeLUService.getAccountTypeID_insertItems,
		read : eRecon_web.direct.action.AccountTypeLUService.getAccountTypeID,
		update:eRecon_web.direct.action.AccountTypeLUService.getAccountTypeID_updateItems,
		destroy:eRecon_web.direct.action.AccountTypeLUService.getAccountTypeID_deleteItems
    }

});
	

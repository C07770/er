Ext.define('eRecon_web.store.generated._RoleStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.RoleModel'],
	model:'eRecon_web.model.RoleModel',
		
	api: {
		create:eRecon_web.direct.action.UserRoleMappingService.getRole_insertItems,
		read : eRecon_web.direct.action.UserRoleMappingService.getRole,
		update:eRecon_web.direct.action.UserRoleMappingService.getRole_updateItems,
		destroy:eRecon_web.direct.action.UserRoleMappingService.getRole_deleteItems
    }

});
	

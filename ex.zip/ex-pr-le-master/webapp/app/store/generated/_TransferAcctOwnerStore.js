Ext.define('eRecon_web.store.generated._TransferAcctOwnerStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.AcctOwnerModel'],
	model:'eRecon_web.model.AcctOwnerModel',
		
	api: {
		create:eRecon_web.direct.action.TransferService.getTransferAcctOwnerValues_insertItems,
		read : eRecon_web.direct.action.TransferService.getTransferAcctOwnerValues,
		update:eRecon_web.direct.action.TransferService.getTransferAcctOwnerValues_updateItems,
		destroy:eRecon_web.direct.action.TransferService.getTransferAcctOwnerValues_deleteItems
    }

});
	

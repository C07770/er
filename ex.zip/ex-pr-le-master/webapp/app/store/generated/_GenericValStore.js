Ext.define('eRecon_web.store.generated._GenericValStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.GenericValModel'],
	model:'eRecon_web.model.GenericValModel',
		
	api: {
		create:eRecon_web.direct.action.RulesMaintenanceService.getReferenceValues_insertItems,
		read : eRecon_web.direct.action.RulesMaintenanceService.getReferenceValues,
		update:eRecon_web.direct.action.RulesMaintenanceService.getReferenceValues_updateItems,
		destroy:eRecon_web.direct.action.RulesMaintenanceService.getReferenceValues_deleteItems
    }

});
	

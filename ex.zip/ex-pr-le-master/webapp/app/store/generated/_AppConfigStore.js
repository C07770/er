Ext.define('eRecon_web.store.generated._AppConfigStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.AppConfigModel'],
	model:'eRecon_web.model.AppConfigModel',
		
	api: {
		create:eRecon_web.direct.action.AppConfigService.getApplicationConfig_insertItems,
		read : eRecon_web.direct.action.AppConfigService.getApplicationConfig,
		update:eRecon_web.direct.action.AppConfigService.getApplicationConfig_updateItems,
		destroy:eRecon_web.direct.action.AppConfigService.getApplicationConfig_deleteItems
    }

});
	

Ext.define('eRecon_web.store.generated._ActiveFlagStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.DropDownModel'],
	model:'eRecon_web.model.DropDownModel',
		
	api: {
		create:eRecon_web.direct.action.AccountMaintenanceService.getActiveFlag_insertItems,
		read : eRecon_web.direct.action.AccountMaintenanceService.getActiveFlag,
		update:eRecon_web.direct.action.AccountMaintenanceService.getActiveFlag_updateItems,
		destroy:eRecon_web.direct.action.AccountMaintenanceService.getActiveFlag_deleteItems
    }

});
	

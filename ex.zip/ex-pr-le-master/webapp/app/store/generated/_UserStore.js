Ext.define('eRecon_web.store.generated._UserStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.UserModel'],
	model:'eRecon_web.model.UserModel',
		
	api: {
		create:eRecon_web.direct.action.UserRoleMappingService.getUser_insertItems,
		read : eRecon_web.direct.action.UserRoleMappingService.getUser,
		update:eRecon_web.direct.action.UserRoleMappingService.getUser_updateItems,
		destroy:eRecon_web.direct.action.UserRoleMappingService.getUser_deleteItems
    }

});
	

Ext.define('eRecon_web.store.generated._AdminOpenCycleStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.AdminOpenCloseCycleModel'],
	model:'eRecon_web.model.AdminOpenCloseCycleModel',
		
	api: {
		create:eRecon_web.direct.action.AdminOpenCloseCycleService.getOpenCloseDetails_insertItems,
		read : eRecon_web.direct.action.AdminOpenCloseCycleService.getOpenCloseDetails,
		update:eRecon_web.direct.action.AdminOpenCloseCycleService.getOpenCloseDetails_updateItems,
		destroy:eRecon_web.direct.action.AdminOpenCloseCycleService.getOpenCloseDetails_deleteItems
    }

});
	

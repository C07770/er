Ext.define('eRecon_web.store.generated._LemFullkeyStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.LemFullkeyModel'],
	model:'eRecon_web.model.LemFullkeyModel',
		
	api: {
		create:eRecon_web.direct.action.LemAdjustmentsService.getFullkey_insertItems,
		read : eRecon_web.direct.action.LemAdjustmentsService.getFullkey,
		update:eRecon_web.direct.action.LemAdjustmentsService.getFullkey_updateItems,
		destroy:eRecon_web.direct.action.LemAdjustmentsService.getFullkey_deleteItems
    }

});
	

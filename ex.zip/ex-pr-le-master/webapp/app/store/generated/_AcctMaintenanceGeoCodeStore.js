Ext.define('eRecon_web.store.generated._AcctMaintenanceGeoCodeStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.DropDownModel'],
	model:'eRecon_web.model.DropDownModel',
		
	api: {
		create:eRecon_web.direct.action.AccountMaintenanceService.getGeoCode_insertItems,
		read : eRecon_web.direct.action.AccountMaintenanceService.getGeoCode,
		update:eRecon_web.direct.action.AccountMaintenanceService.getGeoCode_updateItems,
		destroy:eRecon_web.direct.action.AccountMaintenanceService.getGeoCode_deleteItems
    }

});
	

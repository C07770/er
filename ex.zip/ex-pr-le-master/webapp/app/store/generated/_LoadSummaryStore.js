Ext.define('eRecon_web.store.generated._LoadSummaryStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.LoadSummaryModel'],
	model:'eRecon_web.model.LoadSummaryModel',
		
	api: {
		create:eRecon_web.direct.action.LoadSummaryService.getLoadSummary_insertItems,
		read : eRecon_web.direct.action.LoadSummaryService.getLoadSummary,
		update:eRecon_web.direct.action.LoadSummaryService.getLoadSummary_updateItems,
		destroy:eRecon_web.direct.action.LoadSummaryService.getLoadSummary_deleteItems
    }

});
	

Ext.define('eRecon_web.store.generated._AOUplaodAcctOwnerStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.AcctOwnerModel'],
	model:'eRecon_web.model.AcctOwnerModel',
		
	api: {
		create:eRecon_web.direct.action.AOUploadFilterService.getAOUploadAccountOwnerValues_insertItems,
		read : eRecon_web.direct.action.AOUploadFilterService.getAOUploadAccountOwnerValues,
		update:eRecon_web.direct.action.AOUploadFilterService.getAOUploadAccountOwnerValues_updateItems,
		destroy:eRecon_web.direct.action.AOUploadFilterService.getAOUploadAccountOwnerValues_deleteItems
    }

});
	

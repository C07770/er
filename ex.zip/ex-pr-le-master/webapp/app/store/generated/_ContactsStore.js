Ext.define('eRecon_web.store.generated._ContactsStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.ContactsModel'],
	model:'eRecon_web.model.ContactsModel',
		
	api: {
		create:eRecon_web.direct.action.ContactsService.getContactInformation_insertItems,
		read : eRecon_web.direct.action.ContactsService.getContactInformation,
		update:eRecon_web.direct.action.ContactsService.getContactInformation_updateItems,
		destroy:eRecon_web.direct.action.ContactsService.getContactInformation_deleteItems
    }

});
	

Ext.define('eRecon_web.store.generated._CountriesStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.CountriesModel'],
	model:'eRecon_web.model.CountriesModel',
		
	api: {
		create:eRecon_web.direct.action.RulesMaintenanceService.getCountries_insertItems,
		read : eRecon_web.direct.action.RulesMaintenanceService.getCountries,
		update:eRecon_web.direct.action.RulesMaintenanceService.getCountries_updateItems,
		destroy:eRecon_web.direct.action.RulesMaintenanceService.getCountries_deleteItems
    }

});
	

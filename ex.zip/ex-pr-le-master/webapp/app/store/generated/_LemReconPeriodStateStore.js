Ext.define('eRecon_web.store.generated._LemReconPeriodStateStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.LemReconPeriodStateModel'],
	model:'eRecon_web.model.LemReconPeriodStateModel',
		
	api: {
		create:eRecon_web.direct.action.LemAdjustmentsService.getLemReconPeriodState_insertItems,
		read : eRecon_web.direct.action.LemAdjustmentsService.getLemReconPeriodState,
		update:eRecon_web.direct.action.LemAdjustmentsService.getLemReconPeriodState_updateItems,
		destroy:eRecon_web.direct.action.LemAdjustmentsService.getLemReconPeriodState_deleteItems
    }

});
	

Ext.define('eRecon_web.store.generated._SortByStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.FilterModel'],
	model:'eRecon_web.model.FilterModel',
		
	api: {
		create:eRecon_web.direct.action.FilterService.getSubledgerSortByValues_insertItems,
		read : eRecon_web.direct.action.FilterService.getSubledgerSortByValues,
		update:eRecon_web.direct.action.FilterService.getSubledgerSortByValues_updateItems,
		destroy:eRecon_web.direct.action.FilterService.getSubledgerSortByValues_deleteItems
    }

});
	

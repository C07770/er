Ext.define('eRecon_web.store.generated._BroadcastMessageStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.BroadcastMessageModel'],
	model:'eRecon_web.model.BroadcastMessageModel',
		
	api: {
		create:eRecon_web.direct.action.BroadcastMessageService.getBroadcastMessage_insertItems,
		read : eRecon_web.direct.action.BroadcastMessageService.getBroadcastMessage,
		update:eRecon_web.direct.action.BroadcastMessageService.getBroadcastMessage_updateItems,
		destroy:eRecon_web.direct.action.BroadcastMessageService.getBroadcastMessage_deleteItems
    }

});
	

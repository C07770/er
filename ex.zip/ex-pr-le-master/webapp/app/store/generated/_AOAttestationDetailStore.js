Ext.define('eRecon_web.store.generated._AOAttestationDetailStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.AOAttestationDetailModel'],
	model:'eRecon_web.model.AOAttestationDetailModel',
		
	api: {
		create:eRecon_web.direct.action.AOAttestationSummaryService.getAOAttestationDetailValues_insertItems,
		read : eRecon_web.direct.action.AOAttestationSummaryService.getAOAttestationDetailValues,
		update:eRecon_web.direct.action.AOAttestationSummaryService.getAOAttestationDetailValues_updateItems,
		destroy:eRecon_web.direct.action.AOAttestationSummaryService.getAOAttestationDetailValues_deleteItems
    }

});
	

Ext.define('eRecon_web.store.generated._CurrenciesStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.CurrenciesModel'],
	model:'eRecon_web.model.CurrenciesModel',
		
	api: {
		create:eRecon_web.direct.action.RulesMaintenanceService.getCurrencies_insertItems,
		read : eRecon_web.direct.action.RulesMaintenanceService.getCurrencies,
		update:eRecon_web.direct.action.RulesMaintenanceService.getCurrencies_updateItems,
		destroy:eRecon_web.direct.action.RulesMaintenanceService.getCurrencies_deleteItems
    }

});
	

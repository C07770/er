Ext.define('eRecon_web.store.generated._CycleCalenderLuStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.CycleCalenderModel'],
	model:'eRecon_web.model.CycleCalenderModel',
		
	api: {
		create:eRecon_web.direct.action.CycleCalenderLuService.getCalenderdetails_insertItems,
		read : eRecon_web.direct.action.CycleCalenderLuService.getCalenderdetails,
		update:eRecon_web.direct.action.CycleCalenderLuService.getCalenderdetails_updateItems,
		destroy:eRecon_web.direct.action.CycleCalenderLuService.getCalenderdetails_deleteItems
    }

});
	

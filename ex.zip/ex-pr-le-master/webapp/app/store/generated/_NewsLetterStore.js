Ext.define('eRecon_web.store.generated._NewsLetterStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.NewsLetterModel'],
	model:'eRecon_web.model.NewsLetterModel',
		
	api: {
		create:eRecon_web.direct.action.NewsLetterService.getNewsLetters_insertItems,
		read : eRecon_web.direct.action.NewsLetterService.getNewsLetters,
		update:eRecon_web.direct.action.NewsLetterService.getNewsLetters_updateItems,
		destroy:eRecon_web.direct.action.NewsLetterService.getNewsLetters_deleteItems
    }

});
	

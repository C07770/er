Ext.define('eRecon_web.store.generated._TransferSubmitAOStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.AcctOwnerModel'],
	model:'eRecon_web.model.AcctOwnerModel',
		
	api: {
		create:eRecon_web.direct.action.TransferService.getTransferSubmitAccountOwnerValues_insertItems,
		read : eRecon_web.direct.action.TransferService.getTransferSubmitAccountOwnerValues,
		update:eRecon_web.direct.action.TransferService.getTransferSubmitAccountOwnerValues_updateItems,
		destroy:eRecon_web.direct.action.TransferService.getTransferSubmitAccountOwnerValues_deleteItems
    }

});
	

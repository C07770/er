Ext.define('eRecon_web.store.generated._SectorLobLevel2DescrStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.DropDownModel'],
	model:'eRecon_web.model.DropDownModel',
		
	api: {
		create:eRecon_web.direct.action.SectorLobMappingService.getSectorLobLevel2Descr_insertItems,
		read : eRecon_web.direct.action.SectorLobMappingService.getSectorLobLevel2Descr,
		update:eRecon_web.direct.action.SectorLobMappingService.getSectorLobLevel2Descr_updateItems,
		destroy:eRecon_web.direct.action.SectorLobMappingService.getSectorLobLevel2Descr_deleteItems
    }

});
	

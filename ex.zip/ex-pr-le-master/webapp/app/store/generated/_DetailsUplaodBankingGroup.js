Ext.define('eRecon_web.store.generated._DetailsUplaodBankingGroup',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.DetailsUploadBankingGroupModel'],
	model:'eRecon_web.model.DetailsUploadBankingGroupModel',
		
	api: {
		create:eRecon_web.direct.action.DetailsUploadBankingGroup.getBankingGroup_insertItems,
		read : eRecon_web.direct.action.DetailsUploadBankingGroup.getBankingGroup,
		update:eRecon_web.direct.action.DetailsUploadBankingGroup.getBankingGroup_updateItems,
		destroy:eRecon_web.direct.action.DetailsUploadBankingGroup.getBankingGroup_deleteItems
    }

});
	

Ext.define('eRecon_web.store.generated._AcctMaintenanceCountryStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.DropDownModel'],
	model:'eRecon_web.model.DropDownModel',
		
	api: {
		create:eRecon_web.direct.action.AccountMaintenanceService.getCountryCode_insertItems,
		read : eRecon_web.direct.action.AccountMaintenanceService.getCountryCode,
		update:eRecon_web.direct.action.AccountMaintenanceService.getCountryCode_updateItems,
		destroy:eRecon_web.direct.action.AccountMaintenanceService.getCountryCode_deleteItems
    }

});
	

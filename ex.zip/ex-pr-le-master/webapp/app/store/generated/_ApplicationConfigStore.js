Ext.define('eRecon_web.store.generated._ApplicationConfigStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.ApplicationConfigModel'],
	model:'eRecon_web.model.ApplicationConfigModel',
		
	api: {
		create:eRecon_web.direct.action.ApplicationConfigService.getApplicationConfig_insertItems,
		read : eRecon_web.direct.action.ApplicationConfigService.getApplicationConfig,
		update:eRecon_web.direct.action.ApplicationConfigService.getApplicationConfig_updateItems,
		destroy:eRecon_web.direct.action.ApplicationConfigService.getApplicationConfig_deleteItems
    }

});
	

Ext.define('eRecon_web.store.generated._AccountTypeDefaultStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.AccountTypeDefaultModel'],
	model:'eRecon_web.model.AccountTypeDefaultModel',
		
	api: {
		create:eRecon_web.direct.action.AccountTypeDefaultService.getAccountTypeDefaults_insertItems,
		read : eRecon_web.direct.action.AccountTypeDefaultService.getAccountTypeDefaults,
		update:eRecon_web.direct.action.AccountTypeDefaultService.getAccountTypeDefaults_updateItems,
		destroy:eRecon_web.direct.action.AccountTypeDefaultService.getAccountTypeDefaults_deleteItems
    }

});
	

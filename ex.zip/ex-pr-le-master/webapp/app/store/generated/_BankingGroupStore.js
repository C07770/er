Ext.define('eRecon_web.store.generated._BankingGroupStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.BankingGroupModel'],
	model:'eRecon_web.model.BankingGroupModel',
		
	api: {
		create:eRecon_web.direct.action.SubledgerService.getBankingGroup_insertItems,
		read : eRecon_web.direct.action.SubledgerService.getBankingGroup,
		update:eRecon_web.direct.action.SubledgerService.getBankingGroup_updateItems,
		destroy:eRecon_web.direct.action.SubledgerService.getBankingGroup_deleteItems
    }

});
	

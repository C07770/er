Ext.define('eRecon_web.store.generated._GLFeedCalenderStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.GLFeedCalenderModel'],
	model:'eRecon_web.model.GLFeedCalenderModel',
		
	api: {
		create:eRecon_web.direct.action.GLFeedCalenderService.getGLfeedCalenderDetails_insertItems,
		read : eRecon_web.direct.action.GLFeedCalenderService.getGLfeedCalenderDetails,
		update:eRecon_web.direct.action.GLFeedCalenderService.getGLfeedCalenderDetails_updateItems,
		destroy:eRecon_web.direct.action.GLFeedCalenderService.getGLfeedCalenderDetails_deleteItems
    }

});
	

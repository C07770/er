Ext.define('eRecon_web.store.generated._AccountMaintenanceStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.AccountMaintenanceModel'],
	model:'eRecon_web.model.AccountMaintenanceModel',
		
	api: {
		create:eRecon_web.direct.action.AccountMaintenanceService.getReferenceData_insertItems,
		read : eRecon_web.direct.action.AccountMaintenanceService.getReferenceData,
		update:eRecon_web.direct.action.AccountMaintenanceService.getReferenceData_updateItems,
		destroy:eRecon_web.direct.action.AccountMaintenanceService.getReferenceData_deleteItems
    }

});
	

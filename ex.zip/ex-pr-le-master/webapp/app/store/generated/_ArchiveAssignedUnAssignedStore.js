Ext.define('eRecon_web.store.generated._ArchiveAssignedUnAssignedStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.ArchiveBSDModel'],
	model:'eRecon_web.model.ArchiveBSDModel',
		
	api: {
		create:eRecon_web.direct.action.ArchiveBSDService.getAssignedUnAssignedValues_insertItems,
		read : eRecon_web.direct.action.ArchiveBSDService.getAssignedUnAssignedValues,
		update:eRecon_web.direct.action.ArchiveBSDService.getAssignedUnAssignedValues_updateItems,
		destroy:eRecon_web.direct.action.ArchiveBSDService.getAssignedUnAssignedValues_deleteItems
    }

});
	

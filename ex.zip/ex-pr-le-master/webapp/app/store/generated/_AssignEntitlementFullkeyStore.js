Ext.define('eRecon_web.store.generated._AssignEntitlementFullkeyStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.DropDownModel'],
	model:'eRecon_web.model.DropDownModel',
		
	api: {
		create:eRecon_web.direct.action.AssignEntitlementService.getAssignEntitlementFullkeyValues_insertItems,
		read : eRecon_web.direct.action.AssignEntitlementService.getAssignEntitlementFullkeyValues,
		update:eRecon_web.direct.action.AssignEntitlementService.getAssignEntitlementFullkeyValues_updateItems,
		destroy:eRecon_web.direct.action.AssignEntitlementService.getAssignEntitlementFullkeyValues_deleteItems
    }

});
	

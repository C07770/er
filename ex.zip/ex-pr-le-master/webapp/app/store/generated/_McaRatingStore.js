Ext.define('eRecon_web.store.generated._McaRatingStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.DropDownModel'],
	model:'eRecon_web.model.DropDownModel',
		
	api: {
		create:eRecon_web.direct.action.CentralizedSiteMapService.getMcaRating_insertItems,
		read : eRecon_web.direct.action.CentralizedSiteMapService.getMcaRating,
		update:eRecon_web.direct.action.CentralizedSiteMapService.getMcaRating_updateItems,
		destroy:eRecon_web.direct.action.CentralizedSiteMapService.getMcaRating_deleteItems
    }

});
	

Ext.define('eRecon_web.store.generated._RollbackFeedsStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.RollbackFeedsModel'],
	model:'eRecon_web.model.RollbackFeedsModel',
		
	api: {
		create:eRecon_web.direct.action.RollbackFeedsService.getRollbackFeeds_insertItems,
		read : eRecon_web.direct.action.RollbackFeedsService.getRollbackFeeds,
		update:eRecon_web.direct.action.RollbackFeedsService.getRollbackFeeds_updateItems,
		destroy:eRecon_web.direct.action.RollbackFeedsService.getRollbackFeeds_deleteItems
    }

});
	

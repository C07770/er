Ext.define('eRecon_web.store.generated._AccountsViewStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.AccountsViewModel'],
	model:'eRecon_web.model.AccountsViewModel',
		
	api: {
		create:eRecon_web.direct.action.AccountsViewService.getAllAccounts_insertItems,
		read : eRecon_web.direct.action.AccountsViewService.getAllAccounts,
		update:eRecon_web.direct.action.AccountsViewService.getAllAccounts_updateItems,
		destroy:eRecon_web.direct.action.AccountsViewService.getAllAccounts_deleteItems
    }

});
	

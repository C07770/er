Ext.define('eRecon_web.store.generated._ManagerStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.ManagerModel'],
	model:'eRecon_web.model.ManagerModel',
		
	api: {
		create:eRecon_web.direct.action.SubledgerService.getManagers_insertItems,
		read : eRecon_web.direct.action.SubledgerService.getManagers,
		update:eRecon_web.direct.action.SubledgerService.getManagers_updateItems,
		destroy:eRecon_web.direct.action.SubledgerService.getManagers_deleteItems
    }

});
	

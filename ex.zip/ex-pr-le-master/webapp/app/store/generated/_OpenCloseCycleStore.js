Ext.define('eRecon_web.store.generated._OpenCloseCycleStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.OpenCloseCycleModel'],
	model:'eRecon_web.model.OpenCloseCycleModel',
		
	api: {
		create:eRecon_web.direct.action.OpenCloseCycleService.getCycleStatistics_insertItems,
		read : eRecon_web.direct.action.OpenCloseCycleService.getCycleStatistics,
		update:eRecon_web.direct.action.OpenCloseCycleService.getCycleStatistics_updateItems,
		destroy:eRecon_web.direct.action.OpenCloseCycleService.getCycleStatistics_deleteItems
    }

});
	

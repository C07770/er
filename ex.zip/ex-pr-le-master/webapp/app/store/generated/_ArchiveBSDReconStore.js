Ext.define('eRecon_web.store.generated._ArchiveBSDReconStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.DropDownModel'],
	model:'eRecon_web.model.DropDownModel',
		
	api: {
		create:eRecon_web.direct.action.ArchiveBSDService.getReconPeriod_insertItems,
		read : eRecon_web.direct.action.ArchiveBSDService.getReconPeriod,
		update:eRecon_web.direct.action.ArchiveBSDService.getReconPeriod_updateItems,
		destroy:eRecon_web.direct.action.ArchiveBSDService.getReconPeriod_deleteItems
    }

});
	

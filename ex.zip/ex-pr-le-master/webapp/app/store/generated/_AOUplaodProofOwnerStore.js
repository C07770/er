Ext.define('eRecon_web.store.generated._AOUplaodProofOwnerStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.ManagerModel'],
	model:'eRecon_web.model.ManagerModel',
		
	api: {
		create:eRecon_web.direct.action.AOUploadFilterService.getAOUploadProofOwnerValues_insertItems,
		read : eRecon_web.direct.action.AOUploadFilterService.getAOUploadProofOwnerValues,
		update:eRecon_web.direct.action.AOUploadFilterService.getAOUploadProofOwnerValues_updateItems,
		destroy:eRecon_web.direct.action.AOUploadFilterService.getAOUploadProofOwnerValues_deleteItems
    }

});
	

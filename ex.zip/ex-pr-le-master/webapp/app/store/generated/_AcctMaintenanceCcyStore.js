Ext.define('eRecon_web.store.generated._AcctMaintenanceCcyStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.DropDownModel'],
	model:'eRecon_web.model.DropDownModel',
		
	api: {
		create:eRecon_web.direct.action.AccountMaintenanceService.getCurrencyCode_insertItems,
		read : eRecon_web.direct.action.AccountMaintenanceService.getCurrencyCode,
		update:eRecon_web.direct.action.AccountMaintenanceService.getCurrencyCode_updateItems,
		destroy:eRecon_web.direct.action.AccountMaintenanceService.getCurrencyCode_deleteItems
    }

});
	

Ext.define('eRecon_web.store.generated._FilterStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.FilterModel'],
	model:'eRecon_web.model.FilterModel',
		
	api: {
		create:eRecon_web.direct.action.FilterService.getSubledgerFilterValues_insertItems,
		read : eRecon_web.direct.action.FilterService.getSubledgerFilterValues,
		update:eRecon_web.direct.action.FilterService.getSubledgerFilterValues_updateItems,
		destroy:eRecon_web.direct.action.FilterService.getSubledgerFilterValues_deleteItems
    }

});
	

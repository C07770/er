Ext.define('eRecon_web.store.generated._AccountOwnerLuStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.AccountOwnerLuModel'],
	model:'eRecon_web.model.AccountOwnerLuModel',
		
	api: {
		create:eRecon_web.direct.action.AccountOwnerLuService.getAccountOwners_insertItems,
		read : eRecon_web.direct.action.AccountOwnerLuService.getAccountOwners,
		update:eRecon_web.direct.action.AccountOwnerLuService.getAccountOwners_updateItems,
		destroy:eRecon_web.direct.action.AccountOwnerLuService.getAccountOwners_deleteItems
    }

});
	

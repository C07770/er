Ext.define('eRecon_web.store.generated._AOAttestationSummaryStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.AOAttestationSummaryModel'],
	model:'eRecon_web.model.AOAttestationSummaryModel',
		
	api: {
		create:eRecon_web.direct.action.AOAttestationSummaryService.getAOAttestationSummaryValues_insertItems,
		read : eRecon_web.direct.action.AOAttestationSummaryService.getAOAttestationSummaryValues,
		update:eRecon_web.direct.action.AOAttestationSummaryService.getAOAttestationSummaryValues_updateItems,
		destroy:eRecon_web.direct.action.AOAttestationSummaryService.getAOAttestationSummaryValues_deleteItems
    }

});
	

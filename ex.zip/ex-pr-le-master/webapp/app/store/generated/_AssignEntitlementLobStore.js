Ext.define('eRecon_web.store.generated._AssignEntitlementLobStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.DropDownModel'],
	model:'eRecon_web.model.DropDownModel',
		
	api: {
		create:eRecon_web.direct.action.AssignEntitlementService.getAssignEntitlementLobValues_insertItems,
		read : eRecon_web.direct.action.AssignEntitlementService.getAssignEntitlementLobValues,
		update:eRecon_web.direct.action.AssignEntitlementService.getAssignEntitlementLobValues_updateItems,
		destroy:eRecon_web.direct.action.AssignEntitlementService.getAssignEntitlementLobValues_deleteItems
    }

});
	

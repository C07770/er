Ext.define('eRecon_web.store.generated._SubledgerDetailStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.SubledgerDetailModel'],
	model:'eRecon_web.model.SubledgerDetailModel',
		
	api: {
		create:eRecon_web.direct.action.SubledgerService.getSubledgerDetail_insertItems,
		read : eRecon_web.direct.action.SubledgerService.getSubledgerDetail,
		update:eRecon_web.direct.action.SubledgerService.getSubledgerDetail_updateItems,
		destroy:eRecon_web.direct.action.SubledgerService.getSubledgerDetail_deleteItems
    }

});
	

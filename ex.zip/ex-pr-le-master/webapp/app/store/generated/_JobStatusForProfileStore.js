Ext.define('eRecon_web.store.generated._JobStatusForProfileStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.JobStatusModel'],
	model:'eRecon_web.model.JobStatusModel',
		
	api: {
		create:eRecon_web.direct.action.JobStatusService.getJobStatusForProfile_insertItems,
		read : eRecon_web.direct.action.JobStatusService.getJobStatusForProfile,
		update:eRecon_web.direct.action.JobStatusService.getJobStatusForProfile_updateItems,
		destroy:eRecon_web.direct.action.JobStatusService.getJobStatusForProfile_deleteItems
    }

});
	

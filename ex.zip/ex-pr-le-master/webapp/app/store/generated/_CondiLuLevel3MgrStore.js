Ext.define('eRecon_web.store.generated._CondiLuLevel3MgrStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.DropDownModel'],
	model:'eRecon_web.model.DropDownModel',
		
	api: {
		create:eRecon_web.direct.action.CondiLuService.getCondiLuLevel3Mgr_insertItems,
		read : eRecon_web.direct.action.CondiLuService.getCondiLuLevel3Mgr,
		update:eRecon_web.direct.action.CondiLuService.getCondiLuLevel3Mgr_updateItems,
		destroy:eRecon_web.direct.action.CondiLuService.getCondiLuLevel3Mgr_deleteItems
    }

});
	

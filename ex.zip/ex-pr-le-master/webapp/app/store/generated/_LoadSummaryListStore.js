Ext.define('eRecon_web.store.generated._LoadSummaryListStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.LoadSummaryListModel'],
	model:'eRecon_web.model.LoadSummaryListModel',
		
	api: {
		create:eRecon_web.direct.action.LoadSummaryService.getLoadSummaryList_insertItems,
		read : eRecon_web.direct.action.LoadSummaryService.getLoadSummaryList,
		update:eRecon_web.direct.action.LoadSummaryService.getLoadSummaryList_updateItems,
		destroy:eRecon_web.direct.action.LoadSummaryService.getLoadSummaryList_deleteItems
    }

});
	

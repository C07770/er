Ext.define('eRecon_web.store.generated._SectorLobMappingStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.SectorLobMappingModel'],
	model:'eRecon_web.model.SectorLobMappingModel',
		
	api: {
		create:eRecon_web.direct.action.SectorLobMappingService.getSectorLobMapping_insertItems,
		read : eRecon_web.direct.action.SectorLobMappingService.getSectorLobMapping,
		update:eRecon_web.direct.action.SectorLobMappingService.getSectorLobMapping_updateItems,
		destroy:eRecon_web.direct.action.SectorLobMappingService.getSectorLobMapping_deleteItems
    }

});
	

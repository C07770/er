Ext.define('eRecon_web.store.generated._TransferSortByStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.TransferFilterModel'],
	model:'eRecon_web.model.TransferFilterModel',
		
	api: {
		create:eRecon_web.direct.action.TransferService.getTransferSortByValues_insertItems,
		read : eRecon_web.direct.action.TransferService.getTransferSortByValues,
		update:eRecon_web.direct.action.TransferService.getTransferSortByValues_updateItems,
		destroy:eRecon_web.direct.action.TransferService.getTransferSortByValues_deleteItems
    }

});
	

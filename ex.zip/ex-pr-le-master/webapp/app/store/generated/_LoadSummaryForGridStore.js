Ext.define('eRecon_web.store.generated._LoadSummaryForGridStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.LoadSummaryListModel'],
	model:'eRecon_web.model.LoadSummaryListModel',
		
	api: {
		create:eRecon_web.direct.action.LoadSummaryService.getLoadSummaryForGrid_insertItems,
		read : eRecon_web.direct.action.LoadSummaryService.getLoadSummaryForGrid,
		update:eRecon_web.direct.action.LoadSummaryService.getLoadSummaryForGrid_updateItems,
		destroy:eRecon_web.direct.action.LoadSummaryService.getLoadSummaryForGrid_deleteItems
    }

});
	

Ext.define('eRecon_web.store.generated._CondiLuStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.CondiLuModel'],
	model:'eRecon_web.model.CondiLuModel',
		
	api: {
		create:eRecon_web.direct.action.CondiLuService.getCondiLuDetails_insertItems,
		read : eRecon_web.direct.action.CondiLuService.getCondiLuDetails,
		update:eRecon_web.direct.action.CondiLuService.getCondiLuDetails_updateItems,
		destroy:eRecon_web.direct.action.CondiLuService.getCondiLuDetails_deleteItems
    }

});
	

Ext.define('eRecon_web.store.generated._AssignedUnAssignedStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.AssignedUnAssignedModel'],
	model:'eRecon_web.model.AssignedUnAssignedModel',
		
	api: {
		create:eRecon_web.direct.action.AssignEntitlementService.getAssignedUnAssignedValues_insertItems,
		read : eRecon_web.direct.action.AssignEntitlementService.getAssignedUnAssignedValues,
		update:eRecon_web.direct.action.AssignEntitlementService.getAssignedUnAssignedValues_updateItems,
		destroy:eRecon_web.direct.action.AssignEntitlementService.getAssignedUnAssignedValues_deleteItems
    }

});
	

Ext.define('eRecon_web.store.generated._UserRoleMappingStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.UserRoleMappingModel'],
	model:'eRecon_web.model.UserRoleMappingModel',
		
	api: {
		create:eRecon_web.direct.action.UserRoleMappingService.getUserRoleMapping_insertItems,
		read : eRecon_web.direct.action.UserRoleMappingService.getUserRoleMapping,
		update:eRecon_web.direct.action.UserRoleMappingService.getUserRoleMapping_updateItems,
		destroy:eRecon_web.direct.action.UserRoleMappingService.getUserRoleMapping_deleteItems
    }

});
	

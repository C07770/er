Ext.define('eRecon_web.store.generated._JobStatusStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.JobStatusModel'],
	model:'eRecon_web.model.JobStatusModel',
		
	api: {
		create:eRecon_web.direct.action.JobStatusService.getAllJobStatus_insertItems,
		read : eRecon_web.direct.action.JobStatusService.getAllJobStatus,
		update:eRecon_web.direct.action.JobStatusService.getAllJobStatus_updateItems,
		destroy:eRecon_web.direct.action.JobStatusService.getAllJobStatus_deleteItems
    }

});
	

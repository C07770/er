Ext.define('eRecon_web.store.generated._TransferSubmitPOStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.ManagerModel'],
	model:'eRecon_web.model.ManagerModel',
		
	api: {
		create:eRecon_web.direct.action.TransferService.getTransferSubmitProofOwnerValues_insertItems,
		read : eRecon_web.direct.action.TransferService.getTransferSubmitProofOwnerValues,
		update:eRecon_web.direct.action.TransferService.getTransferSubmitProofOwnerValues_updateItems,
		destroy:eRecon_web.direct.action.TransferService.getTransferSubmitProofOwnerValues_deleteItems
    }

});
	

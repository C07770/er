Ext.define('eRecon_web.store.generated._TransferSummaryStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.TransferSummaryModel'],
	model:'eRecon_web.model.TransferSummaryModel',
		
	api: {
		create:eRecon_web.direct.action.TransferService.getTransferSummary_insertItems,
		read : eRecon_web.direct.action.TransferService.getTransferSummary,
		update:eRecon_web.direct.action.TransferService.getTransferSummary_updateItems,
		destroy:eRecon_web.direct.action.TransferService.getTransferSummary_deleteItems
    }

});
	

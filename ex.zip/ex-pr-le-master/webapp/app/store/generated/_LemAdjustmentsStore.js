Ext.define('eRecon_web.store.generated._LemAdjustmentsStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.LemAdjustmentsModel'],
	model:'eRecon_web.model.LemAdjustmentsModel',
		
	api: {
		create:eRecon_web.direct.action.LemAdjustmentsService.getLemAdjustmentsAccounts_insertItems,
		read : eRecon_web.direct.action.LemAdjustmentsService.getLemAdjustmentsAccounts,
		update:eRecon_web.direct.action.LemAdjustmentsService.getLemAdjustmentsAccounts_updateItems,
		destroy:eRecon_web.direct.action.LemAdjustmentsService.getLemAdjustmentsAccounts_deleteItems
    }

});
	

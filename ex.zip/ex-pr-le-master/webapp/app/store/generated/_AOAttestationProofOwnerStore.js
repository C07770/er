Ext.define('eRecon_web.store.generated._AOAttestationProofOwnerStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.ManagerModel'],
	model:'eRecon_web.model.ManagerModel',
		
	api: {
		create:eRecon_web.direct.action.AOAttestationSummaryService.getAOAttestationProofOwnerValues_insertItems,
		read : eRecon_web.direct.action.AOAttestationSummaryService.getAOAttestationProofOwnerValues,
		update:eRecon_web.direct.action.AOAttestationSummaryService.getAOAttestationProofOwnerValues_updateItems,
		destroy:eRecon_web.direct.action.AOAttestationSummaryService.getAOAttestationProofOwnerValues_deleteItems
    }

});
	

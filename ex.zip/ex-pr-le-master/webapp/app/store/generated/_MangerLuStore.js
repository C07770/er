Ext.define('eRecon_web.store.generated._MangerLuStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.ManagerLuModel'],
	model:'eRecon_web.model.ManagerLuModel',
		
	api: {
		create:eRecon_web.direct.action.ManagerLuService.getManagers_insertItems,
		read : eRecon_web.direct.action.ManagerLuService.getManagers,
		update:eRecon_web.direct.action.ManagerLuService.getManagers_updateItems,
		destroy:eRecon_web.direct.action.ManagerLuService.getManagers_deleteItems
    }

});
	

Ext.define('eRecon_web.store.generated._AcctMaintenanceProofOwnerStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.DropDownModel'],
	model:'eRecon_web.model.DropDownModel',
		
	api: {
		create:eRecon_web.direct.action.AccountMaintenanceService.getProofOwner_insertItems,
		read : eRecon_web.direct.action.AccountMaintenanceService.getProofOwner,
		update:eRecon_web.direct.action.AccountMaintenanceService.getProofOwner_updateItems,
		destroy:eRecon_web.direct.action.AccountMaintenanceService.getProofOwner_deleteItems
    }

});
	

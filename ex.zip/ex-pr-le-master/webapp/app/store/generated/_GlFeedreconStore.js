Ext.define('eRecon_web.store.generated._GlFeedreconStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.ReconperiodModel'],
	model:'eRecon_web.model.ReconperiodModel',
		
	api: {
		create:eRecon_web.direct.action.GLFeedCalenderService.getReconPeriod_insertItems,
		read : eRecon_web.direct.action.GLFeedCalenderService.getReconPeriod,
		update:eRecon_web.direct.action.GLFeedCalenderService.getReconPeriod_updateItems,
		destroy:eRecon_web.direct.action.GLFeedCalenderService.getReconPeriod_deleteItems
    }

});
	

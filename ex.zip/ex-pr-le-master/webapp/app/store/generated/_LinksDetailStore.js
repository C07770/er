Ext.define('eRecon_web.store.generated._LinksDetailStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.LinksDetailModel'],
	model:'eRecon_web.model.LinksDetailModel',
		
	api: {
		create:eRecon_web.direct.action.LinksDetailService.getLinks_insertItems,
		read : eRecon_web.direct.action.LinksDetailService.getLinks,
		update:eRecon_web.direct.action.LinksDetailService.getLinks_updateItems,
		destroy:eRecon_web.direct.action.LinksDetailService.getLinks_deleteItems
    }

});
	

Ext.define('eRecon_web.store.generated._UserMaintenanceStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.UserMaintenanceModel'],
	model:'eRecon_web.model.UserMaintenanceModel',
		
	api: {
		create:eRecon_web.direct.action.UserMaintenanceService.getUsers_insertItems,
		read : eRecon_web.direct.action.UserMaintenanceService.getUsers,
		update:eRecon_web.direct.action.UserMaintenanceService.getUsers_updateItems,
		destroy:eRecon_web.direct.action.UserMaintenanceService.getUsers_deleteItems
    }

});
	

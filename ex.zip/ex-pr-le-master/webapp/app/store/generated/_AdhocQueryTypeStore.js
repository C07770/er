Ext.define('eRecon_web.store.generated._AdhocQueryTypeStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.AdhocQueryTypeModel'],
	model:'eRecon_web.model.AdhocQueryTypeModel',
		
	api: {
		create:eRecon_web.direct.action.AdhocQueryService.getQueryType_insertItems,
		read : eRecon_web.direct.action.AdhocQueryService.getQueryType,
		update:eRecon_web.direct.action.AdhocQueryService.getQueryType_updateItems,
		destroy:eRecon_web.direct.action.AdhocQueryService.getQueryType_deleteItems
    }

});
	

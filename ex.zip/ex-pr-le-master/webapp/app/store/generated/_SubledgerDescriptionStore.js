Ext.define('eRecon_web.store.generated._SubledgerDescriptionStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.LemFullkeyModel'],
	model:'eRecon_web.model.LemFullkeyModel',
		
	api: {
		create:eRecon_web.direct.action.SubledgerService.getSubledgerDescription_insertItems,
		read : eRecon_web.direct.action.SubledgerService.getSubledgerDescription,
		update:eRecon_web.direct.action.SubledgerService.getSubledgerDescription_updateItems,
		destroy:eRecon_web.direct.action.SubledgerService.getSubledgerDescription_deleteItems
    }

});
	

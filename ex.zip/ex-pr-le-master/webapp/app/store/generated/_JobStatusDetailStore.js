Ext.define('eRecon_web.store.generated._JobStatusDetailStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.JobStatusDetailModel'],
	model:'eRecon_web.model.JobStatusDetailModel',
		
	api: {
		create:eRecon_web.direct.action.JobStatusService.getAllJobStatusDetails_insertItems,
		read : eRecon_web.direct.action.JobStatusService.getAllJobStatusDetails,
		update:eRecon_web.direct.action.JobStatusService.getAllJobStatusDetails_updateItems,
		destroy:eRecon_web.direct.action.JobStatusService.getAllJobStatusDetails_deleteItems
    }

});
	

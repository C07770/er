Ext.define('eRecon_web.store.generated._FeedLoadTemplateStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.FeedLoadTemplateModel'],
	model:'eRecon_web.model.FeedLoadTemplateModel',
		
	api: {
		create:eRecon_web.direct.action.FeedLoadTemplateService.getFeedLoadTemplate_insertItems,
		read : eRecon_web.direct.action.FeedLoadTemplateService.getFeedLoadTemplate,
		update:eRecon_web.direct.action.FeedLoadTemplateService.getFeedLoadTemplate_updateItems,
		destroy:eRecon_web.direct.action.FeedLoadTemplateService.getFeedLoadTemplate_deleteItems
    }

});
	

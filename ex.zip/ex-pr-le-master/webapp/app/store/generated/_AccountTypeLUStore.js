Ext.define('eRecon_web.store.generated._AccountTypeLUStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.AccountTypeLUModel'],
	model:'eRecon_web.model.AccountTypeLUModel',
		
	api: {
		create:eRecon_web.direct.action.AccountTypeLUService.getAccountTypeLU_insertItems,
		read : eRecon_web.direct.action.AccountTypeLUService.getAccountTypeLU,
		update:eRecon_web.direct.action.AccountTypeLUService.getAccountTypeLU_updateItems,
		destroy:eRecon_web.direct.action.AccountTypeLUService.getAccountTypeLU_deleteItems
    }

});
	

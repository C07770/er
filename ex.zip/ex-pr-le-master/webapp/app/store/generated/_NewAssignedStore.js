Ext.define('eRecon_web.store.generated._NewAssignedStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.NewAssignedModel'],
	model:'eRecon_web.model.NewAssignedModel',
		
	api: {
		create:eRecon_web.direct.action.NewAssignedService.getApprovalAccounts_insertItems,
		read : eRecon_web.direct.action.NewAssignedService.getApprovalAccounts,
		update:eRecon_web.direct.action.NewAssignedService.getApprovalAccounts_updateItems,
		destroy:eRecon_web.direct.action.NewAssignedService.getApprovalAccounts_deleteItems
    }

});
	

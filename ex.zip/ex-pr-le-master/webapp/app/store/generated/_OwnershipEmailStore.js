Ext.define('eRecon_web.store.generated._OwnershipEmailStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.OwnershipEmailModel'],
	model:'eRecon_web.model.OwnershipEmailModel',
		
	api: {
		create:eRecon_web.direct.action.OwnershipAlertService.getOwnershipEmail_insertItems,
		read : eRecon_web.direct.action.OwnershipAlertService.getOwnershipEmail,
		update:eRecon_web.direct.action.OwnershipAlertService.getOwnershipEmail_updateItems,
		destroy:eRecon_web.direct.action.OwnershipAlertService.getOwnershipEmail_deleteItems
    }

});
	

Ext.define('eRecon_web.store.generated._reconStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.ReconperiodModel'],
	model:'eRecon_web.model.ReconperiodModel',
		
	api: {
		create:eRecon_web.direct.action.ExchangeRateService.getReconPeriod_insertItems,
		read : eRecon_web.direct.action.ExchangeRateService.getReconPeriod,
		update:eRecon_web.direct.action.ExchangeRateService.getReconPeriod_updateItems,
		destroy:eRecon_web.direct.action.ExchangeRateService.getReconPeriod_deleteItems
    }

});
	

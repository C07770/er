Ext.define('eRecon_web.store.TransferSubmitAOStore',{
	extend: 'eRecon_web.store.generated._TransferSubmitAOStore',
	listeners: {
	    beforeload: function(store, options) {
			var pFilter =Ext.getCmp('transferToListautocomplete').getValue();
	        store.getProxy().extraParams={
	        	0:pFilter
	        };
	    }
	}
});
	

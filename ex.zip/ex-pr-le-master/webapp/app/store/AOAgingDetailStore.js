Ext.define('eRecon_web.store.AOAgingDetailStore',{
	extend: 'eRecon_web.store.generated._AOAgingDetailStore'
});

Ext.define('eRecon_web.store.RuleStore',{
	extend: 'eRecon_web.store.generated._RuleStore',
	pageSize: 30,
	load: function(options) {
       var me = this;
       options = options || {};
       if (typeof options == 'function') {
		  options = {
		        callback: options
		  };
	   }
       options.directOptions = options.directOptions || {};
       if (!options.directOptions.priorityMode) {
	       if (me.searchCriteria) {
	    	   options.directOptions.quickSearch = me.searchCriteria.quickSearch || "";
	    	   options.directOptions.ruleId = me.searchCriteria.ruleId;
	    	   options.directOptions.ruleName = me.searchCriteria.ruleName;
			   options.directOptions.ruleRegion =	me.searchCriteria.ruleRegion;
	       }
	       else {
//		    	   options.directOptions.ruleRegion =	'ZZZZZZZZZZZZZZZ'; // to return empty
	       }
       }
	   me.callParent([options]);
	},
	
	getSearchCriteria: function() {
		var me = this;
		if (!me.searchCriteria) {
			me.searchCriteria = {};
		}
		return me.searchCriteria;
	}
});
	

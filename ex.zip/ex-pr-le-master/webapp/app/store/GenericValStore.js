Ext.define('eRecon_web.store.GenericValStore',{
	extend: 'eRecon_web.store.generated._GenericValStore',
	directOptions: {},
	load: function(options) {
	    var me = this;
	    options = options || {};
	    if (typeof options == 'function') {
			  options = {
			        callback: options
			  };
		}
	    options.directOptions = options.directOptions || {};
	    Ext.Object.merge(options.directOptions, me.directOptions);
	    if (!me.directOptions.recalcTotal) {
	    	me.directOptions.totalCount = me.getTotalCount();
	    }
	    me.callParent([options]);
	    me.directOptions.recalcTotal = false;
	}

});
	

Ext.define('eRecon_web.store.dashboard2.generated._StrategicSitePOCityChartDataStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.dashboard2.StrategicSitePOCityChartDataModel'],
	model:'eRecon_web.model.dashboard2.StrategicSitePOCityChartDataModel',
		
	api: {
		create:eRecon_web.direct.action.Dashboard2Service.getStrategicSitesPOCityChartData_insertItems,
		read : eRecon_web.direct.action.Dashboard2Service.getStrategicSitesPOCityChartData,
		update:eRecon_web.direct.action.Dashboard2Service.getStrategicSitesPOCityChartData_updateItems,
		destroy:eRecon_web.direct.action.Dashboard2Service.getStrategicSitesPOCityChartData_deleteItems
    }

});
	

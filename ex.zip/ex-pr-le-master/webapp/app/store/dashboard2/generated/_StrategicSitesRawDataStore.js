Ext.define('eRecon_web.store.dashboard2.generated._StrategicSitesRawDataStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.dashboard2.StrategicSitesRawDataModel'],
	model:'eRecon_web.model.dashboard2.StrategicSitesRawDataModel',
		
	api: {
		create:eRecon_web.direct.action.Dashboard2Service.getStrategicSitesRawData_insertItems,
		read : eRecon_web.direct.action.Dashboard2Service.getStrategicSitesRawData,
		update:eRecon_web.direct.action.Dashboard2Service.getStrategicSitesRawData_updateItems,
		destroy:eRecon_web.direct.action.Dashboard2Service.getStrategicSitesRawData_deleteItems
    }

});
	

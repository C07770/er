Ext.define('eRecon_web.store.dashboard2.generated._StrategicSiteReconPeriodsStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.dashboard2.StrategicSiteReconPeriodsModel'],
	model:'eRecon_web.model.dashboard2.StrategicSiteReconPeriodsModel',
		
	api: {
		create:eRecon_web.direct.action.Dashboard2Service.getStrategicSitesReconPeriods_insertItems,
		read : eRecon_web.direct.action.Dashboard2Service.getStrategicSitesReconPeriods,
		update:eRecon_web.direct.action.Dashboard2Service.getStrategicSitesReconPeriods_updateItems,
		destroy:eRecon_web.direct.action.Dashboard2Service.getStrategicSitesReconPeriods_deleteItems
    }

});
	

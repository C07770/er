Ext.define('eRecon_web.store.dashboard2.generated._StrategicSitesMatrixStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.dashboard2.StrategicSitesMatrixModel'],
	model:'eRecon_web.model.dashboard2.StrategicSitesMatrixModel',
		
	api: {
		create:eRecon_web.direct.action.Dashboard2Service.getStrategicSitesMatrix_insertItems,
		read : eRecon_web.direct.action.Dashboard2Service.getStrategicSitesMatrix,
		update:eRecon_web.direct.action.Dashboard2Service.getStrategicSitesMatrix_updateItems,
		destroy:eRecon_web.direct.action.Dashboard2Service.getStrategicSitesMatrix_deleteItems
    }

});
	

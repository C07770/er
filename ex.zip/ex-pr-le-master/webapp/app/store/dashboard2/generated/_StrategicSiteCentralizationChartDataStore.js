Ext.define('eRecon_web.store.dashboard2.generated._StrategicSiteCentralizationChartDataStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.dashboard2.StrategicSiteCentralizationChartDataModel'],
	model:'eRecon_web.model.dashboard2.StrategicSiteCentralizationChartDataModel',
		
	api: {
		create:eRecon_web.direct.action.Dashboard2Service.getStrategicSitesCentralizationChartData_insertItems,
		read : eRecon_web.direct.action.Dashboard2Service.getStrategicSitesCentralizationChartData,
		update:eRecon_web.direct.action.Dashboard2Service.getStrategicSitesCentralizationChartData_updateItems,
		destroy:eRecon_web.direct.action.Dashboard2Service.getStrategicSitesCentralizationChartData_deleteItems
    }

});
	

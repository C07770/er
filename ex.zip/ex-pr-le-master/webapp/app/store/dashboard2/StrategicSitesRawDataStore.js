Ext.define('eRecon_web.store.dashboard2.StrategicSitesRawDataStore',{
	extend: 'eRecon_web.store.dashboard2.generated._StrategicSitesRawDataStore',
	pageSize: 100
});
	

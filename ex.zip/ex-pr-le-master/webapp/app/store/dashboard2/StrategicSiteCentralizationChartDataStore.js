Ext.define('eRecon_web.store.dashboard2.StrategicSiteCentralizationChartDataStore',{
	extend: 'eRecon_web.store.dashboard2.generated._StrategicSiteCentralizationChartDataStore'
});
	

Ext.define('eRecon_web.store.dashboard.DetailedDataStore',{
	extend: 'eRecon_web.store.dashboard.generated._DetailedDataStore'
});


	

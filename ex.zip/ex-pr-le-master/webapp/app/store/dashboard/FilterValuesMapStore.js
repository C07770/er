Ext.define('eRecon_web.store.dashboard.FilterValuesMapStore',{
	extend: 'eRecon_web.store.dashboard.generated._FilterValuesMapStore'
});
	

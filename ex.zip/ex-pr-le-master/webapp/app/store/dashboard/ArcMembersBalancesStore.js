Ext.define('eRecon_web.store.dashboard.ArcMembersBalancesStore',{
	extend: 'eRecon_web.store.dashboard.generated._ArcMembersBalancesStore'
	, groupField: 'controllerdelegatename'
	, getGroups: function(requestGroupString) {
		var groups = this.callParent(requestGroupString);
		if (!requestGroupString) {
			var records = this.data.items;
			var	length = records.length;
			if (length > 0) {
				var totalGroup = {
				    name: 'grandTotal',
				    children: []
				}
				groups.push(totalGroup);
			}
		}
		return groups;
	}

	, aggregate: function(fn, scope, grouped, args) {
        var out = this.callParent(arguments);
        if (grouped && this.isGrouped()) {
        	out.grandTotal = fn.apply(scope || this, [this.data.items].concat(args));
        }
        return out;
     } 

});
	

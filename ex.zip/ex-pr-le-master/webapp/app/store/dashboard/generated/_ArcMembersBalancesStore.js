Ext.define('eRecon_web.store.dashboard.generated._ArcMembersBalancesStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.dashboard.ArcMembersBalancesModel'],
	model:'eRecon_web.model.dashboard.ArcMembersBalancesModel',
		
	api: {
		create:eRecon_web.direct.action.DashboardService.getArcMembersBalances_insertItems,
		read : eRecon_web.direct.action.DashboardService.getArcMembersBalances,
		update:eRecon_web.direct.action.DashboardService.getArcMembersBalances_updateItems,
		destroy:eRecon_web.direct.action.DashboardService.getArcMembersBalances_deleteItems
    }

});
	

Ext.define('eRecon_web.store.dashboard.generated._FilterValuesMapStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.dashboard.FilterValuesMapModel'],
	model:'eRecon_web.model.dashboard.FilterValuesMapModel',
		
	api: {
		create:eRecon_web.direct.action.DashboardService.getFilterValues_insertItems,
		read : eRecon_web.direct.action.DashboardService.getFilterValues,
		update:eRecon_web.direct.action.DashboardService.getFilterValues_updateItems,
		destroy:eRecon_web.direct.action.DashboardService.getFilterValues_deleteItems
    }

});
	

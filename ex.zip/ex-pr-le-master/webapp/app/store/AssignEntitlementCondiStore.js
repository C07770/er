Ext.define('eRecon_web.store.AssignEntitlementCondiStore',{
	extend: 'eRecon_web.store.generated._AssignEntitlementCondiStore',
	listeners: {
	    beforeload: function(store, options) {
			var pFilter =Ext.getCmp('entitlementAutocomplete').getValue();
	        store.getProxy().extraParams={
	        	0:pFilter
	        };
	    }
	}
});

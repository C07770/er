Ext.define('eRecon_web.store.TransferSubmitPOStore',{
	extend: 'eRecon_web.store.generated._TransferSubmitPOStore',
	listeners: {
	    beforeload: function(store, options) {
			var pFilter =Ext.getCmp('transferToListautocomplete').getValue();
	        store.getProxy().extraParams={
	        	0:pFilter
	        };
	    }
	}
});
	

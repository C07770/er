Ext.define('eRecon_web.store.BankingGroupStore',{
	extend: 'eRecon_web.store.generated._BankingGroupStore',
		
 sorters:[{
    			property:'bankingGroup',
    			direction: 'asc'
    			}
             ]
});
	

Ext.define('eRecon_web.store.RulesApprovalStore',{
	extend: 'eRecon_web.store.generated._RuleStore',
	pageSize: 30,
	load: function(options) {
		var me = this;
	    options = options || {};
	    if (typeof options == 'function') {
		  options = {
		        callback: options
		  };
	    }
	    options.directOptions = options.directOptions || {};
	    options.directOptions.approvalMode = true;
		me.callParent([options]);
	}
});
	

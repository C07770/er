Ext.define('eRecon_web.store.upload.generated._FileStore',{

	extend: 'Clear.data.DirectStore',
	requires  : ['eRecon_web.model.upload.FileModel'],
	model:'eRecon_web.model.upload.FileModel',
		
	api: {
		create:eRecon_web.direct.action.JobStatusService.getUploadHistory_insertItems,
		read : eRecon_web.direct.action.JobStatusService.getUploadHistory,
		update:eRecon_web.direct.action.JobStatusService.getUploadHistory_updateItems,
		destroy:eRecon_web.direct.action.JobStatusService.getUploadHistory_deleteItems
    }

});
	

Ext.define('eRecon_web.store.upload.FileStore',{
	extend: 'eRecon_web.store.upload.generated._FileStore'
});
	

Ext.define('eRecon_web.model.AdminOpenCloseCycleModel', {
	extend: 'eRecon_web.model.generated._AdminOpenCloseCycleModel',
	fields: [
	{
		name: 'openclosedate',
		type: Ext.data.Types.DATE,
		useNull: true,
		dateFormat: 'time'
	}
	]
});

Ext.define('eRecon_web.model.LoadSummaryListModel', {
	extend: 'eRecon_web.model.generated._LoadSummaryListModel',
	fields: [
	{
		name: 'loadEnd',
		type: Ext.data.Types.DATE,
		useNull: true,
		dateFormat: 'time'
	},
	{
		name: 'loadStart',
		type: Ext.data.Types.DATE,
		useNull: true,
		dateFormat: 'time'
	}
	]

});
	

Ext.define('eRecon_web.model.chart.AOGLBalanceChartModel', {
	extend: 'eRecon_web.model.chart.generated._AOGLBalanceChartModel'
});
	

Ext.define('eRecon_web.model.chart.AOTotalGLBalanceChartModel', {
	extend: 'eRecon_web.model.chart.generated._AOTotalGLBalanceChartModel'
});
	

Ext.define('eRecon_web.model.chart.ArcMembersPieChartModel', {
	extend: 'eRecon_web.model.chart.generated._ArcMembersPieChartModel'
});
	

Ext.define('eRecon_web.model.chart.PieChartModel', {
	extend: 'eRecon_web.model.chart.generated._PieChartModel'
});
	

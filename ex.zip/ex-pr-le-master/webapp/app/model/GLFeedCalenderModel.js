Ext.define('eRecon_web.model.GLFeedCalenderModel', {
	extend: 'eRecon_web.model.generated._GLFeedCalenderModel',
	fields: [
	{
		name: 'scheduledDate',
		type: Ext.data.Types.DATE,
		useNull: true,
		dateFormat: 'time'
	}
	]	
});

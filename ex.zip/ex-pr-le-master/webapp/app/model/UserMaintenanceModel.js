Ext.define('eRecon_web.model.UserMaintenanceModel', {
	extend: 'eRecon_web.model.generated._UserMaintenanceModel',
	fields: [
	{
		name: 'last_login_date',
		type: Ext.data.Types.DATE,
		useNull: true,
		dateFormat: 'time'
	},
	{
		name: 'locked_date',
		type: Ext.data.Types.DATE,
		useNull: true,
		dateFormat: 'time'
	}
	]	
});
	

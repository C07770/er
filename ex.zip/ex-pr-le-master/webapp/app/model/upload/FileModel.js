Ext.define('eRecon_web.model.upload.FileModel', {
	extend: 'eRecon_web.model.upload.generated._FileModel'
});
	

Ext.define('eRecon_web.model.dashboard2.StrategicSitesMatrixModel', {
	extend: 'eRecon_web.model.dashboard2.generated._StrategicSitesMatrixModel'
});
	

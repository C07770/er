Ext.define('eRecon_web.model.dashboard2.StrategicSitePOCityChartDataModel', {
	extend: 'eRecon_web.model.dashboard2.generated._StrategicSitePOCityChartDataModel'
});
	

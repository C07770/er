Ext.define('eRecon_web.model.dashboard2.StrategicSiteCentralizationChartDataModel', {
	extend: 'eRecon_web.model.dashboard2.generated._StrategicSiteCentralizationChartDataModel'
});
	

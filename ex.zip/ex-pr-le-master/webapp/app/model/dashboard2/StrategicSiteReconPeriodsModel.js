Ext.define('eRecon_web.model.dashboard2.StrategicSiteReconPeriodsModel', {
	extend: 'eRecon_web.model.dashboard2.generated._StrategicSiteReconPeriodsModel'
});
	

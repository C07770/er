Ext.define('eRecon_web.model.dashboard2.DataConverter_StrategicSiteTrendByPeriodModel', {
	extend: 'eRecon_web.model.dashboard2.generated._DataConverter_StrategicSiteTrendByPeriodModel'
});
	

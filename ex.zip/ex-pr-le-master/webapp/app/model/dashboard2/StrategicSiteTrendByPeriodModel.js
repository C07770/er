Ext.define('eRecon_web.model.dashboard2.StrategicSiteTrendByPeriodModel', {
	extend: 'eRecon_web.model.dashboard2.generated._StrategicSiteTrendByPeriodModel'
});
	

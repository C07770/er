Ext.define('eRecon_web.model.dashboard2.StrategicSiteTrendByPOCityModel', {
	extend: 'eRecon_web.model.dashboard2.generated._StrategicSiteTrendByPOCityModel'
});
	

Ext.define('eRecon_web.model.dashboard2.StrategicSitesRawDataModel', {
	extend: 'eRecon_web.model.dashboard2.generated._StrategicSitesRawDataModel'
});
	

Ext.define('eRecon_web.model.RollbackFeedsModel', {
	extend: 'eRecon_web.model.generated._RollbackFeedsModel',
	fields: [
	{
		name: 'changedate',
		type: Ext.data.Types.DATE,
		useNull: true,
		dateFormat: 'time'
	}
	]																								
});
	

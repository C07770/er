Ext.define('eRecon_web.model.dashboard.DetailedDataModel', {
	extend: 'eRecon_web.model.dashboard.generated._DetailedDataModel'
});
	

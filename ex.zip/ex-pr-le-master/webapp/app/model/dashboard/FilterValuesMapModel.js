Ext.define('eRecon_web.model.dashboard.FilterValuesMapModel', {
	extend: 'eRecon_web.model.dashboard.generated._FilterValuesMapModel'
});
	

Ext.define('eRecon_web.model.dashboard.DashboardArcInfoModel', {
	extend: 'eRecon_web.model.dashboard.generated._DashboardArcInfoModel'
});
	

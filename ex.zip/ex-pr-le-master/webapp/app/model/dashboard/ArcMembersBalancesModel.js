Ext.define('eRecon_web.model.dashboard.ArcMembersBalancesModel', {
	extend: 'eRecon_web.model.dashboard.generated._ArcMembersBalancesModel'
});
	

Ext.define('eRecon_web.model.AOAgingDetailModel', {
	extend: 'eRecon_web.model.generated._AOAgingDetailModel'
});

Ext.define('eRecon_web.model.CycleCalenderModel', {
	extend: 'eRecon_web.model.generated._CycleCalenderModel',
	fields: [
	{
		name: 'openDate',
		type: Ext.data.Types.DATE,
		useNull: true,
		dateFormat: 'time'
	},
	{
		name: 'closeDate',
		type: Ext.data.Types.DATE,
		useNull: true,
		dateFormat: 'time'
	},
	{
		name: 'hardDate',
		type: Ext.data.Types.DATE,
		useNull: true,
		dateFormat: 'time'
	}
	]	
});
	

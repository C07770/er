Ext.define('eRecon_web.model.legalVehicle.FilterValuesMapModel', {
	extend: 'eRecon_web.model.legalVehicle.generated._FilterValuesMapModel'
});
	

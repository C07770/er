Ext.define('eRecon_web.model.legalVehicle.LVReportModel', {
	extend: 'eRecon_web.model.legalVehicle.generated._LVReportModel'
});
	

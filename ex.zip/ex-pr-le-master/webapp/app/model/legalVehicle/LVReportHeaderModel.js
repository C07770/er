Ext.define('eRecon_web.model.legalVehicle.LVReportHeaderModel', {
	extend: 'eRecon_web.model.legalVehicle.generated._LVReportHeaderModel'
});
	

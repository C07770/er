Ext.define('eRecon_web.model.legalVehicle.LVFilterValuesModel', {
	extend: 'eRecon_web.model.legalVehicle.generated._LVFilterValuesModel'
});
	

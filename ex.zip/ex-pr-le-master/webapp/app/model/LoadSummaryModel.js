Ext.define('eRecon_web.model.LoadSummaryModel', {
	extend: 'eRecon_web.model.generated._LoadSummaryModel',
	fields: [
		{
			name: 'loadEnd',
			type: Ext.data.Types.DATE,
			useNull: true,
			dateFormat: 'time'
		},
		{
			name: 'loadStart',
			type: Ext.data.Types.DATE,
			useNull: true,
			dateFormat: 'time'
		}
	]
});
	

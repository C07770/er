Ext.define('eRecon_web.model.generated._AssignedUnAssignedModel', {
	extend: 'Ext.data.Model',
	requires: [
		
		'Ext.data.Types'
	],
	fields: [
		{
			name: 'userid',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'name',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'assigned',
			type: Ext.data.Types.STRING,
			useNull: true
		}
	]
});
	

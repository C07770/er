Ext.define('eRecon_web.model.generated._AdminOpenCloseCycleModel', {
	extend: 'Ext.data.Model',
	requires: [
		
		'Ext.data.Types'
	],
	fields: [
		{
			name: 'reconPeriod',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'businessUnit',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'open',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'openclosedate',
			type: Ext.data.Types.DATE,
			useNull: true
		},
		{
			name: 'activeFlag',
			type: Ext.data.Types.STRING,
			useNull: true
		}
	]
});
	

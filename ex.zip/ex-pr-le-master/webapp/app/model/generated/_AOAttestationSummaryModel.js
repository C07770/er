Ext.define('eRecon_web.model.generated._AOAttestationSummaryModel', {
	extend: 'Ext.data.Model',
	requires: [
		
		'Ext.data.Types'
	],
	fields: [
		{
			name: 'totalAcctCnt',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'agreedCnt',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'disagreedCnt',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'unreviewedCnt',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'acctsubmittedCnt',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'acctunsubmittedCnt',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'attestedCnt',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'unattestedCnt',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'viewAll',
			type: Ext.data.Types.STRING,
			useNull: true
		}
	]
});
	

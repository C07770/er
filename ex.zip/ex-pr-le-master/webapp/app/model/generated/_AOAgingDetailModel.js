Ext.define('eRecon_web.model.generated._AOAgingDetailModel', {
    extend: 'Ext.data.Model',
    requires: [

        'Ext.data.Types'
    ],
    fields: [
        {
            name: 'AGING_TYPE',
            type: Ext.data.Types.STRING,
            useNull: true
        },
        {
            name: 'ACCOUNT_ID',
            type: Ext.data.Types.STRING,
            useNull: true
        },
        {
            name: 'GLBALANCE',
            type: Ext.data.Types.STRING,
            useNull: true
        },
        {
            name: 'SLBALANCE',
            type: Ext.data.Types.STRING,
            useNull: true
        },
        {
            name: 'BENCHMARKVIOLATION',
            type: Ext.data.Types.STRING,
            useNull: true
        },
        {
            name: 'AGING_BENCHMARK',
            type: Ext.data.Types.STRING,
            useNull: true
        },
        {
            name: 'COMMENTS',
            type: Ext.data.Types.STRING,
            useNull: true
        },
        {
            name: 'QTYLT7DR',
            type: Ext.data.Types.STRING,
            useNull: true
        },
        {
            name: 'AMTLT7DR',
            type: Ext.data.Types.STRING,
            useNull: true
        },
        {
            name: 'QTYLT7CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
        ,
        {
            name: 'AMTLT7CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
        ,
        {
            name: 'QTY8_30DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
        ,
        {
            name: 'AMT8_30DR',
            type: Ext.data.Types.NUMBER,
            useNull: true
        }
         ,
        {
            name: 'QTY8_30CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT8_30CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'QTY31_60DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT31_60DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'QTY31_60CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT31_60CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'QTY61_90DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT61_90DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'QTY61_90CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT61_90CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'QTY91_120DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT91_120DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'QTY91_120CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT91_120CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'QTY121_150DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT121_150DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'QTY121_150CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT121_150CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'QTY151_180DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT151_180DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'QTY151_180CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT151_180CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'QTYGT181DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMTGT181DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'QTYGT181CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMTGT181CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMTUNKNOWNDR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMTUNKNOWNCR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'SPECIFICAMTATRISKDR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'SPECIFICAMTATRISKCR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'CONTROLTOTAL',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'FULLKEY',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMTGROSSUNKNOWNDR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'QTYGROSSUNKNOWNDR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMTGROSSUNKNOWNCR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'QTYGROSSUNKNOWNCR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'LCL_CCY_THRESHOLD',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'ACCT_AGING_TYPE',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT_SYS_RED_DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT_SYS_RED_CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT_USER_RED_DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT_USER_RED_CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT_TOT_RED_DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT_TOT_RED_CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT_RPTL_RED_DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT_RPTL_RED_CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT_AT_RISK_RPTL_DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT_AT_RISK_RPTL_CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT_AT_RISK_TYPE_CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT_AT_RISK_TYPE_DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT_GTBM_CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AMT_GTBM_DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'QTY_GTBM_DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'QTY_GTBM_CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'STATUSINDICATOR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'BENCHMARK_DESCRIPTION',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'CCYCODE',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
         {
             name: 'CONDI',
             type: Ext.data.Types.STRING,
             useNull: true
         }
          ,
        {
            name: 'RECON_BREAK_BM',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'LEM_RED_ADJ_CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'LEM_RED_ADJ_DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'ADJUST_USER_RED_CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'ADJUST_USER_RED_DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'AO_COMMENTS',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'LEM_COMMENTS',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'LEM_AMT_AT_RISK_ADJ_CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'LEM_AMT_AT_RISK_ADJ_DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'ADJUST_AMOUNT_AT_RISK_CR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'ADJUST_AMOUNT_AT_RISK_DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'LEM_RESERVE_ADJUST',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         ,
        {
            name: 'ADJUST_RESERVE',
            type: Ext.data.Types.STRING,
            useNull: true
        }
        ,
        {
            name: 'AMT_AT_RISK_RESERVE_DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
        ,
        {
            name: 'AMT_AT_RISK_TARGET_DT_DR',
            type: Ext.data.Types.STRING,
            useNull: true
        }
         
    ]
});
	

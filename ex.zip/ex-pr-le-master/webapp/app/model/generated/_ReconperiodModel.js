Ext.define('eRecon_web.model.generated._ReconperiodModel', {
	extend: 'Ext.data.Model',
	requires: [
		'Ext.data.Types'
	],
	fields: [
		{
			name: 'key',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'value',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'flag',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'reconPeriod',
			type: Ext.data.Types.STRING,
			useNull: true
		}
	]
});

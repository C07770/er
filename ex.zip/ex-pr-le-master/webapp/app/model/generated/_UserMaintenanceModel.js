Ext.define('eRecon_web.model.generated._UserMaintenanceModel', {
	extend: 'Ext.data.Model',
	requires: [
		
		'Ext.data.Types'
	],
	fields: [
		{
			name: 'userid',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'firstName',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'lastName',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'active',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'address',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'city',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'state',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'email',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'country',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'zipcode',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'menu_grp',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'change_dt',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'change_by',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'change_type',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'last_login_date',
			type: Ext.data.Types.DATE,
			useNull: true
		}
		,
		{
			name: 'locked_date',
			type: Ext.data.Types.DATE,
			useNull: true
		},
		{
			name: 'bouser',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'hu_id',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'action',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'region',
			type: Ext.data.Types.STRING,
			useNull: true
		}
	]
});
	

Ext.define('eRecon_web.model.generated._GLFeedCalenderModel', {
	extend: 'Ext.data.Model',
	requires: [
		
		'Ext.data.Types'
	],
	fields: [
		{
			name: 'reconPeriod',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'scheduledDate',
			type: Ext.data.Types.DATE,
			useNull: true
		},
		{
			name: 'businessDay',
			type: Ext.data.Types.STRING,
			useNull: true
		}
	]
});
	

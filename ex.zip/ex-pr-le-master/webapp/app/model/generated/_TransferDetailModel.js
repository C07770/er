Ext.define('eRecon_web.model.generated._TransferDetailModel', {
	extend: 'Ext.data.Model',
	requires: [
		
		'Ext.data.Types'
	],
	fields: [
		{
			name: 'fullKey',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'description',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'benchmark',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'glBalance',
			type: Ext.data.Types.NUMBER,
			useNull: true
		},
		{
			name: 'comments',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'acct_Owner',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'mgruserid',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'transfer_to_acct_owner_id',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'transfertouserid',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'benchmarkViolation',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'status_Code',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'transfererrormsg',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'transfer',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		
	]
});
	

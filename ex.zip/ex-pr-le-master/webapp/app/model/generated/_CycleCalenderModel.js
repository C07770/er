Ext.define('eRecon_web.model.generated._CycleCalenderModel', {
	extend: 'Ext.data.Model',
	requires: [
		
		'Ext.data.Types'
	],
	fields: [
		{
			name: 'reconPeriod',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'openDate',
			type: Ext.data.Types.DATE,
			useNull: true
		},
		{
			name: 'closeDate',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'active_flag',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'change_type',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'change_by',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'change_dt',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'hardDate',
			type: Ext.data.Types.DATE,
			useNull: true
		},
		{
			name: 'action',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		
	]
});
	

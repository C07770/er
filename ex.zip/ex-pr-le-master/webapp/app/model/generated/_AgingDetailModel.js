Ext.define('eRecon_web.model.generated._AgingDetailModel', {
    extend: 'Ext.data.Model',
    requires: [

        'Ext.data.Types'
    ],
    fields: [
        {
            name: 'QTYLT7DR',
            type: Ext.data.Types.NUMBER,
            useNull: true
        },
        {
            name: 'AMTLT7DR',
            type: Ext.data.Types.NUMBER,
            useNull: true
        },
        {
            name: 'QTYLT7CR',
            type: Ext.data.Types.NUMBER,
            useNull: true
        }
        ,
        {
            name: 'AMTLT7CR',
            type: Ext.data.Types.NUMBER,
            useNull: true
        }
        ,
        {
            name: 'QTY8_30DR',
            type: Ext.data.Types.NUMBER,
            useNull: true
        }
        ,
        {
            name: 'AMT8_30DR',
            type: Ext.data.Types.NUMBER,
            useNull: true
        }
         ,
        {
            name: 'QTY8_30CR',
            type: Ext.data.Types.NUMBER,
            useNull: true
        }
         ,
        {
            name: 'AMT8_30CR',
            type: Ext.data.Types.NUMBER,
            useNull: true
        }
    ]
});
	

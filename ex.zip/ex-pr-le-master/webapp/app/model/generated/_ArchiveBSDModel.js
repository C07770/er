Ext.define('eRecon_web.model.generated._ArchiveBSDModel', {
	extend: 'Ext.data.Model',
	requires: [
		
		'Ext.data.Types'
	],
	fields: [
		{
			name: 'businessUnit',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'assigned',
			type: Ext.data.Types.STRING,
			useNull: true
		}
	]
});
	

Ext.define('eRecon_web.model.generated._NewsLetterModel', {
	extend: 'Ext.data.Model',
	requires: [
		
		'Ext.data.Types'
	],
	fields: [
		{
			name: 'fileName',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'lastModified',
			type: Ext.data.Types.STRING,
			useNull: true
		}
	]
});
	

Ext.define('eRecon_web.model.generated._LinksLuModel', {
	extend: 'Ext.data.Model',
	requires: [
		
		'Ext.data.Types'
	],
	fields: [
		{
			name: 'linkId',
			type: Ext.data.Types.NUMBER,
			useNull: true
		},
		{
			name: 'linktxt',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'linkType',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'activeFlag',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'linkUrl',
			type: Ext.data.Types.STRING,
			useNull: true
		}
	]
});
	

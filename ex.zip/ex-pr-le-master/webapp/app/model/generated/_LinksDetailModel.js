Ext.define('eRecon_web.model.generated._LinksDetailModel', {
	extend: 'Ext.data.Model',
	requires: [
		
		'Ext.data.Types'
	],
	fields: [
		{
			name: 'link_url',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'link_txt',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'content_type',
			type: Ext.data.Types.STRING,
			useNull: true
		}
	]
});
	

Ext.define('eRecon_web.model.generated._FeedLoadTemplateModel', {
	extend: 'Ext.data.Model',
	requires: [
		
		'Ext.data.Types'
	],
	fields: [
		{
			name: 'profile_id',
			type: Ext.data.Types.NUMBER,
			useNull: true
		},
		{
			name: 'template_id',
			type: Ext.data.Types.NUMBER,
			useNull: true
		},
		{
			name: 'template_name',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'header',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'targetTable',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'preProcessor',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'postProcessor',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'activeFlag',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		
	]
});
	

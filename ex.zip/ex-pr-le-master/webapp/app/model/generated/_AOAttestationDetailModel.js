Ext.define('eRecon_web.model.generated._AOAttestationDetailModel', {
	extend: 'Ext.data.Model',
	requires: [
		
		'Ext.data.Types'
	],
	fields: [
		{
			name: 'status_code',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'comments',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'aging_type',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'statusindicator',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'ccycode',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'amt_rptl_red_dr',
			type: Ext.data.Types.NUMBER,
			useNull: true
		},
		{
			name: 'amt_rptl_red_cr',
			type: Ext.data.Types.NUMBER,
			useNull: true
		},
		{
			name: 'adjusted_amt_at_risk_dr',
			type: Ext.data.Types.NUMBER,
			useNull: true
		},
		{
			name: 'adjusted_amt_at_risk_cr',
			type: Ext.data.Types.NUMBER,
			useNull: true
		},
		{
			name: 'fullkey',
			type: Ext.data.Types.STRING,
			useNull: true
		},
		{
			name: 'description',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'acct_id',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'glbalance',
			type: Ext.data.Types.NUMBER,
			useNull: true
		}
		,
		{
			name: 'slbalance',
			type: Ext.data.Types.NUMBER,
			useNull: true
		}
		,
		{
			name: 'acct_aging_type',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'businessunit',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'mgruserid',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'reconperiod',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'disagreed_comments',
			type: Ext.data.Types.STRING
			
		}
		,
		{
			name: 'agreed_flag',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'account_id',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'attested_flag',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'account',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'agree',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'disagree',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'unreviewed',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		/*,
		{
			name: 'rnum',
			type: Ext.data.Types.STRING,
			useNull: true
		}*/
		
		
	]
});
	

Ext.define('eRecon_web.model.generated._DropDownModel', {
	extend: 'Ext.data.Model',
	requires: [
		'Ext.data.Types'
	],
	fields: [
		{
			name: 'key',
			type: Ext.data.Types.STRING,
			useNull: true
		}
		,
		{
			name: 'value',
			type: Ext.data.Types.STRING,
			useNull: true
		}
	]
});

/**
@author : ss58446 - Sunil Murthy
@Created Date : Mar 20, 2013 
**/
Ext.define('eRecon_web.common.CustomCreditNumericField', {
    extend:'Ext.form.field.Number',
    alias: 'widget.customCreditNumericField',
    fieldStyle: 'text-align:right',
    decimalPrecision : 2,

    initComponent: function() {
        var me = this,
            allowed;

        me.callParent();

        me.setMinValue(me.minValue);
        me.setMaxValue(me.maxValue);

        // Build regexes for masking and stripping based on the configured options
        if (me.disableKeyFilter !== true) {
            allowed = me.baseChars + '';
            if (me.allowDecimals) {
                allowed += me.decimalSeparator;
            }
            if (me.minValue < 0) {
                allowed += '-';
            }
            allowed = Ext.String.escapeRegex(allowed);
            me.maskRe = new RegExp('[' + allowed + ']');
            if (me.autoStripChars) {
                me.stripCharsRe = new RegExp('[^' + allowed + ']', 'gi');
            }
        }
    },
    getErrors: function(value) {
        var me = this,
            errors = [],
            format = Ext.String.format,
            num;
        
        value = Ext.isDefined(value) ? value : this.getRawValue();

        if (value.length < 1) { // if it's blank and textfield didn't flag it then it's valid
             return errors;
        }

        value = String(value).replace(me.decimalSeparator, '.');
        
        value = String(value).replace(new RegExp('[-]', 'g'), '');
		value = String(value).replace(new RegExp('[,]', 'g'), '');
		value = String(value).replace(new RegExp('[(]', 'g'), '');
		value = String(value).replace(new RegExp('[)]', 'g'), '');

        if(isNaN(value)){
            errors.push(format(me.nanText, value));
        }

        num = me.parseValue(value);

        if (me.minValue === 0 && num < 0) {
            errors.push(this.negativeText);
        }
        else if (num < me.minValue) {
            errors.push(format(me.minText, me.minValue));
        }

        /*if (num > me.maxValue) {
            errors.push(format(me.maxText, me.maxValue));
        }*/


        return errors;
    },

    rawToValue: function(rawValue) {
		if (!this.isValid()) {
			return rawValue;
		}
        var value = this.getRawValue();
		if(value === '' || value === null || value === undefined) {
			return null;
		}
		else{
			value= value.toString();
	    }
		if(value.indexOf("(") >= 0) {
        	return value;
        }
		value = value.replace(new RegExp('[,]', 'g'), '');
		newValue = Ext.util.Format.number(value, '0,000.00/i');
		newValue = newValue.replace(new RegExp('[-]', 'g'), '');
		
		//Fix for issue 33585-142 
		if(newValue != '0' && newValue != '0.00')
			{
				newValue = '(' + newValue + ')';
			}
		
		
		return newValue;
    },

    valueToRaw: function(value) {
    	var me = this,
            decimalSeparator = me.decimalSeparator;
    	
    	if (!me.isValid()) {
			return value;
    	}

		if(value == null || value == undefined) {
			return '';
		}
		value = String(value).replace(new RegExp('[-]', 'g'), '');
		value = String(value).replace(new RegExp('[,]', 'g'), '');
		value = String(value).replace(new RegExp('[(]', 'g'), '');
		value = String(value).replace(new RegExp('[)]', 'g'), '');
		value = String(value).replace(decimalSeparator, '.');
		
		num = me.parseValue(value);
		num = me.fixPrecision(num);
		num = isNaN(num) ? '' : num;
		
		return num * -1;
    },
    
    getSubmitValue: function() {
    	var me = this;
        var value = me.callParent();
    	if (!me.isValid()) {
    		return '';
    	}
    	return this.valueToRaw(value) * 1;
    },

    onChange: function() {
        this.callParent(arguments);
    },

    // private
    parseValue : function(value) {
        value = parseFloat(String(value).replace(this.decimalSeparator, '.'));
        return isNaN(value) ? null : value;
    },

    beforeBlur : function() {
        var me = this,
            v = me.parseValue(me.getRawValue());

        if (!Ext.isEmpty(v)) {
            me.setValue(v);
        }
    },
    onBlur: function(){
    	if(this.getRawValue() != null && this.getRawValue() !== '') {
    		this.setRawValue(this.rawToValue(this.getRawValue()));
    	}
	},
	onFocus: function() {
		if(this.getRawValue() != null && this.getRawValue() !== '') {
			this.setRawValue(this.valueToRaw(this.getRawValue()));
		}
	}

});

Ext.define('eRecon_web.common.FilterCrumb', {
	extend:"Ext.view.View"
	,alias:"widget.filtercrumb"
	,border:false
	,layout:"fit"
	,autoScroll:false
    ,initComponent: function() {
    	//this.itemSelector = "li.x-superboxselect-item";
    	this.tpl = new Ext.XTemplate(
			'<div class="x-superboxselect x-superboxselect-display-btns">',
			'<ul>',
			'<tpl for=".">',
			'<li class="x-superboxselect-item"{labelValue}">',
			'<font style="font-family:tahoma;font-size:12px;"><b>{labelCategory}</b>&nbsp;{labelValue}</font>',
			//'<a class="x-superboxselect-item-close" href="#"></a>',
			'</li>',
			'</tpl>',
			'</ul>',
			'</div>'
    	);
    	this.store = Ext.create("Ext.data.JsonStore", {
    		data:[]
    		,fields:["labelCategory","labelValue","filterParam","filterValue"]
    		,proxy: {
    			type:"memory"
    			,reader:{
    				type:"json"
    			}
    		}
    	});
    	this.listeners = {
    		"scope":this
    		,"itemclick":function(o_, rec_, el_, index_, ev_) {
    			if (ev_.target.className == 'x-superboxselect-item-close') {
    				this.removeFilter(rec_);
    			}
    		}
    	};
    	this.callParent(arguments);
	}
    
	,addFilter: function(o_) {
		var rec_ = this.getStore().findRecord("filterValue",o_.filterValue);
		if(!Ext.isEmpty(rec_)) {
			this.getStore().remove(rec_);
		}
		this.getStore().loadRawData(o_, true);
		this.fireEvent("addfilter", o_);
	}
	
	,removeFilter: function(o_) {
		this.getStore().removeAll();			
	 },
	 filtersExists:function(o_){
		 if(this.getStore().data.length>0){
			 return true;
		 }else{
			 return false;
		 }
	 }
});

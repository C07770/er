Ext.define('eRecon_web.common.Constants', {
    //extend: 'Object', 
    constructor: function (config) {
        // Paths
        this.URL_SERVER_BASE = "";//../eRecon_web";
        this.URL_IBATIS_SERVER_BASE = "getJSONResponse.jrs";
        this.URL_MARKETPLACE_CHROMEFRAME = "https://cmp.nj.ssmb.com/marketplace/control/product/~productId=47268_326725_GLOBAL";
        this.URL_STATE_SAVE = this.URL_SERVER_BASE + "ViewState.action?action=save";

        this.URL_ERECON_METADATA = this.URL_SERVER_BASE + "metadata.json";
//        this.URL_ERECON_METADATA = this.URL_SERVER_BASE + "stubbed/metadata.json";
        this.CHECK_USER_CRED_URL = this.URL_SERVER_BASE + "checkUserCredentials";

        // Subledger Input
        this.SUBLEDGER_SUMMARY_TITLE = "Subledger Input";
        this.SUBLEDGER_DETAIL_TITLE = "Subledger Detail";
        this.SUBLEDGER_DETAIL_PAGE_SIZE = 50;
        this.URL_SUBLEDGER_SUMMARY_GRID = "stubbed/subledger/summary.json";
        this.URL_SUBLEDGER_DETAIL_GRID = "stubbed/subledger/detail.json";
        this.URL_SUBLEDGER_FILTER_GETMANAGERIDS = "stubbed/subledger/filter_getmanagerids.json";

        this.TRANSFER_SUMMARY_TITLE = "Transfer Summary";
        this.TRANSFER_DETAIL_TITLE = "Transfer Detail";
        this.LEMADJUSTMENTS_TITLE = "Controller Delegate Summary";
        this.LEMADJUSTMENTSPOPUP_TITLE = "Controller Delegate Adjustments Page";
        //TODO
        this.URL_FILEDOWNLOADACTION = this.URL_SERVER_BASE + "filedownload?scheduleId=";
        // this.URL_CHART_COLUMN = this.URL_SERVER_BASE+"/"+this.URL_IBATIS_SERVER_BASE+"?jsonPageId=getArrivalTimeForPast_N_Days";

        //OWNERSHIP ALERT
        this.OWNERSHIP_ALERT_TITLE = "OWNERSHIP ALERT VIEW";
        this.OWNERSHIP_EMAIL_TITLE = "EMAIL DETAILS";
        
        this.callParent(arguments);
    }/*, slaColorMap: {"NONE": "#cccccc", "-NA-": "#cccccc", "Within SLA": "#ADE825", "SLA Breach": "#EB191C", "SLA Warning": "#FFFF00"}, slaColorRenderer: function (val_, meta_, rec_, col_, store_, view_) {
     meta_.style = "background-color:" + Portal.common.Constants.prototype.slaColorMap[val_] + ";";
     return val_;
     },*/, statusColorMap: {
        0: {label: "Status unknown", color: "#76766e" },
        1: {label: "Upload Complete", color: "#F5B800"}, //245-184-00
        10: {label: "Talend Job Started", color: "#DCF500"}, //220-245-00
        11: {label: "Talend Job Complete", color: "#ADE825"}, //235-240-30
        12: {label: "Talend Error", color: "#FF0000"} //173-232-37
    },
    statusColorRenderer: function (val_, meta_, rec_, col_, store_, view_) {
        var lbl = eRecon_web.common.Constants.prototype.statusColorMap[val_].label;
        // TODO
        if (rec_.data.XLSERRORS) {
            meta_.style = "background-color:#FF0000;";
            lbl = +" <img src='/static/assets/famfamfam/icons/cross.png' style='width:12px;height:12px;' data-qtip='Rejected'>";
        }
        // TODO
        else if (rec_.data.ETLERRORS) {
            meta_.style = "background-color:#FF0000;";
            lbl = +" <img src='/static/assets/famfamfam/icons/error.png' style='width:12px;height:12px;' data-qtip='Processing Errors'>";
        }
        else {
            meta_.style = "background-color:" + eRecon_web.common.Constants.prototype.statusColorMap[val_].color + ";";
        }

        return lbl;
    }, statusColumnRenderer: function(value) {
    	switch(value)
    	{
    	case 'U':
    		return 'Saved'
    		break;
    	case 'S':
    		return 'Queued'
    		break;
    	case 'C':
    		return 'Completed'
    		break;
    	case 'R':
    		return 'Running'
    		break;
    	case 'F':
    		return 'Failed'
    		break;
    	case 'X': 
    		return 'Exception'
    		break;
    	default:
    		return value;
    	}
    }, toolTipRenderer : function (value, meta, record) {
    	if(value === null || value ==='') {
			return '';
		}
        var max = 15;
        meta.tdAttr = 'data-qtip="' + value + '"';
        return value.length < max ? value : value.substring(0, max - 3) + '...';
    }, doubleValueRenderer: function(value) {
    		if(value === null || value ==='') {
    			return '';
    		} 
    		
    		return Ext.util.Format.number(value, '0,000.00');
    },
    	trim: function(value){
	    	if(value === null || value ==='') {
				return '';
			} 
	    	return value.replace(/^\s+|\s+$/g,'');
    },doubleValueRound:function(value){    	
    	if(value === null || value ==='') {
			return '';
		} 
    	
    	var parts = value.split('.');
    	parts[0]=parts[0].replace(/\B(?=(\d{3})+(?!\d))/g,",");
    	return parts.join(".");
    }
});

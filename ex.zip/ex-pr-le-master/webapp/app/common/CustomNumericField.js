/**
@author : as19415 - Akashi
@Created Date : May 15, 2013 
**/
Ext.define('eRecon_web.common.CustomNumericField', {
    extend:'Ext.form.field.Number',
    alias: 'widget.customNumericField',
    fieldStyle: 'text-align:right',
    hideTrigger:true,
    decimalPrecision : 2,

    initComponent: function() {
        var me = this,
            allowed;

        me.callParent();

        me.setMinValue(me.minValue);
        me.setMaxValue(me.maxValue);

        // Build regexes for masking and stripping based on the configured options
        if (me.disableKeyFilter !== true) {
            allowed = me.baseChars + '';
            if (me.allowDecimals) {
                allowed += me.decimalSeparator;
            }
            if (me.minValue < 0) {
                allowed += '-';
            }
            allowed = Ext.String.escapeRegex(allowed);
            me.maskRe = new RegExp('[' + allowed + ']');
            if (me.autoStripChars) {
                me.stripCharsRe = new RegExp('[^' + allowed + ']', 'gi');
            }
        }
    },
    getErrors: function(value) {
        var me = this,
            errors = [],
            format = Ext.String.format,
            num;
        
        value = Ext.isDefined(value) ? value : this.getRawValue();

        if (value.length < 1) { // if it's blank and textfield didn't flag it then it's valid
             return errors;
        }

        value = String(value).replace(me.decimalSeparator, '.');
        
        value = String(value).replace(new RegExp('[-]', 'g'), '');
		value = String(value).replace(new RegExp('[,]', 'g'), '');
		value = String(value).replace(new RegExp('[(]', 'g'), '');
		value = String(value).replace(new RegExp('[)]', 'g'), '');

//        if(isNaN(value)){
//            errors.push(format(me.nanText, value));
//        }

        num = me.parseValue(value);

        if (me.minValue === 0 && num < 0) {
            errors.push(this.negativeText);
        }
        else if (num < me.minValue) {
            errors.push(format(me.minText, me.minValue));
        }

        /*if (num > me.maxValue) {
            errors.push(format(me.maxText, me.maxValue));
        }*/


        return errors;
    },

    rawToValue: function(rawValue) {
        value = this.getRawValue();
        
        
		if(value === '' || value === null || value === undefined) {
			this.setFieldStyle('background-color:White;background-image:none');
			return null;
		}
		else{
			value= value.toString();
	    }
		if(value.indexOf(",") >= 0 || value.indexOf("(") >= 0) {
        	return value;
        }
		newValue = Ext.util.Format.number(value, '0,000.00/i');
		newValue = newValue.replace(new RegExp('[-]', 'g'), '');
		if(parseFloat(value) < 0){
			if(newValue != ""){
				newValue = '(' + newValue + ')';
			}
			else {
				newValue = 0;
			}
			
		}
//		if(parseFloat(value) == 0)
//			{
//				newValue = Ext.util.Format.number(0, '0,000.00/i');
//			}
		return newValue;
    },

    valueToRaw: function(value) {
    	var me = this,
        decimalSeparator = me.decimalSeparator;
    	
		if(value == null || value == undefined) {
			return '';
		}
		else{
			value= value.toString();
	    }
		var negativeValue;
		if((value.indexOf("-") >= 0) || (value.indexOf("(") >= 0)){
			negativeValue = true;
			if(value.indexOf("-") > 0 || (value.match(/-/g) != null && value.match(/-/g).length > 1)){
				this.setFieldStyle('background-color:Red;background-image:none');
				return value;
			}
			else
				{
					if(!this.readOnly)
					this.setFieldStyle('background-color:White;background-image:none');
				}
		}
		value = String(value).replace(new RegExp('[-]', 'g'), '');
		value = String(value).replace(new RegExp('[,]', 'g'), '');
		value = String(value).replace(new RegExp('[(]', 'g'), '');
		value = String(value).replace(new RegExp('[)]', 'g'), '');
		value = String(value).replace(decimalSeparator, '.');
		
		num = me.parseValue(value);
		num = me.fixPrecision(num);
//		num = isNaN(num) ? '' : num;
		if(negativeValue == true){
			return num * -1;
		}
		else{
			return num * 1;
		}
    },
    
    getSubmitValue: function() {
    	var me = this,
        value = me.callParent();
    	return this.valueToRaw(value) * 1;
    },

    onChange: function() {
        this.callParent(arguments);
    },

    // private
    parseValue : function(value) {
        value = parseFloat(String(value).replace(this.decimalSeparator, '.'));
//        return isNaN(value) ? null : value;
          return value;
    },

    beforeBlur : function() {
        var me = this,
            v = me.parseValue(me.getRawValue());

        if (!Ext.isEmpty(v)) {
            me.setValue(v);
        }
    },
    onBlur: function(){
    	if(this.getRawValue() != null && this.getRawValue() !== '') {
    		this.setRawValue(this.rawToValue(this.getRawValue()));
    	}
	},
	onFocus: function() {
		if(this.getRawValue() != null && this.getRawValue() !== '') {
			this.setRawValue(this.valueToRaw(this.getRawValue()));
		}
	}

});

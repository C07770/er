Ext.define('eRecon_web.common.ExportToExcelStatusPopup', {
    extend: "Ext.window.Window",
    alias: "widget.exporttoexcelstatuspopup",
    title: "Preparing Excel file for download",
    modal: true,
	bodyStyle: {
	    background: '#ffffff'
//	    , padding: '20px'
	},
    width: 300, height: 150,
    layout: 'fit',
    items: [
    {
    	xtype: 'container',
    	searchId: 'progressBarContainer',
    	items: [
	    {
	    	xtype: 'progressbar',
	    	hidden: true,
	    	margin: 20
	    }
    	]
    }
    ],
    
	dockedItems: [
	{
		xtype: 'toolbar',
		dock: 'bottom',
		items: [
		{
			xtype: 'button',
			text: 'Cancel',
			iconCls: 'iconCancel',
			handler: function(btn) {
				btn.up('window').close();
			}
		}
		]
	}    
	],
	
	updateProgress: function() {
		var me = this;
		if (me.isClosed) {
			return;
		}
		eRecon_web.direct.action.CommonOpsService.exportToExcelProgress(me.uuid,
			function(cnt, response) {
				if (!cnt && cnt != 0) {
					//document.getElementById('downloadDocumentIFrame').src = 'MaintainScreenExcelDownload?exportToExcel='+me.uuid;
					window.open('MaintainScreenExcelDownload?exportToExcel='+me.uuid, '_blank');
					me.close();
				}
				else {
					if (cnt && me.totalRecords) {
						me.down('progressbar').setVisible(true);
						var frac = cnt / me.totalRecords;
						me.down('[searchId=progressBarContainer]').setLoading(false);
						me.down('progressbar').updateProgress(frac,cnt + " of " + me.totalRecords);
					}
					Ext.defer(function(){
						me.updateProgress();
					}, 2000);
				}
			}
		);
	},
	
	launchExport: function(storeName, totalRecords, storeParams, extraParams) {
		var me = this;
		if (totalRecords > 100000) {
			Ext.Msg.alert("Error", "The data size exceeds 100,000 records. Please apply filters to reduce the data size");
			me.destroy();
			return;
		}
		me.show();
		eRecon_web.direct.action.CommonOpsService.getUUID(
			function(uuid, response) {
				me.uuid = uuid;
				me.totalRecords = totalRecords;				
				var store = Ext.create(storeName, storeParams||{});				
				store.api.read=eRecon_web.direct.action.AccountOwnerLuService.getAccountOwners;				
				if (extraParams != undefined) {
					store.getProxy().extraParams = extraParams;					
				}
				
				store.load({
					directOptions: {exportToExcel: true, uuid: uuid, blah:false}
				});
				me.down('[searchId=progressBarContainer]').setLoading(true);
				Ext.defer(function(){
					me.updateProgress();
				}, 2000);
			}
		);

	},

	listeners: {
		close: function() {
			this.isClosed = true;
		}
	}

});

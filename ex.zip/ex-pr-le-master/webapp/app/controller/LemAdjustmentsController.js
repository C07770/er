Ext.define('eRecon_web.controller.LemAdjustmentsController',{
	extend: 'Ext.app.Controller',
	stores:	['eRecon_web.store.LemAdjustmentsStore','eRecon_web.store.LemFullkeyStore'], 
	views:['aoattestation.aoaging.Container', 'eRecon_web.view.common.AOCustomDialog'],
	refs: [{
		ref: 'detailGrid',
		selector: 'lemadjustments_detailgrid'
	},
	{
		ref: 'filterForm',
		selector: 'lemadjustments_filterform'
	},
	{
		ref: 'popupForm',
		selector: 'lemadjustmentspopup_container'
	},
	{
		ref: 'lemBalanceAgingContainer',
		selector: 'lemAdjustmentsBalanceAging_Container'
	},
	{
		ref: 'lemReconBreakAgingContainer',
		selector: 'lemAdjustmentsReconBreakAging_Container'
	},
	{
		ref: 'lemAdjustmentsDetails',
		selector: 'lemAdjustmentsDetails_container'
	},
	{
		ref: 'lemAdjustmentsAgingContainer',
		selector:'lemAdjustmentsAging_container'
	},
	{
		ref:'customWindow',
		selector:'lem_custom_dialog'
	},
	{
		ref:'lemAdjustmentsRiskContainer',
		selector:'lemAdjustmentsRisk_Container'
	}
	],


	init: function(){
		var me = this;
		this.control({			
			'lemadjustments_filterform button[action=search]': {
				click: this.lemAdjustmentsFilter
			},
			'lemadjustments_filterform button[action=clear]': {
				click: this.clearFilterSettings
			},
			'lemadjustmentspopup_container button[action=submit]': {
				click: this.lemSubmitAdjustments
			},            
			'lemAdjustmentsBalanceAging_Container customNumericField': {
				change: this.handleAdjustmentsOnChange
			},			
			'lemAdjustmentsReconBreakAging_Container customNumericField': {
				change: this.handleRBAdjustmentsOnChange				
			},
			'lemadjustmentspopup_container':{
				beforerender: this.handleBeforeRender
			},
			'lemAdjustmentsDetails_container *[searchId=agingDetailsLink]' : {
				click: function(lnk) {
					var cont = lnk.up('window');
					if (cont) {
						cont.setLoading(true);
						Ext.defer(function(){cont.setLoading(false);},2500);
					}
					Ext.defer(me.openAgingDetails, 100, me);
				}
			},
			"lemadjustments_detailgrid" : {
				showLEMAgingDialog: this.showLEMAgingDialog
			},			
			'lemAdjustmentsRisk_Container customNumericField': {
				change: this.handleRiskOnChange
			},            
			'lemAdjustmentsBalanceAging_Container textfield': {
				change: this.handleComments
			},			
			'lemAdjustmentsReconBreakAging_Container textfield': {
				change: this.handleComments				
			},
			'lemadjustments_filterform' :{
				beforerender:this.handleBeforeFilterRender
			},
            "lemadjustments_filterform combo[action=comboChange]":{
            	change: this.loadautocomplete         	
            }
		});		
	},
	
	loadautocomplete: function()
	{			
		var filterPanel = this.getFilterForm();
		var fullkeyCombo = filterPanel.down("#fullKey-text");
		var fullkey = "";		
		fullkey = filterPanel.down("#fullKey-text").getValue();	
		if(fullkey && fullkey.indexOf("%") != 0){
			var fullkeyStore= this.getStore('eRecon_web.store.LemFullkeyStore');		
			fullkeyStore.directOptions = {};
			fullkeyStore.getProxy().extraParams = {0 : fullkey}; 
			fullkeyStore.load();
			fullkeyCombo.bindStore(fullkeyStore);		
		}		
	},
	
	handleBeforeFilterRender: function(panel,eOpts)
	{
		var filterPanel = this.getFilterForm();
		var statusCombo = filterPanel.down("#Status-combo");
		var reconPeriodState = this.getStore('eRecon_web.store.LemReconPeriodStateStore');
		reconPeriodState.load({callback: function (records, operation, success) 
			{
					if(success==true){
						if(records.length > 0){
							if(records[0].data.reconPeriodState.toUpperCase() == 'A'){
								statusCombo.show();
							}
							else if(records[0].data.reconPeriodState.toUpperCase() == 'O'){
									statusCombo.hide();
							}
						}						
				}
			}
		});
		
	},
	handleBeforeRender: function(panel, eOpts)
	{			
		var adjustmentDetails = this.getLemAdjustmentsDetails();
		//Balance Aging Tab
		var balanceAdjUserRedDetails = this.getLemBalanceAgingContainer();

		//ReconBreak Aging Tab
		var reconBreakTab = this.getLemAdjustmentsAgingContainer();
		var reconBreakAdjUserRedDetails = this.getLemReconBreakAgingContainer();

		//Risk
		var riskDetails =  this.getLemAdjustmentsRiskContainer();

		var lemCustomWindow = this.getCustomWindow();

		var lemAdjPopupStore = this.getStore('eRecon_web.store.LemAdjustmentsPopupStore');
		lemAdjPopupStore.directOptions = {};
		lemAdjPopupStore.getProxy().extraParams = {
			0: lemCustomWindow.myExtraParams.FullKey
		};


		lemAdjPopupStore.load({callback: function (records, operation, success) 
			{
			if(success==true)
			{
				var statusIndicatorValue;
								
				if(records[0].data.acctAgingType == 'G')
				{
					var g_rec;
    			 	var s_rec;
    			 	
    			 	adjustmentDetails.getForm().loadRecord(records[2]);
    			 	riskDetails.getForm().loadRecord(records[2]);
    			 	
    			 	if(records[0].data.agingtype == 'G'){
    			 			g_rec = 0;
    			 			s_rec = 1;
    			 		}
    			 	else{
        			 		g_rec = 1;
    			 			s_rec = 0;
    			 		}
    			 	
    			 	
					//Balance Aging Tab
					balanceAdjUserRedDetails.getForm().loadRecord(records[g_rec]);
					
					//Recon Break Aging Tab
					reconBreakAdjUserRedDetails.getForm().loadRecord(records[s_rec]);					
				}
				else
				{
					adjustmentDetails.getForm().loadRecord(records[0]);
					riskDetails.getForm().loadRecord(records[0]);					
					
					//Recon Break Aging Tab
					reconBreakAdjUserRedDetails.getForm().loadRecord(records[0]);

					// Hide balance Aging tab
					reconBreakTab.child('lemAdjustmentsBalanceAging_Container').hide();
	        		reconBreakTab.down('#lembalanceaging').tab.hide();
					reconBreakTab.child('lemAdjustmentsReconBreakAging_Container').show();
				}
			
				
				var statusIndicator = adjustmentDetails.down("#statusIndicator-text");
				statusIndicatorValue = (lemCustomWindow.myExtraParams.statusIndicator == 'Red')?1:2;
				if(statusIndicatorValue == 1)
					{
						statusIndicator.setValue("Red");
						statusIndicator.setFieldStyle('color:Red;background-image:none');
					}
				else
					{
					    statusIndicator.setValue("Green");
					    statusIndicator.setFieldStyle('color:Green;background-image:none');
					}							
			}
			else
			{
				console.log("No data");
			}
			}
		});
	},
	
	handleComments: function (textField,newValue,oldValue,options)
	{
		var balAgingContainer = this.getLemBalanceAgingContainer();
		var reconBreakAgingContainer = this.getLemReconBreakAgingContainer();
		
		if (textField.itemId == 'b_LemComments-text')
		{
			if(reconBreakAgingContainer != null){
				var rbcomments = reconBreakAgingContainer.down("#rb_LemComments-text");
				var bcomments = balAgingContainer.down("#b_LemComments-text").getValue();
				rbcomments.setValue(bcomments);				
			}		
		}
		else if (textField.itemId == 'rb_LemComments-text')
		{
			if(balAgingContainer != null){
				var rbcomments = reconBreakAgingContainer.down("#rb_LemComments-text").getValue();
				var bcomments = balAgingContainer.down("#b_LemComments-text");
				bcomments.setValue(rbcomments);				
			}	
		}
	},

	handleAdjustmentsOnChange: function (textField,newValue,oldValue,options)
	{				
		var balAgingContainer = this.getLemBalanceAgingContainer();
		var reconBreakAgingContainer = this.getLemReconBreakAgingContainer();
		var riskContainer =  this.getLemAdjustmentsRiskContainer();
		
		var g_rec;
		var agingType;

		agingType = this.getStore('eRecon_web.store.LemAdjustmentsPopupStore').getAt(0).data.agingType;
		if (agingType == 'G'){
			g_rec = 0;
		}
		else
			g_rec = 1;
		
		var lemAdjustmentsStore = this.getStore('eRecon_web.store.LemAdjustmentsPopupStore').getAt(g_rec).data;						
		var threshold = parseFloat(lemAdjustmentsStore.lclCcyThreshold);
		
		if (textField.itemId == 'b_DrLemAdjustments-text')
		{	
			// Debit Adjusted Red Amount variables
			var drUserRed = 0;
			var drAdjustments = 0;
			var drAdjustedUserRed = 0;
			var drCalculatedAdj = 0;
			var drLemUserRedAdjustments = 0;
			var drAdjustmentsVal = 0;

			// Debit Total Red Amount variables
			var drSysRed = 0; 
			var drTotalRed = 0;
			var drCalculatedRedTotal = 0;

			// Debit Reportable Red Amount variables
			var drReportableRed = 0;											
			if (balAgingContainer != null)
			{		
				//Calculation : DR Adjusted Red Amount = DR User Entered Red Amount + DR LEM Adjustments 					
				drUserRed = parseFloat(balAgingContainer.down("#b_DrUserEnteredRed-text").getSubmitValue());
				drAdjustmentsVal = parseFloat(balAgingContainer.down("#b_DrLemAdjustments-text").getSubmitValue());
				drAdjustments = isNaN(drAdjustmentsVal)?0:drAdjustmentsVal;
				drCalculatedAdj =  ((drUserRed == '')? 0:drUserRed)  + drAdjustments;
				drAdjustedUserRed = balAgingContainer.down("#b_DrAdjUserRed-text");
				
				if(drCalculatedAdj == 0)
					{
						drAdjustedUserRed.reset();
						drAdjustedUserRed.setValue('0.00');
					}
				else
					{
						if(drCalculatedAdj!==drAdjustedUserRed.getSubmitValue()){
							drAdjustedUserRed.setValue(drCalculatedAdj);
						}
					}				
				
				drLemAdj = balAgingContainer.down("#b_DrLemAdjustments-text");
				if(drCalculatedAdj < 0 || isNaN(drAdjustmentsVal))
					{
						drLemAdj.setFieldStyle('background-color:red;background-image:none');
					}
				else
					{
						drLemAdj.setFieldStyle('background-color:white;background-image:none');
					}
				
				//Calculation : DR Total Red Amount = DR System Red Amount + DR LEM Adjustments	
				drSysRed = parseFloat(lemAdjustmentsStore.amtSysRedDr);
				drCalculatedRedTotal = ((drSysRed == '')? 0:drSysRed)  + drCalculatedAdj;
				drTotalRed = balAgingContainer.down("#b_DrTotalRedAmt-text");
				
				if(drCalculatedRedTotal == 0)
					{
						drTotalRed.reset();
						drTotalRed.setValue('0.00');
					}
				else
					{
						if(drCalculatedRedTotal!==drTotalRed.getSubmitValue()){
							drTotalRed.setValue(drCalculatedRedTotal);							
						}
					}
				
				//Calculation : DR Reportable red amount = DR Total Red Amount if the total red amount is greater than threshold
				//or DR Reportable red amount = 0 if total red amount is less than threshold
				drReportableRed = balAgingContainer.down("#b_DrReportableRedAmt-text");
				if(drTotalRed.getSubmitValue() >= threshold)
				{
					if(drTotalRed.getSubmitValue()!==drReportableRed.getSubmitValue()){
						drReportableRed.setValue(drTotalRed.getSubmitValue());
					}
				}
				else
				{
					drReportableRed.reset();
					drReportableRed.setValue('0.00');
				}										
			}

		} 
		else if (textField.itemId == 'b_CrLemAdjustments-text')
		{
			// Debit Red amount variables
			var crUserRed = 0;
			var crAdjustments = 0;
			var crAdjustedUserRed = 0;
			var crCalculatedAdj = 0;
			var crLemAdjustments = 0;
			var crAdjustmentsVal = 0;

			// Debit Total Red Amount variables
			var crSysRed = 0; 
			var crTotalRed = 0;
			var crCalculatedRedTotal = 0;

			// Debit Reportable Red Amount variables
			var crReportableRed = 0;
			
			if (balAgingContainer != null)
			{		
				//Calculation : CR Adjusted Red Amount = CR User Entered Red Amount + CR LEM Adjustments
				crUserRed = parseFloat(balAgingContainer.down("#b_CrUserEnteredRed-text").getSubmitValue());				
				crAdjustmentsVal = parseFloat(balAgingContainer.down("#b_CrLemAdjustments-text").getSubmitValue());
				crAdjustments = isNaN(crAdjustmentsVal)?0:crAdjustmentsVal;
				crCalculatedAdj =  ((crUserRed == '')? 0:crUserRed)  + crAdjustments;
				crAdjustedUserRed = balAgingContainer.down("#b_CrAdjUserRed-text");	
				
				if(crCalculatedAdj == 0)
					{
						crAdjustedUserRed.reset();
						crAdjustedUserRed.setValue('0.00');
					}
				else
					{
						if(crAdjustedUserRed.getSubmitValue()!==crCalculatedAdj){
							crAdjustedUserRed.setValue(crCalculatedAdj);
						}
					}
				
				crLemAdj = balAgingContainer.down("#b_CrLemAdjustments-text");
				if(crCalculatedAdj > 0 || isNaN(crAdjustmentsVal))
					{
						crLemAdj.setFieldStyle('background-color:red;background-image:none');
					}
				else
					{
						crLemAdj.setFieldStyle('background-color:white;background-image:none');
					}
				//Calculation : CR Total Red Amount = CR System Red Amount + CR LEM Adjustments	
				crSysRed = parseFloat(lemAdjustmentsStore.amtSysRedCr);
				crCalculatedRedTotal = ((crSysRed == '')? 0:crSysRed)  + crCalculatedAdj;
				crTotalRed = balAgingContainer.down("#b_CrTotalRedAmt-text");
				
				if(crCalculatedRedTotal == 0)
					{
						crTotalRed.reset();
						crTotalRed.setValue('0.00');
					}
				else
					{
						if(crTotalRed.getSubmitValue()!==crCalculatedRedTotal){
							crTotalRed.setValue(crCalculatedRedTotal);							
						}
					}
				
				
				//Calculation : CR Reportable red amount = CR Total Red Amount if the total red amount is greater than threshold
				//or CR Reportable red amount = 0 if total red amount is less than threshold
				crReportableRed = balAgingContainer.down("#b_CrReportableRedAmt-text");				
				if(Math.abs(crCalculatedRedTotal) >= parseFloat(threshold))
				{
					if(crReportableRed.getSubmitValue()!==crCalculatedRedTotal){
						crReportableRed.setValue(crCalculatedRedTotal);
					}
				}
				else
				{
					crReportableRed.reset();
					crReportableRed.setValue('0.00');
				}
			}
		}		
		this.updateStatusIndicator();		
	},
	handleRBAdjustmentsOnChange : function (textField,newValue,oldValue,options){	
		var balAgingContainer = this.getLemBalanceAgingContainer();
		var riskContainer =  this.getLemAdjustmentsRiskContainer();
		var rbAgingContainer = this.getLemReconBreakAgingContainer();		

		var lemAdjustmentsStore;
	 	var s_rec;
	 	var agingType;

		agingType = lemAdjustmentsStore= this.getStore('eRecon_web.store.LemAdjustmentsPopupStore').getAt(0).data.agingType;
		if (agingType == 'S'){
			s_rec = 0;
		}
		else
			s_rec = 1;
			
		lemAdjustmentsStore= this.getStore('eRecon_web.store.LemAdjustmentsPopupStore').getAt(s_rec).data;


		var threshold = parseFloat(lemAdjustmentsStore.lclCcyThreshold);
		if (textField.itemId == 'rb_DrLemAdjustments-text')
		{			
			// Debit Adjusted Red Amount variables
			var drUserRed = 0;
			var drAdjustments = 0;
			var drAdjustedUserRed = 0;
			var drCalculatedAdj = 0;
			var drLemUserRedAdjustments = 0;

			// Debit Total Red Amount variables
			var drSysRed = 0; 
			var drTotalRed = 0;
			var drCalculatedRedTotal = 0;
			var drAdjustmentsVal = 0;

			// Debit Reportable Red Amount variables
			var drReportableRed = 0;											
			if (rbAgingContainer != null)
			{		
				//Calculation : DR Adjusted Red Amount = DR User Entered Red Amount + DR LEM Adjustments 					
				drUserRed = parseFloat(rbAgingContainer.down("#rb_DrUserEnteredRed-text").getSubmitValue());
				drAdjustmentsVal = parseFloat(rbAgingContainer.down("#rb_DrLemAdjustments-text").getSubmitValue());
				drAdjustments = isNaN(drAdjustmentsVal)?0:drAdjustmentsVal;
				drCalculatedAdj =  ((drUserRed == '')? 0:drUserRed)  + drAdjustments;
				drAdjustedUserRed = rbAgingContainer.down("#rb_DrAdjUserRed-text");
				
				if(drCalculatedAdj == 0)
					{
						drAdjustedUserRed.reset();
						drAdjustedUserRed.setValue('0.00');
					}
				else
					{
						if(drAdjustedUserRed.getSubmitValue()!==drCalculatedAdj){
							drAdjustedUserRed.setValue(drCalculatedAdj);
						}
					}
				
				drLemAdj = rbAgingContainer.down("#rb_DrLemAdjustments-text");
				if(drCalculatedAdj < 0 || isNaN(drAdjustmentsVal))
					{
						drLemAdj.setFieldStyle('background-color:red;background-image:none');
					}
				else
					{
						drLemAdj.setFieldStyle('background-color:white;background-image:none');
					}
				
				//Calculation : DR Total Red Amount = DR System Red Amount + DR LEM Adjustments	
				drSysRed = parseFloat(lemAdjustmentsStore.amtSysRedDr);
				drCalculatedRedTotal = ((drSysRed == '')? 0:drSysRed)  + drCalculatedAdj;
				drTotalRed = rbAgingContainer.down("#rb_DrTotalRedAmt-text");
				
				if(drCalculatedRedTotal == 0)
					{
						drTotalRed.reset();
						drTotalRed.setValue('0.00');
					}
				else
					{
						if(drTotalRed.getSubmitValue()!==drCalculatedRedTotal){
							drTotalRed.setValue(drCalculatedRedTotal);
						}
					}
								
				//Calculation : DR Reportable red amount = DR Total Red Amount if the total red amount is greater than threshold
				//or DR Reportable red amount = 0 if total red amount is less than threshold
				drReportableRed = rbAgingContainer.down("#rb_DrReportableRedAmt-text");				
				if(Math.abs(drCalculatedRedTotal) >= threshold)
				{
					if(drReportableRed.getSubmitValue()!==drCalculatedRedTotal){
						drReportableRed.setValue(drCalculatedRedTotal);		
					}
				}
				else
				{
					drReportableRed.reset();
					drReportableRed.setValue('0.00');									
				}	
				drLemAdj.setFieldStyle('text-align:right;');
			}
		} 
		else if (textField.itemId == 'rb_CrLemAdjustments-text')
		{
			// Debit Red amount variables
			var crUserRed = 0;
			var crAdjustments = 0;
			var crAdjustedUserRed = 0;
			var crCalculatedAdj = 0;
			var crLemAdjustments = 0;
			var crAdjustmentsVal = 0;

			// Debit Total Red Amount variables
			var crSysRed = 0; 
			var crTotalRed = 0;
			var crCalculatedRedTotal = 0;

			// Debit Reportable Red Amount variables
			var crReportableRed = 0;
			
			if (rbAgingContainer != null)
			{		
				//Calculation : CR Adjusted Red Amount = CR User Entered Red Amount + CR LEM Adjustments
				crUserRed = parseFloat(rbAgingContainer.down("#rb_CrUserEnteredRed-text").getSubmitValue());		
				crAdjustmentsVal = parseFloat(rbAgingContainer.down("#rb_CrLemAdjustments-text").getSubmitValue());
				crAdjustments = isNaN(crAdjustmentsVal)?0:crAdjustmentsVal;
				crCalculatedAdj =  ((crUserRed == '')? 0:crUserRed)  + crAdjustments;
				crAdjustedUserRed = rbAgingContainer.down("#rb_CrAdjUserRed-text");	
				
				if(crCalculatedAdj == 0)
					{
						crAdjustedUserRed.reset();
						crAdjustedUserRed.setValue('0.00');
					}
				else
					{
						if(crAdjustedUserRed.getSubmitValue()!==crCalculatedAdj){
							crAdjustedUserRed.setValue(crCalculatedAdj);
						}
					}
						
				crLemAdj = rbAgingContainer.down("#rb_CrLemAdjustments-text");
				if(crCalculatedAdj > 0 || isNaN(crAdjustmentsVal))
					{
						crLemAdj.setFieldStyle('background-color:red;background-image:none');
					}
				else
					{
						crLemAdj.setFieldStyle('background-color:white;background-image:none');
					}
				
				//Calculation : CR Total Red Amount = CR System Red Amount + CR LEM Adjustments	
				crSysRed = parseFloat(lemAdjustmentsStore.amtSysRedCr);
				crCalculatedRedTotal = ((crSysRed == '')? 0:crSysRed)  + crCalculatedAdj;
				crTotalRed = rbAgingContainer.down("#rb_CrTotalRedAmt-text");
				
				if(crCalculatedRedTotal == 0)
					{
						crTotalRed.reset();
						crTotalRed.setValue('0.00');
					}
				else
					{
						if(crTotalRed.getSubmitValue()!==crCalculatedRedTotal){
							crTotalRed.setValue(crCalculatedRedTotal);
						}
					}
				
				
				//Calculation : CR Reportable red amount = CR Total Red Amount if the total red amount is greater than threshold
				//or CR Reportable red amount = 0 if total red amount is less than threshold
				crReportableRed = rbAgingContainer.down("#rb_CrReportableRedAmt-text");				
				if(Math.abs(crCalculatedRedTotal) >= parseFloat(threshold))
				{
					if(crReportableRed.getSubmitValue()!==crCalculatedRedTotal){
						crReportableRed.setValue(crCalculatedRedTotal);	
					}
				}
				else
				{
					crReportableRed.reset();
					crReportableRed.setValue('0.00');
				}
				crLemAdj.setFieldStyle('text-align:right;');
			}
		}		
		this.updateStatusIndicator();		
	},
	handleRiskOnChange : function(textField,newValue,oldValue,options) {
		
		var rbRiskContainer = this.getLemAdjustmentsRiskContainer();
		
		var lemAdjustmentsStore;
		if(this.getStore('eRecon_web.store.LemAdjustmentsPopupStore').count() == 1)
		{
			lemAdjustmentsStore= this.getStore('eRecon_web.store.LemAdjustmentsPopupStore').getAt(0).data;
		}
		else
		{
			lemAdjustmentsStore= this.getStore('eRecon_web.store.LemAdjustmentsPopupStore').getAt(1).data;
		}
		var threshold = parseFloat(lemAdjustmentsStore.lclCcyThreshold);
		if (textField.itemId == 'rb_DrLemAdjustmentsRisk-text')
		{		
			//Debit variables for adjusted amount at risk
			var drAmountAtRisk = 0;
			var drAdjustments = 0;
			var drAdjustedRisk = 0;
			var drCalculatedAdjRisk = 0;
			var drLemRiskAdjustments = 0;
			var drAdjustmentsVal = 0;

			// Debit Reportable Red Amount variables
			var drReportableAmtAtRisk = 0;

			drAdjustments = (newValue == null)?0:newValue;;
			if (rbRiskContainer != null)
			{	
				//Calculation : DR Adjusted Amount At Risk = DR Amount At Risk + DR LEM Adjustments for Risk				
				drAmountAtRisk = parseFloat(lemAdjustmentsStore.specificAmtAtRiskDr);
				drAdjustmentsVal = parseFloat(rbRiskContainer.down("#rb_DrLemAdjustmentsRisk-text").getSubmitValue());
				drAdjustments = isNaN(drAdjustmentsVal)?0:drAdjustmentsVal;
				drCalculatedAdjRisk =  ((drAmountAtRisk == '')? 0:drAmountAtRisk) + drAdjustments;
				drAdjustedRisk = rbRiskContainer.down("#rb_DrAdjAmtAtRisk-text");
												
				if(drCalculatedAdjRisk == 0)
					{
						drAdjustedRisk.reset();
						drAdjustedRisk.setValue('0.00');
					}
				else
					{
						if(drAdjustedRisk.getSubmitValue()!==drCalculatedAdjRisk){
							drAdjustedRisk.setValue(drCalculatedAdjRisk);
						}
					}				
				
				drLemAdjRisk = rbRiskContainer.down("#rb_DrLemAdjustmentsRisk-text");
				if(drCalculatedAdjRisk < 0 || isNaN(drAdjustmentsVal))
					{
						drLemAdjRisk.setFieldStyle('background-color:red;background-image:none');
					}
				else
					{
						drLemAdjRisk.setFieldStyle('background-color:white;background-image:none');
					}
				
				//Calculation : DR Reportable amount at risk = DR Adjusted amount at risk if the adjusted amount at risk is greater than threshold
				//or DR Reportable amount at risk = 0 if adjusted amount at risk is less than threshold
				drReportableAmtAtRisk = rbRiskContainer.down("#rb_DrReportableAmtAtRisk-text");
				if(Math.abs(drCalculatedAdjRisk) >= threshold)
				{	
					if(drReportableAmtAtRisk.getSubmitValue()!==drCalculatedAdjRisk){
							drReportableAmtAtRisk.setValue(drCalculatedAdjRisk);
						}
				}
				else
				{
					drReportableAmtAtRisk.reset();
					drReportableAmtAtRisk.setValue('0.00');
				}
			}
		}
		else if (textField.itemId == 'rb_CrLemAdjustmentsRisk-text')
		{
			//Credit variables for adjusted amount at risk
			var crAmountAtRisk = 0;
			var crAdjustments = 0;
			var crAdjustedRisk = 0;
			var crCalculatedAdjRisk = 0;
			var	crLemRiskAdjustments = 0;
			var crAdjustmentsVal = 0;

			// Debit Reportable Red Amount variables
			var crReportableAmtAtRisk = 0;
						
			if (rbRiskContainer != null)
			{		
				//Calculation : CR Adjusted Amount At Risk = CR Amount At Risk + CR LEM Adjustments for Risk
				crAmountAtRisk = parseFloat(lemAdjustmentsStore.specificAmtAtRiskCr);	
				crAdjustmentsVal = parseFloat(rbRiskContainer.down("#rb_CrLemAdjustmentsRisk-text").getSubmitValue());
				crAdjustments = isNaN(crAdjustmentsVal)?0:crAdjustmentsVal;
				crCalculatedAdjRisk =  ((crAmountAtRisk == '')? 0:crAmountAtRisk)  + crAdjustments;
				crAdjustedRisk = rbRiskContainer.down("#rb_CrAdjAmtAtRisk-text");
				
				if(crCalculatedAdjRisk == 0)
					{
						crAdjustedRisk.reset();
						crAdjustedRisk.setValue('0.00');
					}
				else
					{
						if(crAdjustedRisk.getSubmitValue()!==crCalculatedAdjRisk){
							crAdjustedRisk.setValue(crCalculatedAdjRisk);
						}
					}
								
				crLemAdjRisk = rbRiskContainer.down("#rb_CrLemAdjustmentsRisk-text");
				if(crCalculatedAdjRisk > 0 || isNaN(crAdjustmentsVal))
					{
						crLemAdjRisk.setFieldStyle('background-color:red;background-image:none');
					}
				else
					{
						crLemAdjRisk.setFieldStyle('background-color:white;background-image:none');
					}
				//Calculation : CR Reportable amount at risk = CR Adjusted amount at risk if the adjusted amount at risk is greater than threshold
				//or CR Reportable amount at risk = 0 if adjusted amount at risk is less than threshold
				crReportableAmtAtRisk = rbRiskContainer.down("#rb_CrReportableAmtAtRisk-text");
				if(Math.abs(crCalculatedAdjRisk) >= parseFloat(threshold))
				{
					if(crReportableAmtAtRisk.getSubmitValue()!==crCalculatedAdjRisk){
						crReportableAmtAtRisk.setValue(crCalculatedAdjRisk);
					}
										
				}
				else
				{
					crReportableAmtAtRisk.reset();
					crReportableAmtAtRisk.setValue('0.00');
				}
			}
		}
		else if (textField.itemId == 'rb_ReserveLemAdjustment-text')
		{
			//Calculation : Adjusted Reserve Amount = Reserve + Reserve Adjustments
			var reserve = 0;
			var reserveAdj = 0;
			var AdjustedReserve = 0;
			var CalculatedReserve = 0;
			var reserveAdjVal = 0;
			
			if (rbRiskContainer != null)
			{								
				reserve = parseFloat(rbRiskContainer.down("#rb_Reserve-text").getSubmitValue());
				reserveAdjVal = parseFloat(rbRiskContainer.down("#rb_ReserveLemAdjustment-text").getSubmitValue());
				reserveAdj = isNaN(reserveAdjVal)?0:reserveAdjVal;
				CalculatedReserve =  ((reserve == '')? 0:reserve)  + reserveAdj;
				AdjustedReserve = rbRiskContainer.down("#rb_AdjustedReserve-text");
				
				if(CalculatedReserve == 0)
					{
						AdjustedReserve.reset();
						AdjustedReserve.setValue('0.00');	
					}
				else
					{
						if(AdjustedReserve.getSubmitValue()!==CalculatedReserve){
							AdjustedReserve.setValue(CalculatedReserve);	
						}
					}
				
				adjReserve = rbRiskContainer.down("#rb_ReserveLemAdjustment-text");
				if(CalculatedReserve < 0 ||isNaN(reserveAdjVal))
					{
						adjReserve.setFieldStyle('background-color:red;background-image:none');
					}
				else
					{
						adjReserve.setFieldStyle('background-color:white;background-image:none');
					}
			}
		}
		this.updateStatusIndicator();		
	},

	lemSubmitAdjustments : function () {
		var me = this;
    	var invalidField = this.getPopupForm().down('numberfield:not({isValid()})');
    	if (invalidField) {
            Ext.Msg.show({
                title: "Error",
                msg: "Some input fields contain invalid data. Please fix before submission.",
                buttons: Ext.Msg.OK,
                icon: Ext.Msg.ERROR
            });
            return false;
    	}

		var customDialog = this.getCustomWindow();

		var balAgingContainer = this.getLemBalanceAgingContainer();
		var rbAgingContainer = this.getLemReconBreakAgingContainer();
		var riskContainer = this.getLemAdjustmentsRiskContainer();
		var lemAdjustmentsStore = this.getStore('eRecon_web.store.LemAdjustmentsPopupStore');
		var acctAgingType = lemAdjustmentsStore.getAt(0).data.acctAgingType;
		if (acctAgingType == 'S'){
			g_rec = 0;
		}
		else {
			g_rec = 1;
		}
			
		
		var lemAdjustmentsStoreData = lemAdjustmentsStore.getAt(g_rec).data;
		
		var  validationFail = 0;
		if (balAgingContainer != null)
		{		
			//balance tab variables
			var drUserRedAmt = balAgingContainer.down("#b_DrAdjUserRed-text").getSubmitValue();
			var lemComments = balAgingContainer.down("#b_LemComments-text").getValue();
			var crUserRedAmt = balAgingContainer.down("#b_CrAdjUserRed-text").getSubmitValue();
			var crUserRedAdjAmt = balAgingContainer.down("#b_CrAdjUserRed-text").getSubmitValue();
			
			var drUserRedAmtAdj = balAgingContainer.down("#b_DrLemAdjustments-text").getSubmitValue();
			var crUserRedAmtAdj = balAgingContainer.down("#b_CrLemAdjustments-text").getSubmitValue();
			
			
			//Validation - Controller Delegate Comments is mandatory if debit red amount is adjusted
			if((drUserRedAmtAdj != '' && drUserRedAmtAdj != 0 && drUserRedAmtAdj != null) && eRecon_web.gbl.constants.trim(lemComments) == '')
			{
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Controller Delegate Comments are mandatory if debit/credit red amount is adjusted</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
			}

			//Validation - Controller Delegate Comments is mandatory if credit red amount is adjusted
			else if((crUserRedAmtAdj != '' && crUserRedAmtAdj != 0 && crUserRedAmtAdj != null) && eRecon_web.gbl.constants.trim(lemComments) == '')
			{
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Controller Delegate Comments are mandatory if debit/credit red amount is adjusted</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
			}

			//Validation - Value in Adjusted User Entered Red DR should not reduce the User Entered DR to negative.
			else if(drUserRedAmt < 0)
			{
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Adjusted User Entered Red Debit amount cannot be negative</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
			}

			//Validation - Value in Adjusted User Entered Red CR should not increase the User Entered CR to positive.
			else if(crUserRedAmt  + crUserRedAdjAmt > 0)
			{
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Adjusted User Entered Red Credit amount cannot be positive</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
			}			
		}
		//Validation for recon break tab
		if(rbAgingContainer!=null)
		{			
			//recon break tab variables
			var rb_drUserRedAmt = rbAgingContainer.down("#rb_DrAdjUserRed-text").getSubmitValue();
			var rb_lemComments = rbAgingContainer.down("#rb_LemComments-text").getValue();
			var rb_crUserRedAmt = rbAgingContainer.down("#rb_CrAdjUserRed-text").getSubmitValue();
			var crUserRedAdjAmt = rbAgingContainer.down("#rb_CrAdjUserRed-text").getSubmitValue();
			
			var rb_drUserRedAmtAdj = rbAgingContainer.down("#rb_DrLemAdjustments-text").getSubmitValue();
			var rb_crUserRedAmtAdj = rbAgingContainer.down("#rb_CrLemAdjustments-text").getSubmitValue();
			
			//Validation - Controller Delegate Comments is mandatory if debit red amount is adjusted
			if((rb_drUserRedAmtAdj != '' && rb_drUserRedAmtAdj != 0 && rb_drUserRedAmtAdj != null) && eRecon_web.gbl.constants.trim(rb_lemComments) == '')
			{
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Controller Delegate Comments are mandatory if debit/credit red amount is adjusted</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
			}

			//Validation - Controller Delegate Comments is mandatory if credit red amount is adjusted
			else if((rb_crUserRedAmtAdj != '' && rb_crUserRedAmtAdj != 0 && rb_crUserRedAmtAdj != null) && eRecon_web.gbl.constants.trim(rb_lemComments) == '')
			{
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Controller Delegate Comments are mandatory if debit/credit red amount is adjusted</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
			}

			//Validation - Value in Adjusted User Entered Red DR should not reduce the User Entered DR to negative.
			else if(rb_drUserRedAmt < 0)
			{
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Adjusted User Entered Red Debit amount cannot be negative</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
			}

			//Validation - Value in Adjusted User Entered Red CR should not increase the User Entered CR to positive.
			else if(rb_crUserRedAmt > 0)
			{
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Adjusted User Entered Red Credit amount cannot be positive</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
			}
			
			//Validation - Value in Adjusted User Entered Red CR should not increase the User Entered CR to positive.
			else if((crUserRedAmt + crUserRedAdjAmt) > 0)
			{
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Adjusted User Entered Red Credit amount cannot be positive</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
			}									
		}
		//Validation for risks
		if(riskContainer != null)
		{			
			var rb_drRiskAdjustment = riskContainer.down("#rb_DrAdjAmtAtRisk-text").getSubmitValue();
			var rb_crRiskAdjustment = riskContainer.down("#rb_CrAdjAmtAtRisk-text").getSubmitValue();
			
			var rb_drRiskCategory = riskContainer.down("#rb_DrAmtAtRiskCategory-combo").getValue();
			var rb_crRiskCategory = riskContainer.down("#rb_CrAmtAtRiskCategory-combo").getValue();
			var rb_resolutionDate = riskContainer.down("#rb_DrTargetResolutionDate-text").getValue();			
			var rb_AdjReserve = riskContainer.down("#rb_AdjustedReserve-text").getSubmitValue();
			var rb_ReserveAdjustment = riskContainer.down("#rb_ReserveLemAdjustment-text").getSubmitValue();
			var rb_resDateControl = riskContainer.down("#rb_DrTargetResolutionDate-text");
			
			var rb_drRiskAdj = riskContainer.down("#rb_DrLemAdjustmentsRisk-text").getSubmitValue();
			var rb_crRiskAdj = riskContainer.down("#rb_CrLemAdjustmentsRisk-text").getSubmitValue();
			
			/**
			 * Get the original values from the store. 
			 * Check if anything has changed. If changed then show the user with the validation error.
			 * Ask the user to enter comments.
			 */

			//Validation - Debit risk category is necessary if Debit risk amount is adjusted.
			if((rb_drRiskAdjustment != null && rb_drRiskAdjustment != '' && rb_drRiskAdjustment != 0) && (rb_drRiskCategory == null || rb_drRiskCategory == 0))
			{
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Risk category is mandatory if debit risks are adjusted</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
			}
			//Validation - Resolution date for risk is necessary if debit risk amount is adjusted.
			else if((rb_drRiskAdjustment != null && rb_drRiskAdjustment != '' && rb_drRiskAdjustment != 0) && (rb_resolutionDate == null))
			{
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Resolution date is mandatory for adjusted risks</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
			}
			//Validation - Credit risk category is mandatory if credit risk amount is adjusted.
			else if((rb_crRiskAdjustment != null && rb_crRiskAdjustment != '' && rb_crRiskAdjustment != 0) && (rb_crRiskCategory == null || rb_crRiskCategory == 0))
			{
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Risk category is mandatory if credit risks are adjusted</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
			}
			//Validation - Remove Debit risk category if there is no risk involved.
			else if((rb_drRiskAdjustment != null && rb_drRiskAdjustment == 0) && (rb_drRiskCategory !== null && rb_drRiskCategory != 0))
				{
					validationFail = validationFail + 1;
					Ext.Msg.show({
						title: "Error",
						msg: "<b>You cannot enter amount at risk category dr without corresponding amt at risk dr</b><br>",
						buttons: Ext.Msg.OK,
						icon: Ext.Msg.ERROR
					});
				}
			//Validation - Remove Debit credit category if there is no risk involved.
			else if((rb_crRiskAdjustment != null && rb_crRiskAdjustment == 0) && (rb_crRiskCategory != null && rb_crRiskCategory != 0))
				{
					validationFail = validationFail + 1;
					Ext.Msg.show({
						title: "Error",
						msg: "<b>You cannot enter amount at risk category cr without corresponding amt at risk cr</b><br>",
						buttons: Ext.Msg.OK,
						icon: Ext.Msg.ERROR
					});
				}
			//Validation - Remove resolution dates if there is no risk involved.
			else if((rb_drRiskAdjustment != null && rb_drRiskAdjustment == 0) 
					&& (rb_resolutionDate != null))
				{
					validationFail = validationFail + 1;
					Ext.Msg.show({
						title: "Error",
						msg: "<b>You cannot enter resolution date without corresponding amt at risk DR</b><br>",
						buttons: Ext.Msg.OK,
						icon: Ext.Msg.ERROR
					});
				}
			
			//Validation - Value in Adjusted Risk DR should not reduce the Amount at Risk DR to negative.
			else if(rb_drRiskAdjustment < 0)
			{
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Adjusted Amount at Risk Debit amount cannot be negative</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
			}
			
			//Validation - Value in Adjusted Risk CR should not reduce the Amount at Risk CR to negative.
			else if(rb_crRiskAdjustment > 0)
			{
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Adjusted Amount at Risk Credit amount cannot be positive</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
			}
			else if((rb_crRiskAdj != '' && rb_crRiskAdj != 0 && rb_crRiskAdj != null) && eRecon_web.gbl.constants.trim(rb_lemComments) == '')
			{
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Controller Delegate Comments are mandatory if debit/credit risk amount is adjusted</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
			}
			else if((rb_drRiskAdj != '' && rb_drRiskAdj != 0 && rb_drRiskAdj != null) && eRecon_web.gbl.constants.trim(rb_lemComments) == '')
			{
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Controller Delegate Comments are mandatory if debit/credit risk amount is adjusted</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
			}
			
			else if((rb_ReserveAdjustment != '' && rb_ReserveAdjustment != 0 && rb_ReserveAdjustment != null) && eRecon_web.gbl.constants.trim(rb_lemComments) == '')
			{
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Controller Delegate Comments are mandatory if reserve amount is adjusted</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
			}
			
			else if((lemAdjustmentsStoreData.amtAtRiskTypeCr != rb_crRiskCategory
					|| lemAdjustmentsStoreData.amtAtRiskTypeDr != rb_drRiskCategory) && eRecon_web.gbl.constants.trim(rb_lemComments) == "") {
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b> Please enter a comment as this account has been adjusted by Controller Delegate/Financial Controller.</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
				
			}
			else if ((lemAdjustmentsStoreData.amtAtRiskTargetDtDr != Ext.Date.format(rb_resDateControl.value,'m/d/Y'))  && (eRecon_web.gbl.constants.trim(rb_lemComments) == "")){
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b> Please enter a comment as this account has been adjusted by Controller Delegate/Financial Controller.</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
				
			}
			else if(rb_AdjReserve < 0)
			{
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Adjusted Reserve amount cannot be negative</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
			}
			else if(!rb_resDateControl.isValid())
			{
				validationFail = validationFail + 1;
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Please enter a valid date in mm/dd/yyyy format or select from date picker</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
			}
			
		}
		if(validationFail == 0)	
		{
			//Save LEM adjustment details
			var lemAdjustments = this.getLemAdjustmentsDetails();
			var lemAdjustmentsData = lemAdjustments.getValues();	
			var detailGrid = this.getDetailGrid();

			//Balance Aging Tab
			var balanceAdjUserRedDetails = this.getLemBalanceAgingContainer();
			var balAdjUserRedData = balanceAdjUserRedDetails.getForm().getValues();

			//ReconBreak Aging Tab
			var reconBreakAdjUserRedDetails = this.getLemReconBreakAgingContainer();
			var rbAdjUserRedData = reconBreakAdjUserRedDetails.getForm().getValues();
			
			// Risk Details
			var reconBreakAdjRiskDetails = this.getLemAdjustmentsRiskContainer();
			var rbAdjRiskData	=	reconBreakAdjRiskDetails.getForm().getValues();

			var lemAdjustmentsData = {"lemAdjustments":lemAdjustmentsData,
					"balUserRedAdjustments":balAdjUserRedData,
//					"balRiskAdjustments":balAdjRiskData,
					"rbUserRedAdjustments":rbAdjUserRedData,
					"rbRiskAdjustments":rbAdjRiskData};

			var encodedLemAdjData = Ext.encode(lemAdjustmentsData);
			eRecon_web.direct.action.LemAdjustmentsService.saveLemAdjustmentsDetails(encodedLemAdjData, function(p, response) {
				if(response.result == "Success") {
					me.getController('MainController').showStatus('Successfully saved the record(s).');
	    			detailGrid.store.load();
	    			customDialog.close();
	    		}

			});	
		}
	},

	clearFilterSettings: function(){
		var filterPanel = this.getFilterForm();
		filterPanel.getForm().reset();
	},

	lemAdjustmentsFilter: function () {
		if (this.currentBankingGroup !== null) 
		{
			var filterPanel = this.getFilterForm();
			var detailsGrid =this.getDetailGrid();
			if (filterPanel.getForm().isValid()) 
			{
				var bankingGroup = filterPanel.down("#bankinggroup-combo").getValue();
				var statusIndicator = filterPanel.down("#statusindicator-combo").getValue();
				var fullKey = filterPanel.down("#fullKey-text").getValue();
				var submitStatus = filterPanel.down("#Status-combo");
				var SubmitStatusVal = null;
				if(submitStatus != null){
					SubmitStatusVal = submitStatus.getValue();
				}

				var lemAdjStore = this.getStore('eRecon_web.store.LemAdjustmentsStore');
				lemAdjStore.directOptions = {};
				lemAdjStore.getProxy().extraParams = {
					0: bankingGroup,
					1: statusIndicator,
					2: fullKey,
					3: SubmitStatusVal
				};
				lemAdjStore.loadPage(1,{
					callback: function (records, operation, success) {
					}
				});
			}	        	        
		}
	}, 
	
	openAgingDetails: function(lbl) {
		var me = this;
	
		var adjStore = this.getStore('eRecon_web.store.LemAdjustmentsPopupStore');
		
		var lemPopupObj = this.getCustomWindow();
		var accountId = adjStore.getAt(0).data.accountId;
		var acctAgingType = adjStore.getAt(0).data.acctAgingType;
		var reconPeriod = adjStore.getAt(0).data.reconPeriod;

		var agingDialog = Ext.create('eRecon_web.view.common.AOCustomDialog',{
			items: [{
				xtype: 'aoaging_tabcontainer'
			}], 	    
			title : "Aging Details",
			id	: "AOAgingDetails"
		});
		agingDialog.extraParams={AccountId:accountId,AgingType:acctAgingType,ReconPeriod:reconPeriod};
		agingDialog.show();  
	},  showLEMAgingDialog: function(grid, col, row) {
		
		var contr = this.getController("eRecon_web.controller.AOAgingController");
		if (!contr.wasInit) {
	    	contr.init();
	    	contr.wasInit = true;
    	}
		var rec = grid.getStore().getAt(row);              			            			
        
        var lemAdjustmentDialog = Ext.create('eRecon_web.view.lemadjustments.LemDialog',{
     	    items: [{
     	        xtype: "lemadjustmentspopup_container"
     	    }],
     	    title : "Controller Delegate Adjustments"
     	});
        lemAdjustmentDialog.myExtraParams={FullKey:rec.get("fullKey"),statusIndicator:rec.get("statusIndicator")};
     	lemAdjustmentDialog.show();   
	},
	
	updateStatusIndicator : function(){
		var lemAdjustmentDetail = this.getLemAdjustmentsDetails();
		var rbAgingContainer = this.getLemReconBreakAgingContainer();
		var balAgingContainer = this.getLemBalanceAgingContainer();
		var riskContainer =  this.getLemAdjustmentsRiskContainer();		
		
		var ConsolidatedStatus = lemAdjustmentDetail.down("#statusIndicator-text");
		var riskStatusIndicator = riskContainer.down("#risk_statusIndicator-hidden");
		riskStatusIndicator.setValue("");
		
		if(rbAgingContainer!=null){
			var rbStatusIndicator = rbAgingContainer.down("#rb_statusIndicator-hidden");
			var drReportableRed = rbAgingContainer.down("#rb_DrReportableRedAmt-text");
			var crReportableRed = rbAgingContainer.down("#rb_CrReportableRedAmt-text");
			var rb_redStatusCount = 0;
			rbStatusIndicator.setValue("");
			
			if(crReportableRed != null)
			{
				crReportableRedValue = crReportableRed.getSubmitValue();						
				if(Math.abs(crReportableRedValue) > 0)
				{							
					rb_redStatusCount = rb_redStatusCount + 1;
				}
			}
			if(drReportableRed != null)
			{
				if(drReportableRed.getSubmitValue() != '' && drReportableRed.getSubmitValue() > 0)
				{
					rb_redStatusCount = rb_redStatusCount + 1;
				}
			}
			if(rb_redStatusCount > 0)
			{					
				rbStatusIndicator.setValue("Red");					  	
			}
			else					
			{
				rbStatusIndicator.setValue("Green");					
			}
		}
		if(balAgingContainer !=null){
			var balStatusIndicator = balAgingContainer.down("#b_statusIndicator-hidden");
			var drReportableRed = balAgingContainer.down("#b_DrReportableRedAmt-text");
			var crReportableRed = balAgingContainer.down("#b_CrReportableRedAmt-text");			
			var b_redStatusCount = 0;
			balStatusIndicator.setValue("");
			
			if(crReportableRed != null)
			{
				crReportableRedValue = crReportableRed.getSubmitValue();						
				if(Math.abs(crReportableRedValue) > 0)
				{							
					b_redStatusCount = b_redStatusCount + 1;
				}
			}
			if(drReportableRed != null)
			{
				if(drReportableRed.getSubmitValue() != '' && drReportableRed.getSubmitValue() > 0)
				{
					b_redStatusCount = b_redStatusCount + 1;
				}
			}
			if(b_redStatusCount > 0)
			{					
				balStatusIndicator.setValue("Red");					  	
			}
			else					
			{
				balStatusIndicator.setValue("Green");					
			}
		}
		if(riskContainer != null){
			var drReportableAmtAtRisk = riskContainer.down("#rb_DrReportableAmtAtRisk-text");
			var crReportableAmtAtRisk = riskContainer.down("#rb_CrReportableAmtAtRisk-text");
			var risk_redStatusCount = 0;
			
			if(crReportableAmtAtRisk != null)
			{
				crReportableAmtAtRiskValue = crReportableAmtAtRisk.getSubmitValue();						
				if(Math.abs(crReportableAmtAtRiskValue) > 0)
				{							
					risk_redStatusCount = risk_redStatusCount + 1;
				}
			}
			if(drReportableAmtAtRisk != null)
			{
				if(drReportableAmtAtRisk.getSubmitValue() != '' && drReportableAmtAtRisk.getSubmitValue() > 0)
				{
					risk_redStatusCount = risk_redStatusCount + 1;
				}
			}
			if(risk_redStatusCount > 0)
			{					
				riskStatusIndicator.setValue("Red");					  	
			}
			else					
			{
				riskStatusIndicator.setValue("Green");					
			}
		}
		
		if(rbStatusIndicator.getValue() == "Red" || balStatusIndicator.getValue() == "Red" ||riskStatusIndicator.getValue() == "Red" )
		{
			ConsolidatedStatus.setValue("Red");
			ConsolidatedStatus.setFieldStyle('color:Red;background-image:none');
		}
		else
		{
			ConsolidatedStatus.setValue("Green");	
			ConsolidatedStatus.setFieldStyle('color:Green;background-image:none');
		}
	}
});

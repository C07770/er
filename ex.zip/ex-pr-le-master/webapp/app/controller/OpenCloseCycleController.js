Ext.define('eRecon_web.controller.OpenCloseCycleController',{
	extend: 'Ext.app.Controller',
	requires: ["eRecon_web.store.OpenCloseCycleStore"],
	stores:	["eRecon_web.store.OpenCloseCycleStore"],
	refs: [{
	       ref: 'OpenCloseCycle',
	       selector: 'OpenCloseCycle'
	    },
	    {
	    	ref: 'OpenCloseCycleSearch',
	    	selector: 'OpenCloseCycleSearch'
	    }],
	
	init: function()
	{
		this.control({
			'OpenCloseCycleSearch button[action=search]': {
	            click: this.searchCycle
	        },
	        'OpenCloseCycleSearch button[action=clear]': {
	            click: this.clearSelections
	        }
		});
	},
			
	clearSelections: function(){
		var searchPanel = this.getOpenCloseCycleSearch();
		searchPanel.getForm().reset();
	},
	
	searchCycle: function(){					
		var searchPanel = this.getOpenCloseCycleSearch();
        var openCloseCycleGrid =this.getOpenCloseCycle();
        if (searchPanel.getForm().isValid()) 
        {
        	var reconPeriod=searchPanel.down("#reconPeriod").getValue();        	
			var businessUnit=searchPanel.down("#businessUnit").getValue();
			var openAccounts=searchPanel.down("#openAccounts").getValue();
			if(openAccounts == '') openAccounts = null;
			var pendingAccounts=searchPanel.down("#pendingAccounts").getValue();
			if(pendingAccounts == '') pendingAccounts = null;
			var redAccounts=searchPanel.down("#redAccounts").getValue();
			if(redAccounts == '') redAccounts = null;
			var greenAccounts=searchPanel.down("#greenAccounts").getValue();
			if(greenAccounts == '') greenAccounts = null;
			var submittedAccounts=searchPanel.down("#submittedAccounts").getValue();
			if(submittedAccounts == '') submittedAccounts = null;
			var unsubmittedAccounts=searchPanel.down("#unsubmittedAccounts").getValue();
			if(unsubmittedAccounts == '') unsubmittedAccounts = null;
			var agingType=searchPanel.down("#agingType").getValue();
			if(agingType == '') agingType = null;
			var open=searchPanel.down("#open").getValue();
			if(open == '') open = null;
			var amtOpen=searchPanel.down("#amtOpen").getValue();
			if(amtOpen == '') amtOpen = null;
			var amtPending=searchPanel.down("#amtPending").getValue();
			if(amtPending == '') amtPending = null;
			var amtRed=searchPanel.down("#amtRed").getValue();
			if(amtRed == '') amtRed = null;
			var amtGreen=searchPanel.down("#amtGreen").getValue();
			if(amtGreen == '') amtGreen = null;
			var amtSubmitted=searchPanel.down("#amtSubmitted").getValue();
			if(amtSubmitted == '') amtSubmitted = null;
			var amtUnsubmitted=searchPanel.down("#amtUnsubmitted").getValue();
			if(amtUnsubmitted == '') amtUnsubmitted = null;
        	
        	var openCloseStore = this.getStore('eRecon_web.store.OpenCloseCycleStore');
        	openCloseStore.directOptions = {};
        	openCloseStore.getProxy().extraParams = {
        		0: reconPeriod,
        		1: businessUnit,
        		2: open,
        		3: openAccounts,
        		4: amtOpen,
        		5: pendingAccounts,
        		6: amtPending,
        		7: redAccounts,
        		8: amtRed,
        		9: greenAccounts,
        		10: amtGreen,
        		11: submittedAccounts,
        		12: amtSubmitted,
        		13: unsubmittedAccounts,
        		14: amtUnsubmitted,
        		15: agingType

            };
        	
        	openCloseStore.load({
                callback: function (records, operation, success) {
                }
            });
        }		
	}	
});

Ext.define('eRecon_web.controller.RollbackFeedsController',{
	extend: 'Ext.app.Controller',	
	//views:['eRecon_web.view.common.CustomDialog'],
	requires: ["eRecon_web.store.RollbackFeedsStore"],
	stores: ["eRecon_web.store.RollbackFeedsStore"],
	refs: [{
	       ref: 'RollbackFeedsGrid',
	       selector: 'RollbackFeeds_Grid'
	    },
	    {
	    	ref: 'RollbackFeedsSearch',
	    	selector: 'RollbackFeeds_Search'
	    }],
	
	init: function()
	{
		this.control({
			'RollbackFeeds_Search button[action=searchdetails]': {
	            click: this.RollbackFeedsSearch
	        },
	        'RollbackFeeds_Search button[action=clear]': {
	            click: this.clearSearchPanel
	        },
	        'RollbackFeeds_Search button[action=insert]': {
	            click: this.insertNewRecord
	        },
	        'RollbackFeeds_Grid button[action=save]': {
	        	click: this.saveRecords
	        },
	        'RollbackFeeds_Grid button[action=rollBackExcel]': {
	        	click: this.rollBackdownlaodfile
	        }
		});
	},
		
	insertNewRecord : function(){
//		debugger;
		var searchForm = this.getRollbackFeedsSearch();
		var scheduleid = searchForm.down("#scheduleid").getValue();
		var corp = searchForm.down("#corp").getValue();
		var proof = searchForm.down("#proof").getValue();
		var date = searchForm.down("#date").getValue();
    	var status = searchForm.down("#status").getValue();
    	var feedid = searchForm.down("#feedid").getValue();
    	var region = searchForm.down("#region").getValue(); 
		var flag = 0;
		
		if(scheduleid == "" || scheduleid == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Schedule id is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		
        var form = searchForm.getForm();
		var formdata = Ext.encode(form.getValues());
		var rollBackStore = this.getRollbackFeedsGrid().getStore();
		rollBackStore.directOptions = {};
		rollBackStore.getProxy().extraParams = {
			0:(scheduleid =="")? null : Number(scheduleid),
	        1:corp,
	        2:proof,               
	        3:date,
	        4:status,
	        5:feedid,
	        6:region
        };
		
        Ext.Msg.show({
			title: "Confirmation",
			msg: "Do you want to insert a record?",
		    buttons: Ext.Msg.OKCANCEL,
		    fn: function(btn) {
				if (btn == 'ok') {
					eRecon_web.direct.action.RollbackFeedsService.doAddRecords(formdata, function(p, response) {
				    	if(response.result!= "Error") {
				    		rollBackStore.loadPage(1,{
				                callback: function (records, operation, success) {
				                }
				            });
				            Ext.MessageBox.alert( "Status", response.result );
				    	}else{
				    		Ext.MessageBox.alert( "Status", response.result );
				    	}
				    	
				    }); 
				}
			}
		});
	},
	
	saveRecords : function(){
//		debugger;
		var store = this.getRollbackFeedsGrid().getStore();
		var flag = 0;
		var dataArray = [];
		var updateData = store.getUpdatedRecords();  
		var deleteData = store.getRemovedRecords();
		
		if(updateData.length == 0 && deleteData.length == 0) 
		{
    		Ext.MessageBox.alert( "Alert", "No changes found");
    		return false;
		}
		if(updateData.length != 0)
			{
				Ext.each(updateData, function(item, index, array) {
		        dataArray.push({
					"newData" : item.data,
		        	"previousData" : item.raw,
		        	"modified" : item.modified 
			        });
			    });
			}
		
		if(deleteData.length != 0)
			{
				Ext.each(deleteData, function(item, index, array) {
			        dataArray.push({
						"deleteData" : item.data
			        });
			    });
			}
		
		if(flag ==0){
			var encodedArray = Ext.encode(dataArray);
			eRecon_web.direct.action.RollbackFeedsService.saveRecords(encodedArray, function(p, response) {
				if(response.result!== "Error") {
		    		store.load();
		    		Ext.MessageBox.alert( "Status", response.result );
		    	}
		    	Ext.MessageBox.alert( "Status", response.result );
		    }); 
		}
	}, 
	RollbackFeedsSearch : function(){
		var searchPanel = this.getRollbackFeedsSearch();
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());		



        if (searchPanel.getForm().isValid()) 
        {        	
        	var scheduleid = searchPanel.down("#scheduleid").getValue();
        	var corp = searchPanel.down("#corp").getValue();
        	var proof = searchPanel.down("#proof").getValue();
        	var date = searchPanel.down("#date").getValue();
        	var status = searchPanel.down("#status").getValue();
        	var feedid = searchPanel.down("#feedid").getValue();
        	var region = searchPanel.down("#region").getValue();       	
        	var RollbackFeedStore = this.getRollbackFeedsGrid().getStore();
        	RollbackFeedStore.directOptions = {};
        	RollbackFeedStore.getProxy().extraParams = {
                0:(scheduleid =="" ||scheduleid==null)? null : Number(scheduleid),
                1:(corp =="")? null : corp,
                2:(proof =="")? null : proof,               
                3:(date =="")? null : date,
                4:(status =="")? null : status,
                5:(feedid =="")? null : feedid,
                6:(region =="")? null : region,
            };
        	
        	RollbackFeedStore.load({
                callback: function (records, operation, success) {
                }
            });
        }	
	},
	
	clearSearchPanel : function(){
		var searchPanel = this.getRollbackFeedsSearch(); 
		searchPanel.getForm().reset();
		var RollbackFeedStore = this.getRollbackFeedsGrid().getStore();
    	RollbackFeedStore.directOptions = {};
    	RollbackFeedStore.getProxy().extraParams = {
            0:null,
            1:null,
            2:null,               
            3:null,
            4:null,
            5:null,
    	     6:null
        };
    	
    	RollbackFeedStore.load({
            callback: function (records, operation, success) {
            }
        });
	} ,
	rollBackdownlaodfile: function(){
		var searchPanel = this.getRollbackFeedsSearch();
		var scheduleid = searchPanel.down("#scheduleid").getValue();
    	var corp = searchPanel.down("#corp").getValue();
    	var proof = searchPanel.down("#proof").getValue();
    	var date = searchPanel.down("#date").getValue();
    	var status = searchPanel.down("#status").getValue();
    	var feedid = searchPanel.down("#feedid").getValue();
    	var region = searchPanel.down("#region").getValue();
		var RollbackFeedStore = this.getRollbackFeedsGrid().getStore();
		Ext.create('eRecon_web.common.ExportToExcelStatusPopup').launchExport(
			'eRecon_web.store.RollbackFeedsStore',
			RollbackFeedStore.total,
			null,
			{
			0:(scheduleid =="" ||scheduleid==null)? null : Number(scheduleid),
            1:corp,
            2:proof,               
            3:date,
            4:status,
            5:feedid,
            6:region
			}
		);
	}
});

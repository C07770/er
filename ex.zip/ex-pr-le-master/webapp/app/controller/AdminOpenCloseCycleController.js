Ext.define('eRecon_web.controller.AdminOpenCloseCycleController',{
	extend: 'Ext.app.Controller',
	requires: ["eRecon_web.store.AdminOpenCycleStore"],
	stores:	["eRecon_web.store.AdminOpenCycleStore"],
	refs: [{
	       ref: 'adminOpenCloseCycle',
	       selector: 'secadmin_adminopencyclegrid'
	    },
	    {
	    	ref: 'searchForm',
	    	selector: 'adminOpenCloseSearch'
	    }],
	
	init: function()
	{
		this.control({
			'adminOpenCloseSearch button[action=AdminOpenClose-search]': {
	            click: this.openCloseCycleSearch
	        },
	        'adminOpenCloseSearch button[action=AdminOpenClose-clear]': {
	            click: this.clearFilterForm
	        },
	        'secadmin_adminopencyclegrid button[action=adminOpenClose-save]': {
	        	click: this.saveRecords
	        },
	        'secadmin_adminopencyclegrid  button[action=adminOpenClose-excel-button]': {
	        	click: this.openCloseCycledownlaodfile
	        },
	        'adminOpenCloseSearch  button[action=AdminOpenClose-add]': {
	        	click: this.openCloseCycleAddRecord
	        }
		});
	},
	
	saveRecords: function(){
		
		var store = this.getStore('eRecon_web.store.AdminOpenCycleStore');
		var dataArray = [];
		var updateData = store.getUpdatedRecords(); 
		var deleteData = store.getRemovedRecords();
		
		if(updateData.length == 0 && deleteData.length == 0) 
		{
    		Ext.MessageBox.alert( "Alert", "No changes found");
    		return false;
		}
		if(updateData.length != 0)
			{
				Ext.each(updateData, function(item, index, array) {
		        dataArray.push({
					"newData" : item.data,
		        	"previousData" : item.raw,
		        	"modified" : item.modified 
			        });
			    });
			}
		if(deleteData.length != 0)
			{
			Ext.each(deleteData, function(item, index, array) {
		        dataArray.push({
					"deleteData" : item.data
		        });
		    });
			}
		
		var encodedArray = Ext.encode(dataArray);
		eRecon_web.direct.action.AdminOpenCloseCycleService.saveRecords(encodedArray, function(p, response) {
	    	if(response.result !== "Error") {
	    		Ext.MessageBox.alert( "Status", response.result);
	    		store.load();
	    	}else{
	    		Ext.MessageBox.alert( "Status", response.result);
	    	}
	    }); 
	},
	
	clearFilterForm: function(){
		var searchPanel = this.getSearchForm();
		searchPanel.getForm().reset();
		var openCloseStore = this.getAdminOpenCloseCycle().getStore();
		openCloseStore.directOptions = {};
		openCloseStore.getProxy().extraParams = {
            0: null
        };
        openCloseStore.load();
	},
	
	openCloseCycleSearch: function(){
		var searchPanel = this.getSearchForm();
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var openCloseStore = this.getAdminOpenCloseCycle().getStore();
		openCloseStore.directOptions = {};
		openCloseStore.getProxy().extraParams = {
            0: formdata
        };
        openCloseStore.loadPage(1,{
            callback: function (records, operation, success) {
            }
        });
	},
	openCloseCycledownlaodfile: function(){
		var searchPanel = this.getSearchForm();
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var openCloseStore = this.getAdminOpenCloseCycle().getStore();
		Ext.create('eRecon_web.common.ExportToExcelStatusPopup').launchExport(
			'eRecon_web.store.AdminOpenCycleStore',
			openCloseStore.total,
			null,
			{0: formdata}
		);
	},
	openCloseCycleAddRecord: function(){
		var searchPanel = this.getSearchForm();
		var reconPeriod = searchPanel.down("#reconPeriod-combo").getValue();
		var businessUnit = searchPanel.down("#businessunit-combo").getValue();
		if(reconPeriod == "" || reconPeriod == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>ReconPeriod is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		if(businessUnit == "" || businessUnit == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>BusinessUnit  is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var adminOpenCycleStore = this.getAdminOpenCloseCycle().getStore();
		adminOpenCycleStore.directOptions = {};
		adminOpenCycleStore.getProxy().extraParams = {
            0: formdata
        };
        Ext.Msg.show({
			title: "Confirmation",
			msg: "Do you want to insert a record?" ,
		    buttons: Ext.Msg.OKCANCEL,
		    fn: function(btn) {
				if (btn == 'ok') {
					eRecon_web.direct.action.AdminOpenCloseCycleService.doAddRecords(formdata, function(p, response) {
				    	if(response.result!= "Error") {
				    		adminOpenCycleStore.loadPage(1,{
				                callback: function (records, operation, success) {
				                }
				            });
				            Ext.MessageBox.alert( "Status", response.result);
				    	}else{
				    		Ext.MessageBox.alert( "Status", response.result);
				    	}
				    }); 
				}
			}
		});
	}
	
});

Ext.define('eRecon_web.controller.RulesApprovalController',{
	extend: 'Ext.app.Controller',
	requires:	['eRecon_web.store.RulesApprovalStore'],
	stores:	['eRecon_web.store.RulesApprovalStore'],	
    init: function(){
		var me = this;
		me.control({
			'rulesapproval_grid': {
				boxready: function(grid) {
					grid.store.on('load', function(){
						grid.getSelectionModel().restoreSelection();
					});
					grid.store.load();
				},
				
				edit: function(edt,e) {
					if (e.record.dirty) {
						eRecon_web.direct.action.RulesMaintenanceService.updateRuleComments(e.record.get('ruleId'), e.record.get('comments'), function(){
							e.record.commit();
							e.grid.getView().refresh();
						});
					}
					e.grid.getView().refresh();
				}
			},
			
			'rulesapproval_container': {
				refresh_data: function(card) {
					var grid = card.down('rulesapproval_grid');
					grid.store.load();
				}
			},
			
			'rulesapproval_container *[searchId=approve], *[searchId=reject]': {
				click: {
					fn: function(btn) {
						me.onSubmit(btn);
					},
					delay: 200
				}
			},
			
			'rulesapproval_container *[searchId=export_to_excel]': {
				click: function(btn) {
					var rulesApprovalContainer = btn.up('rulesapproval_container'); 
					var selectedRules = rulesApprovalContainer.down('grid').getSelectionModel().getSelection();
					if (selectedRules.length == 0) {
						Ext.Msg.alert("","Please select the rules to export.");
						return;
					}
					var selectedRulesStr = '';
					for (var i1 = 0; i1 < selectedRules.length; i1++) {
						if (selectedRulesStr != '') {
							selectedRulesStr += '~';
						}
						selectedRulesStr += selectedRules[i1].get('ruleId');
					}
					rulesApprovalContainer.setLoading({msg: "Please wait..."});
					Ext.Ajax.request({
						url: 'filedownloadtrigger.up?downloadType=RULE_TEST_AND_EXPORT',
						method:'POST', 
						params: {
							ruleId: selectedRulesStr
						},
						scope : me,
						success : function(response, opts) {
							response = Ext.decode(response.responseText);
							if(response.success){
								rulesApprovalContainer.setLoading(false);
								Ext.MessageBox.alert('Success', "Rule Test file is being created. You will be notified once the rule test is complete. Schedule ID: " + response.scheduleId);
							}
							else {
								Ext.MessageBox.alert('Failure', response.message);
								rulesApprovalContainer.setLoading(false);
							}
						},
						failure: function(err) {
							Ext.MessageBox.alert('Error occured', 'Please try again!');
							rulesApprovalContainer.setLoading(false);
						}
					}); 
				}
			}
		});
	},
	onSubmit: function(btn){
		var rulesApprovalContainer = btn.up('rulesapproval_container'); 
		var grid = btn.up('rulesapproval_container').down('rulesapproval_grid');
		var selectedRec = grid.getSelectionModel().getSelection();		
		var arr = [];
		var approvalMode = (btn.searchId == "approve");
		var msg;
		if (approvalMode) {
			msg = "You are about to approve the selected roll up rule(s). The changes you approve will take effect with the opening of the next recon cycle. Please confirm you wish to approve the rule(s)";
		}
		else {
			msg = "You are about to reject the selected roll up rule(s). Please confirm that you wish to reject the rule(s)";
		}
		//for(var prop in grid.getSelectionModel().multipageSelection){
			//arr.push(prop);
		//}
		for(var i=0; i<selectedRec.length; i++) {
		  arr.push(selectedRec[i].data.ruleIdToken);
		}
		if (arr.length == 0) {
			Ext.Msg.alert("","No rules were selected");
			return;
		}
		var performAction = function() {
			var clbck = function(dummy,rtnObj) {
				if (rtnObj.status) {
					grid.store.load();
				}
				else {
					Ext.Msg.alert("","Operation failed");
				}
			}; 
			Ext.Msg.show({
				title: "Confirmation",
				msg: msg,
				buttons: Ext.Msg.OKCANCEL,
				icon: Ext.window.MessageBox.WARNING,
				fn: function(b) {
					if (b == 'ok') {
						if (approvalMode) {
							eRecon_web.direct.action.RulesMaintenanceService.approveRules(arr,clbck);
						}
						else {
							eRecon_web.direct.action.RulesMaintenanceService.rejectRules(arr,clbck);
						}
				    }
				}	
			});
		}
		
		if (approvalMode) {
			performAction();
		
		}
		else {
			eRecon_web.direct.action.RulesMaintenanceService.checkRulesComments(arr,function(dummy1, rtnObj){
				if (rtnObj.result == 0) {
					Ext.Msg.alert( "","Please enter a comment for each rule that has been rejected");
					return;
				}
				else {
					if (rtnObj.result == 2) {
						Ext.Msg.alert( "","Invalid Rule ID");
						return;
					}
					performAction();
				}
				
			});
		}

	}

});

Ext.define('eRecon_web.controller.AccountTypeLUController',{
	extend: 'Ext.app.Controller',	
	views:['eRecon_web.view.common.CustomDialog'],
	requires: ["eRecon_web.store.AccountTypeLUStore"],
	stores:	["eRecon_web.store.AccountTypeLUStore"],
	refs: [{
	       ref: 'AccountTypeLUGrid',
	       selector: 'AccountTypeLU_Grid'
	    },
	    {
	    	ref: 'AccountTypeLUSearch',
	    	selector: 'AccountTypeLU_Search'
	    }],
	
	init: function()
	{
		this.control({
			'AccountTypeLU_Search button[action=searchdetails]': {
	            click: this.AccountTypeLUSearchDetails
	        },
	        'AccountTypeLU_Search button[action=clear]': {
	            click: this.clearSearchPanel
	        },
	        'AccountTypeLU_Search button[action=insert]': {
	            click: this.insertNewRecord
	        },
	        'AccountTypeLU_Grid button[action=save]': {
	        	click: this.saveRecords
	        },
	        'AccountTypeLU_Grid button[action=acctTypeExcel]': {
	        	click: this.acctTypedownlaodfile
	        }
		});
	},
		
	insertNewRecord : function(){
		var searchForm = this.getAccountTypeLUSearch();
		var form = searchForm.getForm();
		var formdata = Ext.encode(form.getValues());
		var AccountStore = this.getAccountTypeLUGrid().getStore();
		AccountStore.directOptions = {};
		AccountStore.getProxy().extraParams = {
            0: formdata
        };
		var accounttypeid = searchForm.down("#accounttypeid").getValue();
		var accountparentid = searchForm.down("#accountparentid").getValue();
		var acronym = searchForm.down("#acronym").getValue();
		var accountlevel = searchForm.down("#accountlevel").getValue();
		var description = searchForm.down("#description").getValue();
		var activeFlag = searchForm.down("#activeflag").getValue();
//		debugger;
		var flag = 0;
		
		if(accounttypeid == "" || accounttypeid == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Account type id is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			flag = 1;
		}
		if(accountparentid == "" || accountparentid == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Account parent id is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			flag = 1;
		}
		if(acronym == "" || acronym == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Acronym is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			flag = 1;
		}
		if(accountlevel == "" || accountlevel == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Account Level is required .</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			flag = 1;
		}
		if(description == "" || description == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Description is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			flag = 1;
		}
		if(activeFlag == "" || activeFlag == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Active Flag is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			flag = 1;
		}

		if (flag == 0){
			Ext.Msg.show({
				title: "Confirmation",
				msg: "Do you want to insert a record?",
			    buttons: Ext.Msg.OKCANCEL,
			    fn: function(btn) {
					if (btn == 'ok') {			
						var formValues = searchForm.getValues();
						var dataArray = [];
						dataArray.push({
							"newInsertData" : formValues
				        });	
						formValues.action = 'INSERT';
						var encodedArray = Ext.encode(dataArray);
						eRecon_web.direct.action.AccountTypeLUService.saveRecords(encodedArray, function(p, response) {
							if(response.result[0]!= null){
								if(response.result[0] == "Success") {
									AccountStore.loadPage(1,{
						                callback: function (records, operation, success) {
					                	}
									});
						    		Ext.Msg.alert('Status',response.result[1]);
						    	}
								else{
									Ext.Msg.alert('Status',response.result[1]);
								}
							}		    	
					    	else {		    		
					    		Ext.Msg.alert('Status',response.result[1]);
					    	}
						});
					}
				}
			});				
		}
	},
	
	saveRecords : function(){
		var store = this.getAccountTypeLUGrid().getStore();
		var flag = 0;
		var dataArray = [];
		var updateData = store.getUpdatedRecords();  
		var deleteData = store.getRemovedRecords();
		
		if(updateData.length == 0 && deleteData.length == 0) 
		{
    		Ext.MessageBox.alert( "Alert", "No changes found");
    		return false;
		}
		if(updateData.length != 0)
			{
				Ext.each(updateData, function(item, index, array) {
		        dataArray.push({
					"newData" : item.data,
		        	"previousData" : item.raw,
		        	"modified" : item.modified 
			        });
			    });
			}
		
		if(deleteData.length != 0)
			{
				Ext.each(deleteData, function(item, index, array) {
			        dataArray.push({
						"deleteData" : item.data
			        });
			    });
			}
		
		if(flag ==0){
			var encodedArray = Ext.encode(dataArray);
			eRecon_web.direct.action.AccountTypeLUService.saveRecords(encodedArray, function(p, response) {
				if(response.result[0]!= null){
					if(response.result[0] == "Success" || response.result[0] =="Exception") {
			    		Ext.MessageBox.alert( "Status", response.result[1] );
			    		store.load();		    		
			    	}
				}
				else if (response.result[0] == null || response.result[0] =="Fail"){
					Ext.MessageBox.alert( "Status", "Record(s) modiciation failed" );
				}
		    }); 
		}
	}, 
	AccountTypeLUSearchDetails : function(){
//		debugger;
		var searchPanel = this.getAccountTypeLUSearch();  
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
        if (searchPanel.getForm().isValid()) 
        {        	
        	var AccountStore = this.getAccountTypeLUGrid().getStore();
        	AccountStore.directOptions = {};
        	AccountStore.getProxy().extraParams = {
                0: formdata
            };
        	
        	AccountStore.load({
                callback: function (records, operation, success) {
                }
            });
        }	
	},
	
	clearSearchPanel : function(){
		var searchPanel = this.getAccountTypeLUSearch(); 
		searchPanel.getForm().reset();
		var AccountStore = this.getAccountTypeLUGrid().getStore();
    	AccountStore.directOptions = {};
    	AccountStore.getProxy().extraParams = {
            0: null
        };
    	
    	AccountStore.load({
            callback: function (records, operation, success) {
            }
        });
	},
	acctTypedownlaodfile: function(){
		var searchPanel = this.getAccountTypeLUSearch();
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var AccountStore = this.getAccountTypeLUGrid().getStore();
		Ext.create('eRecon_web.common.ExportToExcelStatusPopup').launchExport(
			'eRecon_web.store.AccountTypeLUStore',
			AccountStore.total,
			null,
			{0: formdata}
		);
	}
});

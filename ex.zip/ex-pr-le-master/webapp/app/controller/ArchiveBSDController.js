Ext.define('eRecon_web.controller.ArchiveBSDController',{
	extend: 'Ext.app.Controller',
	requires: ['eRecon_web.store.ArchiveAssignedUnAssignedStore'], 
	stores:	['eRecon_web.store.ArchiveAssignedUnAssignedStore'], 	
    refs: [
    {
    	ref: 'filterForm',
    	selector: 'archive_reconform'
    },
    {
    	ref: 'assignForm',
    	selector: 'archiveBSD_assignForm'
    }
    ],
    
		
	init: function(){
		this.control({
			'archive_reconform combo[action=select]':{
				select: this.loadAssignUnAssignForm
			},
			'archive_reconform button[action=runSubmit]':{
				click: this.runProfile
			},
			"archiveBSD_assignForm archiveBSDitemselector[changeTag=itemselect]": {
				insertdeleteArchiveBSDRecord: Ext.Function.createBuffered(function(operation) {
            		this.insertdeleteArchiveBSDRecord(operation);
            	}, 100, this)
            }
		});
	},
	loadAssignUnAssignForm : function(){
		var assignForm = this.getAssignForm();
		var itemSelector=assignForm.down("#assignSelector");
		var filterForm = this.getFilterForm();
		var reconPeriod = filterForm.down("#reconperiod-combo").getValue();
		if(reconPeriod ==='' || reconPeriod===null){
    		return false;
		}
		itemSelector.setLoading(true);
		var itemSelectorStore = itemSelector.getStore();
		itemSelectorStore.directOptions = {};
		itemSelectorStore.getProxy().extraParams = {
			0:reconPeriod
		};
		if(reconPeriod!='' && reconPeriod!= undefined && reconPeriod!= null){
			itemSelectorStore.load(function(){
				var assigned=[];
				Ext.each(itemSelectorStore.data.items,function(item){
					if(item['data']['assigned']==='Y'){
						assigned.push(item['data']['businessUnit']);
					}
				});
				itemSelector.setValue(assigned);
				itemSelector.setLoading(false);
			}
			);
		}
	},
	insertdeleteArchiveBSDRecord : function(operation){
		var filterForm = this.getFilterForm();
		var reconPeriod = filterForm.down("#reconperiod-combo").getValue();
		var assignForm = this.getAssignForm();
		var itemSelector=assignForm.down("#assignSelector");
		var businessUnits;
		if(reconPeriod ==='' || reconPeriod===null){
			Ext.MessageBox.alert( "Alert", "Select Valid Recon period");
    		return false;
		}
		if(operation==='add'){
			businessUnits = itemSelector.toField.lastValue;
		}else if (operation==='remove'){
			businessUnits = itemSelector.fromField.lastValue;
		}
		if((operation=='add' || operation=='remove')){
			if(businessUnits!=undefined && businessUnits!=null && businessUnits!= ''){
				eRecon_web.direct.action.ArchiveBSDService.insertdeleteArchiveBSDRecord(businessUnits,reconPeriod,operation);
			}
		}
		else if ((operation=='addall' || operation=='removeall')){
			itemSelector.setLoading(true);
			eRecon_web.direct.action.ArchiveBSDService.insertdeleteArchiveBSDAllRecord(reconPeriod,operation, function(p, response) {
				if(response.result.successMsg=== 'Success') {	
					var itemSelectorStore = itemSelector.getStore();
					itemSelectorStore.directOptions = {};
					itemSelectorStore.getProxy().extraParams = {
						0:reconPeriod
					};
					itemSelectorStore.load({
					callback: function (records, operation, success) 
					{
						var assigned=[];
						Ext.each(itemSelectorStore.data.items,function(item){
							if(item['data']['assigned']==='Y'){
								assigned.push(item['data']['businessUnit']);
							}
						});
						itemSelector.setValue(assigned);
						itemSelector.setLoading(false);
					}
					});
			  }
		  });
		}
	},
	runProfile : function (){
		var filterForm = this.getFilterForm();
		var reconPeriod = filterForm.down("#reconperiod-combo").getValue();
		var assignForm = this.getAssignForm();
		var itemSelector=assignForm.down("#assignSelector");
		eRecon_web.direct.action.ArchiveBSDService.runClick(function(p, response) {
			if(response.result.successMsg=== 'Success') {	
				var itemSelectorStore = itemSelector.getStore();
				itemSelectorStore.directOptions = {};
				itemSelectorStore.getProxy().extraParams = {
					0:reconPeriod
				};
				itemSelectorStore.load({
				callback: function (records, operation, success) 
				{
					var assigned=[];
					Ext.each(itemSelectorStore.data.items,function(item){
						if(item['data']['assigned']==='Y'){
							assigned.push(item['data']['businessUnit']);
						}
					});
					itemSelector.setValue(assigned);
					itemSelector.setLoading(false);
				}
				});
		  }
	  });
	}
});

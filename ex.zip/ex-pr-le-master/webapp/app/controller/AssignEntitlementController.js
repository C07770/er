Ext.define('eRecon_web.controller.AssignEntitlementController',{
	extend: 'Ext.app.Controller',
	requires: ['eRecon_web.store.AssignEntitlementCountryStore','eRecon_web.store.AssignedUnAssignedStore','eRecon_web.store.AssignEntitlementCountryStore','eRecon_web.store.AssignEntitlementRegionStore','eRecon_web.store.AssignEntitlementLobStore','eRecon_web.store.AssignEntitlementCondiStore','eRecon_web.store.AssignEntitlementFullkeyStore'],
	stores:	['eRecon_web.store.AssignEntitlementCountryStore','eRecon_web.store.AssignedUnAssignedStore','eRecon_web.store.AssignEntitlementCountryStore','eRecon_web.store.AssignEntitlementRegionStore','eRecon_web.store.AssignEntitlementLobStore','eRecon_web.store.AssignEntitlementCondiStore','eRecon_web.store.AssignEntitlementFullkeyStore','eRecon_web.store.AssignEntitlementCorpStore'], 	
    refs: [
    {
        ref: 'entityForm',
        selector: 'assignentitlement_entityform'
    },
    {
    	ref: 'filterForm',
    	selector: 'assign_filterform'
    },
    {
    	ref: 'assignForm',
    	selector: 'assignentitlement_assignform'
    }
    ],
    
		
	init: function(){
		this.control({
			'assignentitlement_entityform combo[action=select]':{
				select: this.setFilterForm
			},
			'assign_filterform multiselect[action=multiselect-control]':{
				change: this.loadAssignUnAssignForm
			},
			'assign_filterform combo[action=autocomplete-entitlement]':{
				select: this.loadAssignUnAssignForm
			},
			"assignentitlement_assignform assignentitlementitemselector[changeTag=itemselect]": {
				insertdeleteEntitlementRecord: Ext.Function.createBuffered(function(operation) {
            		this.insertdeleteEntitlementRecord(operation);
            	}, 100, this)
            }
		});
	},
	
	setFilterForm: function(){
		var entityForm=this.getEntityForm();	
		var entity = entityForm.down("#entity-combo").getValue();
		var filterForm = this.getFilterForm();
		var assignForm = this.getAssignForm();
		var itemSelector=assignForm.down("#assignSelector");
		var itemSelectorStore = itemSelector.getStore();
		var profileType= filterForm.down("#profile_type");
		itemSelector.store.data.clear();
		itemSelector.toField.store.removeAll();
		itemSelector.fromField.store.removeAll();
		var filterCtrl;
		var multiselectStore;
		if(entity==='country'){
			 filterCtrl = filterForm.down("#multiselect-control");
			 filterForm.down("#combo-control").hide();
			 if( filterForm.down("#profileGroup-control")!=null){
				 filterForm.down("#profileGroup-control").hide();	
			 }
			 multiselectStore = this.getStore('eRecon_web.store.AssignEntitlementCountryStore');
			 filterCtrl.bindStore(multiselectStore); 
			  filterCtrl.setFieldLabel('Country');
        }else if(entity==='region'){
        	 filterCtrl = filterForm.down("#multiselect-control");
        	 filterForm.down("#combo-control").hide();
        	 if( filterForm.down("#profileGroup-control")!=null){
				 filterForm.down("#profileGroup-control").hide();	
			 }
        	 multiselectStore = this.getStore('eRecon_web.store.AssignEntitlementRegionStore');
			 filterCtrl.bindStore(multiselectStore); 
			  filterCtrl.setFieldLabel('Region');
        }else if(entity==='lob'){
        	filterCtrl = filterForm.down("#multiselect-control");
       	 	filterForm.down("#combo-control").hide();
	       	 if( filterForm.down("#profileGroup-control")!=null){
				 filterForm.down("#profileGroup-control").hide();	
			 }	
       	    multiselectStore = this.getStore('eRecon_web.store.AssignEntitlementLobStore');
		    filterCtrl.bindStore(multiselectStore); 
		    filterCtrl.setFieldLabel('LOB:');
        }else if (entity==='condi'){
        	filterCtrl = filterForm.down("#combo-control");
       	 	filterForm.down("#multiselect-control").hide();
	       	 if( filterForm.down("#profileGroup-control")!=null){
				 filterForm.down("#profileGroup-control").hide();	
			 }
       	    multiselectStore = this.getStore('eRecon_web.store.AssignEntitlementCondiStore');
       	    filterCtrl.setFieldLabel('FRS Business Unit');
       	    filterCtrl.setValue('');
       	    filterCtrl.bindStore(multiselectStore); 
        }else if (entity==='corp'){
        	filterCtrl = filterForm.down("#combo-control");
       	 	filterForm.down("#multiselect-control").hide();
	       	 if( filterForm.down("#profileGroup-control")!=null){
				 filterForm.down("#profileGroup-control").hide();	
			 }
       	    multiselectStore = this.getStore('eRecon_web.store.AssignEntitlementCorpStore');
       	    filterCtrl.setFieldLabel('CORP');
       	    filterCtrl.setValue('');
       	    filterCtrl.bindStore(multiselectStore); 
        }
		else if (entity==='fullkey'){
        	filterCtrl = filterForm.down("#combo-control");
       	 	filterForm.down("#multiselect-control").hide();
	       	 if( filterForm.down("#profileGroup-control")!=null){
				 filterForm.down("#profileGroup-control").hide();	
			 }
       	    multiselectStore = this.getStore('eRecon_web.store.AssignEntitlementFullkeyStore');
		    filterCtrl.bindStore(multiselectStore);
		    filterCtrl.setValue('');
		    filterCtrl.setFieldLabel('FULLKEY');
        }else if(entity =='select'){
        	filterForm.down("#multiselect-control").hide();
        	filterForm.down("#combo-control").hide();
        	if( filterForm.down("#profileGroup-control")!=null){
				 filterForm.down("#profileGroup-control").hide();	
			 }
        }else if (entity =='profilegroup'){
        	filterForm.down("#combo-control").hide();
        	filterForm.down("#multiselect-control").hide();
        	var mask = new Ext.LoadMask(Ext.getBody(),{msg:"Please wait..."});
        	mask.show();
    		eRecon_web.direct.action.AssignEntitlementService.getProfileGroupTree(function(p, response) {
				var firstRecord;
    			var fields= new Array();
    			var data=new Array();
    			var index = 0;			
    			var gridHeaderArray = new Array();
    			
    			var profileGroupTree = new Ext.tree.TreePanel({
    				title: 'Profile Group',
    				lines: false,
    				useArrows:true,
    			    modal:true,
    				renderTo: Ext.getBody(),
    				width: 200,
    				itemId:"profileGroup-control",
    				height:400,
    				scrollable:true,
    				rootVisible:false,
    				listeners:{
    					itemclick:{
    						fn:function(view,record,item,index,event){
    							if(record.data.parentId!=="root"){
    								profileType.setValue(record.data.id);
    								itemSelectorStore.directOptions = {};
    					    		itemSelectorStore.getProxy().extraParams = {
    					    			0:record.data.id.toString(),
    					    			1:'8'
    					    		};
					    			itemSelectorStore.load(function(){
					    				var assigned=[];
					    				Ext.each(itemSelectorStore.data.items,function(item){
					    					if(item['data']['assigned']==='Y'){
					    						assigned.push(item['data']['userid']);
					    					}
					    				});
					    				itemSelector.setValue(assigned);
					    			}
					    			);
    							}else{
    								profileType.setValue("");
    							}
    						}
    					}
    				}
    			});
    			
    			 var rootNode ={
    				name:'ProfileGroup',
    				text:'ProfileGroup',
    				expanded:true,
    				leaf:false,
    				children:[]
    			 };
    			 
    			 profileGroupTree.setRootNode(rootNode);
    			 var root = profileGroupTree.getRootNode();
    			 
    			 for (var i=0; i < response.result.length; i++){
    					var record =  response.result[i];
    					if(record.PARENTID == 0){
    						var subNode_Level1 = {
    								name :record.TITLE,
    								text: record.TITLE,
    								id:record.ID,
    								leaf:true
    							};
    						root.appendChild(subNode_Level1);
    						var subNode_L1 = root.findChild("text",record.TITLE);						
    						for (var j=0; j <= response.result.length - 1; j++){
    							if(record.ID == response.result[j].PARENTID){															
    								var subNode_Level2 = {
    										name :response.result[j].TITLE,
    										text: response.result[j].TITLE,
    										id:response.result[j].ID,
    										leaf:true
    									};
    								subNode_L1.data.leaf = false;
    								subNode_L1.appendChild(subNode_Level2);
    							} 							
    						}
    					}
    			 }
    			 filterForm.add(profileGroupTree);
    			 mask.hide();
          });
        }
		if(entity==='select' || entity==='profilegroup'){
			console.log(" No Action ..");
		}else{
			filterCtrl.show();
		}
		if(entity!=='condi' && entity!=='fullkey' && entity!=='profilegroup' && entity!=='select' && entity!=='corp'){
			filterCtrl.getStore().load();
		} 
	},
	loadAssignUnAssignForm : function(){
		var assignForm = this.getAssignForm();
		var entityForm=this.getEntityForm();	
		var itemSelector=assignForm.down("#assignSelector");
		var entity = entityForm.down("#entity-combo").getValue();
		var filterForm = this.getFilterForm();
		var profileType= filterForm.down("#profile_type-text");
		var filterCtrl;
		var entitlementId;
		var value='';
		var selectedvalue;
		itemSelector.setLoading(true);
		if(entity==='country'){
			 filterCtrl = filterForm.down("#multiselect-control");
			 selectedvalue=filterCtrl.getValue();
			 if(selectedvalue!==undefined && selectedvalue!=='' && selectedvalue!==null){
				 if(selectedvalue.length===1){
					 value=selectedvalue[0];
				 }else{
					 value=selectedvalue[1];
				 }
			 }
			 entitlementId='9';
			 
        }else if(entity==='region'){
        	 filterCtrl = filterForm.down("#multiselect-control");
        	 selectedvalue=filterCtrl.getValue();
        	 if(selectedvalue!==undefined && selectedvalue!=='' && selectedvalue!==null){
				 if(selectedvalue.length===1){
					 value=selectedvalue[0];
				 }else{
					 value=selectedvalue[1];
				 }
			 }
        	 entitlementId='3';
        }else if (entity==='lob'){
        	 filterCtrl = filterForm.down("#multiselect-control");
        	 selectedvalue=filterCtrl.getValue();
        	 if(selectedvalue!==undefined && selectedvalue!=='' && selectedvalue!==null){
				 if(selectedvalue.length===1){
					 value=selectedvalue[0];
				 }else{
					 value=selectedvalue[1];
				 }
			 }
			 entitlementId='2';
        }else if(entity==='condi'){
        	 filterCtrl = filterForm.down("#combo-control");
        	 value= filterCtrl.value;
			 entitlementId='1';
        }else if(entity==='fullkey'){
	       	 filterCtrl = filterForm.down("#combo-control");
	    	 value= filterCtrl.value;
			 entitlementId='4';
        }else if(entity==='corp'){
	       	 filterCtrl = filterForm.down("#combo-control");
	    	 value= filterCtrl.value;
			 entitlementId='5';
        }else if (entity==='profileGroup'){
        	value= profileType.getValue();
			entitlementId='8';
        }
		var itemSelectorStore = itemSelector.getStore();
		itemSelectorStore.directOptions = {};
		itemSelectorStore.getProxy().extraParams = {
			0:value,
			1:entitlementId
		};
		if(value!='' && value!= undefined && value!= null){
			itemSelectorStore.load(function(){
				var assigned=[];
				Ext.each(itemSelectorStore.data.items,function(item){
					if(item['data']['assigned']==='Y'){
						assigned.push(item['data']['userid']);
					}
				});
				itemSelector.setValue(assigned);
			}
			);
		}
		itemSelector.setLoading(false);
	},
	insertdeleteEntitlementRecord : function(operation){
		var entityForm = this.getEntityForm();
		var filterForm = this.getFilterForm();
		var profileType= filterForm.down("#profile_type");
		var entity = entityForm.down("#entity-combo").getValue();
		var entitlementId;
		var selectedValue;
		var value;
		if(entity==='country'){
			selectedValue = filterForm.down("#multiselect-control").value;
			if(selectedValue!==undefined && selectedValue!=='' && selectedValue!==null){
				 if(selectedValue.length===1){
					 value=selectedValue[0];
				 }else{
					 value=selectedValue[1];
				 }
			 }
			entitlementId='9';
		}else if (entity==='region'){
			selectedValue = filterForm.down("#multiselect-control").value;
			if(selectedValue!==undefined && selectedValue!=='' && selectedValue!==null){
				 if(selectedValue.length===1){
					 value=selectedValue[0];
				 }else{
					 value=selectedValue[1];
				 }
			 }
			entitlementId='3';
		}
		
		else if (entity==='lob'){
			selectedValue = filterForm.down("#multiselect-control").value;
			if(selectedValue!==undefined && selectedValue!=='' && selectedValue!==null){
				 if(selectedValue.length===1){
					 value=selectedValue[0];
				 }else{
					 value=selectedValue[1];
				 }
			 }
			entitlementId='2';
		}
		
		else if (entity==='condi'){
			value = filterForm.down("#combo-control").value;
			entitlementId='1';
		}
		else if (entity==='corp'){
			value = filterForm.down("#combo-control").value;
			entitlementId='5';
		}else if (entity==='fullkey'){
			value = filterForm.down("#combo-control").value;
			entitlementId='4';
		}else if (entity==='profilegroup'){
			value = profileType.getValue();
			entitlementId='8'
		}
		var assignForm = this.getAssignForm();
		var itemSelector=assignForm.down("#assignSelector");
		var users;
		if(operation==='add'){
			 users = itemSelector.toField.lastValue;
		}else if (operation==='remove'){
			 users = itemSelector.fromField.lastValue;
		}
		if((operation=='add' || operation=='remove')){
			if(users!=undefined && users!=null && users!= ''){
				eRecon_web.direct.action.AssignEntitlementService.insertdeleteEntitlementRecord(users,entitlementId,value,operation);
			}
		}
		else if ((operation=='addall' || operation=='removeall')){
			var Confirmmsg='';
			if(operation==='addall'){
				Confirmmsg='Are you sure to Assign All Users';
			}else if (operation==='removeall'){
				Confirmmsg='Are you sure to Unassign All Users';
			}
			
			Ext.Msg.show({
			title: "Confirmation",
			msg: Confirmmsg,
		    buttons: Ext.Msg.OKCANCEL,
		    fn: function(btn) {
				if (btn == 'ok') {
					itemSelector.setLoading(true);
					eRecon_web.direct.action.AssignEntitlementService.insertdeleteEntitlementAllRecord(entitlementId,value,operation, function(p, response) {
						if(response.result.successMsg!== null) {	
							var itemSelectorStore = itemSelector.getStore();
							itemSelectorStore.directOptions = {};
							itemSelectorStore.getProxy().extraParams = {
								0:value,
								1:entitlementId
							};
							itemSelectorStore.load(function(){
								var assigned=[];
								Ext.each(itemSelectorStore.data.items,function(item){
									if(item['data']['assigned']==='Y'){
										assigned.push(item['data']['userid']);
									}
								});
								itemSelector.setValue(assigned);
							}
							);
							itemSelector.setLoading(false);
					  }
				  });
				}
			}
			});
	   }
	}
});

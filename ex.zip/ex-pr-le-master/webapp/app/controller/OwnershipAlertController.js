Ext.define('eRecon_web.controller.OwnershipAlertController',{
	extend: 'Ext.app.Controller',
	stores:	['eRecon_web.store.OwnershipAlertStore',
	       	 'eRecon_web.store.OwnershipEmailStore'], 
    refs: [
     {
       ref: 'ThePanel',
       selector: 'ownershipalert_alertgrid'
     },
     {
         ref: "filterPanel",
         selector: "ownershipalert_filterform"
     }
    ],
		
	init: function(){
		this.control({
			"ownershipalert_alertgrid button[action=load]":
			{
				click: this.onLoad
			}/*,
			"ownershipalert_alertgrid":
			{
		    	ownershipAlertSelectionChange: this.setMessageId
            }*/,
            "ownershipalert_filterform button[action=search]": 
            {
                click: this.filterSearchClick
            },
            "ownershipalert_filterform button[action=clear]":
            	
			{
            	click: this.clearAllClick
            },
            "ownershipalert_alertgrid button[action=export]": {
                click: this.doOwnershipAlertExportAction
            }
            
            
		});
	},
		
	 onLoad: function(){
		
		var filterPanel = this.getFilterPanel();
		var formValues = filterPanel.getValues();
                
        var ownershipStore = this.getStore('eRecon_web.store.OwnershipAlertStore');
        ownershipStore.directOptions = {};
        ownershipStore.getProxy().extraParams = {
        	 0: null,
     	     1: null,
     	     2: null,
     	     3: null,
     	     4: null,
     	     5: null,
     	     6: null,
     	     7: null,
     	     8: null,
     	     9: null
     	};
        
        ownershipStore.loadPage(1);
    },
	
	currentMessageId: null,

	setMessageId: function (selectedMessageId)
	{
		if(selectedMessageId!==null)
		{
			if (selectedMessageId !== this.currentMessageId) {
				var emailStore = this.getStore('eRecon_web.store.OwnershipEmailStore');
     
				emailStore.getProxy().extraParams = {
					0: selectedMessageId.get("messageId")};
				emailStore.loadPage(1);
				this.currentMessageId = selectedMessageId;}
		}
    },
	clearAllClick: function () 
	{
		var filterPanel = this.getFilterPanel();
		filterPanel.getForm().reset();
		ownershipAlertStore = this.getStore('eRecon_web.store.OwnershipAlertStore');
		ownershipAlertStore.directOptions = {};
		ownershipAlertStore.getProxy().extraParams = {
            0: null
        };
    	
    	ownershipAlertStore.load({
            callback: function (records, operation, success) {
            }
        });
	},
	
	filterSearchClick: function () 
	{
	    var filterPanel = this.getFilterPanel();
	    var form = filterPanel.getForm();
		var formdata = Ext.encode(form.getValues());
	    if (filterPanel.getForm().isValid()) 
	    {
	        var formValues = filterPanel.getValues();
	        var ownershipStore = this.getStore('eRecon_web.store.OwnershipAlertStore');
	        ownershipStore.directOptions = {};
//	        ownershipStore.getProxy().extraParams = {
//	            0: (formValues.scheduleId == '' || formValues.scheduleId == null)? null: Number(formValues.scheduleId),
//	            1: (formValues.fullKey == '' || formValues.fullKey == null)? null: formValues.fullKey,
//	            2: (formValues.aoPoId == '' || formValues.aoPoId == null)? null: formValues.aoPoId,
//	            3: (formValues.userName == '' || formValues.userName == null)? null: formValues.userName,
//	            4: (formValues.assignDate == '' || formValues.assignDate == null)? null: formValues.assignDate,
//	            5: (formValues.roleAssigned == '' || formValues.roleAssigned == null)? null: formValues.roleAssigned,
//	            6: (formValues.messageId == '' || formValues.messageId == null)? null: Number(formValues.messageId),
//	            7: (formValues.emailSent == '' || formValues.emailSent == null)? null: formValues.emailSent,
//	            8: (formValues.lemUserId == '' || formValues.lemUserId == null)? null: formValues.lemUserId,
//	            9: (formValues.finContrId == '' || formValues.finContrId == null)? null: formValues.finContrId
//	        };
	        ownershipStore.getProxy().extraParams = {
	        	0: formdata
	        }
	        ownershipStore.loadPage(1);
        }
	 },
	 doOwnershipAlertExportAction : function(){
			var searchPanel = this.getFilterPanel();
			var form = searchPanel.getForm();
			var formdata = Ext.encode(form.getValues());
			var ownershipStore = this.getStore('eRecon_web.store.OwnershipAlertStore');
			Ext.create('eRecon_web.common.ExportToExcelStatusPopup').launchExport(
				'eRecon_web.store.OwnershipAlertStore',
				ownershipStore.total,
				null,
				{0: formdata}
			);
		},
	 doOwnershipAlertExportAction1 : function() {
		console.log("Export action called");

		var filterPanel = this.getFilterPanel();
		var formValues = filterPanel.getValues();
		var lemUserId  = formValues.lemUserId;
		var finContrId = formValues.finContrId;
		if(lemUserId ==='' || lemUserId===null){
			lemUserId=null;
		}else{
			lemUserId=lemUserId.substring(lemUserId.indexOf('(')+1,lemUserId.indexOf(')'));
		}
		if(finContrId=='' || finContrId==null){
			finContrId=null;
		}else{
			finContrId=finContrId.substring(finContrId.indexOf('(')+1,finContrId.indexOf(')'));
		}
		var formdata = {
			scheduleId : (formValues.scheduleId == '' || formValues.scheduleId == null) ? null : Number(formValues.scheduleId),
			fullKey : (formValues.fullKey == '' || formValues.fullKey == null) ? null : formValues.fullKey,
			aoPoId : (formValues.aoPoId == '' || formValues.aoPoId == null) ? null	: formValues.aoPoId,
			userName : (formValues.userName == '' || formValues.userName == null) ? null : formValues.userName,
			assignDate : (formValues.assignDate == '' || formValues.assignDate == null) ? null : formValues.assignDate,
			roleAssigned : (formValues.roleAssigned == '' || formValues.roleAssigned == null) ? null : formValues.roleAssigned,
			messageId : (formValues.messageId == '' || formValues.messageId == null) ? null : Number(formValues.messageId),
			emailSent : (formValues.emailSent == '' || formValues.emailSent == null) ? null	: formValues.emailSent,
			lemUserId : lemUserId,
			finContrId : finContrId
		};

		Ext.Ajax.request({
			url : 'filedownloadtrigger.up?downloadType=OWNERSHIP_ALERT',
			method : 'POST',
			params : {
				formdata : Ext.encode(formdata)
			},
			scope : this,
			success : function(response, opts) {
				response = Ext.decode(response.responseText);
				if (response.success) {
					Ext.MessageBox.alert('Successful', "Your request has been submitted successfully with the request id "
											+ response.scheduleId
											+ ". You should recieve an email on completion.");
				} else {
					Ext.MessageBox.alert('Failed',	response.message);
				}
			},
			failure : function(err) {
				Ext.MessageBox.alert('Error occured during Subledger file download.','Please try again!');
			}
		});
	}
});
	

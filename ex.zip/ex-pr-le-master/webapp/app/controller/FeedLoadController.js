Ext.define('eRecon_web.controller.FeedLoadController',{
	extend: 'Ext.app.Controller',
	requires: ["eRecon_web.store.JobStatusForProfileStore"],
	stores:	["eRecon_web.store.JobStatusForProfileStore"],
	refs: [{
	       ref: 'feedLoadGrid',
	       selector: 'feedLoad_filehistorygrid'
	    },
	    {
	    	ref: 'feedLoadTypePanel',
	    	selector: 'feedLoadType_container'
	    },
	    {
	    	ref: 'feedLoadContainer',
	    	selector: 'feedLoad_container'
	    },
	    {
	    	ref: 'feedLoadUploadPanel',
	    	selector: 'feedLoadupload_panel'
	    },{
    		ref: 'jobStatusDetailPanel',
    		selector: 'jobstatusgriddetailspanel'
	    },
	    {
			ref: 'jobStatusFilterPanel',
			selector: 'jobstatus_filterform'
	    }],
	
	init: function()
	{
		this.control({
	        "feedLoadupload_panel": {
                "feedsuploadfile": this.handleFeedLoadFileUpload
            },
            "feedLoad_filehistorygrid" : {
            	feedsFileRunProfile: this.doHandleRunProfile,
            	feedsFileDiscardProfile: this.doHandleDiscardProfile,
            	clickevent : this.doHandleScheduleIdClick
            },
            "feedLoad_container": {
                "activate": this.onLoad
            }
		});
	},
	onLoad: function(){
		var feedLoadStore = this.getFeedLoadGrid().getStore();
    	feedLoadStore.directOptions = {};
    	feedLoadStore.getProxy().extraParams = {
            0: 'FeedLoad'
        };
        var feedLoadTypepanel = this.getFeedLoadTypePanel();
        var profileId = feedLoadTypepanel.down("#profile_id-text");
        var templateId = feedLoadTypepanel.down("#template_id-text");
        var templateText = feedLoadTypepanel.down("#template_text-text");
        var profileTree = feedLoadTypepanel.down("#profileTree-id");
        feedLoadStore.load({
            callback: function (records, operation, success) {
        		if(profileTree==='' || profileTree===null || profileTree ==='undefined'){
		            var mask = new Ext.LoadMask(Ext.getBody(),{msg:"Please wait..."});
		    		mask.show();
		            eRecon_web.direct.action.FeedLoadService.getFeedLoadTree(function(p, response) {
		    			var firstRecord;
		    			var fields= new Array();
		    			var data=new Array();
		    			var index = 0;			
		    			var gridHeaderArray = new Array();
		    			
		    			var FeedLoadTypesTree = new Ext.tree.TreePanel({
		    				title: '',
		    				lines: false,
		    				useArrows:true,
		    			    modal:true,
		    			    bodyStyle :{border :0},
		    				//renderTo: Ext.getBody(),
		    				width: 210,
		    				//flex:1,
		    				autoScroll :true,
		    				border:false,
		    				itemId:"profileTree-id",
		    				height:510,
		    				scrollable:true,
		    				rootVisible:false,
		    				listeners:{
		    					itemclick:{
		    						fn:function(view,record,item,index,event){
		    							if(record.data.parentId!=="root"){
		    								profileId.setValue(record.data.id);
		    								templateId.setValue(record.data.id);
		    								templateText.setValue(record.data.text);
		    								//var feedLoadStore = this.getFeedLoadGrid().getStore();
		    						    	feedLoadStore.directOptions = {};
		    						    	feedLoadStore.getProxy().extraParams = {
		    						            0: 'FeedLoad|'+record.data.text
		    						        };
		    						        feedLoadStore.load();


		    							}else{
		    								profileId.setValue("");
		    							}
		    						}
		    					}
		    				}
		    			});
		    			
		    			 var rootNode ={
		    				name:'Templates',
		    				text:'Templates',
		    				expanded:true,
		    				leaf:false,
		    				children:[]
		    			 };
		    			 
		    			 FeedLoadTypesTree.setRootNode(rootNode);
		    			 var root = FeedLoadTypesTree.getRootNode();
		    			 
		    			 for (var i=0; i < response.result.length; i++){
		    					var record =  response.result[i];
		    					if(record.parentId == 0){
		    						var subNode_Level1 = {
		    								name :record.title,
		    								text: record.title,
		    								id:record.id,
		    								leaf:true
		    							};
		    						root.appendChild(subNode_Level1);
		    						var subNode_L1 = root.findChild("text",record.title);						
		    						for (var j=0; j <= response.result.length - 1; j++){
		    							if(record.id == response.result[j].parentId){															
		    								var subNode_Level2 = {
		    										name :response.result[j].title,
		    										text: response.result[j].title,
		    										id:response.result[j].id,
		    										leaf:true
		    									};
		    								subNode_L1.data.leaf = false;
		    								subNode_L1.appendChild(subNode_Level2);
		    							} 							
		    						}
		    					}
		    			 }
		    			 feedLoadTypepanel.add(FeedLoadTypesTree);
		    			 mask.hide();
		    		});
        	   }
            }
        });
       // var searchForm = this.getAccountTypeDefaultSearch();
		//var SubAccount = searchForm.down("#acct_type_id");
        
	},
	handleFeedLoadFileUpload: function (o) {
        console.log("Feed Load file upload");
        var feedloadUploadPanel = this.getFeedLoadUploadPanel();
        var feedLoadTypepanel = this.getFeedLoadTypePanel();
        var profileId= feedLoadTypepanel.down("#profile_id-text").getValue();
        var templateId = feedLoadTypepanel.down("#template_id-text").getValue();
        var templateText = feedLoadTypepanel.down("#template_text-text").getValue();
        if(profileId==='' || profileId===null){
        	Ext.Msg.show({
				title: "Error",
				msg: "<b>Please select a Profile</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
        }
        var form = o.cmp.getForm();
        var feedLoadForm = this.getFeedLoadUploadPanel();
        var UploadFile = feedLoadForm.down("#feedfileupload-file").getValue();
        var feedLoadStore = this.getFeedLoadGrid().getStore();
        feedLoadStore.directOptions = {};
        feedLoadStore.getProxy().extraParams = {
            0: 'FeedLoad'
        };
        if (UploadFile !== '') {
            if (form.isValid()) {
                form.submit({
                    url: "fileuploadtrigger?UploadType="+templateText+"&ProfileId="+profileId,
                    waitMsg: 'Uploading file...',
                    scope: this,
                    success: function (fp, o) {
                    	feedLoadStore.loadPage(1,{
        	                callback: function (records, operation, success) {
        	                }
        	            });
                        Ext.Msg.show({
                            title: "Success",
                            msg: "File has been successfully saved in the server. Please click on Process File to load data",
                            buttons: Ext.Msg.OK,
                            icon: Ext.Msg.QUESTION
                        });
                    },
                    failure: function (fp, o) {
                        var errs = "";
                        for (var z = 0; z < o.result.validationErrors.length; z++) {
                            errs += "- " + o.result.validationErrors[z] + "<br>";
                        }
                        Ext.Msg.show({
                            title: "Error",
                            msg: "<b>The following errors occurred:</b><br>" + errs,
                            buttons: Ext.Msg.OK,
                            icon: Ext.Msg.ERROR
                        });
                    }
                });
            }
        } else {
            Ext.Msg.show({
                title: "Success",
                msg: "No file to Upload",
                buttons: Ext.Msg.OK,
                icon: Ext.Msg.QUESTION
            });
        }
    },
    doHandleRunProfile : function(column, recordIndex, record, view) {
    	var data = {
    			"scheduleId" : record.get("scheduleId").toString(),
    			"profileName" : record.get("profileName"),
    			"fileName" : record.get("fileName"),
    			"soeId" : record.get("userId")
    			//"profileId" : record.get("profileName"),
    			//"templateId" : record.get("templateId")//
    	}
    	var encodedArray = Ext.encode(data);
    	eRecon_web.direct.action.FeedLoadService.handleProcessFile(encodedArray, function(p, response) {
    		if(response.result == "Success") {
    			view.getStore().load();
    			Ext.MessageBox.alert( "Status", "Request to process file has been queued in the system." );
    		} else {
    			Ext.MessageBox.alert( "Status", "Error submitting request to process the file." );
    		}
    	});
    }, 
    doHandleDiscardProfile : function(column, recordIndex, record, view) {
    	var data = {
    			"scheduleId" : record.get("scheduleId").toString(),
    			"profileName" : record.get("profileName"),
    			"fileName" : record.get("fileName"),
    			"soeId" : record.get("userId")
    	}
    	var encodedArray = Ext.encode(data);
    	eRecon_web.direct.action.FeedLoadService.handleDiscardFile(encodedArray, function(p, response) {
    		if(response.result == "Success") {
    			view.getStore().load();
    			Ext.MessageBox.alert( "Status", "Successfully discarded the file." );
    		} else {
    			Ext.MessageBox.alert( "Status", "Error Discarding file" );
    		}
    	});
    },
    doHandleScheduleIdClick :function (column, record, rowIndex, colIndex, e) {
    	var me = this;
    	console.log(record.get("scheduleId"));
    	var jobStatusDetailPanel = me.getJobStatusDetailPanel();

    	me.getController('eRecon_web.controller.MainController')
    	  .activateCard({view: "eRecon_web.view.jobstatus.JobStatusContainer"},
			function() {	
				var filterPanel = me.getJobStatusFilterPanel();
				filterPanel.getForm().setValues({scheduleId: record.get("scheduleId")});
				
				var button = filterPanel.down("button[action=search]");
				button.fireEvent('click', button, Ext.EventObject);
			}
    	  );
    }
    
	
});

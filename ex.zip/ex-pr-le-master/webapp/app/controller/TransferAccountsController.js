Ext.define('eRecon_web.controller.TransferAccountsController',{
	extend: 'Ext.app.Controller',
	stores:	['eRecon_web.store.TransferSummaryStore','eRecon_web.store.TransferDetailStore','eRecon_web.store.TransferSubmitPOStore','eRecon_web.store.TransferSubmitAOStore'], 
    refs: [{
       ref: 'ThePanel',
       selector: 'transferaccounts_summarygrid'
    },
    {
        ref: 'detailPanel',
        selector: 'transferaccounts_detailgrid'
    },
    {
    	ref: 'filterForm',
    	selector: 'transfer_filterform'
    },
    {
    	ref: 'ownerForm',
    	selector: 'transfer_ownershipform'
    },
    {
    	ref: 'popForm',
    	selector: 'transfer_popup'
    },
    {
    	ref: 'recallForm',
    	selector: 'recall_confirm'
    }
    	
    ],
	init: function(){
		this.control({
			'transfer_ownershipform ':{
				afterrender: this.initialize
			},
			'transfer_ownershipform combo[action=select]':{
				select: this.setOwnerShip
			},
			'transferaccounts_summarygrid':{
				bankingGroupSelectionChange: this.setBankingGroup
			},
			"transfer_filterform button[action=search]": {
                click: this.transferFilterSearchClick
            },
            "transfer_filterform button[action=clear]": {
                click: this.clearFilterSettings
            },
			"transferaccounts_detailgrid button[action=transfer]": {
                click: this.transferAccounts
            },
            "transferaccounts_detailgrid button[action=transferall]": {
                click: this.transferallaccounts
            },
            "transferaccounts_detailgrid button[action=recall]": {
                click: this.recallaccounts
            },
            "transferaccounts_detailgrid button[action=recallall]": {
                click: this.recallallaccounts
            },
            "transferaccounts_detailgrid button[action=savecomments]": {
                click: this.saveComments
            },
            "transfer_popup":{
            	"transfertosubmit": this.transfertosubmit,
            	"transfertocancel": this.transfertocancel
            },
            "recall_confirm":{
            	"recallsubmit": this.recallsubmit,
            	"recallcancel": this.recallcancel
            },
            "transfer_popup combo[action=onSelect]": {
            	select:this.selectedValue
            },
            'transferaccounts_detailgrid': {
				edit: function(edt,e) {
					if (e.record.dirty) {
						e.grid.getView().refresh();
					}
				}
			}
            
		});
	},
	transferaction:null,
	recallaction:null,
	win:null,
	confwin:null,
	selectedtransferTo:null,
	initialize:function(){
			 this.win=Ext.create("eRecon_web.view.transferaccounts.transferPopup", {
	 			applyTo: Ext.getBody(),
		    		width: 300,
		    		height:150   
	 		});
	 		this.confwin=Ext.create("eRecon_web.view.transferaccounts.RecallConfirm", {
	 			applyTo: Ext.getBody(),
	 			layout: 'fit',
	 			width: 300,
	 			title: "Recall Message",
	 			height: 125   
	 		});
	},
	
	currentBankingGroup: null,
	setBankingGroup: function (selectedBankingGroup) {
			if(selectedBankingGroup!==null)
			{
				if (selectedBankingGroup !== this.currentBankingGroup) {
		        var detailStore = this.getStore('eRecon_web.store.TransferDetailStore');
		        var transferOwnerShipForm=this.getOwnerForm();
		        var filterPanel = this.getFilterForm();	
				filterPanel.getForm().reset();
		        var selectedownership = transferOwnerShipForm.down("#ownership-combo").getValue();
		        detailStore.getProxy().extraParams = {
		            0: selectedBankingGroup.get("businessGroup"),
		            1: selectedBankingGroup.get("reconPeriod"),
		            2:null,
		            3:null,
		            4:null,
		            5:null,
		            6:null,
		            7:selectedownership,
		            8:selectedBankingGroup.get("accounts")
		        };
		        detailStore.loadPage(1);
		        this.currentBankingGroup = selectedBankingGroup;
		    }
		 }
	},
	setOwnerShip: function () {
			var transferOwnerShipForm=this.getOwnerForm();
			var filterPanel = this.getFilterForm();
			var detailGrid= this.getDetailPanel();
            var selectedownership = transferOwnerShipForm.down("#ownership-combo").getValue();
            detailGrid.store.removeAll();
            var summaryStore = this.getStore('eRecon_web.store.TransferSummaryStore');
            summaryStore.directOptions = {};
            summaryStore.getProxy().extraParams = {
                0: selectedownership
            };
            summaryStore.loadPage(1);	
            var popupform=this.getPopForm();
    		var comboBox=popupform.down("#transferToList-combo");
    		var label = popupform.down("#transferToList-label");
            var postore = this.getStore('eRecon_web.store.TransferSubmitPOStore');
    		var aostore= this.getStore('eRecon_web.store.TransferSubmitAOStore');
            if(selectedownership==='AO')
            	{
            		filterPanel.down("#mgrId-combo").hide();
            		filterPanel.down("#acctOwner-combo").show();
            		detailGrid.down('[dataIndex=transfertouserid]').setVisible(false);
            		detailGrid.down('[dataIndex=transfer_to_acct_owner_id]').setVisible(true);
            		comboBox.bindStore(aostore);  
            		label.setText("Reconciliation Responsibility is not transferred until the new Account Owner has accepted the transfer.");
            		
            	}
            else if(selectedownership==='PO')
            	{
            		filterPanel.down("#mgrId-combo").show();
            		filterPanel.down("#acctOwner-combo").hide();
            		detailGrid.down('[dataIndex=transfertouserid]').setVisible(true);
            		detailGrid.down('[dataIndex=transfer_to_acct_owner_id]').setVisible(false);
            		comboBox.bindStore(postore);
            		label.setText("Reconciliation Responsibility is not transferred until the new Proof Owner has accepted the transfer.");
            	}
	},
	transferAccounts: function(){
			var detailPanel = this.getDetailPanel();
	    	var selectedRecords = detailPanel.getView().getSelectionModel().getSelection();
			if(selectedRecords.length == 0) {
	    		Ext.MessageBox.alert( "Alert", "No Records Have Been Selected");
	    		return false;
			}
    	    this.transferaction='Transfer';    	   
	    	this.win.show();

	},		
	transferallaccounts: function(){
			this.transferaction='Transferall'
	    	this.win.show();

	},		
	recallaccounts: function(){
			var detailPanel = this.getDetailPanel();
	    	var selectedRecords = detailPanel.getView().getSelectionModel().getSelection();
			if(selectedRecords.length == 0) {
	    		Ext.MessageBox.alert( "Alert", "No Records Have Been Selected");
	    		return false;
			}
			this.recallaction='Recall';
			this.confwin.show();		

	},		
	recallallaccounts: function(){
		    this.recallaction='Recallall';
			this.confwin.show();
	},
	transfertosubmit: function(o){
			var me = this;
			var transferOwnerShipForm=this.getOwnerForm();
	 		var role = transferOwnerShipForm.down("#ownership-combo").getValue();
	 		var popupform= this.getPopForm();
	 		var filterPanel = this.getFilterForm();
	 		var transferOwnerShipForm=this.getOwnerForm();
        	var selectedownership = transferOwnerShipForm.down("#ownership-combo").getValue();
            var fullKey = filterPanel.down("#fullKey-text").getValue();
	 		var transferTo= this.selectedtransferTo;
	 		var filter = filterPanel.down("#fiter-combo").getValue();
            var condi = filterPanel.down("#condi-text").getValue();
            if(transferTo=='' || transferTo==null){
	 			Ext.MessageBox.alert( "Alert","Please select appropriate AO/PO in the list");
	        	return false;
	 		}
            if(selectedownership==='AO')
        	{
        		managerFilter=filterPanel.down("#acctOwner-combo").getValue();
        	}
            else if(selectedownership==='PO')
        	{
        		managerFilter=filterPanel.down("#mgrId-combo").getValue();
        	}
        	var businessUnit = this.currentBankingGroup.get("businessGroup");
            var reconPeriod  = this.currentBankingGroup.get("reconPeriod");
	 		var detailPanel = this.getDetailPanel(); 	
			var dataArray = [];
			var detailStore= this.getStore('eRecon_web.store.TransferDetailStore');
			if(this.transferaction==='Transfer'){
				var data =detailPanel.getView().getSelectionModel().getSelection();
				Ext.each(data, function(item, index, array) {
				    dataArray.push({
						"newData" : item.data,
				    	"previousData" : item.raw,
				    	"modified" : item.modified 
				    });
				});
				var encodedArray = Ext.encode(dataArray);
				eRecon_web.direct.action.TransferService.transferAccounts(encodedArray,role,transferTo, function(p, response) {
			        	if(response.result !== "Error") {
				        	me.getController('MainController').showStatus(response.result);
			        		detailStore.load();
			    		}
			        	
			    });
			}
			else if (this.transferaction==='Transferall'){
				eRecon_web.direct.action.TransferService.transferAllAccounts(businessUnit,reconPeriod,role,condi,fullKey,filter,managerFilter,transferTo, function(p, response) {
		        	if(response.result !== "Error") {
			        	me.getController('MainController').showStatus(response.result);
		        		detailStore.load();
		    		}
		        	
				});
			}
		    popupform.down("#transferToList-combo").setValue('');
		    this.selectedtransferTo = null;
		    this.win.hide();
			
	},
	transfertocancel:function(o){
			var popupform= this.getPopForm();
			popupform.down("#transferToList-combo").setValue('');
			this.selectedtransferTo = null;
			this.win.hide();
		
	},
	recallsubmit:function(o){
			var me = this;
			var transferOwnerShipForm=this.getOwnerForm();
			var role = transferOwnerShipForm.down("#ownership-combo").getValue();
			var detailPanel = this.getDetailPanel(); 	
			var filterPanel = this.getFilterForm();
	 		var transferOwnerShipForm=this.getOwnerForm();
        	var selectedownership = transferOwnerShipForm.down("#ownership-combo").getValue();
            var fullKey = filterPanel.down("#fullKey-text").getValue();
	 		var filter = filterPanel.down("#fiter-combo").getValue();
            var condi = filterPanel.down("#condi-text").getValue();
            if(selectedownership==='AO')
        	{
        		managerFilter=filterPanel.down("#acctOwner-combo").getValue();
        	}
            else if(selectedownership==='PO')
        	{
        		managerFilter=filterPanel.down("#mgrId-combo").getValue();
        	}
        	var businessUnit = this.currentBankingGroup.get("businessGroup");
            var reconPeriod  = this.currentBankingGroup.get("reconPeriod");
			var dataArray = [];
			var detailStore= this.getStore('eRecon_web.store.TransferDetailStore');
			if(this.recallaction==='Recall'){
				var data =detailPanel.getView().getSelectionModel().getSelection();
				Ext.each(data, function(item, index, array) {
				    dataArray.push({
						"newData" : item.data,
				    	"previousData" : item.raw,
				    	"modified" : item.modified 
				    });
				});
				var encodedArray = Ext.encode(dataArray);
				eRecon_web.direct.action.TransferService.recallAccounts(encodedArray,role, function(p, response) {
				    	if(response.result !== "Error") {
				        	me.getController('MainController').showStatus(response.result);
				    		detailStore.load();
						}
				    	
				});
			}
			else if (this.recallaction==='Recallall'){
				eRecon_web.direct.action.TransferService.recallAllAccounts(businessUnit,reconPeriod,role,condi,fullKey,filter,managerFilter, function(p, response) {
		        	if(response.result !== "Error") {
			        	me.getController('MainController').showStatus(response.result);
		        		detailStore.load();
		    		}
		        	
				});
			}
			this.confwin.hide();
	
	},

	recallcancel:function(o){			
			this.confwin.hide();
			
	},
	transferFilterSearchClick: function () {
	    if (this.currentBankingGroup !== null) {
	        var filterPanel = this.getFilterForm();
	        var transferOwnerShipForm=this.getOwnerForm();
	        if (filterPanel.getForm().isValid()) {
        	var selectedownership = transferOwnerShipForm.down("#ownership-combo").getValue();
            var fullKey = filterPanel.down("#fullKey-text").getValue();
            var managerFilter;
            if(selectedownership==='AO')
            	{
            		managerFilter=filterPanel.down("#acctOwner-combo").getValue();
            	}
            else if(selectedownership==='PO')
            	{
            		managerFilter=filterPanel.down("#mgrId-combo").getValue();
            	}
            var filter = filterPanel.down("#fiter-combo").getValue();
            var sortBy = filterPanel.down("#sortBy-combo").getValue();
            var condi = filterPanel.down("#condi-text").getValue();
            var detailsStore = this.getStore('eRecon_web.store.TransferDetailStore');
            detailsStore.directOptions = {};
            detailsStore.getProxy().extraParams = {
                0: this.currentBankingGroup.get("businessGroup"),
                1: this.currentBankingGroup.get("reconPeriod"),
                2: fullKey,
                3: managerFilter,
                4: filter,
                5: sortBy,
                6: condi,
                7: selectedownership,
                8: this.currentBankingGroup.get("accounts")
            };
            detailsStore.loadPage(1,{
                callback: function (records, operation, success) {
                }
            });
	        }
	    }
	},
	clearFilterSettings: function(){
		var filterPanel = this.getFilterForm();	
		filterPanel.getForm().reset();
	},
	saveComments:function(){
		var store = this.getStore('eRecon_web.store.TransferDetailStore');
		var dataArray = [];
		var data = store.getUpdatedRecords(); 
		if(data.length == 0) {
	    		Ext.MessageBox.alert( "Alert", "No changes found");
	    		return false;
	    }
	    Ext.each(data, function(item, index, array) {
	        dataArray.push({
				"newData" : item.data,
	        	"previousData" : item.raw,
	        	"modified" : item.modified 
	        });
	    });
	    var encodedArray = Ext.encode(dataArray);
	    eRecon_web.direct.action.TransferService.saveComments(encodedArray, function(p, response) {
	    	if(response.result == "Success") {
	    		store.load();
	    		
	    	}
	    	Ext.MessageBox.alert( "Status", response.result );
	    });      
	},
	selectedValue : function(){
		var popupform = this.getPopForm();
		this.selectedtransferTo = popupform.down("#transferToList-combo").getValue();
	}
});

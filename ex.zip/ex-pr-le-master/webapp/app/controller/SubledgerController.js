Ext.define('eRecon_web.controller.SubledgerController', {
    extend: 'Ext.app.Controller',
    requires: ['eRecon_web.store.BankingGroupStore', 'eRecon_web.store.SubledgerDetailStore','eRecon_web.store.SubledgerDescriptionStore'],
    stores: ['eRecon_web.store.BankingGroupStore', 'eRecon_web.store.SubledgerDetailStore','eRecon_web.store.SubledgerDescriptionStore'],
    refs: [
        {
        	ref : 'summaryPanel',
            selector: 'subledger_summarygrid'
        },
        {
            ref: 'detailPanel',
            selector: 'subledger_detailgrid'
        },
        {
            ref: "filterPanel",
            selector: "subledger_filterform"
        },
        {
        	ref: "displaySubmittedButton",
        	selector: "subledger_detailgrid button[action=display_submitted]"
        },
        {
        	ref: "displayAllButton",
        	selector: "subledger_detailgrid button[action=display_all]"
        }
    ],

    init: function () {
		var me = this;
    	var store = this.getStore('eRecon_web.store.SubledgerDetailStore');
    	store.on({
    		load:  this.doHandleHeaderCheckboxes,
    		scope:  this            
    	});

    	
        this.control(/*{
         'subledger_detailgrid': {
         checkchange: this.onCheckchange
         }
         },*/
            {
                'subledger_summarygrid button[action=Refresh]': {
                    click: this.refreshSummayView
                },
                'subledger_summarygrid': {
                    bankingGroupSelectionChange: {
                		fn: me.setBankingGroup,
                		buffer: 300
                	},
                	load: me.onLoad()
                },
                
                'subledger_filterform': {
                	collapse: {
                		fn: function() {
                			me.getFilterPanel().up('subledger_container').updateLayout();
                		},
                		buffer: 500
                	},
                	
					expand: {
						fn: function() {
							me.getFilterPanel().up('subledger_container').updateLayout();
						},
						buffer: 500
					}

                },


                "subledger_filterform button[action=search]": {
                    click: this.filterSearchClick
                },
                "subledger_filterform button[action=clear]": {
                    click: this.doClearFilter
                },
                "subledger_detailgrid": {
                	showAgingDialog: Ext.Function.createBuffered(function(grid, rowIndex) {
                		me.showAgingDialog(grid, rowIndex);
                	}, 100, me)
                },
                "subledger_detailgrid button[action=save]": {
                    click: {
            			fn: me.doSaveAction,
            			delay: 100
            		}
                },
                "subledger_detailgrid button[action=submit]": {
                    click: this.doSubmitAction
                },
                "subledger_detailgrid button[action=unsubmit]": {
                    click: this.doUnSubmitAction
                },
                "subledger_detailgrid button[action=unsubmitall]": {
                    click: this.doUnSubmitAllAction
                },
                "subledger_detailgrid button[action=export]": {
                    click: this.doExportAction
                },
                "subledger_detailgrid button[action=display_submitted]": {
                    click: this.doDisplaySubmittedAction
                },
                "subledger_detailgrid button[action=display_all]": {
                    click: this.doDisplayAllAction
                },
                "subledger_filterform combo[action=descriptionChange]":{
                	change: this.loadautocomplete         	
                }
                
            });
    },

    onLoad: function () {
        var store = this.getStore('eRecon_web.store.BankingGroupStore');
        store.load();
    },
    loadautocomplete: function()
	{	
		var me = this;
		var filterPanel = this.getFilterPanel();
		var descriptionCombo = filterPanel.down("#description-text");
		var description = "";		
		description = filterPanel.down("#description-text").getValue();	
		if(description && description.indexOf("%") != 0){
			var descriptionStore= this.getStore('eRecon_web.store.SubledgerDescriptionStore');		
			descriptionStore.getProxy().extraParams = {0 : description}; 
			descriptionStore.load();
			descriptionStore.load({
		    	   scope: me,
		    	   params: {0: description},
		    	   callback: function(records, operation, sucsess){
		    		   descriptionCombo.bindStore(descriptionStore);
		    	   }
		     }); 
		}		
	},
    
    refreshSummayView: function() {
    	 var store = this.getStore('eRecon_web.store.BankingGroupStore');
    	
    	 var summaryPanel = this.getSummaryPanel();
    	 var selectedRecords = summaryPanel.getView().getSelectionModel().getSelection();
    	 summaryPanel.getView().getSelectionModel().setLastFocused(selectedRecords[0]);
         store.load({
        	 callback: function(records, operation, sucsess){
        		 if(selectedRecords.length > 0) {
        			 summaryPanel.getView().getSelectionModel().select(selectedRecords[0].index, false, true);
        		 }
             }
         });
    },

    currentBankingGroup: null,
    statusCode: null,

    setBankingGroup: function (selectedBankingGroup) {
        if (selectedBankingGroup !== this.currentBankingGroup) {
            var detailStore = this.getStore('eRecon_web.store.SubledgerDetailStore');
            var filterPanel = this.getFilterPanel();
        	filterPanel.getForm().reset();
            detailStore.getProxy().extraParams = {
                0: selectedBankingGroup.get("bankingGroup"),
                1: selectedBankingGroup.get("reconPeriod"),
                2: null, // no-fullKey specified
                3: null, // no managerId specified
                4: null, // no filter
                5: null, // no sortby
                6: null, // no description
                7: null, // no condi
                8: null, // no Submitted only
                9: selectedBankingGroup.get("accounts"),
                10: selectedBankingGroup.get("submittedAccounts"),
                11: selectedBankingGroup.get("unSubmittedAccounts")
            };
            
            /*var detailPanel = this.getDetailPanel();
            detailStore.pageSize = parseInt(detailPanel.down("#pagesizeid").getValue(), 10);*/
            detailStore.loadPage(1, 
            	{
            		callback: function() {
            			filterPanel.up('subledger_container').updateLayout();
            		}
            	}
            );
            this.currentBankingGroup = selectedBankingGroup;
//            this.doClearFilter();
            var displayAllButton = Ext.getCmp('subledgerDetail_displayAll');
        	var displaySubmittedButton = Ext.getCmp('subledgerDetail_displaySubAccount');
        	displaySubmittedButton.setVisible(true);
        	displayAllButton.setVisible(false);
        	var displayUnSubmitAllButton = Ext.getCmp('subledgerDetail_unsubmit_all');
        	displayUnSubmitAllButton.setVisible(false);
        }
    },
    
    filterSearchClick: function () {
        if (this.currentBankingGroup !== null) {
            var filterPanel = this.getFilterPanel();
            var filterParams = this.getFilterParams();
            if (filterPanel.getForm().isValid()) {
                var detailsStore = this.getStore('eRecon_web.store.SubledgerDetailStore');
                detailsStore.directOptions = {};
                detailsStore.getProxy().extraParams = {
                    0: filterParams.currentBankingGroup.get("bankingGroup"),
                    1: filterParams.currentBankingGroup.get("reconPeriod"),
                    2: filterParams.fullKey,
                    3: filterParams.managerId,
                    4: filterParams.filter,
                    5: filterParams.sortBy,
                    6: filterParams.description,
                    7: filterParams.condi,
                    8: filterParams.statusCode, // no Submitted only
                    9: filterParams.currentBankingGroup.get("accounts"),
                    10: filterParams.currentBankingGroup.get("submittedAccounts"),
                    11: filterParams.currentBankingGroup.get("unSubmittedAccounts")
                };
                var localcurreentBankingGroup;
                localcurreentBankingGroup=this.currentBankingGroup;
                detailsStore.loadPage(1, {
                    callback: function (records, operation, success) {
                    	filterPanel.up('subledger_container').updateLayout();
                    	if((filterParams.filter == 'Unsubmitted Accounts') && (filterParams.managerId!=null) && (filterParams.condi!=null) && (filterParams.fullKey!=null)){
                         	var rec = detailsStore.getAt(0);
                         	if(null!=rec){
                         		var submittedAccts = rec.get("submittedAccounts");
                         		var unSubmittedAccts = rec.get("unSubmittedAccounts");
                         		localcurreentBankingGroup.set("submittedAccounts",submittedAccts);
                         		localcurreentBankingGroup.set("unSubmittedAccounts",unSubmittedAccts);
                         	}
                       }
                    }
                });
            }
        }
    },
    doClearFilter: function () {
    	var filterPanel = this.getFilterPanel();
    	filterPanel.getForm().reset();
    	
    	//Hide Display all button. Show Display submitted button.
    	this.getDisplaySubmittedButton().setVisible(true);
    	this.getDisplayAllButton().setVisible(false);
    	
    	
    	var filterParams = this.getFilterParams();
    	if(filterParams.currentBankingGroup == null) {
    		return true;
    	}
        
    	
    	var detailsStore = this.getStore('eRecon_web.store.SubledgerDetailStore');
        detailsStore.directOptions = {};
        detailsStore.getProxy().extraParams = {
            0: filterParams.currentBankingGroup.get("bankingGroup"),
            1: filterParams.currentBankingGroup.get("reconPeriod"),
            2: filterParams.fullKey,
            3: filterParams.managerId,
            4: filterParams.filter,
            5: filterParams.sortBy,
            6: filterParams.description,
            7: filterParams.condi,
            8: filterParams.statusCode, // no Submitted only
            9: filterParams.currentBankingGroup.get("accounts"),
            10: filterParams.currentBankingGroup.get("submittedAccounts"),
            11: filterParams.currentBankingGroup.get("unSubmittedAccounts")
        };
        detailsStore.loadPage(1, {
            callback: function (records, operation, success) {
        		filterPanel.up('subledger_container').updateLayout();
        	}
        });
    	
    },
    onCheckchange: function (column, rowIndex, checked) {
        console.log(checked);
    },
    doSaveAction : function() {
    	var me = this;
    	var store = this.getStore('eRecon_web.store.SubledgerDetailStore');
    	
    	var dataArray = [];
        var data = store.getUpdatedRecords();
        if(data.length == 0) {
    		Ext.MessageBox.alert( "Alert", "No changes found");
    		return false;
    	}
        
        Ext.each(data, function(item, index, array) {
            dataArray.push({
    			"newData" : item.data,
            	"previousData" : item.raw,
            	"modified" : item.modified 
            });
        });
        var encodedArray = Ext.encode(dataArray);
        
        eRecon_web.direct.action.SubledgerService.saveSubledgerDetails(encodedArray, function(p, response) {
        	if(response.result == "Success") {
        		var filterParams = me.getFilterParams();
                store.getProxy().extraParams = {
                    0: filterParams.currentBankingGroup.get("bankingGroup"),
                    1: filterParams.currentBankingGroup.get("reconPeriod"),
                    2: filterParams.fullKey,
                    3: filterParams.managerId,
                    4: filterParams.filter,
                    5: filterParams.sortBy,
                    6: filterParams.description,
                    7: filterParams.condi,
                    8: filterParams.statusCode,
                    9: filterParams.currentBankingGroup.get("accounts"),
                    10: filterParams.currentBankingGroup.get("submittedAccounts"),
                    11: filterParams.currentBankingGroup.get("unSubmittedAccounts")
                };
            	
            	store.load({
                    callback: function (records, operation, success) {
            			me.getFilterPanel().up('subledger_container').updateLayout();            		
                    }
                });
    		}
        	me.getController('MainController').showStatus('Successfully Saved the record.');
        });
    },
    doSubmitAction : function() {
    	var me = this;
    	var detailPanel = this.getDetailPanel();
    	var selectedRecords = detailPanel.getView().getSelectionModel().getSelection();
    	if(selectedRecords.length == 0) {
    		Ext.MessageBox.alert( "Error", "No rows selected");
    		return false;
    	}
    	
    	var summaryPanel = this.getSummaryPanel();
		var summaryPanelSelectedRecord = summaryPanel.getView().getSelectionModel().getSelection();
		var summaryPanelStore = this.getStore('eRecon_web.store.BankingGroupStore');
		var rowIndex = summaryPanelSelectedRecord[0].index;
		
    	var dataArray = [];
    	var stopIteration;
    	
    	var fullKeys = new Array();
    	Ext.each(selectedRecords, function(item, index, array) {
    		if(item.data.manualrecon == 0 && item.data.autorecon == 0) {
    			stopIteration = true;
    			fullKeys.push(item.data.fullKey);
    		}
    	});
    	
    	if(stopIteration) {
    		Ext.MessageBox.alert( "Error", "A recon type of Auto or Manual must be selected before you can enter aging details for this fullkey." + fullKeys.toString());
    		return false;
    	}
    	
    	fullKeys = new Array();
    	Ext.each(selectedRecords, function(item, index, array) {
    		if((item.data.agree == 0 && item.data.glBalance != item.data.slBalance) || (item.data.manualrecon == 0 && item.data.autorecon == 0)) {
    			stopIteration = true;
    			fullKeys.push(item.data.fullKey);
    		}
    	});
    	
    	if(stopIteration) {
    		Ext.MessageBox.alert( "Error", "The record(s) with the following Full Key(s) has to be aged.<br/>" + fullKeys.toString());
    		return false;
    	}
    	
    	Ext.each(selectedRecords, function(item, index, array) {
    		dataArray.push({
    			"newData" : item.data,
    			"previousData" : item.raw,
    			"modified" : item.modified 
    		});
    	});
    		
    	var encodedArray = Ext.encode(dataArray);
    	eRecon_web.direct.action.SubledgerService.submitSubledgerDetails(encodedArray, function(p, response) {
    		if(response.result.successMsg!== null) {
    			summaryPanelStore.load({
                    callback : function(r, options, success) {
                        summaryPanel.getView().getSelectionModel().select(rowIndex ,false, true);
                        var store = me.getStore('eRecon_web.store.SubledgerDetailStore');
                		var filterParams = me.getFilterParams();
                        store.getProxy().extraParams = {
                            0: filterParams.currentBankingGroup.get("bankingGroup"),
                            1: filterParams.currentBankingGroup.get("reconPeriod"),
                            2: filterParams.fullKey,
                            3: filterParams.managerId,
                            4: filterParams.filter,
                            5: filterParams.sortBy,
                            6: filterParams.description,
                            7: filterParams.condi,
                            8: filterParams.statusCode,
                            9: filterParams.currentBankingGroup.get("accounts"),
                            10: filterParams.currentBankingGroup.get("submittedAccounts"),
                            11: filterParams.currentBankingGroup.get("unSubmittedAccounts")
                        };
                    	
                    	store.load({
                            callback: function (records, operation, success) {
                    			me.getFilterPanel().up('subledger_container').updateLayout();
                            }
                        });
                    }
				});
				me.getController('MainController').showStatus(response.result.successMsg);
    		}
    		else{
    			me.getController('MainController').showStatus(response.result.errMsg);
		     }
		});
    },
    doExportAction : function() {
    	console.log("Export action called");
    	var filterParams = this.getFilterParams();
    	if (filterParams.currentBankingGroup !== null) {
    		var formdata = {
    				bankingGroup: filterParams.currentBankingGroup.get("bankingGroup"),
    				reconPeriod: filterParams.currentBankingGroup.get("reconPeriod"),
    				fullKey: filterParams.fullKey,
    				statusCode: filterParams.statusCode,
    				managerId:filterParams.managerId,
    				filter:filterParams.filter,
    				sortBy:filterParams.sortBy,
    				description:filterParams.description,
    				condi: filterParams.condi
    		}
    		
    		
    		Ext.Ajax.request({
    			url : 'filedownloadtrigger.up?downloadType=SUBLEDGER',
    			method:'POST', 
    			params : {
    				formdata: Ext.encode(formdata)
    			},
    			scope : this,
    			success : function(response, opts) {
    				response = Ext.decode(response.responseText);
    				if(response.success){
    					Ext.MessageBox.alert('Successful', 
    							"Your request has been submitted successfully with the request id " + response.scheduleId + ". You should recieve an email on completion.");
    				}
    				else {
    					Ext.MessageBox.alert('Failed', response.message);
    				}
    			},
    			failure : function(err) {
    				Ext.MessageBox.alert('Error occured during Subledger file download.', 'Please try again!');
    			}
    		}); 		

    	} else {
    		Ext.MessageBox.alert( "Alert", "No rows selected in the summary grid." );
    	}
    },
    doDisplaySubmittedAction : function() {
    	var me = this;
    	var displayAllButton = Ext.getCmp('subledgerDetail_displayAll');
    	var displaySubmittedButton = Ext.getCmp('subledgerDetail_displaySubAccount');
    	displaySubmittedButton.setVisible(false);
    	displayAllButton.setVisible(true);
    	
    	var displayUnSubmitAllButton = Ext.getCmp('subledgerDetail_unsubmit_all');
    	displayUnSubmitAllButton.setVisible(true);
    	var filterParams = this.getFilterParams();
    	var store = this.getStore('eRecon_web.store.SubledgerDetailStore');
    	store.getProxy().extraParams = {
            0: filterParams.currentBankingGroup.get("bankingGroup"),
            1: filterParams.currentBankingGroup.get("reconPeriod"),
            2: filterParams.fullKey,
            3: filterParams.managerId,
            4: filterParams.filter,
            5: filterParams.sortBy,
            6: filterParams.description,
            7: filterParams.condi,
            8: '1',
            9: 0,
            10: filterParams.currentBankingGroup.get("submittedAccounts"),
            11: filterParams.currentBankingGroup.get("unSubmittedAccounts")
        };
    	
    	store.load({
            callback: function (records, operation, success) {
            	this.statusCode = "S";
            	me.getFilterPanel().up('subledger_container').updateLayout();
            }
        });
    	
    },
    doDisplayAllAction: function() {
    	var me = this;
    	var displayAllButton = Ext.getCmp('subledgerDetail_displayAll');
    	var displaySubmittedButton = Ext.getCmp('subledgerDetail_displaySubAccount');

    	displaySubmittedButton.setVisible(true);
    	displayAllButton.setVisible(false);
    	
    	var displayUnSubmitAllButton = Ext.getCmp('subledgerDetail_unsubmit_all');
    	displayUnSubmitAllButton.setVisible(false);

    	var store = this.getStore('eRecon_web.store.SubledgerDetailStore');
    	store.getProxy().extraParams = {
            0: this.currentBankingGroup.get("bankingGroup"),
            1: this.currentBankingGroup.get("reconPeriod"),
            2: null,
            3: null,
            4: null,
            5: null,
            6: null,
            7: null,
            8: null,
            9: this.currentBankingGroup.get("accounts"),
            10: this.currentBankingGroup.get("submittedAccounts"),
            11: this.currentBankingGroup.get("unSubmittedAccounts")
        };
    	
    	store.load({
            callback: function (records, operation, success) {
            	this.statusCode = null;
            	me.getFilterPanel().up('subledger_container').updateLayout();
            }
        });
    	
    },
    doUnSubmitAction : function() {
    	var me = this;
    	var detailPanel = this.getDetailPanel();
    	var selectedRecords = detailPanel.getView().getSelectionModel().getSelection();
    	if(selectedRecords.length == 0) {
    		Ext.MessageBox.alert( "Error", "No rows selected.");
    		return false;
    	}
    	
    	var isAgreedFlag = false;
    	Ext.each(selectedRecords, function(item, index, array) {
    		if(item.data.agreedFlag == 'Agreed' || item.data.attestedFlag == 'Y') {
    			isAgreedFlag = true;
    			return false;
    		}
    	});
    	
    	if(isAgreedFlag) {
    		Ext.MessageBox.alert( "Error", "Cannot unsubmit Attested or Agreed records.");
    		return false;
    	}
    	
    	var summaryPanel = this.getSummaryPanel();
		var summaryPanelSelectedRecord = summaryPanel.getView().getSelectionModel().getSelection();
		var summaryPanelStore = this.getStore('eRecon_web.store.BankingGroupStore');
		var rowIndex = summaryPanelSelectedRecord[0].index;
		
		
    	var dataArray = [];
    	Ext.each(selectedRecords, function(item, index, array) {
    		dataArray.push({
    			"newData" : item.data,
    			"previousData" : item.raw,
    			"modified" : item.modified 
    		});
    	});
    	var encodedArray = Ext.encode(dataArray);
    	eRecon_web.direct.action.SubledgerService.unSubmitSubledgerDetails(encodedArray, function(p, response) {
    		if(response.result.successMsg!== null) {
    			summaryPanelStore.load({
                    callback : function(r, options, success) {
                        summaryPanel.getView().getSelectionModel().select(rowIndex ,false, true);
                        var store = me.getStore('eRecon_web.store.SubledgerDetailStore');
                		var filterParams = me.getFilterParams();
                        store.getProxy().extraParams = {
                            0: filterParams.currentBankingGroup.get("bankingGroup"),
                            1: filterParams.currentBankingGroup.get("reconPeriod"),
                            2: filterParams.fullKey,
                            3: filterParams.managerId,
                            4: filterParams.filter,
                            5: filterParams.sortBy,
                            6: filterParams.description,
                            7: filterParams.condi,
                            8: filterParams.statusCode,
                            9: filterParams.currentBankingGroup.get("accounts"),
                            10: filterParams.currentBankingGroup.get("submittedAccounts"),
                            11: filterParams.currentBankingGroup.get("unSubmittedAccounts")
                        };
                    	
                    	store.load({
                            callback: function (records, operation, success) {
                    			me.getFilterPanel().up('subledger_container').updateLayout();
                            }
                        });
                    }
				});
	        	me.getController('MainController').showStatus(response.result.successMsg);
    		}else{
	        	me.getController('MainController').showStatus(response.result.errMsg);
    		}
    	});
    	
    }, 
    
    doUnSubmitAllAction : function() {
    	var me = this;
    	var detailPanel = this.getDetailPanel();
    	
    	var summaryPanel = this.getSummaryPanel();
		var summaryPanelSelectedRecord = summaryPanel.getView().getSelectionModel().getSelection();
		var summaryPanelStore = this.getStore('eRecon_web.store.BankingGroupStore');
		var rowIndex = summaryPanelSelectedRecord[0].index;
		
		var store = this.getStore('eRecon_web.store.SubledgerDetailStore');
    	
		
		if(store.count() <= 0 ) {
			Ext.MessageBox.alert( "Error", "No records found.");
    		return false;
		}
		
		var isAgreedFlag = false;
		store.each(function(rec) {
			if(rec.data.agreedFlag == 'Agreed' || rec.data.attestedFlag == 'Y') {
    			isAgreedFlag = true;
    			return false;
    		}
        });
		
		if(isAgreedFlag) {
    		Ext.MessageBox.alert( "Error", "Cannot unsubmit Attested or Agreed records.");
    		return false;
    	}
		
		Ext.MessageBox.confirm('Confirm', 'Are you sure you want to unsubmit all the displayed accounts?', 
				function(btn) {
					if(btn==='yes') {
						var dataArray = [];
				    	store.each(function(rec) {
				    		dataArray.push({
				    			"newData" : rec.data
				    		});
				        });
				    	
				    	var encodedArray = Ext.encode(dataArray);
				    	eRecon_web.direct.action.SubledgerService.unSubmitSubledgerDetails(encodedArray, function(p, response) {
				    		if(response.result.successMsg!== null) {
				    			summaryPanelStore.load({
				                    callback : function(r, options, success) {
				                        summaryPanel.getView().getSelectionModel().select(rowIndex ,false, true);
				                        var store = me.getStore('eRecon_web.store.SubledgerDetailStore');
				                		var filterParams = me.getFilterParams();
				                        store.getProxy().extraParams = {
				                            0: filterParams.currentBankingGroup.get("bankingGroup"),
				                            1: filterParams.currentBankingGroup.get("reconPeriod"),
				                            2: filterParams.fullKey,
				                            3: filterParams.managerId,
				                            4: filterParams.filter,
				                            5: filterParams.sortBy,
				                            6: filterParams.description,
				                            7: filterParams.condi,
				                            8: filterParams.statusCode,
				                            9: filterParams.currentBankingGroup.get("accounts"),
				                            10: filterParams.currentBankingGroup.get("submittedAccounts"),
				                            11: filterParams.currentBankingGroup.get("unSubmittedAccounts")
				                        };
				                    	
				                    	store.load({
				                            callback: function (records, operation, success) {
				                    			me.getFilterPanel().up('subledger_container').updateLayout();
				                            }
				                        });
				                    }
								});
					        	me.getController('MainController').showStatus(response.result.successMsg);
				    		}else{
					        	me.getController('MainController').showStatus(response.result.errMsg);
				    		}
				    	});
					}
		});
		
    	
    	
    }, 
    
    doHandleHeaderCheckboxes : function() {
    	console.log("check boxes reset");
        Ext.query('#manualReconSelectAllCb')[0].checked = false;
        Ext.query('#autoReconSelectAllCb')[0].checked = false;
        Ext.query('#agreeSelectAllCb')[0].checked = false;
    }, 
    
    showAgingDialog: function(grid, rowIndex) {
    	var vprt = Ext.ComponentQuery.query('viewport')[0]; 
		vprt.setLoading(true);
    	var contr = this.getController("eRecon_web.controller.AgingController");
		if (!contr.wasInit) {
	    	contr.init();
	    	contr.wasInit = true;
    	}
		
		
    	var rec = grid.getStore().getAt(rowIndex);
    	Ext.defer(function() {
	    	var agingDialog = Ext.create('eRecon_web.view.common.CustomDialog', {
	    		items : {
	    			xtype : 'aging_tabcontainer'
	    		},
	    		title : "Age",
	    		id : "AgingDetails",
	    		
				autoScroll:true,
				headerPosition: 'top',
				layout: 'form',
	    		
	    		extraParams : {
	    			FullKey : rec.get("fullKey"),
	    			GLBalance : rec.get("glBalance"),
	    			SLBalance : rec.get("slBalance"),
	    			AutoReconType : rec.get("autorecon"),
	    			AgingType : rec.get("agingType"),
	    			ManualReconType : rec.get("manualrecon"),
	    			AgingBenchMark : rec.get("agingBenchmark"),
	    			AccountId : rec.get("accountId"),
	    			StatusIndicator : rec.get("statusindicator"),
	    			Reconperiod : rec.get("reconperiod"),
	    			LCL_CCY_Threshold : rec.get("lcl_ccy_threshold"),
	    			BenchMarkViolation : rec.get("benchmarkviolation"),
	    			Comments : rec.get("comments")
	    		},
	    		
	    		listeners: {
	    			show: function() {
	    				console.log("showAgingDialog called.");
	    			}
	    		}
			});   
	    	agingDialog.show();
	    	vprt.setLoading(false);
	   	},25); // end of defer
    },
    getFilterParams: function() {
    	var filterPanel = this.getFilterPanel();
    	var fullKey = filterPanel.down("#fullKey-text").getValue();
    	var managerId = filterPanel.down("#mgrId-combo").getValue();
    	var filter = filterPanel.down("#fiter-combo").getValue();
    	var sortBy = filterPanel.down("#sortBy-combo").getValue();
    	var condi = filterPanel.down("#condi-text").getValue();
    	var description = filterPanel.down("#description-text").getValue();
    	var statusCode = null;
    	if(!this.getDisplaySubmittedButton().isVisible()) {
    		statusCode = '1';
    	}
    	
    	var filterParams = {
    			fullKey: fullKey == "" || fullKey == null ? null : fullKey,
    			managerId: managerId,
    			filter : filter,
    			sortBy : sortBy,
    			description : description,
    			condi : condi == "" || condi == null ? null : condi,
    			currentBankingGroup : this.currentBankingGroup,
    			statusCode: statusCode
    	};
    	return filterParams;
    }
});
	

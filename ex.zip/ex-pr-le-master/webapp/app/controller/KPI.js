Ext.define("eRecon_web.controller.KPI",{
  extend:"Ext.app.Controller",
  stores:[
	 "eRecon_web.store.chart.AllTabsPieChartStore"	
  ], 
    
  refs:[{ref:"allTabsPieChart", selector:"allTabsPieChart"}],
   
  init: function() {
	this.control({
	  "erecon_kpi_panel": {
		"activate":this.initializeComponents
	  }
   }); 
  },
  
  initializeComponents: function() {

	var tabsChartStore = this.getAllTabsPieChart().getStore();
	tabsChartStore.getProxy().extraParams = {
	  0: null
    };
	tabsChartStore.load();
  }
});

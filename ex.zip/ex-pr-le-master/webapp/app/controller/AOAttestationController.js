Ext.define('eRecon_web.controller.AOAttestationController', {
    extend: 'Ext.app.Controller',
	requires: ['eRecon_web.store.AOAttestationSummaryStore',
			'eRecon_web.store.AOAttestationDetailStore',
			'eRecon_web.store.AOUplaodBusinessUnitStore',
			'eRecon_web.store.AOUplaodProofOwnerStore', 
			'eRecon_web.store.AOUplaodAcctOwnerStore'],
    stores: ['eRecon_web.store.AOAttestationSummaryStore',
             'eRecon_web.store.AOAttestationDetailStore',
             'eRecon_web.store.AOUplaodBusinessUnitStore',
             'eRecon_web.store.AOUplaodProofOwnerStore', 
             'eRecon_web.store.AOUplaodAcctOwnerStore'],
	refs: [{
	    ref: 'summaryContainer',
	    selector: 'aoattestation_aosummaryform'
	 },
	 {
	     ref: 'detailPanel',
	     selector: 'aoattestation_detailgrid'
	 },
	 {
	 	ref: 'filterForm',
	 	selector: 'aoattestation_filterform'
	 },
	 {
		ref: 'ownerForm',
	 	selector: 'aoattestation_acctownerform' 
	 },
	 {
		ref: 'uploadForm',
	 	selector: 'aoupload_container' 
	 },
	 {
		ref: 'downloadPanel',
	 	selector: 'aodownload_panel' 
	 }
	 ],
    init: function () {
        this.control({
            'aoattestation_acctownerform combo[action=select]': {
            	select: this.populateSummaryForm
            }, 
            'aoattestation_aosummaryform button[action=redirect]': {
            	click: this.redirect
            },
            'aoattestation_aosummaryform': {
            	clickReviewLink: this.populateDetailGrid
            },
            "aoattestation_filterform button[action=search]": {
                click: this.filterSearchClick
            },
            "aoattestation_filterform button[action=clear]": {
                click: this.doClearFilter
            }, 
            "aoattestation_detailgrid":{
            	showAOAttestationAgingDialog: this.showAOAttestationAgingDialog
            },
            "aoattestation_detailgrid button[action=submit]":{
            	click: {
            		fn: this.showVerbiage,
            		delay: 200  // to give time to apply the comments
            	}
            },
            "aoattestation_verbiage":{
            	"attestsubmit": this.doSubmitAction,
            	"attestcancel": this.doCancelAction
            },
            "aoattestation_container":{
            	activate:this.onLoad
            }
        });
    },
    win:null,
    condition:null,
    
 redirect : function(){
	 var me = this;
     me.getController('eRecon_web.controller.MainController')
       .activateCard({view: "eRecon_web.view.aoupload.AOUploadContainer"},
    	   function() {
    	   	   var aodownloadPanel = me.getDownloadPanel();
		       var aouploadAcctOwner= aodownloadPanel.down("#acctowner-combo");
		       var aoattestationAOForm = me.getOwnerForm();
		       var selectedValue=aoattestationAOForm.down("#acct_owner-combo").getValue();
		       aouploadAcctOwner.setValue(selectedValue);
		       var acct_owner='';
		       if(selectedValue===''){
		           acct_owner=null;
		       }
		       else{
		           acct_owner=selectedValue;
		       }
		       var businessUnit=aodownloadPanel.down("#bankinggroup-combo");
		       aouploadAcctOwner.select(acct_owner,true);
		       //Proof Owner
		       var proofOwnerStore = me.getStore('eRecon_web.store.AOUplaodProofOwnerStore');
		       var proofOwner=aodownloadPanel.down("#proofowner-combo");
		       proofOwner.clearValue();
	     
		       //Business Unit
		       var businessUnitStore = me.getStore('eRecon_web.store.AOUplaodBusinessUnitStore');
		       var businessUnit=aodownloadPanel.down("#bankinggroup-combo");
		       businessUnit.clearValue();
	     
		       businessUnitStore.load({
		    	   scope: me,
		    	   params: {0: acct_owner},
		    	   callback: function(records, operation, sucsess){
		    		   businessUnit.bindStore(businessUnitStore);
		    	   }
		       });
	     
		       proofOwnerStore.load({
		    	   scope: me,
		    	   params: {0: acct_owner, 1: null},
		    	   callback: function(records, operation, sucsess){
		    		   proofOwner.bindStore(proofOwnerStore);
		    	   }
		       });  
	       } // end of activateCard callback argument
       ); 
},
populateSummaryForm:function(){
	var aosummaryform=this.getSummaryContainer();
	var aoattestationAOForm=this.getOwnerForm(); 
	var filterPanel = this.getFilterForm();
	var detailGrid= this.getDetailPanel();
	this.condition=null;
    detailGrid.store.removeAll();
	var acctOwner = aoattestationAOForm.down("#acct_owner-combo").getValue();
	if(acctOwner===''){
		acctOwner=null;
	}
	var aoSummaryFormStore = this.getStore('eRecon_web.store.AOAttestationSummaryStore');
	aoSummaryFormStore.directOptions = {};
	aoSummaryFormStore.getProxy().extraParams = {
		0:acctOwner
	};
	aoSummaryFormStore.load({
		callback: function (records, operation, success) 
		{
			if(success==true)
			{   			
				aosummaryform.getForm().loadRecord(records[0]);
			}
		}
	});
	var proofOwner = filterPanel.down("#mgrId-combo");
	proofOwner.clearValue();
	businessUnit=filterPanel.down("#busineesunit-combo");
	businessUnit.clearValue();
	proofOwner.store.load({
		params: {0: acctOwner
		}
	});
	businessUnit.store.load({
		  params: {0: acctOwner
		  }
	});

},
    filterSearchClick: function () {
        	var filterPanel = this.getFilterForm();
        	var aoattestationAOForm=this.getOwnerForm();      	
        	var acctOwner = aoattestationAOForm.down("#acct_owner-combo").getValue();
        	var condition = this.condition;
	        if (filterPanel.getForm().isValid()) {
		        if(condition!=null){
		            var fullKey = filterPanel.down("#fullKey-text").getValue();
		            var mgruserid=filterPanel.down("#mgrId-combo").getValue(); 
		            var businessUnit = filterPanel.down("#busineesunit-combo").getValue(); 
		            var filter = filterPanel.down("#fiter-combo").getValue();	
		            var detailsStore = this.getStore('eRecon_web.store.AOAttestationDetailStore');
		            detailsStore.directOptions = {};
		            detailsStore.getProxy().extraParams = {
		            	0: acctOwner,
		                1: condition,
		                2: filter,
		                3: fullKey, 
		                4: mgruserid,
		                5: businessUnit
		            };
		            detailsStore.loadPage(1,{
		                callback: function (records, operation, success) {
		                }
		            });
	           }
	        }        	
    },
    doClearFilter: function () {
    	var filterPanel = this.getFilterForm();
    	filterPanel.getForm().reset();
    },
    
    showVerbiage : function()  {
    	var store = this.getStore('eRecon_web.store.AOAttestationDetailStore');
    	var data = store.getUpdatedRecords(); 
    	if(data.length == 0) {
    		Ext.MessageBox.alert( "Alert", "No changes found");
    		return false;
    	}
    	for (i = 0; i < data.length; i++) {	        
	        var Disagree = data[i].data['disagree'];
	        var DisagreeComments = data[i].data['disagreed_comments'];
	        if((null == DisagreeComments || ''==eRecon_web.gbl.constants.trim(DisagreeComments)) && (Disagree == "1" )) {
	        	
	        	Ext.MessageBox.alert( "Alert","Please Enter Comments for Accounts Which have been Disagreed");
	        	return false;
	        }
        }
    	this.win=Ext.create("eRecon_web.view.aoattestation.AOAttestationVerbiage", {
			applyTo: Ext.getBody(),
    	width: 1100,
   		height:300   
	    });
    	this.win.show();
	
},
	doCancelAction :function(){
		this.win.close();
	
},
	doSubmitAction: function(){
		var me = this;
    	var store = this.getStore('eRecon_web.store.AOAttestationDetailStore');
    	var aosummaryform=this.getSummaryContainer();
    	var aoattestationAOForm=this.getOwnerForm();      	
    	var acctOwner = aoattestationAOForm.down("#acct_owner-combo").getValue();
    	if(acctOwner===''){
    		acctOwner=null;
    	}
    	var aoSummaryFormStore = this.getStore('eRecon_web.store.AOAttestationSummaryStore');
    	var dataArray = [];
        var data = store.getUpdatedRecords();      
        Ext.each(data, function(item, index, array) {
            dataArray.push({
    			"newData" : item.data,
            	"previousData" : item.raw,
            	"modified" : item.modified 
            });
        });
        var encodedArray = Ext.encode(dataArray);
        
        eRecon_web.direct.action.AOAttestationSummaryService.submitAttestationDetails(encodedArray, function(p, response) {
        	if(response.result.successMsg!== null) {
        		store.load({
        			scope:this,
        			callback: function(records, operation, sucsess){
        			}
        		});

        		aoSummaryFormStore.load({
        			scope: this,
        			params: {0: acctOwner, 1: null},
        			callback: function (records, operation, success) 
        			{
        				if(success==true)
        				{   			
        					aosummaryform.getForm().loadRecord(records[0])
        				}
        			}
        		});
        		me.getController('MainController').showStatus(response.result.successMsg);
        	}else{
        		me.getController('MainController').showStatus(response.result.errMsg);
    		}
        });  
        this.win.close();
}, 

populateDetailGrid: function(condition){				
	var aoattestationGridPanel = this.getDetailPanel();
	var aoattestationAOForm = this.getOwnerForm();
	var acctOwner= aoattestationAOForm.down("#acct_owner-combo").getValue();
	var filterPanel = this.getFilterForm();
	filterPanel.getForm().reset();
	this.condition=condition;
	var store = aoattestationGridPanel.getStore();
	store.directOptions = {};
	store.getProxy().extraParams = {
		0: acctOwner, 
        1: condition,
        2: null,
        3: null, 
        4: null,
        5: null
    };
    store.loadPage(1,{
        callback: function (records, operation, success) {
        }
    });
}, showAOAttestationAgingDialog: function(grid, rowIndex) {
	
	var contr = this.getController("eRecon_web.controller.AOAgingController");
	if (!contr.wasInit) {
    	contr.init();
    	contr.wasInit = true;
	}
	
	var rec = grid.getStore().getAt(rowIndex);
	var agingDialog = Ext.create('eRecon_web.view.common.AOCustomDialog', {
        items: [
            {
                xtype: 'aoaging_tabcontainer'
            }
        ],
        title: "Aging Details",
        id: "AOAgingDetails",
       
        extraParams : {
        	AccountId:rec.get("account_id"), ReconPeriod:rec.get("reconperiod"),AgingType:rec.get("acct_aging_type")
        }
    });
	
	agingDialog.on('show', function(agingDialog) {
		   console.log(agingDialog.extraParams.param1, agingDialog.extraParams.param2);
	});
	
	agingDialog.show();
},
	onLoad:function(){
		 var filterPanel = this.getFilterForm();
		 var aoattestationAOForm=this.getOwnerForm();      	
     	 var acctOwner = aoattestationAOForm.down("#acct_owner-combo").getValue(); 
     	 var businessUnit = filterPanel.down("#busineesunit-combo");
		 var proofOwner = filterPanel.down("#mgrId-combo");
		 proofOwner.clearValue();
	     if(acctOwner===''){
	    	 acctOwner=null;
	     }
	     proofOwner.store.load({
	    	 params: {0: acctOwner}
	     });
	     businessUnit.clearValue();
	     businessUnit.store.load({
	    	 params: {0: acctOwner}
	     });
	     this.populateSummaryForm();
}
});

Ext.define('eRecon_web.controller.AccountMaintenanceController',{
	extend: 'Ext.app.Controller',
	stores: ['eRecon_web.store.AccountMaintenanceStore'],
	
	refs: [
	{
       ref: 'detailGrid',
       selector: 'acctmaintenance_grid'
     },
     {
         ref: "filterForm",
         selector: "acctmaintenance_filterform"
     },
     {
         ref: "filterPopup",
         selector: "accountmaintenance_filterpopup"
     }
    ], 
	        
	init: function(){
	   	this.control({
	   		
	        "acctmaintenance_filterform button[action=search]": 
	        {
	        	click: this.filterSearchClick
	        },
	        "acctmaintenance_filterform button[action=reset]":
	        {
	            	click: this.doClearFilter
	        },
	        "acctmaintenance_filterform button[action=filter]":
	        {
	            	click: this.doshowFilterPopup
	        },
	        "accountmaintenance_filterpopup button[action=filter]":
	        {
	        		click: this.doAdvanceFilter
	        },
	        "acctmaintenance_grid button[action=export]": {
                click: this.doExportAction
            }
	   	});
	},
	win:null,
	exportParams:null,
	filterSearchClick: function () {
		var filterPanel = this.getFilterForm();
		var formValues = filterPanel.getValues();
		this.exportParams=formValues;
    	var filteValues={
    		"newData":formValues           
    		};
    	var jsonStr = Ext.encode(filteValues);
    	var detailGrid = this.getDetailGrid();
    	var acctmaintenanceStore = detailGrid.getStore();
    	acctmaintenanceStore.directOptions = {};
    	acctmaintenanceStore.getProxy().extraParams = {
    	 0: jsonStr
    	};
    	acctmaintenanceStore.loadPage(1);
    	
    },        	

	doClearFilter: function () {
		this.getFilterForm().getForm().reset()
		/**
		 * Reset the params as well for advanced export.
		 */
		this.exportParams=null;
	},
	
	doshowFilterPopup: function () {
		this.win =Ext.create("eRecon_web.view.accountmaintenance.AccountMaintenanceFilterPopUp", {
			applyTo: Ext.getBody(),
	   		width: 1100,
	   		height:620
		  });
		 this.win.show();
	},
	doAdvanceFilter : function(){
		var filterPanel = this.getFilterPopup();
		var formValues = filterPanel.getValues();
		this.exportParams=formValues;
    	var filteValues={
    		"newData":formValues           
    		};
    	var jsonStr = Ext.encode(filteValues);
    	var detailGrid = this.getDetailGrid();
    	var acctmaintenanceStore = detailGrid.getStore();
    	acctmaintenanceStore.directOptions = {};
    	acctmaintenanceStore.getProxy().extraParams = {
    	 0: jsonStr
    	};
    	acctmaintenanceStore.loadPage(1);
    	this.win.close();
	},
	doExportAction : function() {
		console.log("Export action called");
		var formValues = this.exportParams;
		if(formValues === null) {
			var filterPanel = this.getFilterForm();
			formValues = filterPanel.getValues();
		}
		
		Ext.Ajax.request({
			url : 'filedownloadtrigger.up?downloadType=ACCOUNT_MAINTENANCE',
			method:'POST', 
			params : {
				formdata: Ext.encode(formValues)
			},
			scope : this,
			success : function(response, opts) {
				response = Ext.decode(response.responseText);
				if(response.success){
					Ext.MessageBox.alert('Successful', 
							"Your request has been submitted successfully with the request id " + response.scheduleId + ". You should recieve an email on completion.");
				}
				else {
					Ext.MessageBox.alert('Failed', response.message);
				}
			},
			failure : function(err) {
				Ext.MessageBox.alert('Error occured during Subledger file download.', 'Please try again!');
			}
		}); 		

	}
 });

Ext.define('eRecon_web.controller.BroadcastEditMessageController',{
	extend: 'Ext.app.Controller',
	stores:	["eRecon_web.store.BroadcastMessageStore"],
	refs: [{
	       ref: 'BroadcastMessageEdit',
	       selector: 'broadcastmessageeditform'
	    }],
	
	init: function()
	{
		this.control({
			'broadcastmessageeditform': {
				beforeactivate: this.handlebeforeactivate
	        },
	        'broadcastmessageeditform button[action=saveButton]': {
	            click: this.saveRecord
	        },
	        'broadcastmessageeditform button[action=cancelButton]': {
	            click: this.cancelAction
	        }
		});
	},
	
	handlebeforeactivate : function(panel, eOpts){
		var broadcastMessageStore = this.getStore('eRecon_web.store.BroadcastMessageStore');
		broadcastMessageStore.load({
			scope:this,
			callback: function (records, operation, success) 
	        {
				if(success==true)
					{
						var htmlScript = records[0].data.broadcastMessage;
						var broadCastMsgEditForm= this.getBroadcastMessageEdit();
						var broadCastMsgEditPanel = broadCastMsgEditForm.down("#broadmessageedit-form");
					    broadCastMsgEditPanel.setValue(htmlScript);
					}
	        }
		});
	},
	saveRecord: function(){
		var broadCastMsgEditForm= this.getBroadcastMessageEdit();
		var broadCastMsgEditPanel = broadCastMsgEditForm.down("#broadmessageedit-form");
		var braodCastMsg = broadCastMsgEditPanel.getValue();
		var broadcastMessageStore = this.getStore('eRecon_web.store.BroadcastMessageStore');
		eRecon_web.direct.action.BroadcastMessageService.saveRecords(braodCastMsg, function(p, response) {
	    	if(response.result == "Success") {
	    		broadcastMessageStore.load({
	    			scope:this,
	    			callback: function (records, operation, success) 
	    	        {
	    				if(success==true)
	    					{
	    						var htmlScript = records[0].data.broadcastMessage;
	    					    broadCastMsgEditPanel.setValue(htmlScript);
	    					}
	    					Ext.MessageBox.alert("Success","Success");
	    	        }
	    		});
	    	}else{
	    		Ext.MessageBox.alert( "Status", response.result);
	    	}
	    }); 
	},
	cancelAction : function(){
		var broadcastMessageStore = this.getStore('eRecon_web.store.BroadcastMessageStore');
		broadcastMessageStore.load({
			scope:this,
			callback: function (records, operation, success) 
	        {
				if(success==true)
					{
						var htmlScript = records[0].data.broadcastMessage;
						var broadCastMsgEditForm= this.getBroadcastMessageEdit();
						var broadCastMsgEditPanel = broadCastMsgEditForm.down("#broadmessageedit-form");
					    broadCastMsgEditPanel.setValue(htmlScript);
					}
	        }
		});
	}
});

Ext.define('eRecon_web.controller.JobStatusController',{
	extend: 'Ext.app.Controller',
	stores:	['eRecon_web.store.JobStatusStore', 'eRecon_web.store.JobStatusDetailStore'], 
	refs: [{
		ref: 'summaryPanel',
		selector: 'jobstatusgridpanel'
	},
	{
		ref: 'detailPanel',
		selector: 'jobstatusgriddetailspanel'
	},
	{
		ref: 'filterPanel',
		selector: 'jobstatus_filterform'
	}
	],

	init: function(){
		this.control({
			'jobstatusgridpanel button[action=load]':{
				click: this.onLoad
			},
			'jobstatusgridpanel': {
				jobStatusGridRowSelectionChange: this.doHandleJobStatusGridRowSelectionChange
            },
            
            'jobstatus_filterform  button[action=search]': {
				click: this.doHandleFilterSearch
            },
            
            'jobstatus_filterform  button[action=reset]': {
				click: this.doHandleFilterReset
            }, 
            'jobstatusgriddetailspanel button[action=export]': {
                click: this.doExportAction
            }
		});
	},

	onLoad:	function(){
		var store = this.getStore('eRecon_web.store.JobStatusStore');
		store.getProxy().extraParams = {
			0: "All",
			1: null
		};
		store.load();
	},loadJobStatuses: function() {
		var store = this.getStore('eRecon_web.store.JobStatusStore');
		store.getProxy().extraParams = {
			0: "All",
			1: null
		};
		store.load();
	},
	doHandleJobStatusGridRowSelectionChange: function(scheduleId) {
		console.log(scheduleId);
		 var jobStatusDetailStore = this.getStore('eRecon_web.store.JobStatusDetailStore');

		 jobStatusDetailStore.getProxy().extraParams = {
             0: scheduleId
         };
        
		 jobStatusDetailStore.loadPage(1);
	}, 
	doHandleFilterSearch: function(obj, e) {
		console.log("search");
		var summaryPanel = this.getSummaryPanel();
		var filterPanel = this.getFilterPanel();
		var formValues = filterPanel.getValues();
		var jobStatusDetailStore = this.getStore('eRecon_web.store.JobStatusDetailStore');
		var store = this.getStore('eRecon_web.store.JobStatusStore');
		store.getProxy().extraParams = {
			0: (formValues.profileName == '' || formValues.profileName == null) ? 'All' : formValues.profileName,
			1: (formValues.scheduleId == '' || formValues.scheduleId == null) ? null : Number(formValues.scheduleId)
		};
		store.load( {
			callback: function(records, operation, sucsess){
//					summaryPanel.getView().getSelectionModel().select(0); //This is for selection
					jobStatusDetailStore.getProxy().extraParams = {
						0 :  Number(formValues.scheduleId)
					};

					jobStatusDetailStore.loadPage(1);
			}
		});
	},
	doHandleFilterReset : function(obj, e) {
		var filterPanel = this.getFilterPanel();
		filterPanel.getForm().reset();
		var jobStatusDetailStore = this.getStore('eRecon_web.store.JobStatusDetailStore');
		var store = this.getStore('eRecon_web.store.JobStatusStore');
		store.getProxy().extraParams = {
			0 : "All",
			1 : null
		};
		store.load({
			callback : function(records, operation,	success) {
				jobStatusDetailStore.getProxy().extraParams = {
					0 : null
				};

				jobStatusDetailStore.loadPage(1);
			}
		});
	},
	doExportAction : function() {
    	console.log("Export action called");
    	
    	 var summaryPanel = this.getSummaryPanel();
    	 var selectedRecords = summaryPanel.getView().getSelectionModel().getSelection();
    	 
    	if (selectedRecords.length > 0) {
    		var scheduleId = selectedRecords[0].get("scheduleId");

    		var formdata = {
    			scheduleId: scheduleId +''
    		};
    		
    		Ext.Ajax.request({
    			url : 'filedownloadtrigger.up?downloadType=AUDIT_TRAIL',
    			method:'POST', 
    			params : {
    				formdata: Ext.encode(formdata)
    			},
    			scope : this,
    			success : function(response, opts) {
    				response = Ext.decode(response.responseText);
    				if(response.success){
    					Ext.MessageBox.alert('Successful', 
    							"Your request has been submitted successfully with the request id " + response.scheduleId + ". You should recieve an email on completion.");
    				}
    				else {
    					Ext.MessageBox.alert('Failed', response.message);
    				}
    			},
    			failure : function(err) {
    				Ext.MessageBox.alert('Error occured during audit trail download.', 'Please try again!');
    			}
    		});	

    	} else {
    		Ext.MessageBox.alert( "Alert", "No rows selected in the summary grid." );
    		return false;
    	}
    }
});

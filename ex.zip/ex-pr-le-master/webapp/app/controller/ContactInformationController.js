Ext.define('eRecon_web.controller.ContactInformationController',{
	extend: 'Ext.app.Controller',
	stores:	["eRecon_web.store.ContactsStore"],
	refs: [{
	       ref: 'contacts',
	       selector: 'ContactInformation_Contacts'
	    }],
	
	init: function()
	{
		
	}			
});

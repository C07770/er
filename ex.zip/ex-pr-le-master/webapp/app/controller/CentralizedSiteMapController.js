Ext.define('eRecon_web.controller.CentralizedSiteMapController',{
	extend: 'Ext.app.Controller',	
	requires: ["eRecon_web.store.CentralizedSiteMapStore","eRecon_web.store.JobStatusForProfileStore","eRecon_web.store.JobStatusDetailStore"],
	stores: ["eRecon_web.store.CentralizedSiteMapStore","eRecon_web.store.JobStatusForProfileStore","eRecon_web.store.JobStatusDetailStore"],
	refs: [
	  { ref: 'CentralizedSiteMapGrid', selector: 'CentralizedSiteMap_Grid' },
	  { ref: 'CentralizedSiteMapSearch', selector: 'CentralizedSiteMap_Search'},
	  { ref: 'CentralizedSiteMapUploadGrid', selector: 'CentralizedSiteMap_UploadGrid'},
	  { ref: 'CentralizedSiteMapUploadContainer', selector: 'CentralizedSiteMapUpload_Container'}
	],
	
	init: function()
	{
		this.control({
			 "CentralizedSiteMap_Search":{
	    	 "boxready":this.onCentReady
	     },
	     "CentralizedSiteMapUpload_Container":{
	    	 'beforecollapse':this.uploadGridCloseFn,
	     'show':this.uploadGridShowFn
	    	 
	     },
	     'CentralizedSiteMap_UploadGrid':{
	    	 'centSiteUploadStatusGridRowSelectionChange': this.doHandleCentSiteUploadStatusGridRowSelectionChange,
	     'feedsFileRunProfile': this.doHandleRunProfile,
     	'feedsFileDiscardProfile': this.doHandleDiscardProfile
     	//'clickevent' : this.doHandleScheduleIdClick
	     },
			'CentralizedSiteMap_Search button[action=searchdetails]': {
	            click: this.CentralizedSiteMapSearchDetails
	        },
	        'CentralizedSiteMap_Search button[action=clear]': {
	            click: this.clearSearchPanel
	        },
	        'CentralizedSiteMap_Search button[action=insert]': {
	            click: this.insertNewRecord
	        },
	        'CentralizedSiteMap_Grid button[action=save]': {
	        	click: this.saveRecords
	        },
	        'CentralizedSiteMap_Grid button#bssMetricsSync': {
		    	 "click": this.handleSyncButtonClick
		     },
	        'CentralizedSiteMap_Grid button[action=CentralizedSiteMapexcel]': {
	        	click: this.CentralizedSiteMapdownloadfile
	        },
	        'CentralizedSiteMap_Grid button[action=uploadfile]': {
	        	click: this.CentralizedSiteMapUploadfile
	        },
	         'jobstatusgriddetailspanel button[action=export]': {
                click: this.doAuditTrailExportAction
            }
		});
	},
	uploadGridCloseFn: function(){
		this.getCentralizedSiteMapGrid().show();
	},
	uploadGridShowFn: function(){
		this.getCentralizedSiteMapGrid().hide();
	},
	onCentReady: function(){
		var saveButton = Ext.ComponentQuery.query('CentralizedSiteMap_Grid button[action=save]')[0];
		if(Ext.util.Cookies.get('Governance_Dashboard_User')=="true"||Ext.util.Cookies.get('Dashboard_User')=="true"||Ext.util.Cookies.get('eRecon_support')=="true" ){
			saveButton.setDisabled(false);
		}
		
var centUploadStore = this.getCentralizedSiteMapUploadGrid().getStore();
centUploadStore.directOptions = {};
centUploadStore.getProxy().extraParams = {
            0: 'CentSiteUpload'
        };
        centUploadStore.load();
        },
		
	insertNewRecord : function(){
		var searchForm = this.getCentralizedSiteMapSearch();
		var formdata = Ext.encode(searchForm.getValues());
		var store = this.getCentralizedSiteMapGrid().getStore();
		store.directOptions = {};
		store.getProxy().extraParams = {
            0: formdata
        };
		var reconPeriod= searchForm.down("#reconPeriod-text").getValue();
		var fullkey= searchForm.down("#fullkey").getValue();
		var centralizedsite = searchForm.down("#centralizedsite").getValue();
		Ext.Msg.show({
			title: "Error",
			msg: "data " + fullkey + " | "+centralizedsite ,
			buttons: Ext.Msg.OK,
			icon: Ext.Msg.ERROR
		});						
	if(reconPeriod=="" ||reconPeriod==null){
		Ext.Msg.show({
			title: "Error",
			msg: "<b>Recon Period is required.</b><br>",
			buttons: Ext.Msg.OK,
			icon: Ext.Msg.ERROR
		});
		flag=1;
	}
//		debugger;
		var flag = 0;
		
		if(fullkey == "" || fullkey == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>fullkey is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			flag = 1;
		}
		if(centralizedsite == "" || centralizedsite == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>BSS Metrics is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			flag = 1;
		}
		if (flag == 0){	
			Ext.Msg.show({
				title: "Confirmation",
				msg: "Do you want to insert a record?",
			    buttons: Ext.Msg.OKCANCEL,
			    fn: function(btn) {
					if (btn == 'ok') {
			var formValues = searchForm.getValues();
			if(formValues.fullkey == "" ){formValues.fullkey = null;}
			if(formValues.centralizedsite == "" ){formValues.centralizedsite = null;}
			if(formValues.centralizedsiteao == "" ){formValues.centralizedsiteao = null;}
			if(formValues.centralizedsitepo == "" ){formValues.centralizedsitepo = null;}
			var dataArray = [];
			dataArray.push({
				"newInsertData" : formValues
	        });	
			formValues.action = 'INSERT';
			var encodedArray = Ext.encode(dataArray);
			eRecon_web.direct.action.CentralizedSiteMapService.doAddRecords(encodedArray, function(p, response) {
				if(response.result!= null){
					if(response.result == "Success") {
						store.loadPage(1,{
			                callback: function (records, operation, success) {
		                	}
						});
			    		Ext.Msg.alert('Status','1 Record inserted successfully');
			    	}
					else{
						Ext.Msg.alert('Status','Record not inserted');
					}
				}		    	
		    	else {		    		
		    		Ext.Msg.alert('Status','Record not saved');
		    	}	
			});
					}
			    }
			});
		}//flag
	},
	
	saveRecords : function(){
		var store = this.getCentralizedSiteMapGrid().getStore();
		var flag = 0;
		var dataArray = [];
		var updateData = store.getUpdatedRecords();  
		var deleteData = store.getRemovedRecords();
		
		if(updateData.length == 0 && deleteData.length == 0) 
		{
    		Ext.MessageBox.alert( "Alert", "No changes found");
    		return false;
		}
		if(updateData.length != 0)
			{
				Ext.each(updateData, function(item, index, array) {
		        dataArray.push({
					"newData" : item.data,
		        	"previousData" : item.raw,
		        	"modified" : item.modified 
			        });
			    });
			}
		
		if(deleteData.length != 0)
			{
				Ext.each(deleteData, function(item, index, array) {
			        dataArray.push({
						"deleteData" : item.data
			        });
			    });
			}
		
		if(flag ==0){
			var encodedArray = Ext.encode(dataArray);
			eRecon_web.direct.action.CentralizedSiteMapService.saveRecords(encodedArray, function(p, response) {
				if(response.result[0]!= null){
					if(response.result[0] == "Success" || response.result[0] =="Exception") {
			    		Ext.MessageBox.alert( "Status", response.result[1] );
			    			
			    		store.load();
			    	}
				}
				else if (response.result[0] == null || response.result[0] =="Fail"){
					Ext.MessageBox.alert( "Status", "Record(s) modification failed" );
				}
		    }); 
		}
	}, 
	CentralizedSiteMapSearchDetails : function(){      
	  var searchPanel = this.getCentralizedSiteMapSearch();		  
	  var form = searchPanel.getForm();
	  var vals = "";
	  for(var i = 0; i<form._fields.items.length;i++){
	    if(form._fields.items[i].value) {
	    	vals = true;
	    }
	  }
	  if(vals) {	  
		var formdata = Ext.encode(form.getValues());
	    var CentralizedSiteMapStore = this.getCentralizedSiteMapGrid().getStore();
	    CentralizedSiteMapStore.directOptions = {};
	    CentralizedSiteMapStore.getProxy().extraParams = {
	      0: formdata
	    };
	    CentralizedSiteMapStore.loadPage(1,{
	      callback: function (records, operation, success) {
	      }
	    }); 
	  }
	  else {
	    Ext.Msg.alert("Error!","Filter selection(s) are required to perform a fullkey search");
	  }
	},
	
	clearSearchPanel : function(){
		var searchPanel = this.getCentralizedSiteMapSearch(); 
		searchPanel.getForm().reset();
		var CentralizedSiteMapStore = this.getCentralizedSiteMapGrid().getStore();
    	CentralizedSiteMapStore.directOptions = {};
    	CentralizedSiteMapStore.getProxy().extraParams = {
            0: null
        };
        CentralizedSiteMapStore.load();
    	
//    	CentralizedSiteMapStore.load({
//            callback: function (records, operation, success) {
//            }
//        });    	
	},
	CentralizedSiteMapdownloadfile: function(){
		
var CentralizedSiteMapStore = this.getCentralizedSiteMapGrid().getStore();
 if(CentralizedSiteMapStore.totalCount>450000){
	Ext.Msg.alert("Error"," There is a 450,000 fullkey limit per excel download.  Please apply another filter to the current population to refine the search to an amount less than the limit");
 return;
 }

		var searchPanel = this.getCentralizedSiteMapSearch();
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var reconPeriod= searchPanel.down("#reconPeriod-text").getValue();
		var fullKey= searchPanel.down("#fullkey").getValue();
		var centralizedSite= searchPanel.down("#centralizedsite").getValue();
		var intAudFlg= searchPanel.down("#intAudFlg").getValue();
		var extAudFlg= searchPanel.down("#extAudFlg").getValue();
		var acctRevFlg= searchPanel.down("#acctRevFlg").getValue();
		var acctRevRating= searchPanel.down("#acctRevRating").getValue();
		var mcaFlg= searchPanel.down("#mcaFlg").getValue();
		var mcaRating= searchPanel.down("#mcaRating").getValue();
		var dormAcctFlg= searchPanel.down("#dormAcctFlg").getValue();
		var confEnt= searchPanel.down("#confEnt").getValue();
		var sodType= searchPanel.down("#sodType").getValue();
		var capFlg= searchPanel.down("#capFlg").getValue();
		var issueNum= searchPanel.down("#issueNum").getValue();   
		var capNum= searchPanel.down("#capNum").getValue();
		var nonCentralizedSiteFullkey= searchPanel.down("#nonCentralizedSiteFullkey").getValue();
		var strategicPartner= searchPanel.down("#strategicPartner").getValue();
		var governanceCommentary = searchPanel.down("#governanceCommentary").getValue();
		
		var capDesc = searchPanel.down("#capDesc").getValue();
		var initialTrd = searchPanel.down("#initial_trd").getValue();
		var revisedTrd = searchPanel.down("#revised_trd").getValue();
		var finalTrd = searchPanel.down("#final_trd").getValue();
		
		  

		
//		Ext.create('eRecon_web.common.ExportToExcelStatusPopup').launchExport(
//			'eRecon_web.store.CentralizedSiteMapStore',
//			CentralizedSiteMapStore.total,
//			null,
//			{"reconPeriod": formdata/*, "fullKey": fullkey*/}
//		);
		//-----------------------------------------------------------------------------
		var userRole = 'GPO BSS DASHBOARD USER';		
		var dataArray = { userRole: userRole };
		var encodedArray = Ext.encode(dataArray);
		eRecon_web.direct.action.CentralizedSiteMapService.getUserRole(encodedArray, function(p,response){
			if(response.result == null ){
				this.userRole = null;
			}
        });
		
		var formdata = {
			fullKey: fullKey,
			reconPeriod: reconPeriod,
			centSiteId: centralizedSite,
			centralizationStatus: null,
			internalAudFlag: intAudFlg,
			externalAudFlag: extAudFlg,
			acctReviewFlag: acctRevFlg,
			acctReviewRating: acctRevRating,
			mcaFlag: mcaFlg,
			mcaRating: mcaRating,
			dormantAcctFlg: dormAcctFlg,
			conflictEntitlement: confEnt,
			sodType:  sodType,
			capFlag: capFlg,
			issueNumber: issueNum,
			capNumber: capNum,
			ssidGl: null,
			proposedSite: nonCentralizedSiteFullkey, 
			zbaAging: null,
			strategicPartner: strategicPartner,
			governanceCommentary: governanceCommentary,
		capDesc :capDesc,
		initialTrd:initialTrd,
		revisedTrd:revisedTrd,
		finalTrd:finalTrd,
		internal_aud_rpt_num: null,
		external_aud_rpt_num : null,
		red_part_baseline: null,
		red_baseline_top_reason: null,
		red_rept_red_aging : null,
		red_actioin_items: null,
		red_initial_trd: null,
		red_revised_trd : null,
		red_final_trd: null,
		abnormal_bal_flag : null,
		userRole: userRole
		}
		Ext.Ajax.request({
			url : 'filedownloadtrigger.up?downloadType=BSS_MATRIX_EXCEL_EXPORT',
			method:'POST', 
			params : {
				formdata: Ext.encode(formdata)
			},
			scope : this,
			success : function(response, opts) {
				response = Ext.decode(response.responseText);
				if(response.success){
					Ext.MessageBox.alert('Successful', 
							"Your request has been submitted successfully with the request id " + response.scheduleId + ". You should recieve an email on completion.");
				}
				else {
					Ext.MessageBox.alert('Failed', response.message);
				}
			},
			failure : function(err) {
				Ext.MessageBox.alert('Error occured during Centralized Site Matrix Excel file download.', 'Please try again!');
			}
		}); 		
		//-----------------------------------------------------------------------------
	},
	CentralizedSiteMapUploadfile:function(o){
		var me =this;
		var form = o.up('form').getForm();
		var profileName = "BSS_UPL_METRICS_FEED";
		var CentralizedSiteMapStore = this.getCentralizedSiteMapGrid().getStore();
		var UploadFile = o.up('form').down("#feedfileupload-file").getValue();
		if (UploadFile !== '') {
			if (form.isValid()) {
				eRecon_web.direct.action.CentralizedSiteMapService.getProfileIdForBSSUpload(profileName,function(result){
					console.log(result);
				//});
                form.submit({
                	url: "fileuploadtrigger?UploadType="+profileName+"&ProfileId="+result,
                    waitMsg: 'Uploading file...',
                    scope: this,
                    success: function (fp, o) {
//                    	CentralizedSiteMapStore.loadPage(1,{
//        	                callback: function (records, operation, success) {
//        	                }
//        	            });
                	//CentralizedSiteMapStore.load();

                        Ext.Msg.show({
                            title: "Success",
                            msg: "File has been successfully saved in the server. Please click on Process File to load data",
                            buttons: Ext.Msg.OK,
                            icon: Ext.Msg.QUESTION
                        });
                        me.getCentralizedSiteMapUploadContainer().expand();
                        me.getCentralizedSiteMapUploadGrid().getStore().reload();
                    },
                    failure: function (fp, o) {
                        var errs = "";
                        for (var z = 0; z < o.result.validationErrors.length; z++) {
                            errs += "- " + o.result.validationErrors[z] + "<br>";
                        }
                        Ext.Msg.show({
                            title: "Error",
                            msg: "<b>The following errors occurred:</b><br>" + errs,
                            buttons: Ext.Msg.OK,
                            icon: Ext.Msg.ERROR
                        });
                    }
                });
                
                });
            }
        } else {
            Ext.Msg.show({
                title: "Success",
                msg: "No file to Upload",
                buttons: Ext.Msg.OK,
                icon: Ext.Msg.QUESTION
            });
        }
	},
	
	handleSyncButtonClick : function(){
	eRecon_web.direct.action.CentralizedSiteMapService.doBssMetricsSync( function(p,response){
		Ext.MessageBox.alert('Alert', response.result)
	});
	}
,
	doHandleCentSiteUploadStatusGridRowSelectionChange: function(scheduleId) {
		console.log(scheduleId);
		 var jobStatusDetailStore = this.getStore('eRecon_web.store.JobStatusDetailStore');

		 jobStatusDetailStore.getProxy().extraParams = {
             0: scheduleId
         };
        
		 jobStatusDetailStore.loadPage(1);
	},

	 doHandleRunProfile : function(column, recordIndex, record, view) {
    	var data = {
    			"scheduleId" : record.get("scheduleId").toString(),
    			"profileName" : record.get("profileName"),
    			"fileName" : record.get("fileName"),
    			"soeId" : record.get("userId")
    			//"profileId" : record.get("profileName"),
    			//"templateId" : record.get("templateId")//
    	}
    	var encodedArray = Ext.encode(data);
    	eRecon_web.direct.action.FeedLoadService.handleProcessFile(encodedArray, function(p, response) {
    		if(response.result == "Success") {
    			view.getStore().load();
    			Ext.MessageBox.alert( "Status", "Request to process file has been queued in the system." );
    		} else {
    			Ext.MessageBox.alert( "Status", "Error submitting request to process the file." );
    		}
    	});
    }, 
    doHandleDiscardProfile : function(column, recordIndex, record, view) {
    	var data = {
    			"scheduleId" : record.get("scheduleId").toString(),
    			"profileName" : record.get("profileName"),
    			"fileName" : record.get("fileName"),
    			"soeId" : record.get("userId")
    	}
    	var encodedArray = Ext.encode(data);
    	eRecon_web.direct.action.FeedLoadService.handleDiscardFile(encodedArray, function(p, response) {
    		if(response.result == "Success") {
    			view.getStore().load();
    			Ext.MessageBox.alert( "Status", "Successfully discarded the file." );
    		} else {
    			Ext.MessageBox.alert( "Status", "Error Discarding file" );
    		}
    	});
    },
    doAuditTrailExportAction : function() {
    	console.log("Export action called");
    	
    	 var summaryPanel = this.getCentralizedSiteMapUploadGrid();
    	 var selectedRecords = summaryPanel.getView().getSelectionModel().getSelection();
    	 
    	if (selectedRecords.length > 0) {
    		var scheduleId = selectedRecords[0].get("scheduleId");

    		var formdata = {
    			scheduleId: scheduleId +''
    		};
    		
    		Ext.Ajax.request({
    			url : 'filedownloadtrigger.up?downloadType=AUDIT_TRAIL',
    			method:'POST', 
    			params : {
    				formdata: Ext.encode(formdata)
    			},
    			scope : this,
    			success : function(response, opts) {
    				response = Ext.decode(response.responseText);
    				if(response.success){
    					Ext.MessageBox.alert('Successful', 
    							"Your request has been submitted successfully with the request id " + response.scheduleId + ". You should recieve an email on completion.");
    				}
    				else {
    					Ext.MessageBox.alert('Failed', response.message);
    				}
    			},
    			failure : function(err) {
    				Ext.MessageBox.alert('Error occured during audit trail download.', 'Please try again!');
    			}
    		});	

    	} else {
    		Ext.MessageBox.alert( "Alert", "No rows selected in the summary grid." );
    		return false;
    	}
    }
//    ,
//    doHandleScheduleIdClick :function (column, record, rowIndex, colIndex, e) {
//    	var me = this;
//    	console.log(record.get("scheduleId"));
//    	var jobStatusDetailPanel = me.getJobStatusDetailPanel();
//
//    	me.getController('eRecon_web.controller.MainController')
//    	  .activateCard({view: "eRecon_web.view.jobstatus.JobStatusContainer"},
//			function() {	
//				var filterPanel = me.getJobStatusFilterPanel();
//				filterPanel.getForm().setValues({scheduleId: record.get("scheduleId")});
//				
//				var button = filterPanel.down("button[action=search]");
//				button.fireEvent('click', button, Ext.EventObject);
//			}
//    	  );
//    }
    
});

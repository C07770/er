 Ext.define('eRecon_web.controller.CondiLuController',{
	extend: 'Ext.app.Controller',
	requires: ["eRecon_web.store.CondiLuStore"],
	stores:	["eRecon_web.store.CondiLuStore"],
	refs: [{
	       ref: 'condiLuGrid',
	       selector: 'secadmin_condiluGrid'
	    },
	    {
	    	ref: 'searchForm',
	    	selector: 'secadmin_condilusearch'
	    },{
	    	ref:'condicontainer',
	    	selector:'secadmin_condilucontainer'
	    }
	    ],
	
	init: function()
	{
		this.control({
			'secadmin_condilusearch button[action=CondiLu-SearchRecord]': {
	            click: this.condiLuSearch
	        },
	        'secadmin_condilusearch button[action=CondiLu-Clear]': {
	            click: this.clearFilterForm
	        },
	        'secadmin_condiluGrid button[action=CondiLu-save]': {
	        	click: this.saveRecords
	        },
	        'secadmin_condiluGrid  button[action=CondiLu-excel]': {
	        	click: this.condiLudownlaodfile
	        },
	        'secadmin_condiluGrid  button[action=CondiLu-add]': {
	        	click: this.showSearchPanel
	        },
	        'secadmin_condilusearch  button[action=CondiLu-AddRecord]': {
	        	click: this.condiLuAddRecord
	        },
	        'secadmin_condilucontainer': {
	        	activate: this.onLoad
	        }
		});
	},
	condiSearchPanel:null,
	exportParams:null,
	onLoad:function(){
		var condiLuStore = this.getCondiLuGrid().getStore();
		condiLuStore.directOptions = {};
		condiLuStore.getProxy().extraParams = {
            0: null
        };
        condiLuStore.load({
            callback: function (records, operation, success) {
            }
        });
	},
	showSearchPanel:function(){
		this.condiSearchPanel =Ext.create("eRecon_web.view.condilu.CondiLuSearch", {
			applyTo: Ext.getBody(),
	   		width: 900,
	   		height:510
		  });
		 this.condiSearchPanel.show();
	},
	saveRecords: function(){
		var store = this.getStore('eRecon_web.store.CondiLuStore');
		var dataArray = [];
		var updateData = store.getUpdatedRecords(); 
		var deleteData = store.getRemovedRecords();
		
		if(updateData.length == 0 && deleteData.length == 0) 
		{
    		Ext.MessageBox.alert( "Alert", "No changes found");
    		return false;
		}
		if(updateData.length != 0)
			{
				Ext.each(updateData, function(item, index, array) {
		        dataArray.push({
					"newData" : item.data,
		        	"previousData" : item.raw,
		        	"modified" : item.modified 
			        });
			    });
			}
		if(deleteData.length != 0)
			{
			Ext.each(deleteData, function(item, index, array) {
		        dataArray.push({
					"deleteData" : item.data
		        });
		    });
			}
		
		var encodedArray = Ext.encode(dataArray);
		
		Ext.Msg.show({
			title: "Confirmation",
			msg: "Are you sure want to delete/Update record(s)?",
		    buttons: Ext.Msg.OKCANCEL,
		    fn: function(btn) {
				if (btn == 'ok') {
					eRecon_web.direct.action.CondiLuService.saveRecords(encodedArray, function(p, response) {
				    	if(response.result !== "Error") {
				    		Ext.MessageBox.alert( "Status", response.result );
				    		store.load();
				    	}else{
				    		Ext.MessageBox.alert( "Status", response.result);
				    	}
				    }); 
				}else{
					store.load();
				}
			}
		});
	},
	
	clearFilterForm: function(){
		var searchPanel = this.getSearchForm();
		searchPanel.getForm().reset();
	},
	
	condiLuSearch: function(){
		var searchPanel = this.getSearchForm();
		var form = searchPanel.getForm();
		this.exportParams=form.getValues();
		var formdata = Ext.encode(form.getValues());
		var condiLuStore = this.getCondiLuGrid().getStore();
		condiLuStore.directOptions = {};
		condiLuStore.getProxy().extraParams = {
            0: formdata
        };
        condiLuStore.loadPage(1,{
            callback: function (records, operation, success) {
            }
        });
        this.condiSearchPanel.close();
	},
	condiLudownlaodfile: function(){
		var formValues = this.exportParams;
		var formdata = Ext.encode(formValues);
		var condiLuStore = this.getCondiLuGrid().getStore();
		Ext.create('eRecon_web.common.ExportToExcelStatusPopup').launchExport(
			'eRecon_web.store.CondiLuStore',
			condiLuStore.total,
			null,
			{0: formdata}
		);
	},
	condiLuAddRecord: function(){
		var searchPanel = this.getSearchForm();
		var condi = searchPanel.down("#businessUnit-text").getValue();
		var form = searchPanel.getForm();
		if(condi == "" || condi == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Condi is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		var formdata = Ext.encode(form.getValues());
		var condiluStore = this.getCondiLuGrid().getStore();
		condiluStore.directOptions = {};
		condiluStore.getProxy().extraParams = {
            0: null
        };
		eRecon_web.direct.action.CondiLuService.doAddRecords(formdata, function(p, response) {
	    	if(response.result!= "Error") {
	    		condiluStore.loadPage(1,{
	                callback: function (records, operation, success) {
	                }
	            });
	            Ext.MessageBox.alert( "Status", response.result);
	    	}else{
	    		Ext.MessageBox.alert( "Status", response.result);
	    	}
	    }); 
	}
	
});

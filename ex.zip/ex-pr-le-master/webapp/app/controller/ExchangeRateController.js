Ext.define('eRecon_web.controller.ExchangeRateController',{
	extend: 'Ext.app.Controller',	
	requires: ["eRecon_web.store.ExchangeRateStore"],
	stores: ["eRecon_web.store.ExchangeRateStore"],
	refs: [{
	       ref: 'ExchangeRateGrid',
	       selector: 'ExchangeRate_Grid'
	    },
	    {
	    	ref: 'ExchangeRateSearch',
	    	selector: 'ExchangeRate_Search'
	    },{
	    	ref:'ExchangeRateContainer',
	    	selector:'ExchangeRate_Container'
	    }],
	
	init: function()
	{
		this.control({
			'ExchangeRate_Search button[action=searchdetails]': {
	            click: this.ExchangeRateSearchDetails
	        },
	        'ExchangeRate_Search button[action=clear]': {
	            click: this.clearSearchPanel
	        },
	        'ExchangeRate_Search combo[itemId=reconperiod]': {
	        	change: this.handlereconperiodCombo
	        },
	        'ExchangeRate_Search button[action=insert]': {
	            click: this.insertNewRecord
	        },
	        'ExchangeRate_Grid button[action=save]': {
	        	click: this.saveRecords
	        },
	        'ExchangeRate_Grid button[action=exchangeRateexcel]': {
	        	click: this.exchangeRatedownloadfile
	        }
		});
	},
	handlereconperiodCombo:function(combo,newVal,oldVal) {
		var oRec=combo.findRecordByValue(oldVal);
		  oRec && combo.inputEl.removeCls('comboSelectedItem');
		  if(newVal==Ext.util.Cookies.get('currentReconPeriod')){
			  var nRec=combo.findRecordByValue(newVal);
			  nRec && combo.inputEl.addCls('comboSelectedItem');
		  }
	},	
	insertNewRecord : function(){
		var searchForm = this.getExchangeRateSearch();
		var Mask = new Ext.LoadMask(this.getExchangeRateContainer(), {msg:"Saving please wait"});
		Mask.show();
		var currencycode = searchForm.down("#currencycode").getValue();
		var currencydesc = searchForm.down("#currencydesc").getValue();
		var currentrate = searchForm.down("#currentrate").getValue();
		var previousrate = searchForm.down("#previousrate").getValue();
		var variance = searchForm.down("#variance").getValue();
		var reconperiod = searchForm.down("#reconperiod").getValue();
		var activeFlag = searchForm.down("#activeflag").getValue();
//		debugger;
		var flag = 0;
		var formdata = Ext.encode(searchForm.getValues());
		var exchangeRateStore = this.getExchangeRateGrid().getStore();
		exchangeRateStore.directOptions = {};
		exchangeRateStore.getProxy().extraParams = {
            0: formdata
        };
		if(currencycode == "" || currencycode == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Currency code is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			flag = 1;
		}
		if(reconperiod == "" || reconperiod == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Recon Period is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			flag = 1;
		}
		if (flag == 0){	
			Ext.Msg.show({
				title: "Confirmation",
				msg: "Do you want to insert a record?",
			    buttons: Ext.Msg.OKCANCEL,
			    fn: function(btn) {
					if (btn == 'ok') {
			var formValues = searchForm.getValues();			
			if(formValues.currentrate == ""){formValues.currentrate = null;}
			if(formValues.previousrate == ""){formValues.previousrate = null;}
			if(formValues.variance == ""){formValues.variance = null;}
			var dataArray = [];
			dataArray.push({
				"newInsertData" : formValues
	        });	
			formValues.action = 'INSERT';
			var encodedArray = Ext.encode(dataArray);
			eRecon_web.direct.action.ExchangeRateService.saveRecords(encodedArray, function(p, response) {
				if(response.result[0]!= null){
					if(response.result[0] == "Success") {
						exchangeRateStore.loadPage(1,{
			                callback: function (records, operation, success) {
			                }
			            });
			            Mask.hide();
			    		Ext.Msg.alert('Status',response.result[1]);
			    	}
					else{
						Mask.hide();
						Ext.Msg.alert('Status',response.result[1]);
					}
				}		    	
		    	else {		    		
		    		Ext.Msg.alert('Status',response.result[1]);
		    	}	
			});
					}
			    }
			});
		}//flag
	},
	
	saveRecords : function(){
		var store = this.getExchangeRateGrid().getStore();
		var flag = 0;
		var dataArray = [];
		var Mask = new Ext.LoadMask(this.getExchangeRateContainer(), {msg:"Saving please wait"});
		Mask.show();
		var updateData = store.getUpdatedRecords();  
		var deleteData = store.getRemovedRecords();
		
		if(updateData.length == 0 && deleteData.length == 0) 
		{
    		Ext.MessageBox.alert( "Alert", "No changes found");
    		return false;
		}
		if(updateData.length != 0)
			{
				Ext.each(updateData, function(item, index, array) {
		        dataArray.push({
					"newData" : item.data,
		        	"previousData" : item.raw,
		        	"modified" : item.modified 
			        });
			    });
			}
		
		if(deleteData.length != 0)
			{
				Ext.each(deleteData, function(item, index, array) {
			        dataArray.push({
						"deleteData" : item.data
			        });
			    });
			}
		
		if(flag ==0){
			var encodedArray = Ext.encode(dataArray);
			eRecon_web.direct.action.ExchangeRateService.saveRecords(encodedArray, function(p, response) {
				if(response.result[0]!= null){
					if(response.result[0] == "Success" || response.result[0] =="Exception") {
			    		Ext.MessageBox.alert( "Status", response.result[1] );
			    		store.load();
			    		Mask.hide();
			    	}
				}
				else if (response.result[0] == null || response.result[0] =="Fail"){
					Mask.hide();
					Ext.MessageBox.alert( "Status", "Record(s) modification failed" );
				}
		    }); 
		}
	}, 
		ExchangeRateSearchDetails : function(){
//		debugger;
		var searchPanel = this.getExchangeRateSearch();  
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
        if (searchPanel.getForm().isValid()) 
        {        	
        	var ExchangeRateStore = this.getExchangeRateGrid().getStore();
        	ExchangeRateStore.directOptions = {};
        	ExchangeRateStore.getProxy().extraParams = {
                0: formdata
            };
        	
        	ExchangeRateStore.load({
                callback: function (records, operation, success) {
                }
            });
        }	
	},
	
	clearSearchPanel : function(){
		var searchPanel = this.getExchangeRateSearch(); 
		searchPanel.getForm().reset();
		var ExchangeRateStore = this.getExchangeRateGrid().getStore();
    	ExchangeRateStore.directOptions = {};
    	ExchangeRateStore.getProxy().extraParams = {
            0: null
        };
    	
    	ExchangeRateStore.load({
            callback: function (records, operation, success) {
            }
        });    	
	},
	exchangeRatedownloadfile: function(){
		var searchPanel = this.getExchangeRateSearch();
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var ExchangeRateStore = this.getExchangeRateGrid().getStore();
		Ext.create('eRecon_web.common.ExportToExcelStatusPopup').launchExport(
			'eRecon_web.store.ExchangeRateStore',
			ExchangeRateStore.total,
			null,
			{0: formdata}
		);
	}
});

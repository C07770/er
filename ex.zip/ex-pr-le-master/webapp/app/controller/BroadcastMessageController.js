Ext.define('eRecon_web.controller.BroadcastMessageController',{
	extend: 'Ext.app.Controller',
	stores:	["eRecon_web.store.BroadcastMessageStore"],
	refs: [{
	       ref: 'broadcastMessage',
	       selector: 'BroadcastMessage'
	    }],
	
	init: function()
	{
		this.control({
			'BroadcastMessage':{
           	 beforeactivate: this.handlebeforeactivate           	 
		}	
		});
	},
	
	handlebeforeactivate : function(panel, eOpts){
		var broadcastMessageStore = this.getStore('eRecon_web.store.BroadcastMessageStore');
		broadcastMessageStore.load({
			scope:this,
			callback: function (records, operation, success) 
	        {
				if(success==true)
					{
						var htmlScript = records[0].data.broadcastMessage;
					   this.getBroadcastMessage().getComponent('broadcastForm').body.update(htmlScript);
					}
	        }
		});
	}
		
				
});

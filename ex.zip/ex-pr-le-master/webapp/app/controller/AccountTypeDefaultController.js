Ext.define('eRecon_web.controller.AccountTypeDefaultController',{
	extend: 'Ext.app.Controller',	
	views:['eRecon_web.view.common.CustomDialog'],
	requires: ["eRecon_web.store.AccountTypeDefaultStore"],
	stores:	["eRecon_web.store.AccountTypeDefaultStore"],
	refs: [{
	       ref: 'AccountTypeDefaultGrid',
	       selector: 'AccountTypeDefault_Grid'
	    },
	    {
	    	ref: 'AccountTypeDefaultSearch',
	    	selector: 'AccountTypeDefault_Search'
	    }],
	
	init: function()
	{
		this.control({
			'AccountTypeDefault_Search button[action=search]': {
	            click: this.AccountTypeDefaultSearch
	        },
	        'AccountTypeDefault_Search button[action=clear]': {
	            click: this.clearSearchPanel
	        },
	        'AccountTypeDefault_Search button[action=insert]': {
	            click: this.insertNewRecord
	        },
	        'AccountTypeDefault_Grid button[action=save]': {
	        	click: this.saveRecords
	        },
	        'AccountTypeDefault_Search button[action=openSearchTree]':{
	        	click: this.searchSubAccount
	        },
	        'AccountTypeDefault_Grid button[action=acctDefaultExcel]':{
	        	click: this.acctDefaultdownlaodfile
	        }
		});
	},

	searchSubAccount:function(){
		var mask = new Ext.LoadMask(Ext.getBody(),{msg:"Please wait..."});
		mask.show();
		
		var searchForm = this.getAccountTypeDefaultSearch();
		var SubAccount = searchForm.down("#acct_type_id");
		
		eRecon_web.direct.action.AccountTypeDefaultService.getAccountTypeTree(function(p, response) {

			var firstRecord;
			var fields= new Array();
			var data=new Array();
			var index = 0;			
			var gridHeaderArray = new Array();
			
			var AccountTypesTree = new Ext.tree.TreePanel({
				title: 'Account Defaults',
				lines: false,
				useArrows:true,
				floating:true,	
			    modal:true,
				renderTo: Ext.getBody(),
				width: 500,
	    		height:500,
	    		closable:true,
	    		rootVisible:false,
	    		listeners:{
	    			itemclick:{
	    				fn:function(view,record,item,index,event){
	    					SubAccount.setValue(record.data.id);
	    				}
	    			}
	    		}
			});
			
			 var rootNode ={
				name:'SubAccounts',
				text:'SubAccounts',
				expanded:true,
				leaf:false,
				children:[]
			 };
			 
			 AccountTypesTree.setRootNode(rootNode);
			 var root = AccountTypesTree.getRootNode();
			 
			 for (var i=0; i < response.result.length; i++){
					var record =  response.result[i];
					if(record.PARENTID == 0){
						var subNode_Level1 = {
								name :record.TITLE,
								text: record.TITLE,
								id:record.ID,
								leaf:true
							};
						root.appendChild(subNode_Level1);
						var subNode_L1 = root.findChild("text",record.TITLE);						
						for (var j=0; j < response.result.length - 1; j++){
							if(record.ID == response.result[j].PARENTID){															
								var subNode_Level2 = {
										name :response.result[j].TITLE,
										text: response.result[j].TITLE,
										id:response.result[j].ID,
										leaf:true
									};
								subNode_L1.data.leaf = false;
								subNode_L1.appendChild(subNode_Level2);
							} 							
						}
					}
			 }
			 mask.hide();
			 AccountTypesTree.show();
		});					
	},
	
	insertNewRecord : function(){
		var searchForm = this.getAccountTypeDefaultSearch();
		var acctTypeId = searchForm.down("#acct_type_id").getValue();
		var acctAgingType = searchForm.down("#acct_aging_type").getValue();
		var riskType = searchForm.down("#risk_type").getValue();
		var agingBenchmark = searchForm.down("#aging_benchmark").getValue();
		var usdthreshold = searchForm.down("#usd_threshold").getValue();
		var activeFlag = searchForm.down("#active_flag").getValue();
		var isValidAccount = false;
//		debugger;
		var flag = 0;
		
		if(acctAgingType == "" || acctAgingType == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Account Aging Type is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			flag = 1;
		}
		if(riskType == "" || riskType == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Risk Type is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			flag = 1;
		}
		if(agingBenchmark == "" || agingBenchmark == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Aging Benchmark is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			flag = 1;
		}
		if(usdthreshold == "" || usdthreshold == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>USD Threshold is required .</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			flag = 1;
		}
		if(activeFlag == "" || activeFlag == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Active Flag is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			flag = 1;
		}
	
		if(acctTypeId == "" || acctTypeId == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Sub Account Type is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			flag = 1;
		}
		else{
			eRecon_web.direct.action.AccountTypeDefaultService.getAccountTypeTree(function(p, response) {
				if (response.result.length > 0){
//					debugger;
					for (var i=0; i < response.result.length; i++){
						if (response.result[i].ID == acctTypeId){
							isValidAccount = true;
							break;
						}
					}
					if (!isValidAccount){
//						debugger;
						flag = 1;
						Ext.Msg.show({
							title: "Error",
							msg: "<b>Please enter valid SubAccount Type ID.</b><br>",
							buttons: Ext.Msg.OK,
							icon: Ext.Msg.ERROR
						});							
					}
					else{
						if (flag == 0){
							Ext.Msg.show({
								title: "Confirmation",
								msg: "Do you want to insert a record?",
							    buttons: Ext.Msg.OKCANCEL,
							    fn: function(btn) {
									if (btn == 'ok') {	
							var formValues = searchForm.getValues();
							var dataArray = [];
							dataArray.push({
								"newInsertData" : formValues
					        });	
							formValues.action = 'INSERT';
							var encodedArray = Ext.encode(dataArray);
							eRecon_web.direct.action.AccountTypeDefaultService.saveRecords(encodedArray, function(p, response) {
								if(response.result[0]!= null){
									if(response.result[0] == "Success") {		    
							    		Ext.Msg.alert('Status',response.result[1]);
							    	}
									else{
										Ext.Msg.alert('Status',response.result[1]);
									}
								}		    	
						    	else {		    		
						    		Ext.Msg.alert('Status',response.result[1]);
						    	}
							});
									}
								}
							});
						}//flag
					}
				}
			});
		}
	},
	
	saveRecords : function(){
		var store = this.getAccountTypeDefaultGrid().getStore();
		var flag = 0;
		var dataArray = [];
		var updateData = store.getUpdatedRecords();  
		var deleteData = store.getRemovedRecords();
		
		if(updateData.length == 0 && deleteData.length == 0) 
		{
    		Ext.MessageBox.alert( "Alert", "No changes found");
    		return false;
		}
		if(updateData.length != 0)
			{
				Ext.each(updateData, function(item, index, array) {
		        dataArray.push({
					"newData" : item.data,
		        	"previousData" : item.raw,
		        	"modified" : item.modified 
			        });
			    });
			}
		
		if(deleteData.length != 0)
			{
				Ext.each(deleteData, function(item, index, array) {
			        dataArray.push({
						"deleteData" : item.data
			        });
			    });
			}
		
		if(flag ==0){
			var encodedArray = Ext.encode(dataArray);
			eRecon_web.direct.action.AccountTypeDefaultService.saveRecords(encodedArray, function(p, response) {				
				if(response.result[0]!= null){
					if(response.result[0] == "Success" || response.result[0] =="Exception") {
			    		Ext.MessageBox.alert( "Status", response.result[1] );
			    		store.load();		    		
			    	}
				}
				else if (response.result[0] == null || response.result[0] =="Fail"){
					Ext.MessageBox.alert( "Status", "Record(s) modiciation failed" );
				}		    	
		    }); 
		}
	},
	AccountTypeDefaultSearch : function(){		
		var searchPanel = this.getAccountTypeDefaultSearch(); 
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
        if (searchPanel.getForm().isValid()) 
        {        	
        	var AccountDefaultStore = this.getAccountTypeDefaultGrid().getStore();
        	AccountDefaultStore.directOptions = {};
        	AccountDefaultStore.getProxy().extraParams = {
                0: formdata
            };
        	
        	AccountDefaultStore.load({
                callback: function (records, operation, success) {
                }
            });
        }	
	},
	
	clearSearchPanel : function(){
		var searchPanel = this.getAccountTypeDefaultSearch(); 
		searchPanel.getForm().reset();
		var AccountDefaultStore = this.getAccountTypeDefaultGrid().getStore();
    	AccountDefaultStore.directOptions = {};
    	AccountDefaultStore.getProxy().extraParams = {
            0: null
        };
    	
    	AccountDefaultStore.load({
            callback: function (records, operation, success) {
            }
        });
	},
	
	acctDefaultdownlaodfile: function(){
		var searchPanel = this.getAccountTypeDefaultSearch(); 
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var AccountDefaultStore = this.getAccountTypeDefaultGrid().getStore();
		Ext.create('eRecon_web.common.ExportToExcelStatusPopup').launchExport(
			'eRecon_web.store.AccountTypeDefaultStore',
			AccountDefaultStore.total,
			null,
			{0: formdata}
		);
	}
});

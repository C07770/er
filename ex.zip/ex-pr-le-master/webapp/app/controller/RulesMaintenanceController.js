Ext.define('eRecon_web.controller.RulesMaintenanceController',{
	extend: 'Ext.app.Controller',
	requires:	[
		'eRecon_web.store.RuleStore',
		'eRecon_web.view.rulesmaintenance.RulesMaintenanceGrid',
		'eRecon_web.view.rulesmaintenance.RuleDetailForm'
	],
	stores:	['eRecon_web.store.RuleStore'],
	views: ['eRecon_web.view.rulesmaintenance.RulesMaintenanceGrid',
	        'eRecon_web.view.rulesmaintenance.RuleDetailForm'
	        ],
	init: function(){
		var me = this;
		me.control({
			'rulesmaintenance_container': {
				boxready: function() {
					me.refreshRuleStore();
				},
				refresh_data: function() {
					me.refreshRuleStore();
				},
				close: function() {
					me.stopLocking();
				}
		    },
		    
			'rulesmaintenance_container *[searchId=quickSearch]': {
		    	triggerClick: function(trig) {
					me.quickSearch(trig.value);0
				},
				
				keypress: function(trig, e) {
					if (e.keyCode == e.ENTER) {
						me.quickSearch(trig.value);
					}
				},
				
				change: { 
					fn: function(trig, newVal) {
						me.quickSearch(newVal);
					},
					buffer: 300
				}
			},
			
			'rulesmaintenance_container *[searchId=search]': {
				click: function(btn) {
					var v = Ext.create('eRecon_web.view.rulesmaintenance.RulesSearchPopup');
					var ruleStore = Ext.getStore('eRecon_web.store.RuleStore');
					var searchCriteria = ruleStore.getSearchCriteria();
					searchCriteria.quickSearch = btn.up('*[searchId=rulesmaintenance_toolbar]')
					                                .down('*[searchId=quickSearch]').value 
					v.setSearchCriteria(searchCriteria);
					v.show();
				}
			},

			'rulesmaintenance_container *[searchId=edit]': {
				click: function(btn) {
					me.lockScreen(function() {
						var grid = btn.up('rulesmaintenance_container').down('rulesmaintenance_grid');
						var selectedRecord = grid.getSelectionModel().getSelection()[0];
						if (!selectedRecord) {
							Ext.MessageBox.alert("", "Please select the rule first");
							return;
						}
						var status = selectedRecord.get("status");
						if (status != "Test" && status != "Rejected") {
							Ext.MessageBox.alert( "", 'Only rules in "Test" or "Rejected" status can be edited');
							return;
						}
						var v = Ext.create('eRecon_web.view.rulesmaintenance.RuleEditPopup');
						v.show();
						//me.alignRoleNameField(v);
						v.down('form').loadRecord(selectedRecord);
					});
				}
			},

			'rulesmaintenance_container *[searchId=new]': {
				click: function(btn) {
					me.lockScreen(function() {
						var v = Ext.create('eRecon_web.view.rulesmaintenance.RuleEditPopup');
						var rec = Ext.create('eRecon_web.model.RuleModel');
						v.show();
						v.isNewRule = true;
						v.setTitle("New Rule");
						//me.alignRoleNameField(v);
						v.down('form').loadRecord(rec); 
					});
				}
			},

			'rulesmaintenance_container *[searchId=delete]': {
				click: function(btn) {
					var grid = btn.up('rulesmaintenance_container').down('rulesmaintenance_grid');
					var selectedRecord = grid.getSelectionModel().getSelection()[0];
					var status = selectedRecord.get('status'); 
					if (status != "Active" && status != "Test" && status != "Rejected") {
						Ext.Msg.alert("","Invalid status for delete");
						return;
					}
					me.lockScreen(function() {
						Ext.Msg.show({
						    title: 'Confirmation',
						    msg: 'Please click "OK" to confirm',
						    buttons: Ext.Msg.OKCANCEL,
						    icon: Ext.window.MessageBox.WARNING,
						    fn: function(btn) {
								me.stopLocking();
								if (btn == 'ok') {
									if (status == "Active") {
										selectedRecord.set('status',"Delete");
									}
									if (status == "Test" || status == "Rejected") {
										grid.store.remove(selectedRecord);
										grid.store.sync({
											success: function(){
												me.refreshRuleStore();
											}
										});
										return;
									}
									grid.store.sync();
								}
							}
						});
					});
				}
			},
			
			'rulesmaintenance_container *[searchId=adjust_priorities]': {
				click: function(btn) {
					me.lockScreen(function() {
						me.stopLocking(); // Here we are just checking if somebody else locked the screen,
										  // so we are releasing the lock immediately	
										  // The actual lock will happen on the search popup apply button
						var v = Ext.create('eRecon_web.view.rulesmaintenance.RulesSearchPopup');
						var searchCriteria = Ext.getStore('eRecon_web.store.RuleStore').searchCriteria;
						if (searchCriteria) {
							v.setSearchCriteria(searchCriteria);
						}
						v.setPriorityMode(true);
						v.show();
					});
				}
			},
			
			'rulesmaintenance_container *[searchId=exit_priority_adjustment]': {
				click: function(btn) {
					var grid = Ext.ComponentQuery.query('rulesmaintenance_grid')[0];
					var wereChanges = false;
					grid.store.each(function(item) {
						if (item.dirty) {
							wereChanges = true;
							return false;
						}
					});
					var tempFn = function() {
						me.stopLocking();
						var colArr = Ext.Array.map(grid.columns, function(item){
							return item.cloneConfig({sortable: true});
						}); 
						Ext.Array.erase(colArr,0,1); // we don't want to duplicate the "+" from rowexpander
						grid.reconfigure(me.getStore('eRecon_web.store.RuleStore'), colArr);
						me.adjustToolbar(false);
						me.refreshRuleStore();
					};
					if (wereChanges) {
						Ext.Msg.show({
							title: "Warning",
							icon: Ext.window.MessageBox.WARNING,
						    msg: 'The priority changes are not saved and will be lost.<br>'+
						    	 'Please click "OK" to confirm',
						    buttons: Ext.Msg.OKCANCEL,
						    fn: function(btn) {
								if (btn == 'ok') {
									grid.store.rejectChanges();
									tempFn();
								}
							}

						});
					}
					else {
						tempFn();
					}
				}
			},
			
			'rulesmaintenance_container *[searchId=priority_up], *[searchId=priority_down]': {
				click: function(btn) {
					me.changePriority(btn);
				}
			},
			
			'rulesmaintenance_container *[searchId=remove_gaps]': {
				click: function(btn) {
					var wereChanges = false;
					var store = Ext.ComponentQuery.query('rulesmaintenance_grid')[0].store;
					for (var i = 0; i < store.getCount(); i++) {
						var item = store.getAt(i);
						var p = item.get("proposedPriority");
						if (p != i+1) {
							item.set("proposedPriority", i+1);
							wereChanges = true;
						}
					}
					if (wereChanges) {
						Ext.Msg.alert('', 'Some proposed priorites were changed to eliminate the sequential gap. The changes will be saved when you click "Save Priorities" button');
					}
				}
			},
			
			'rulesmaintenance_container *[searchId=save_priorities]': {
				click: function(btn) {
					if (!me.werePriorityChanges()) {
						Ext.Msg.alert('', 'There were no changes made');
						return;
					}
					me.getStore('eRecon_web.store.RuleStore').sync({
						success: function() {
							//Ext.Msg.alert('Success', 'Changes were successfully submitted');
							me.getController('MainController').showStatus('Changes were successfully submitted');
						},
						
						failure: function() {
							Ext.MessageBox.alert('Error', 'Saving priorities failed');
						}
					});
				}
			},
			
			'rulesmaintenance_container *[searchId=test_and_export]': {
				click: function(btn) {
					var searchPopup = Ext.create('eRecon_web.view.rulesmaintenance.RulesSearchPopup');
					var searchCriteria = Ext.getStore('eRecon_web.store.RuleStore').searchCriteria;
					if (searchCriteria) {
						searchPopup.setSearchCriteria(searchCriteria);
					}
					searchPopup.setTestAndExportMode(true);
					searchPopup.show();
				}
			},
			
			'rulesmaintenance_container *[searchId=submit_for_approval]': {
				click: function(btn) {
					var grid = btn.up('rulesmaintenance_container').down('rulesmaintenance_grid');
					var selectedRecord = grid.getSelectionModel().getSelection()[0];
					if (!selectedRecord) {
						return;
					}
					var status = selectedRecord.get("status");
					if (status != "Test" && status != "Delete") {
						Ext.Msg.alert( "", 'Only rules in "Test" or "Delete" status can be submitted for approval');
						return;
					}
					Ext.Msg.show({
						title: "Confirmation",
						msg: "You are about to submit the rule for approval/deletion.<br>" + 
						     "Please confirm that you wish to submit this rule.",
					    buttons: Ext.Msg.OKCANCEL,
					    fn: function(btn) {
							if (btn == 'ok') {
								if (status == "Test") {
									selectedRecord.set('status','Pending Approval');
								}
								if (status == "Delete") {
									selectedRecord.set('status','Delete Pending Approval');
								}
								grid.store.sync({
									success: function() {
										//Ext.Msg.alert('Success', 'The rule was successfully submitted for approval');
										me.getController('MainController').showStatus('The rule was successfully submitted for approval', 5000);
									},
									
									failure: function() {
										Ext.MessageBox.alert('Error', 'Operation failed');
									}
								});
							}
						}
					});
				}
			},
			
			'rulesmaintenance_container *[searchId=recall]': {
				click: function(btn) {
					var grid = btn.up('rulesmaintenance_container').down('rulesmaintenance_grid');
					var selectedRecord = grid.getSelectionModel().getSelection()[0];
					if (!selectedRecord) {
						return;
					}
					var status = selectedRecord.get("status");
					if (status != "Pending Approval" 
							&& status != "Delete" 
							&& status != "Delete Pending Approval"
							&& status != "Approved Delete"
							&& status != "Approved"
					   ) {
						Ext.Msg.alert( "", 'Only rules in "Pending Approval", "Delete", "Delete Pending Approval", "Approved Delete", "Approved" status can be recalled');
						return;
					}
					Ext.Msg.show({
						title: "Confirmation",
						msg: "You are about to recall the rule. Please confirm.",
					    buttons: Ext.Msg.OKCANCEL,
					    fn: function(btn) {
							if (btn == 'ok') {
								var ruleId = selectedRecord.get('ruleId');
								var arr = [ruleId.toString()];
								eRecon_web.direct.action.RulesMaintenanceService.recallRules(arr, function(dummy,rtnObj) {
									if (rtnObj.status) {
										me.refreshRuleStore(null, null, function() {
											me.getController('MainController').showStatus('The rule was successfully recalled', 5000);
											var idx = grid.store.findExact('ruleId', ruleId);
											if (idx >= 0) {
												grid.getSelectionModel().select(idx);
											}
										});
									}
									else {
										Ext.Msg.alert("","Operation failed");
									}
								}); 								
							}
						}
					});
				}
			},

			'rulesmaintenance_container *[searchId=collapseTool]': {
				click: function(tool) {
					var detailForm = Ext.ComponentQuery.query('rulesmaintenance_ruledetailform')[0];
					var visible = detailForm.isVisible(); 
					if (visible) {
						tool.setType('down');
					}
					else {
						tool.setType('up');
					}
					detailForm.setVisible(!visible);
				}
			},

			'rulesmaintenance_rulessearchpopup *[searchId=applyButton]': {
				click: function(btn) {
					var rulesSearchPopup = btn.up('rulesmaintenance_rulessearchpopup');
					var searchCriteria = {};
					searchCriteria.quickSearch = rulesSearchPopup.down('*[searchId=quickSearch]').value;
					Ext.ComponentQuery.query('*[searchId=rulesmaintenance_toolbar]')[0]
					           .down('*[searchId=quickSearch]').setValue(searchCriteria.quickSearch);
 					searchCriteria.ruleId = rulesSearchPopup.down('*[searchId=ruleId]').value;
					searchCriteria.ruleName = rulesSearchPopup.down('*[searchId=ruleName]').value;
					searchCriteria.ruleRegion = rulesSearchPopup.down('*[searchId=ruleRegion]').value;
					var ruleStore = Ext.getStore('eRecon_web.store.RuleStore'); 
					if (rulesSearchPopup.priorityMode || rulesSearchPopup.testAndExportMode) {
						if (!searchCriteria.ruleRegion) {
							Ext.Msg.alert("", "Please select region");
							return;
						}
						if (rulesSearchPopup.testAndExportMode) {
							ruleStore = Ext.create('eRecon_web.store.RuleStore');
						}
						ruleStore.currentPage = 1;
						me.refreshRuleStore(ruleStore, {ruleRegion: searchCriteria.ruleRegion, 
											 priorityMode: rulesSearchPopup.priorityMode,
											 testAndExportMode: rulesSearchPopup.testAndExportMode
											}, 
							function(){
								if (rulesSearchPopup.priorityMode) {
									me.arrangePriorityAdjustment();
								}
								else if (rulesSearchPopup.testAndExportMode) {
									var popup = Ext.create('eRecon_web.view.rulesmaintenance.RuleTestAndExportPopup');
									popup.down('grid').reconfigure(ruleStore);
									popup.show();
								}
							}
						);
					}
					else {
						ruleStore.searchCriteria = searchCriteria;
						ruleStore.currentPage = 1;
						me.refreshRuleStore();
					}
					rulesSearchPopup.close();
				}
			},
			
			'rulesmaintenance_testandexportpopup button[searchId=submit]': {
				click: function(btn) {
					var testAndExportPopup = btn.up('window'); 
					var selectedRules = testAndExportPopup.down('grid').getSelectionModel().getSelection();
					if (selectedRules.length == 0) {
						Ext.Msg.alert("","Please select a rule to test before submitting the test result export.");
						return;
					}
					var selectedRulesStr = '';
					for (var i1 = 0; i1 < selectedRules.length; i1++) {
						if (selectedRulesStr != '') {
							selectedRulesStr += '~';
						}
						selectedRulesStr += selectedRules[i1].get('ruleId');
					}
					testAndExportPopup.setLoading({msg: "Please wait..."});
					Ext.Ajax.request({
						url: 'filedownloadtrigger.up?downloadType=RULE_TEST_AND_EXPORT',
						method:'POST', 
						params: {
							ruleId: selectedRulesStr
						},
						scope : me,
						success : function(response, opts) {
							response = Ext.decode(response.responseText);
							if(response.success){
								testAndExportPopup.setLoading(false);
								Ext.MessageBox.alert('Success', "Rule Test file is being created. You will be notified once the rule test is complete. Schedule ID: " + response.scheduleId);
								testAndExportPopup.close();
							}
							else {
								Ext.MessageBox.alert('Failure', response.message);
								testAndExportPopup.setLoading(false);
							}
						},
						failure: function(err) {
							Ext.MessageBox.alert('Error occured', 'Please try again!');
							testAndExportPopup.setLoading(false);
						}
					}); 

				}
			},
			
			'rulesmaintenance_grid': {
				selectionchange: Ext.Function.createBuffered(
					function(selectionModel, selectedRecords, options) {
						var selectedRecord = selectedRecords[0];
						if (selectedRecord) {
							var cont = Ext.ComponentQuery.query('rulesmaintenance_ruledetailform')[0];
							cont.loadRecord(selectedRecord);
							//me.alignRoleNameField(cont);
						}
					},300),
				beforeedit: function(editor, ev) {
					if (ev.record.get('status') != "Test") {
						return false;
					}
					if (!Ext.ComponentQuery.query('*[searchId=rulesmaintenance_toolbar]')[0].priorityMode) {
						return false;
					}
					Ext.defer(function(){
						var nmbFld = editor.editors.getAt(0).field; 
						nmbFld.setMinValue(1);
						nmbFld.setMaxValue(ev.grid.store.getRange().length);
					},200);
				},
				edit: function(editor, ev) {
					var arr = ev.grid.store.getRange();
					var rec = ev.record;
					var idx = Ext.Array.indexOf(arr, rec);
					var idx1 = rec.get('proposedPriority') - 1;
					if (idx == idx1) {
						return;
					}
					Ext.Array.remove(arr, rec);
					Ext.Array.insert(arr,idx1,[rec]);
					for (var i=0; i<arr.length; i++) {
						arr[i].set("proposedPriority", i+1);
					}
					ev.grid.store.loadData(arr);	
				}
			},
			
			'rulesmaintenance_ruleeditpopup': {
				close: function() {
					me.stopLocking();
				}
			},
			
			'rulesmaintenance_ruleeditpopup rulevaluetriggerfield': {
				ruleValueTriggerClick: function(triggerField) {
				    if (!triggerField.up('rulesmaintenance_ruleeditpopup').down('combo[searchId=ruleRegion]').value) {
				    	Ext.Msg.alert("", "Please select the region first");
				    	return;
				    }
					me.getController('eRecon_web.controller.RuleFieldMultiselectController').showMultiselectPopup(triggerField);
				}
			},
			
			'rulesmaintenance_ruleeditpopup combo[searchId=ruleRegion]': {
				change: function(combo, newValue, oldValue) {
					combo.oldValue = oldValue;
				},
				
				select: function(combo, records) {
					var arr = combo.up('window').query('rulevaluetriggerfield:not([name=ccyCode])');
					var needConfirm = false;
					Ext.each(arr, function(item) {
						if (item.value) {
							needConfirm = true;
							return false;
						}
					});

					if (needConfirm) {
						Ext.Msg.show({
							title: "Confirmation",
							msg: "The region-dependent values will be cleared. Please confirm",
							buttons: Ext.Msg.OKCANCEL,
							fn: function(btn) {
								if (btn == 'ok') {
									Ext.each(arr, function(item) {
										item.setValue(null);
									});
								}
								else {
									combo.setValue(combo.oldValue);
								}
							}
						});
					}
				}
			},
			
			'rulesmaintenance_ruleeditpopup button[searchId=apply]': {
				click: function(btn) {
					var w = btn.up('window'); 
					var form = w.down('form'); 
					
					var errMsg = "";
					if (!form.down('*[name=ruleName]').value) {
						errMsg += "Please enter Rule Name<br>";
					}
					
					if (!form.down('*[name=geocode]').value) {
						errMsg += "Please select region<br>";
					}
					
					if (!form.down('*[name=ctryCode]').value //country
							&& !form.down('*[name=account]').value //gl acc 1
							&& !form.down('*[name=lclLvId]').value // local LVID
							&& !form.down('*[name=icAcctId]').value  // intercompany
							&& !form.down('*[name=ccyCode]').value  // ccy code
							&& !form.down('*[name=glAcct2]').value  // gl acc 2
							&& !form.down('*[name=subAcctTypeId]').value  // FRS acc
							&& !form.down('*[name=gaapInd]').value  // GAAP Indicator
							&& !form.down('*[name=condi]').value  // FRS BU
							&& !form.down('*[name=glSrcSysId]').value  // Src. sys id
							&& !form.down('*[name=leLvId]').value  // LVID
							&& !form.down('*[name=product]').value  // local prod. code
							&& !form.down('*[name=glGoc]').value  // GOC
							&& !form.down('*[name=source]').value  // GL System Identifier
							&& !form.down('*[name=feedId]').value  // GL Feed ID
					) {
						errMsg += "Please enter one or more selection criteria<br>";
					}

					if (!form.down('*[name=rGlAcct2]').value 
							&& !form.down('*[name=rGaapInd]').value 
							&& !form.down('*[name=rGlSrcSysId]').value 
							&& !form.down('*[name=rProduct]').value 
							&& !form.down('*[name=rGlGoc]').value
							&& !form.down('*[name=rIcAcctId]').value
					) {
						errMsg += "Please select at least one rollup level<br>";
					}

					if (errMsg) {
						Ext.Msg.alert("", errMsg);
						return;
					}

					form.getForm().updateRecord();
					var rec = w.down('form').getRecord();
					
					me.setValueFromCheckbox(form, rec, 'rGlAcct2');
					me.setValueFromCheckbox(form, rec, 'rGaapInd');
					me.setValueFromCheckbox(form, rec, 'rGlSrcSysId');
					me.setValueFromCheckbox(form, rec, 'rProduct');
					me.setValueFromCheckbox(form, rec, 'rGlGoc');
					me.setValueFromCheckbox(form, rec, 'rIcAcctId');

					var store = Ext.getStore('eRecon_web.store.RuleStore');
					var isNewRule = w.isNewRule; 
					if (isNewRule) {
						store.add(rec);
					}
				
					if (rec.get('status') == 'Rejected') {
						rec.set('status', 'Test');
					}
					
					store.sync({success: function(){
							Ext.ComponentQuery.query('rulesmaintenance_grid')[0].getSelectionModel().deselectAll(true);
							Ext.ComponentQuery.query('rulesmaintenance_grid')[0].getSelectionModel().select(rec);
							if (isNewRule) {
								rec.raw = Ext.clone(rec.data);
							}
						}
					});
					w.close();
				}
			}


		});
	},
	
//	alignRoleNameField: function(cont) {
//		Ext.suspendLayouts();
//		var lclLvIdField = cont.down('*[name="lclLvId"]');
//		var glAcc1Field = cont.down('*[name="account"]');
//		var ruleNameField = cont.down('*[name="ruleName"]');
//		Ext.resumeLayouts();
//		ruleNameField.setWidth(300);
//		var x1 = Math.abs(cont.el.getOffsetsTo(lclLvIdField.el)[0]);
//		var x2 = Math.abs(cont.el.getOffsetsTo(glAcc1Field.el)[0]) + glAcc1Field.getWidth();
//		ruleNameField.setWidth(Math.abs(x2 - x1));
//	},
	
	setValueFromCheckbox: function(form, rec, fldName) {
		if (form.down('checkbox[name='+fldName+']').getValue()) {
			rec.set(fldName,'Y');
		}
		else {
			rec.set(fldName,'');
		}
	},
	
	adjustToolbar: function(isPriorityMode) {
		Ext.suspendLayouts();
		Ext.ComponentQuery.query('*[searchId=rulesmaintenance_pagingtoolbar]')[0].setVisible(!isPriorityMode);
		var toolbar = Ext.ComponentQuery.query('*[searchId=rulesmaintenance_toolbar]')[0];
		toolbar.priorityMode = isPriorityMode;
		if (isPriorityMode) {
			toolbar.down('*[searchId=rulesmaintenance_title]').setValue('Rules Maintenance - Priority Adjustment Mode');
		}
		else {
			toolbar.down('*[searchId=rulesmaintenance_title]').setValue('Rules Maintenance');
		}
		Ext.each(toolbar.query('button, tbseparator, triggerfield, *[prioritiesMode]'),
		function(item) {
			item.setVisible(!!item.prioritiesMode == isPriorityMode);
		});
		Ext.resumeLayouts();
		toolbar.doLayout();
	},
	
	arrangePriorityAdjustment: function(region) {
		var me = this;
		me.lockScreen(function() {
			var grid = Ext.ComponentQuery.query('rulesmaintenance_grid')[0];
			me.adjustToolbar(true);
			var tempStore = Ext.create('Ext.data.ArrayStore', 
					{
						model: grid.store.model,
						data: grid.store.getRange()
					}
			);
			tempStore.sort([{sorterFn: function(o1,o2){
				var pr1 = me.getProposedPriority(o1);
				var pr2 = me.getProposedPriority(o2);
		
				if (pr1 > pr2) {
					return 1;
				}
				else if (pr1 < pr2) {
					return -1;
				}
				else {
					return 0;
				}
			  }
			}]);
			var colArr = Ext.Array.map(grid.columns, function(item){
				return item.cloneConfig({sortable: false});
			}); 
			Ext.Array.erase(colArr,0,1); // we don't want to duplicate the "+" from rowexpander
			grid.reconfigure(tempStore, colArr);
			grid.store.sorters.clear(); // we don't need sorting anymore
		});
	},
	
	changePriority: function(btn) {
		var me = this;
		var grid = Ext.ComponentQuery.query('rulesmaintenance_grid')[0];
		var selectedRecord = grid.getSelectionModel().getSelection()[0];
		if (!selectedRecord) {
			return;
		}
		if (selectedRecord.get('status') != "Test") {
			Ext.Msg.alert("", 'Please select the rule having "Test" status');
			return;
		}
		var arr = grid.store.getRange();
		var idx = Ext.Array.indexOf(arr, selectedRecord);
		var idx1;
		if (btn.searchId == 'priority_up') {
			idx1 = idx - 1;
		}
		else {
			idx1 = idx + 1;
		}
		if (idx1 < 0 || idx1 > arr.length - 1) {
			return;
		}
		var rec = arr[idx1];
		var pr1 = me.getProposedPriority(rec);
		var pr = me.getProposedPriority(arr[idx]);
		rec.set('proposedPriority', pr);
		arr[idx].set('proposedPriority', pr1);
		arr[idx1] = arr[idx];
		arr[idx] = rec;
		grid.store.loadData(arr);
		grid.getView().focusRow(selectedRecord);
	},
	
	getProposedPriority: function(rec) {
		var pr = rec.get('proposedPriority');
		if (pr != 0 && !pr) {
			pr = rec.get('rulePriority');
		}
		return pr;
	},
	
	refreshRuleStore: function(store, arg_directOptions, callbackFn) {
		if (!store) {
			store = Ext.getStore('eRecon_web.store.RuleStore');
		}
		if (store.getCount()==0 && store.currentPage > 1) {
			store.currentPage -= 1;
		}
		store.load(
		  {
			directOptions: arg_directOptions || {},
			callback: function() {
				if (store.getCount()) {
					Ext.ComponentQuery.query('rulesmaintenance_grid')[0].getSelectionModel().select(0);
				}
				else {
					// clear fields
					Ext.ComponentQuery.query('rulesmaintenance_ruledetailform')[0].getForm().reset();
				}
				if (callbackFn) {
					callbackFn();
				}
			}
		 }
		);
	},
	
	lockScreen: function(callback) {
		var me = this;
		if (!me.lockTask) {
			me.lockTask = Ext.util.TaskManager.newTask({
			    run: function() {
					eRecon_web.direct.action.RulesMaintenanceService.lockScreenForUpdate("rulesmaintenance",
						function(rslt,e) {
							if (!e.status) {
								me.stopLocking();
								Ext.Msg.alert("", 'Problem connecting to the server');
								return;
							}
							if (rslt.status == "success") {
								if (me.lockTask.callback) {
									me.lockTask.callback();
									me.lockTask.callback = null;  // we need to run it only once
								}
							}
							else {
								me.stopLocking();
								Ext.Msg.alert("", 'The user ' + rslt.lockedBy +' is currently editing the rules');
							}
						}	
					);
				},
				interval: 20000,
				fireOnStart: true
			});
		}
		me.stopLocking();
		me.lockTask.callback = callback;
		me.lockTask.restart();
	},
	
	stopLocking: function() {
		var me = this;
		try {
			me.lockTask.stop();
		}
		catch(err) {
			
		}
	},
	
	quickSearch: function(searchStr) {
		var me = this;
		var ruleStore = Ext.getStore('eRecon_web.store.RuleStore');
		ruleStore.currentPage = 1;
		var searchCriteria = ruleStore.getSearchCriteria();
		searchCriteria.quickSearch = searchStr; 
		me.refreshRuleStore();
	},
	
	werePriorityChanges: function() {
		var store = Ext.ComponentQuery.query('rulesmaintenance_grid')[0].store;
		for (var i = 0; i < store.getCount(); i++) {
			var item = store.getAt(i);
			if (item.dirty) {
				return true;
			}
		}
		return false;
	}

});




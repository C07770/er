/**
New Assigned Controller
*/
Ext.define('eRecon_web.controller.NewAssignedController',{
	extend: 'Ext.app.Controller',
	stores:	['eRecon_web.store.NewAssignedStore'],
    refs: [
    {
        ref: 'detailPanel',
        selector: 'newassigned_detailgrid'
    },
    {
    	ref: 'ownerForm',
    	selector: 'newassigned_ownershipform'
    },
    {
    	ref:'acceptConfirm',
    	selector: 'accept_confirm'
    },
    {
    	ref:'declineConfirm',
    	selector: 'decline_confirm'
    }
    ],


	init: function(){
		this.control({
			'newassigned_ownershipform':{
				afterrender: this.initialize
			},
			'newassigned_ownershipform combo[action=select]':{
				select: this.setOwnerShip
			},
			'newassigned_ownershipform button[action=search]':{
				click: this.newAssignedSearchClick
			},
			'newassigned_ownershipform button[action=clear]':{
				click: this.newAssignedClearClick
			},
			'newassigned_detailgrid button[action=acceptanddecline]':{
				click: this.acceptdecline
			},
			'newassigned_detailgrid button[action=acceptall]':{
				click: this.acceptallconfirm
			},
            "accept_confirm":{
            	"acceptall": this.acceptall,
            	"acceptallcancel": this.acceptallcancel
            },
            "decline_confirm":{
            	"declineall": this.declineall,
            	"declineallcancel": this.declineallcancel
            },
			'newassigned_detailgrid button[action=declineall]':{
				click: this.declineallconfirm
			}

		});
	},
	confwin:null,
	declineconfwin:null,
	acceptaction:null,
	initialize:function(){

		this.confwin=Ext.create("eRecon_web.view.newassigned.AcceptConfirm", {
			applyTo: Ext.getBody(),
			layout: 'fit',
			width: 300,
			title: "Accept All",
			height: 125
		});

		this.declineconfwin=Ext.create("eRecon_web.view.newassigned.DeclineConfirm", {
			applyTo: Ext.getBody(),
			layout: 'fit',
			width: 300,
			title: "Decline All",
			height: 125
		});
},

		setOwnerShip: function () {
			var OwnerShipForm=this.getOwnerForm();
			var detailGrid= this.getDetailPanel();
            var role = OwnerShipForm.down("#ownership-combo").getValue();
            if(role==='AO'){
            	detailGrid.down('[dataIndex=transfertouserid]').setVisible(false);
            	detailGrid.down('[dataIndex=transfer_to_acct_owner_id]').setVisible(true);
            }
            else if (role==='PO'){
            	detailGrid.down('[dataIndex=transfertouserid]').setVisible(true);
            	detailGrid.down('[dataIndex=transfer_to_acct_owner_id]').setVisible(false);
            }

            var detailStore = this.getStore('eRecon_web.store.NewAssignedStore');
            detailStore.directOptions = {};
            detailStore.getProxy().extraParams = {
                0: role,
                1:null
            };
            detailStore.loadPage(1);

},

	newAssignedSearchClick : function(){

			var OwnerShipForm=this.getOwnerForm();
			var detailGrid= this.getDetailPanel();
			var role = OwnerShipForm.down("#ownership-combo").getValue();
			if(role==='' || role===null){
				Ext.MessageBox.alert( "Alert", "Please select the  Ownership");
	    		return false;
			}
			var filter= OwnerShipForm.down("#fullkey-textfield").getValue();
			var detailStore = this.getStore('eRecon_web.store.NewAssignedStore');
	            detailStore.directOptions = {};
	            detailStore.getProxy().extraParams = {
	                0: role,
	                1: filter
	            };
	        detailStore.loadPage(1);

},

	newAssignedClearClick : function(){
			var OwnerShipForm=this.getOwnerForm();
			OwnerShipForm.down("#fullkey-textfield").setValue('');
},
	acceptdecline : function (){

		var store = this.getStore('eRecon_web.store.NewAssignedStore');
		var OwnerShipForm=this.getOwnerForm();
		var role = OwnerShipForm.down("#ownership-combo").getValue();
    	var dataArray = [];
        var data = store.getUpdatedRecords();
        if(data.length == 0) {
    		Ext.MessageBox.alert( "Alert", "Please select the full keys you wish to accept or decline");
    		return false;
    	}
        Ext.each(data, function(item, index, array) {
            dataArray.push({
    			"newData" : item.data,
            	"previousData" : item.raw,
            	"modified" : item.modified
            });
        });
        var encodedArray = Ext.encode(dataArray);

        eRecon_web.direct.action.NewAssignedService.acceptdeclineAccounts(encodedArray,role,function(p, response) {
        	if(response.result != "Error") {
        		Ext.getCmp('my-status').setStatus({
        		    text: '<p class="statusbar-success">' + response.result + '</p>',
        		    iconCls: 'iconAccept',
        		    clear: {
        		        wait: 60000,
        		        anim: true,
        		        useDefaults: false
        		    }
        		});
        		store.load();
    		}
        });

},

	acceptallconfirm : function(){
		this.acceptaction='AcceptAll';
		this.confwin.show();
	},

	declineallconfirm : function(){
		this.acceptaction='DeclineAll';
		this.declineconfwin.show();
	},

	acceptall : function (){
		if(this.acceptaction == 'AcceptAll')
			{
				var OwnerShipForm=this.getOwnerForm();
				var role = OwnerShipForm.down("#ownership-combo").getValue();
				var store = this.getStore('eRecon_web.store.NewAssignedStore');
		    	eRecon_web.direct.action.NewAssignedService.acceptAllAccounts(role, function(p, response) {
		    		if(response.result != "Error") {
		    			Ext.getCmp('my-status').setStatus({
		        		    text: '<p class="statusbar-success">'+response.result+'</p>',
		        		    iconCls: 'iconAccept',
		        		    clear: {
		        		        wait: 60000,
		        		        anim: true,
		        		        useDefaults: false
		        		    }
		        		});
		    			store.load();
		    		}
		    	});
			}
		this.confwin.hide();
	},
	acceptallcancel : function(o){
		this.confwin.hide();
},

declineallcancel : function(o){
	this.declineconfwin.hide();
},

	declineall : function (){
		if(this.acceptaction == 'DeclineAll')
		{
			var OwnerShipForm=this.getOwnerForm();
			var role = OwnerShipForm.down("#ownership-combo").getValue();
			var store = this.getStore('eRecon_web.store.NewAssignedStore');
	    	eRecon_web.direct.action.NewAssignedService.declineAllAccounts(role, function(p, response) {
	    		if(response.result != "Error") {
	    			Ext.getCmp('my-status').setStatus({
	        		    text: '<p class="statusbar-success">'+response.result+'</p>',
	        		    iconCls: 'iconAccept',
	        		    clear: {
	        		        wait: 60000,
	        		        anim: true,
	        		        useDefaults: false
	        		    }
	        		});
	    			store.load();
	    		}
	    	});
		}
		this.declineconfwin.hide();
}

});

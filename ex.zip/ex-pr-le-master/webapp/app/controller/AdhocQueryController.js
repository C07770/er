Ext.define('eRecon_web.controller.AdhocQueryController',{
	extend: 'Ext.app.Controller',	
	refs: [{
	       ref: 'AdhocQueryPanel',
	       selector: 'AdhocQuery_Panel'
	    },{
		       ref: 'AdhocQueryContainer',
		       selector: 'AdhocQuery_Container'
		   },{
		       ref: 'SavedQueryGrid',
		       selector: 'SavedQuery_Grid'
		   }],
	
	init: function()
	{
		this.control({
			'AdhocQuery_Panel button[action=submit]': {
	            click: this.populateGrid
	        },
	        'AdhocQuery_Panel button[action=save]': {
	            click: this.saveAndExecute
	        },
	        'SavedQuery_Grid button[action=savegridchanges]':{
	        	click: this.saveGridChanges
	        },
	        'SavedQuery_Grid' :{
	        	beforerender: this.deleteTempQueries
	        },
	        'AdhocQuery_Panel button[action=clear]': {
	            click: this.clearAllFields
	        },
	        'SavedQuery_Grid' :{
	        	selectionchange: this.getQuery
	        },
	        'AdhocQuery_Panel button[action=export]': {
	            click: this.doExport
	        }
		});
		
	},
	
	doExport :  function(){
		console.log("Export action called");
		var queryPanel = this.getAdhocQueryPanel();				
		var reason = queryPanel.down("#reason").getValue();
		var query = queryPanel.down("#sqlstatement").getValue();
		var sqlType = queryPanel.down("#statementtype").getValue();
		
    	if (query !== null && reason != null) {
    		var formdata = {
    				query: query,
    				reason: reason,
    				sqlType: sqlType
    		}
    		    		
    		Ext.Ajax.request({
    			url : 'filedownloadtrigger.up?downloadType=ADHOCQUERY',
    			method:'POST', 
    			params : {
    				formdata: Ext.encode(formdata)
    			},
    			scope : this,
    			success : function(response, opts) {
    				response = Ext.decode(response.responseText);
    				if(response.success){
    					Ext.MessageBox.alert('Successful', 
    							"Your request has been submitted successfully with the request id " + response.scheduleId + ". You should recieve an email on completion.");
    				}
    				else {
    					Ext.MessageBox.alert('Failed', response.message);
    				}
    			},
    			failure : function(err) {
    				Ext.MessageBox.alert('Error occured during Subledger file download.', 'Please try again!');
    			}
    		}); 		

    	} else {
    		Ext.MessageBox.alert( "Alert", "No rows selected in the summary grid." );
    	}
	},
	
	getQuery: function(){
		
		var sqlStmt = "";
		var queryPanel = this.getAdhocQueryPanel();
		var selModel = this.getSavedQueryGrid().getSelectionModel();
		var selRec = selModel.getSelection();
		
		if(selRec.length >0 ){
			sqlStmt = selRec[0].data.sqlstatement;
		}
		queryPanel.down("#sqlstatement").setValue(sqlStmt);   		   		
	},
	
	deleteTempQueries : function(){
		eRecon_web.direct.action.AdhocQueryService.DeleteTempQueries(function(p, response) {	    	
	    });
	},
	
	clearAllFields : function(){		
		var queryPanel = this.getAdhocQueryPanel();
		
		queryPanel.down("#sqlstatement").setValue("");
		queryPanel.down("#reason").setValue("");
		queryPanel.down("#description").setValue("");
		
	},
	
	saveGridChanges : function(){
		var store = this.getSavedQueryGrid().getStore();
		var dataArray = [];
		var updateData = store.getUpdatedRecords(); 		
		var deleteData = store.getRemovedRecords();
	
		if(updateData.length == 0 && deleteData.length == 0) 
		{
    		Ext.MessageBox.alert( "Alert", "No changes found");
    		return false;
		}
		if(updateData.length != 0)
		{
			Ext.each(updateData, function(item, index, array) {
	        dataArray.push({
				"newData" : item.data,
	        	"previousData" : item.raw,
	        	"modified" : item.modified 
		        });
		    });
		}
		if(deleteData.length != 0)
		{
			Ext.each(deleteData, function(item, index, array) {
		        dataArray.push({
					"deleteData" : item.data
		        });
		    });
		}
		var encodedArray = Ext.encode(dataArray);
		eRecon_web.direct.action.AdhocQueryService.SaveModifiedRecords(encodedArray, function(p, response) {
	    	if(response.result == "Success") {
	    		store.load();
	    		Ext.Msg.show({
					title: "Status",
					msg: "<b>Grid Changes saved.</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ALERT
				});
	    	}else{
	    		Ext.Msg.show({
					title: "Status",
					msg: "<b>Description must be unique.</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ERROR
				});
	    	}
	    });
	},	
	
	populateGrid:function(){
		var validationFlag=this.fieldsValidation();
		
		if(validationFlag){
			this.getGridDetails("N");
//			this.SaveExecutedQuery("N");				
		}		
	},
	fieldsValidation:function(){
		
		var queryPanel = this.getAdhocQueryPanel();				
		var reason = queryPanel.down("#reason").getValue();
		var query = queryPanel.down("#sqlstatement").getValue();
		var sqlType = queryPanel.down("#statementtype").getRawValue();
		var index = query.toUpperCase().indexOf('_OBS');
		var validationFlag = true;
		if (query == ""){
			validationFlag = false;
			Ext.Msg.show({
				title: "Error",
				msg: "<b>SQL Statement is required is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});
		}
		if(query.split(' ')[0].toUpperCase()!=sqlType){
			validationFlag = false;
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Statement type and SQL statement are mismatch.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});
		}
		if (reason == ""){
			validationFlag = false;
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Reason is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});
		}
		
		if(index > -1){
			validationFlag = false;
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Execution of _OBS tables are not allowed.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});
		}
		return validationFlag;
	},
	
	getGridDetails : function(isSave) {	
		var me=this;
		var adhocContainer = this.getAdhocQueryContainer();
		var queryPanel = this.getAdhocQueryPanel();	
		var query  = queryPanel.down("#sqlstatement").getValue();
		var sqlType = queryPanel.down("#statementtype").getRawValue();
		var Reason = queryPanel.down("#reason").getValue();
		var RowCountRetrieved = 'YES';
				
		var mask = new Ext.LoadMask(Ext.getBody(),{msg:"Please wait..."});
		mask.show();
		eRecon_web.direct.action.AdhocQueryService.getAdhocResult(query,sqlType,Reason,RowCountRetrieved,function(p, response) {
			
			if(response.status == true && sqlType == 'SELECT' && response.result.total > 0){					
			var firstRecord;
			var fields= new Array();
			var data=new Array();
			var index = 0;			
			var gridHeaderArray = new Array();
			firstRecord = response.result.records[0];				
			for (var header in firstRecord){
				var gridHeader = new Array();
				fields[index]=header;
				var gridCol = Ext.create(Ext.grid.column.Column,{text:header,dataIndex:header});
				if(header == 'RNUM') {gridCol.hidden=true;}
				gridHeaderArray[index] = gridCol;
				index++;
			}
			fields.sort();

			for (var i=0; i < 500; i++){
				var record =  response.result.records[i];
				var datarow=new Array;
				var j = 0;
				for(var val in record){					
					datarow[j] = record[fields[j]];
					j++;
				}
				data[i] = datarow;
			}
			           		
			var resultGridStore = new Ext.data.ArrayStore({
				fields: fields,
				data:data,
				pageSize:25
				
			});
			resultGridStore.load();
			
			if(adhocContainer.getChildByElement('resultGrid') != null) {
				adhocContainer.remove(adhocContainer.getChildByElement('resultGrid'),true);
				adhocContainer.doLayout();
			}
							
			var resultGrid = new  Ext.grid.GridPanel({
				id:'resultGrid',
				stateful:true,
				autoscroll:true,
				height : 270,
			    store: resultGridStore,
			    forceFit: false,
			    enableColumnMove: true,    
			    border: false,   
			    columnLines: true,
			    bbar:[{
			    	xtype:'pagingtoolbar',
			    	store:resultGridStore,
			    	displayInfo: true,
			    	dock: "bottom"	    	
			    }],
			    columns :gridHeaderArray,
			    viewConfig: {
			        emptyText: "No details available."}
			});

			resultGrid.title = "Your SQL Statement returns [" + response.result.total + "] records. ";
						
			adhocContainer.add({region:"south",flex:3,items:resultGrid,collapsible:true,autoScroll:false});
			adhocContainer.doLayout();

			resultGridStore.on('load', function(store, records, successful, operation) {
		        this.loadData(data.slice((this.currentPage-1)*25, (this.currentPage)*25));
		    },resultGridStore);
			
			resultGridStore.load();
			if(isSave=="Y"){ // Save query If user click on Execute and save button  
				me.SaveExecutedQuery("Y");
			}
			mask.hide();
			if (response.result.total > 500){
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Your query returns more than 500 records. To see complete list of records please download it in excel.</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ALERT
				});
			}
		}
			else if(response.status == true && sqlType == 'SELECT' && response.result.total == 0){
				mask.hide();
				Ext.Msg.show({
					title: "Error",
					msg: "<b>Data not found.</b><br>",
					buttons: Ext.Msg.OK,
					icon: Ext.Msg.ALERT
				});
				if(isSave=="Y"){ // Save query If user click on Execute and save button  
					me.SaveExecutedQuery("Y");
				}
			}
		else if(sqlType == 'SELECT' && (response.status == false || response.result=="" ||response.result.total ==0)){
//			else if(response.status == false || response.result=="" ||response.result.total ==0){
			mask.hide();
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Please check the query.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});
			adhocContainer.remove(adhocContainer.items.items[3]);
		}else if(response.status == true && sqlType=="UPDATE" && response.result!=""){
//			mask.hide();
//			var resultGridStore=Ext.ComponentQuery.query('#SavedQuery_Grid')[0].getStore();
//			resultGridStore.load();
			Ext.Msg.show({
				title: "Sucess",
				msg: "<b>Record updated successfully</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ALERT
			});
			if(isSave=="Y"){ // Save query If user click on Execute and save button  
				me.SaveExecutedQuery("Y");
			}
			adhocContainer.remove(adhocContainer.items.items[3]);
		}else if(response.status == true && sqlType=="DELETE" && response.result!=""){
//			mask.hide();
//			var resultGridStore=Ext.ComponentQuery.query('#SavedQuery_Grid')[0].getStore();
//			resultGridStore.load();
			Ext.Msg.show({
				title: "Sucess",
				msg: "<b>Record deleted successfully</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ALERT
			});
			if(isSave=="Y"){ // Save query If user click on Execute and save button  
				me.SaveExecutedQuery("Y");
			}
			adhocContainer.remove(adhocContainer.items.items[3]);
		}else if(response.status == true && sqlType=="INSERT" && response.result!=""){
//			mask.hide();
//			var resultGridStore=Ext.ComponentQuery.query('#SavedQuery_Grid')[0].getStore();
//			resultGridStore.load();
			Ext.Msg.show({
				title: "Sucess",
				msg: "<b>Record inserted successfully</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ALERT
			});
			if(isSave=="Y"){ // Save query If user click on Execute and save button  
				me.SaveExecutedQuery("Y");
			}
			adhocContainer.remove(adhocContainer.items.items[3]);
		}else if(response.status == true && (sqlType=="EXECUTE" || sqlType=="CREATE" ||sqlType=="TRUNCATE" ||sqlType=="ALTER SEQUENCE") && response.result!=""){
//			mask.hide();
//			var resultGridStore=Ext.ComponentQuery.query('#SavedQuery_Grid')[0].getStore();
//			resultGridStore.load();
			Ext.Msg.show({
				title: "Sucess",
				msg: "<b>Query executed successfully</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ALERT
			});
			if(isSave=="Y"){ // Save query If user click on Execute and save button  
				me.SaveExecutedQuery("Y");
			}
			adhocContainer.remove(adhocContainer.items.items[3]);
		}else{
			mask.hide();
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Please check the query.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});
			adhocContainer.remove(adhocContainer.items.items[3]);
		}
			mask.hide();
		});	
	},
	
	saveAndExecute :  function(){
		var validationFlag=this.fieldsValidation();
		if(validationFlag){
			this.getGridDetails("Y");
//			this.SaveExecutedQuery("Y");
		}
				
	},
	
	SaveExecutedQuery : function(saved){
		var me=this;
		var adhocContainer = this.getAdhocQueryContainer();
		var queryPanel =  this.getAdhocQueryPanel();	
		var savedGrid = this.getSavedQueryGrid();
		var adhocQueryPanelData = queryPanel.getForm().getValues();
		var query = queryPanel.down("#sqlstatement").getValue();
		adhocQueryPanelData.saved = saved;
		var encodedPanelData = Ext.encode(adhocQueryPanelData);
		eRecon_web.direct.action.AdhocQueryService.SaveQuery(encodedPanelData, function(p, response) {
			if(response.status==true){
				var store=Ext.ComponentQuery.query('#SavedQuery_Grid')[0].getStore();
				store.load();
			}
		});		
		savedGrid.getStore().load({
			callback:function(records,options,success){
				if(success){
					queryPanel.down("#sqlstatement").setValue(query);
				}					
			}
		});
	}
});


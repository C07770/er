Ext.define('eRecon_web.controller.FeedCalenderController',{
	extend: 'Ext.app.Controller',
	requires: ["eRecon_web.store.GLFeedCalenderStore"],
	stores:	["eRecon_web.store.GLFeedCalenderStore"],
	refs: [{
	       ref: 'glCalendarGrid',
	       selector: 'secadmin_glfeedCalenderGrid'
	    },
	    {
	    	ref: 'searchForm',
	    	selector: 'glfeedCalenderSearch'
	    }],
	
	init: function()
	{
		this.control({
			'glfeedCalenderSearch button[action=feedcal-search]': {
	            click: this.feedCalSearch
	        },
	        'glfeedCalenderSearch button[action=feedcal-clear]': {
	            click: this.clearFilterForm
	        },
	        'glfeedCalenderSearch combo[itemId=reconPeriod-text]': {
	        	change: this.handlereconperiodCombo
	        },
	        'secadmin_glfeedCalenderGrid button[action=feedCal-save]': {
	        	click: this.saveRecords
	        },
	        'secadmin_glfeedCalenderGrid  button[action=feedCal-excel]': {
	        	click: this.feedCaldownlaodfile
	        },
	        'glfeedCalenderSearch  button[action=feedcal-add]': {
	        	click: this.feedCalAddRecord
	        }
		});
	},
	handlereconperiodCombo:function(combo,newVal,oldVal) {
		var oRec=combo.findRecordByValue(oldVal);
		  oRec && combo.inputEl.removeCls('comboSelectedItem');
		  if(newVal==Ext.util.Cookies.get('currentReconPeriod')){
			  var nRec=combo.findRecordByValue(newVal);
			  nRec && combo.inputEl.addCls('comboSelectedItem');
		  }
	},
	saveRecords: function(){
		
		var store = this.getStore('eRecon_web.store.GLFeedCalenderStore');
		var dataArray = [];
		var updateData = store.getUpdatedRecords(); 
		var deleteData = store.getRemovedRecords();
		
		if(updateData.length == 0 && deleteData.length == 0) 
		{
    		Ext.MessageBox.alert( "Alert", "No changes found");
    		return false;
		}
		if(updateData.length != 0)
			{
				Ext.each(updateData, function(item, index, array) {
		        dataArray.push({
					"newData" : item.data,
		        	"previousData" : item.raw,
		        	"modified" : item.modified 
			        });
			    });
			}
		if(deleteData.length != 0)
			{
			Ext.each(deleteData, function(item, index, array) {
		        dataArray.push({
					"deleteData" : item.data
		        });
		    });
			}
		
		var encodedArray = Ext.encode(dataArray);
		eRecon_web.direct.action.GLFeedCalenderService.saveRecords(encodedArray, function(p, response) {
	    	if(response.result != "Error") {
	    		Ext.MessageBox.alert( "Status", response.result);
	    		store.load();
	    	}else{
	    		Ext.MessageBox.alert( "Status", response.result);
	    	}
	    });  
	},
	
	clearFilterForm: function(){
		var searchPanel = this.getSearchForm();
		searchPanel.getForm().reset();
		var feedCalStore = this.getGlCalendarGrid().getStore();
		feedCalStore.directOptions = {};
		feedCalStore.getProxy().extraParams = {
            0: null
        };
        feedCalStore.load();
	},
	
	feedCalSearch: function(){
		var searchPanel = this.getSearchForm();
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var feedCalStore = this.getGlCalendarGrid().getStore();
		feedCalStore.directOptions = {};
		feedCalStore.getProxy().extraParams = {
            0: formdata
        };
        feedCalStore.loadPage(1,{
            callback: function (records, operation, success) {
            }
        });
	},
	feedCaldownlaodfile: function(){
		var searchPanel = this.getSearchForm();
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var feedCalStore = this.getGlCalendarGrid().getStore();
		Ext.create('eRecon_web.common.ExportToExcelStatusPopup').launchExport(
			'eRecon_web.store.GLFeedCalenderStore',
			feedCalStore.total,
			null,
			{0: formdata}
		);
	},
	feedCalAddRecord: function(){
		var searchPanel = this.getSearchForm();
		var reconPeriod = searchPanel.down("#reconPeriod-text").getValue();
		var businessDay = searchPanel.down("#businessDay-text").getValue();
		if(reconPeriod == "" || reconPeriod == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Recon Period is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		if(businessDay == "" || businessDay == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Business day is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var feedCalStore = this.getGlCalendarGrid().getStore();
		feedCalStore.directOptions = {};
		feedCalStore.getProxy().extraParams = {
            0: formdata
        };
        Ext.Msg.show({
			title: "Confirmation",
			msg: "Do you want to insert a record?",
		    buttons: Ext.Msg.OKCANCEL,
		    fn: function(btn) {
				if (btn == 'ok') {
					eRecon_web.direct.action.GLFeedCalenderService.doAddRecords(formdata, function(p, response) {
					if(response.result== "Success") {
						feedCalStore.loadPage(1,{
					        callback: function (records, operation, success) {
					        }
					    });
					    Ext.MessageBox.alert( "Status", response.result);
					}else{
						Ext.MessageBox.alert( "Status", response.result);
					}
					}); 
				}
			}
		});
	}
	
});

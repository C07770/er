Ext.define('eRecon_web.controller.DashboardController',{
	extend: 'Ext.app.Controller',
	stores:	["eRecon_web.store.chart.ArcMembersPieChartStore",
	       	 "eRecon_web.store.chart.AllTabsPieChartStore",
	       	 "eRecon_web.store.chart.AOGLBalanceDrChartStore",
	       	 "eRecon_web.store.chart.AOGLBalanceCrChartStore",
	       	 "eRecon_web.store.dashboard.ArcMembersBalancesStore",
	       	 "eRecon_web.store.dashboard.DetailedDataStore"
	       	 ], 
    refs: [
           { ref: 'dashboardContainer', selector: 'dashboardContainer' },
           { ref: 'allTabsPieChart', selector: 'allTabsPieChart' },
           { ref: 'aoGLBalanceDrChart', selector: 'aoGLBalanceDrChart' },
           { ref: 'aoGLBalanceCrChart', selector: 'aoGLBalanceCrChart' },
           { ref: 'arcMembersPieChart', selector: 'arcMembersPieChart' },
           { ref: 'filterCrumb', selector: 'filtercrumb'},
           { ref: "detailedRawGrid", selector:"grid#detailedrawgrid" },
           { ref:"summaryOfActivityGrid", selector:"grid#summaryofactivitygrid"}
           ],
		
	init: function(){
		var me = this;
		
		this.control({					
			"dashboardContainer": {
        		boxready: function() {
        			me.initializeComponents();        			      		          
        		}
        	},        	
        	"allTabsPieChart" : {
        		pieChartClick: function(item) {
        			me.getDashboardContainer().down('filtercrumb').addFilter({labelCategory: 'Tab:', labelValue: item.display, 
        				filterValue: item.display, filterParam: "Tabs"});
        			this.updateCharts();
        		}
        	},
        	"aoGLBalanceDrChart" : {
        		axisClick : function(item) {
        			me.getDashboardContainer().down('filtercrumb').addFilter({labelCategory: 'Dr:', labelValue: item.axis,
        				filterValue: item.axis, filterParam: "AO_Dr"});
        			me.refreshGrid();
        		},
        		seriesClick : function(item) {
        			me.getDashboardContainer().down('filtercrumb').addFilter({labelCategory: 'Dr:', labelValue: item.axis + ' for ' + item.series,
        				filterValue: {AOName: item.series, Axis: item.axis}, filterParam: "AO_Dr_Value"});
           			me.refreshGrid();
        		}
        	},
        	"aoGLBalanceCrChart" : {
        		axisClick : function(item) {
        			me.getDashboardContainer().down('filtercrumb').addFilter({labelCategory: 'Cr:', labelValue: item.axis,
        				filterValue: item.axis, filterParam: "AO_Cr"});
           			me.refreshGrid();
        		},
        		seriesClick : function(item) {
        			me.getDashboardContainer().down('filtercrumb').addFilter({labelCategory: 'Cr:', labelValue: item.axis + ' for ' + item.series,
        				filterValue: {AOName: item.series, Axis: item.axis}, filterParam: "AO_Cr_Value"});
           			me.refreshGrid();
        		}
        	},
        	"arcMembersPieChart" : {
        		pieChartClick: function(item) {
        			me.getDashboardContainer().down('filtercrumb').addFilter({labelCategory: 'Arc Member:', labelValue: item.display,
        				filterValue: item.display, filterParam: "ArcMember"});
        			this.updateCharts();
        		}
        	},
        	"filtercrumb" : {
        		removefilter: function(o_) {
        			this.updateCharts();
        		}
        	},
        	
        	'detailedpopup': {
        		boxready: function() {        			        				 	    	    		
        			Ext.defer(function(){me.getDashboardContainer().setLoading(false);}, 200);
        		}
        	},

        	'arcmembersbalancesgrid': {
        		scope:this,
        		itemclick: function(t, rec, item, index, e, eOpts) {
        			if (e.target.className == 'cell-expand') {
        				var dashboardContainer = me.getDashboardContainer();
        				dashboardContainer.setLoading(true);
        				Ext.defer(function(){dashboardContainer.setLoading(false);}, 5000);
        				Ext.defer(function() {        					
  	    					var v = Ext.create('eRecon_web.view.dashboard.DetailedPopup');
  	    					var s  = 'Detailed data for ';
  	    					s += 'Region: ' + rec.get('geocode') + ';<span style="padding-left: 30px">&nbsp</span>' ;
  	    					s += 'Account Owner: ' + rec.get('aoname');
  	    					v.setTitle(s);
  	    					v.center();
  	    					v.show();	    	
  	    					var mask = new Ext.LoadMask(Ext.getBody(),{msg:"Please wait..."});
        			  	mask.show();
  	    					var directOptions = me.prepareFilterParams();
  	    					directOptions.aoName = rec.get('aoname');
  	    					var store = me.getStore('eRecon_web.store.dashboard.DetailedDataStore');
  	    					store.currentPage = 1;
  	    					store.savedDirectOptions = directOptions;	    					
  	    					me.getStore('eRecon_web.store.dashboard.DetailedDataStore').load();	
  	    					mask.hide();
        				},100);        				
        			}
        		}
        	}, 
        	"#distributionEastSidePanel" : {
        		collapse: function() {
        		},
        		expand : function() {
        			updateCharts();
        		}
        		
        	},
        	"erecon_dashboard_form_filters button#searcharcdashbtn": {
        	  "click": this.handleArcDashFilter
        	},
        	"erecon_dashboard_form_filters button#searchlvsumrptbtn": {
        	  "click": this.handleLVSummaryRptFilter
        	},
        	"erecon_dashboard_form_filters combo#arcdashlvcbo": {
        	  "change": this.handleLVSummaryRptSearchEnable
        	},
        	"button#exportexcelbtn": {
        	  "click": this.handleExportToExcel
        	},
        	"erecon_dashboard_form_filters combo[name=reconperiod]": {
        		"change": this.handleReconPeriodFilter
        	},
        	"aoGLBalanceCrChart":{
        		"removemask":function(){this.mask.hide();}
        	}
		});
	},
	
	initializeComponents : function() {
		//this.getArcMembersPieChart().getStore().load();		
		//Grid
		this.refreshGrid();
	},

	updateCharts: function() {
		//this.refreshGrid();
		var filterCrumbStore = this.getFilterCrumb().getStore(); 
		var records = filterCrumbStore.getRange();
		var arcMember = null;
		var tab = null;
		for(i = 0; i<records.length; i++) {
			var data = records[i].getData();
			if(data.filterParam == 'ArcMember') {
				arcMember = data.filterValue;
			} else if(data.filterParam == 'Tabs') {
				tab = data.filterValue;
			}
		}
		//Tabs Chart
		var tabsChartStore = this.getAllTabsPieChart().getStore();
		tabsChartStore.getProxy().extraParams = {
			0: arcMember
        };
		tabsChartStore.load();
		
		//CR and DR charts
		
		//Update labels
		var crChartTitle = 'Credit ';
		var drChartTitle = 'Debit ';
		if(tab == '180DPD') {
			crChartTitle =  'Over 180 Days Credit';
			drChartTitle =  'Over 180 Days Debit';
		} else if(tab == 'Disagreed') {
			crChartTitle =  'Disagreed Credit Balance';
			drChartTitle =  'Disagreed Debit Balance';
		} else if(tab == 'At Risk') {	
			crChartTitle =  'At Risk Credit';
			drChartTitle =  'At Risk Debit';
		} else if(tab == 'UnAttested') {
			crChartTitle =  'Unreviewed Credit Balance';
			drChartTitle = 'Unreviewed Debit Balance';;
		} else if(tab == 'Reportable Red') {
			crChartTitle = 'Reportable Red Amount Credit';
			drChartTitle =  'Reportable Red Amount Debit';
		} else if(tab == 'UnSubmitted') {
			crChartTitle = 'Unsubmitted Credit Balance';
			drChartTitle = 'Unsubmitted Debit Balance';
		}
		this.getAoGLBalanceCrChart().up().setTitle(crChartTitle);
		this.getAoGLBalanceDrChart().up().setTitle(drChartTitle);
		
		var crStore = this.getAoGLBalanceCrChart().getStore();
		var drStore = this.getAoGLBalanceDrChart().getStore();
		crStore.removeAll();
		drStore.removeAll();
		this.getAoGLBalanceCrChart().surface.removeAll();
		this.getAoGLBalanceDrChart().surface.removeAll();
		if(arcMember == null || tab == null) {
			this.getAoGLBalanceCrChart().redraw(false);
			this.getAoGLBalanceDrChart().redraw(false);
		} else {
			crStore.getProxy().extraParams = {
				0: arcMember,
	            1: tab
	        };
			crStore.load();
			
			//DR Chart
			drStore.getProxy().extraParams = {
	            0: arcMember,
	            1: tab
	        };
			drStore.load();
		}
	},
	
    refreshGrid: Ext.Function.createBuffered(function() {
    	var me = this;
//			var store = me.getStore('eRecon_web.store.dashboard.ArcMembersBalancesStore');
//			var directOptions = me.prepareFilterParams();
//			store.load({directOptions: directOptions});
			var selectedTab = me.getSelectedTab();
			me.getDashboardContainer().down('arcmembersbalancesgrid').arrangeColumns(selectedTab);
	},100),

	getSelectedTab: function() {
		var me = this;
		var filterCrumbStore = me.getFilterCrumb().getStore();
		var filterValue;
		filterCrumbStore.each(function(rec) {
			if (rec.get('filterParam').toUpperCase() == 'TABS') {
				filterValue = rec.get('filterValue');
				return false;
			}
		});
		return filterValue;
	},

	prepareFilterParams: function() {
		var me = this;
		var directOptions = {};
		var filterCrumbStore = me.getFilterCrumb().getStore();
		filterCrumbStore.each(function(rec) {
			var filterParam = rec.get('filterParam');
			var filterValue = rec.get('filterValue');
		    switch (filterParam.toUpperCase()) {
		    	case 'ARCMEMBER':
		    		directOptions.arcMember = filterValue;
		    		break;
		    	case 'TABS':
		    		directOptions.tabName = filterValue;
		    		break;
		    	case 'AO_DR':
		    		directOptions.aoNameDr = filterValue;
		    		break;
		    	case 'AO_CR':
		    		directOptions.aoNameCr = filterValue;
		    		break;
		    	case 'AO_DR_VALUE':
		    		directOptions.aoNameDr = filterValue.AOName;
		    		directOptions.amtDrVal = filterValue.Axis;
		    		break;
		    	case 'AO_CR_VALUE':
		    		directOptions.aoNameCr = filterValue.AOName;
		    		directOptions.amtCrVal = filterValue.Axis;
		    		break;
		    }
		});
		return directOptions;
	},
	
	handleArcDashFilter: function(){
		this.mask = new Ext.LoadMask(Ext.getBody(),{msg:"Preparing Dashboard..."});
		this.mask.show();
			
		var controllerFld = Ext.ComponentQuery.query("erecon_dashboard_form_filters combo[name=controller]")[0];
		var arcMemberFld = Ext.ComponentQuery.query("erecon_dashboard_form_filters combo[name=arcMemberFilterCbo]")[0];
		var reconPeriodFld = Ext.ComponentQuery.query("erecon_dashboard_form_filters combo[name=reconperiod]")[0];	
					
	  eRecon_web.direct.action.DashboardService.getArcMembersBalances(reconPeriodFld.getValue() ? reconPeriodFld.getValue():"", controllerFld.getValue() ? controllerFld.getValue() : "", arcMemberFld.getValue() ? arcMemberFld.getValue() :"",function(p,response){
		  
	  console.log("p");
	  console.log(p);
	  console.log("presponse"); console.log(response);
	    //var result =[{"controllerdelegatename":"SINGHAL,AKASHI","arcmember":"cm85282","fullkeycount":"15","glbalance":"5116.52","reportableredamtdr":"0","reportableredamtcr":"0","userid":"CM85282","reconperiod":"MAR-2015","geocode":"NAM"},{"controllerdelegatename":"Reusswig,Markus","arcmember":null,"fullkeycount":"1102","glbalance":"1228434601.96","reportableredamtdr":"25434597444.81","reportableredamtcr":"-24205909990.89","userid":"CM85282","reconperiod":"MAR-2015","geocode":"EMEA"},{"controllerdelegatename":"Jones,Robert","arcmember":null,"fullkeycount":"1020","glbalance":"11932584467.85","reportableredamtdr":"15387249620.76","reportableredamtcr":"-3455862715.51","userid":"CM85282","reconperiod":"MAR-2015","geocode":"NAM"},{"controllerdelegatename":null,"arcmember":null,"fullkeycount":"1115","glbalance":"-10088500868.39","reportableredamtdr":"235432850169.55","reportableredamtcr":"-245521438235.21","userid":"CM85282","reconperiod":"MAR-2015","geocode":"LATAM"},{"controllerdelegatename":null,"arcmember":"TM23386","fullkeycount":"65","glbalance":"9210163.8","reportableredamtdr":"1082600479.85","reportableredamtcr":"-1073367569.38","userid":"CM85282","reconperiod":"MAR-2015","geocode":"APAC"},{"controllerdelegatename":null,"arcmember":null,"fullkeycount":"23","glbalance":"27837.73","reportableredamtdr":"648870010.27","reportableredamtcr":"-648853422.81","userid":"CM85282","reconperiod":"MAR-2015","geocode":"NAM"},{"controllerdelegatename":"Romero,Gustavo Adolfo","arcmember":null,"fullkeycount":"1179","glbalance":"-9276450912.06","reportableredamtdr":"7705484835.82","reportableredamtcr":"-16981475165.42","userid":"CM85282","reconperiod":"MAR-2015","geocode":"LATAM"},{"controllerdelegatename":null,"arcmember":null,"fullkeycount":"1989","glbalance":"-967592619405.72","reportableredamtdr":"904214398296.12","reportableredamtcr":"-1871804827411.52","userid":"CM85282","reconperiod":"MAR-2015","geocode":"APAC"},{"controllerdelegatename":"Sinurat,Dewi","arcmember":"JE33915","fullkeycount":"11609","glbalance":"630025436367.18","reportableredamtdr":"21495823046586.72","reportableredamtcr":"-20865797593433.57","userid":"CM85282","reconperiod":"MAR-2015","geocode":"APAC"},{"controllerdelegatename":null,"arcmember":null,"fullkeycount":"1100","glbalance":"-150765373391.41","reportableredamtdr":"146383943621.26","reportableredamtcr":"-297148694695.39","userid":"CM85282","reconperiod":"MAR-2015","geocode":"EMEA"},{"controllerdelegatename":"Stone,Donna","arcmember":null,"fullkeycount":"1006","glbalance":"1516000.1","reportableredamtdr":"600864500.68","reportableredamtcr":"-599766600.6","userid":"CM85282","reconperiod":"MAR-2015","geocode":"NAM"}];
	    var grid = Ext.ComponentQuery.query("arcmembersbalancesgrid")[0];
	    console.log(response.result);
	    grid.getStore().loadData(response.result);
	    
	    
	    
	    
    });
	  
    	//this.getDashboardContainer().child("#arcdashtab").tab.show();
    	this.getDashboardContainer().child("#arcdashtab").tab.show();
	    
this.getDashboardContainer().setActiveTab(1);
    	
		
  	eRecon_web.direct.action.DashboardService.getAllTabsChartInfo(reconPeriodFld.getValue() ? reconPeriodFld.getValue():"", controllerFld.getValue() ? controllerFld.getValue() : "", arcMemberFld.getValue() ? arcMemberFld.getValue() :"",function(p,response){	  	  	
  	  var chart = Ext.ComponentQuery.query("allTabsPieChart")[0];
  	  chart.getStore().loadData(response.result);
  	

  	});
	  	  	  	  
	  eRecon_web.direct.action.DashboardService.getAllArcMembersChartDetails(reconPeriodFld.getValue() ? reconPeriodFld.getValue():"", controllerFld.getValue() ? controllerFld.getValue() : "", arcMemberFld.getValue() ? arcMemberFld.getValue() :"",function(p,response){	    
	    var arcMembersPieChart = Ext.ComponentQuery.query("arcMembersPieChart")[0];
	    arcMembersPieChart.getStore().loadData(response.result);
	  });
	  	
	  eRecon_web.direct.action.DashboardService.getAllAOGLBalanceCrChartDetails(reconPeriodFld.getValue() ? reconPeriodFld.getValue():"", controllerFld.getValue() ? controllerFld.getValue() : "", arcMemberFld.getValue() ? arcMemberFld.getValue() :"",function(p,response){	  	  
	    var balCrChart = Ext.ComponentQuery.query("aoGLBalanceCrChart")[0];
	  	balCrChart.getStore().loadData(response.result);
	  });
	  	
	  eRecon_web.direct.action.DashboardService.getAllAOGLBalanceDrChartDetails (reconPeriodFld.getValue() ? reconPeriodFld.getValue():"", controllerFld.getValue() ? controllerFld.getValue() : "", arcMemberFld.getValue() ? arcMemberFld.getValue() :"",function(p,response){
	    var balDrChart = Ext.ComponentQuery.query("aoGLBalanceDrChart")[0];
	  	balDrChart.getStore().loadData(response.result);		  	  	 
	  });	 	
	  	 	  	
	},
	
	handleLVSummaryRptFilter: function() {
      this.getDashboardContainer().setActiveTab(2);
	},
	
	handleLVSummaryRptSearchEnable: function(field_) {
	  var lvSummaryRptSearchBtn = Ext.ComponentQuery.query("erecon_dashboard_form_filters button#searchlvsumrptbtn")[0];
	  if(field_.getValue()) {
	    lvSummaryRptSearchBtn.enable();
	  }
	  else {
		lvSummaryRptSearchBtn.disable();
	  }
	},
	
	handleExportToExcel: function() {
//		var searchPanel = this.getAccountTypeLUSearch();
//		var form = searchPanel.getForm();
//		var formdata = Ext.encode(form.getValues());
//		var AccountStore = this.getAccountTypeLUGrid().getStore();
//		Ext.create('eRecon_web.common.ExportToExcelStatusPopup').launchExport(
//			'eRecon_web.store.AccountTypeLUStore',
//			AccountStore.total,
//			null,
//			{0: formdata}
//		);
//	}
		var store = this.getDetailedRawGrid().getStore();
		console.log("store: " + store);
//		Ext.create("eRecon_web.common.ExportToExcelStatusPopup").launchExport(
//		  "eRecon_web.store.dashboard.DetailedDataStore",
//		  store.total,
//		  null,
//		  {0:"Test"}
//          );
		//-----------------------------------------------------------------------------
		if (store !== null) {
			var firstRec = store.getAt(0);	
			var reconPeriod = firstRec.get("reconperiod");
			var region = null; 
			var centralizedsite = null;
			var pocity = null; 
			var arcmember = firstRec.get("arcmember");
			var controllername = firstRec.get("controllername");
			var userRole = 'GPO BSS USER';		
		    
			var dataArray = { userRole: userRole };
			var encodedArray = Ext.encode(dataArray);
			eRecon_web.direct.action.DashboardService.getUserRole(encodedArray, function(p,response){
				if(response.result == null ){
					userRole = null;
				}
			});
			
			var formdata = {
				reconPeriod: reconPeriod,
				region: region,
				centralizedsite: centralizedsite,
				arcmember: arcmember,
				controllername: controllername,
				pocity: pocity,
				userRole: userRole
			}
			Ext.Ajax.request({
				url : 'filedownloadtrigger.up?downloadType=BSS_EXCEL_EXPORT',
				method:'POST', 
				params : {
					formdata: Ext.encode(formdata)
				},
				scope : this,
				success : function(response, opts) {
					response = Ext.decode(response.responseText);
					if(response.success){
						Ext.MessageBox.alert('Successful', 
								"Your request has been submitted successfully with the request id " + response.scheduleId + ". You should recieve an email on completion.");
					}
					else {
						Ext.MessageBox.alert('Failed', response.message);
					}
				},
				failure : function(err) {
					Ext.MessageBox.alert('Error occured during BSS Excel file download.', 'Please try again!');
				}
			}); 		
		
		} else {
			Ext.MessageBox.alert( "Alert", "No rows selected in the summary grid." );
		}
		//-----------------------------------------------------------------------------
	},
	
	handleReconPeriodFilter: function(fld_){
		var searchBtn = Ext.ComponentQuery.query("button#searcharcdashbtn")[0];
		if(fld_.rawValue) {
		  searchBtn.enable();		
	  }
		else {
			searchBtn.disable();   
			//
			
		}
	}
	
});
	

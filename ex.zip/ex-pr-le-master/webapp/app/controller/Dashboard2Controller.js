Ext.define('eRecon_web.controller.Dashboard2Controller',{
	extend: 'Ext.app.Controller',
	stores:	[
	       	 'eRecon_web.store.dashboard2.StrategicSitesMatrixStore',
	       	 'eRecon_web.store.dashboard2.StrategicSitesRawDataStore'
	], 
  refs: [
           { ref: 'dashboard2Container', selector: 'dashboard2Container' },
           { ref: 'strategicSiteRawDataPopup', selector: 'StrategicSiteRawDataPopup' },
           { ref: 'filterCrumb', selector: 'filtercrumb'},
           { ref: "ssiteTrendChart", selector:"chart#sitetrendchart"},
           { ref: "grpTrendChart", selector:"chart#grouptrendchart"},
           { ref: "rawDataGridPopup", selector:"grid#strategicrawdata"},
           { ref: "strategicSitesPieChart", selector:"strategicsitespiechart chart#stratsitespiechart"},
           { ref: "managedAcctPieChart", selector:"managedaccountspiechart chart#managedacctpiechart"}
  ],
  
currentReconPeriod : false,
rawDataObj:null,
		
	init: function(){
		var me = this;
		
		me.control({
					
			'dashboard2Container': {
        		boxready: function() {
        			me.initializeComponents();        			
        		}
        	},
        	
        	'dashboard2Container *[searchId=periodsCombo]': {
        		change: function(combo,newVal,oldVal) {
        		var oRec=combo.findRecordByValue(oldVal);
        		  oRec && combo.inputEl.removeCls('comboSelectedItem');
        		  if(newVal==Ext.util.Cookies.get('currentReconPeriod')){var nRec=combo.findRecordByValue(newVal);
        		  nRec && combo.inputEl.addCls('comboSelectedItem');}
        		if(!me.currentReconPeriod){
        			me.refreshGrid(true);
        		}
        		me.currentReconPeriod=false;
        		}
        	},
        	
        	'dashboard2Container *[searchId=regionCombo]': {
        		change: function(combo,newVal,oldVal) {
        		 var countryCbo = Ext.ComponentQuery.query("clearablecombobox[searchId=countryCombo]")[0];
        		if(!Ext.isEmpty(newVal)){
                     var params = {region:combo.getValue()};
                     countryCbo.setValue(null);
                     countryCbo.getStore().setProxy({
                    	 type:"direct",
                       directFn:eRecon_web.direct.action.Dashboard2Service.getCountryByRegion
                     });
                     countryCbo.getStore().load({params:Ext.encode(params)});
        		}else{
        			 countryCbo.getStore().setProxy({
                    	 type:"direct",
	        		    directFn:eRecon_web.direct.action.DashboardService.getFilterValues
                     });
        			countryCbo.getStore().load({params:"COUNTRY"});
        		}
        			me.refreshGrid();
        		}
        	},
        	
        	'dashboard2Container *[searchId=countryCombo]': {
        		change: function() {
        			me.refreshGrid();
        		}
        	},
        	
        	'dashboard2Container button#pptExportBtn': {
        		click: function() {
       			me.gridExportToPPT();
       		}
       	},
       	
        	'dashboard2Container button#pptPieExportBtn': {
        		click: function() {
       			me.pieExportToPPT();
       		}
       	},
        	
        	"StrategicSiteRawDataPopup": {
        		"close": function(){ 
        		me.rawDataObj=null;
        		}
        	},
	        'StrategicSiteRawDataPopup button[action=StrategicSitesExcel]': {
	        	click: this.strategicSiteDownloadExcel
	        },
        	
        	'strategicsitesmatrixgrid': {
        		itemclick: function(t, rec, item, index, e, eOpts) { 
    				if (e.target.className == 'cell-expand') {
    					var site = rec.get('strategicSite');
    					var utility = e.target.getAttribute("dataIndex");
    					var grid = Ext.ComponentQuery.query('strategicsitesmatrixgrid')[0];
    					var centralizedsite = "ALL";
    					
    					for (var i=0; i<grid.columns.length; i++) {
    						var columnItems = grid.columns[i].items;
    						if (columnItems && columnItems.length > 0){
	    						for (var j=0; j<columnItems.length; j++) {
	    							var item = columnItems.items[j];
	    							if (item && item.dataIndex == utility){
	    								centralizedsite = item.text;
	    								break;
	    							}
	    								
	    						}
	    					}
    					}
    					//reconperiod,region,country,centralizedsite
    					var period = rec.get('reconperiod');
    					var country = rec.get('country_desc');
    					var region = rec.get('geocode');
    					
	    				var dashboard2Container = me.getDashboard2Container();
	    				dashboard2Container.setLoading(true);
	    				Ext.defer(function(){dashboard2Container.setLoading(false);}, 5000);
	    				Ext.defer(function() {
	    					var store = me.getStore('eRecon_web.store.dashboard2.StrategicSitesRawDataStore');
	    					store.removeAll();
	    					
	    					var v = Ext.create('eRecon_web.view.dashboard2.StrategicSiteRawDataPopup');
	    					var s  = 'Detailed data for ';
	    					s += 'Utility: ' + centralizedsite + ", " + country + ", " + region;
	    					v.setTitle(s);
	    					v.center();
	    					v.show();	    					
	    					store.currentPage = 1;
	    					store.savedDirectOptions = {site: site, utility: utility, period: period};
	    					
	    					store.on('beforeload', function(){
	    					var extraValues={
	    							"newData":{reconperiod: period, country: country, region: region, centralizedsite:centralizedsite}           
						    	};
						    var jsonStr = Ext.encode(extraValues);
						    store.getProxy().extraParams = {
						             0: jsonStr
						    	};
							});
	    					store.load();
	    				},100);    			
    				}
    			},
    			"summaryrowclick":function(stratSite_){  
    				var me=this;
    				var site = stratSite_;
    				var grid = Ext.ComponentQuery.query('strategicsitesmatrixgrid')[0];
    				var centralizedsite = "ALL";
    				
    				for (var i=0; i<grid.columns.length; i++) {
    					var columnItems = grid.columns[i].items;
    					if (columnItems && columnItems.length > 0){
    						for (var j=0; j<columnItems.length; j++) {
    							var item = columnItems.items[j];
    							if (item && item.dataIndex == site){
    								centralizedsite = item.text;
    								break;
    							}
    								
    						}
    					}
    				}
    				//reconperiod,region,country,centralizedsite
    				var period = Ext.ComponentQuery.query('dashboard2Container *[searchId=periodsCombo]')[0].getRawValue();
    				var country = Ext.ComponentQuery.query('dashboard2Container *[searchId=countryCombo]')[0].getRawValue();
    				var region = Ext.ComponentQuery.query('dashboard2Container *[searchId=regionCombo]')[0].getRawValue();
    				
    				var dashboard2Container = me.getDashboard2Container();
    				dashboard2Container.setLoading(true);
    				Ext.defer(function(){dashboard2Container.setLoading(false);}, 5000);
    				Ext.defer(function() {
    					if(me.rawDataObj==null || !me.rawDataObj.isVisible()){
    					var store = me.getStore('eRecon_web.store.dashboard2.StrategicSitesRawDataStore');
    					store.removeAll();
    					
    					me.rawDataObj = Ext.create('eRecon_web.view.dashboard2.StrategicSiteRawDataPopup');
    					var s  = 'Detailed data for ';
    					s += 'Utility: ' + centralizedsite;
    					if (country) s += ", " + country;
    					if (region) s += ", " + region;
    					me.rawDataObj.total = true;
    					me.rawDataObj.setTitle(s);
    					me.rawDataObj.center();
    					me.rawDataObj.show();	    					
   					store.currentPage = 1;
    					store.savedDirectOptions = {site: "", utility: site, period: period};
    					
    					store.on('beforeload', function(){
    					var extraValues={
    							"newData":{reconperiod: period, country: country, region: region, centralizedsite:centralizedsite}           
    			    	};
    			    var jsonStr = Ext.encode(extraValues);
    			    store.getProxy().extraParams = {
    			             0: jsonStr
    			    	};
    				});
					store.load({
						scope:this,
						callback:function(recs_){
							var region = recs_[0].data.region, country = recs_[0].data.country;							
//							var s  = 'Detailed data for ';
//    					s += 'Utility: ' + centralizedsite;
//    					if (country) s += ", " + country;
//    					if (region) s += ", " + region;
//    					v.setTitle(s);							
						}
					});
						}
    		});   
    				return;
	        }
        }
		});
	},
	
	initializeComponents : function() {		  
	    var me = this;
	    var periodsCombo = me.getDashboard2Container().down('*[searchId=periodsCombo]');
	    var countryCombo = me.getDashboard2Container().down('*[searchId=countryCombo]');
	    var regionCombo = me.getDashboard2Container().down('*[searchId=regionCombo]');
	    periodsCombo.store.on('load',function(store,rec){

for(var i=0;i<rec.length;i++){
	 if(rec[i].data.flag=="TRUE"){
		 me.currentReconPeriod=true;
		 periodsCombo.select(store.getAt(i));
		// me.currentReconPeriod=rec[i].data.values;
		// me.refreshGrid();
	 }
}


	    })
	   // periodsCombo.select(periodsCombo.store.getAt(0));
	    countryCombo.select(countryCombo.store.getAt(0));
	    regionCombo.select(regionCombo.store.getAt(0));
	    
	  /*  var periodsCombo = me.getDashboard2Container().down('*[searchId=periodsCombo]');
	    periodsCombo.select(periodsCombo.store.getAt(0));
		  me.refreshGrid();*/			
  		

  			
	/* group trend chart */

  		
//  var chart = this.getGrpTrendChart();	   
//	    eRecon_web.direct.action.Dashboard2Service.getStrategicSiteTrendByPeriod(function(p,response){
//	    	var resp = Ext.JSON.decode(response.result);
//	        console.log(resp.data[0]);	        	        
//		    for(var k in resp.data[0]){
//		      if(k != "reconperiod"){
//		        var entityName = k;
//		        var lines = 
//	   		      {
//				      type: "line",
//				      axis: "left",
//				      xField: "reconperiod",
//				      yField: entityName,
//				      title:  entityName,
//				      fill: false,
//				      style: {
//						 opacity: 1,
//						 'stroke-width': 2
//					  },
//				      highlight: {
//				        size: 7,
//				        radius: 7
//				      },
//				      tips: {
//			            width: 140,
//			            renderer:chartTipsRenderer
//			          }
//				  };	
//		          chart.series.add(lines);		          
//		          chart.getStore().getProxy().getModel().prototype.fields.add(Ext.create('Ext.data.Field', {
//		              name: entityName
//		          }));			          		        		  	
//		      }
//		    }
//		    chart.getStore().loadData(resp.data);
//	    });
  	   	    	              	           

		me.refreshGrid();			
//  		chart.redraw();
  		//sitechart.redraw();
	},
	
    refreshGrid: Ext.Function.createBuffered(function(_reconPeriod_Change) {  
    	//this.getDashboard2Container().setActiveTab(1);
      var me = this; 
     // me.refreshCharts();
      //this.getDashboard2Container().setActiveTab(0);
      var store = me.getStore('eRecon_web.store.dashboard2.StrategicSitesMatrixStore');
	    var period = me.getPeriod();
		  var country = me.getSelectedCountryCode();//need to pass country code
		  
		  var region = me.getRegion();
		 // if(period==null || period==undefined || Ext.isEmpty(period)){
		//	  period=me.currentReconPeriod;
		 // }
	   // if (period) {
	    	this.getDashboard2Container().setActiveTab(1);
	    	if(_reconPeriod_Change){
	    		 me.refreshCharts(true);
	    	}else{
	       me.refreshCharts();
	    	}
	        this.getDashboard2Container().setActiveTab(0);
		    store.load({
		      directOptions:{period: period, country: country, region: region}, 
		      scope:this,
  			  callback: function(){  
  			  	//me.refreshCharts();  			  	
		      	}
	      });
	   // }
	},100),
	
//	clearComboBoxRefreshGrid : function(){
//		var me = this;
//		me.getDashboard2Container().down('*[searchId=periodsCombo]').clearValue();
//		me.getDashboard2Container().down('*[searchId=countryCombo]').clearValue();
//		me.getDashboard2Container().down('*[searchId=regionCombo]').clearValue();
//		me.refreshGrid();
//	},
	
	getPeriod: function() {
		var me = this;
		var periodsCombo = me.getDashboard2Container().down('*[searchId=periodsCombo]');
		return me.getCBSValue(periodsCombo, 'values', 'description');
	},
	
	getCountry: function() {
		var me = this;
		var countryCombo = me.getDashboard2Container().down('*[searchId=countryCombo]');
		return me.getCBSValue(countryCombo, 'values', 'description');
	},
	
	getRegion: function() {
		var me = this;
		var regionCombo = me.getDashboard2Container().down('*[searchId=regionCombo]');
		return me.getCBSValue(regionCombo, 'values', 'description');
	},
	
	getCBSValue: function (cb, nameIn, nameOut){
	    try{
	         var r = cb.getStore().find(nameIn,cb.getValue());
	         return cb.getStore().getAt(r).get(nameOut);
	    }
	    catch(err){
	         return null;
	    }
	},
/*	generateData: function() { 
	var me = this;
	var data1;
eRecon_web.direct.action.Dashboard2Service.getStrategicSitesPOCityChartData(function(p,response){
			var fkTotalCount = 0;
			for (var i=0; i < response.result.length; i++) {
				fkTotalCount = fkTotalCount + response.result[i].fkcount;
			}
			for (var i=0; i < response.result.length; i++) {
				var fkcount = response.result[i].fkcount;
				//var fkcount2 = response.result[1].fkcount;
				
				var description = response.result[i].description;
				//var description2 = response.result[1].description;
				console.log("printing data : ");
				//console.log(description);
				
				var percentage = fkcount/fkTotalCount *100;
				//var percentage2 = fkcount2/(fkcount2 + fkcount1) *100;
				//console.log(percentage);  
				if(data1==""){
				data1 = [{name:description, data:fkcount, percent:percentage}];
			}
			
			else if(data1!=""){
				data1 = data1 +"," +[{name:description, data:fkcount, percent:percentage}];
			}

			}
					console.log("data:-" + data1);
				//	Ext.Msg.alert( "Status", data1);
				//	Ext.Message.alert( "Status", data1);
			
		});
	
		return data1;
	}, 

*/
	
	arrangeManagedAccountsPieChart: function() {
		var me = this;
		var managedAccountPieChartStore = Ext.create('Ext.data.JsonStore', {
		    fields: ['name', 'data', 'percent']
		});
		var period = me.getPeriod();
		var country = me.getCountry();
		var region = me.getRegion();
		var dataArray = { period: period, country: country, region: region };
		var encodedArray = Ext.encode(dataArray);
		var managedAcctChart = this.getManagedAcctPieChart()
				eRecon_web.direct.action.Dashboard2Service.getStrategicSitesCentralizationChartData(encodedArray, function(p,response){

			console.log(response);	
			

			var fkTotalCount = 0;
			for (var i=0; i < response.result.length; i++) {
				fkTotalCount = fkTotalCount + response.result[i].fkcount;
			}
			for (var i=0; i < response.result.length; i++) {
				var fkcount = response.result[i].fkcount;
				//var fkcount2 = response.result[1].fkcount;
				
				var description = response.result[i].description;
				//var description2 = response.result[1].description;
				
				console.log(description);
				
				var percentage = fkcount/fkTotalCount *100;
				//var percentage2 = fkcount2/(fkcount2 + fkcount1) *100;
				console.log(percentage);  
				
				managedAccountPieChartStore.add({name: description, data: fkcount, percent: percentage});
				}
				managedAcctChart.bindStore(managedAccountPieChartStore);
				managedAcctChart.setVisible(true);		
			});

	





/*var managedAcctChart = this.getManagedAcctPieChart()
		eRecon_web.direct.action.Dashboard2Service.getStrategicSitesCentralizationChartData(function(p,response){

			var fkTotalCount = 0;
			for (var i=0; i < response.result.length; i++) {
				fkTotalCount = fkTotalCount + response.result[i].fkcount;
			}
			for (var i=0; i < response.result.length; i++) {
				var fkcount = response.result[i].fkcount;
				//var fkcount2 = response.result[1].fkcount;
				
				var description = response.result[i].description;
				//var description2 = response.result[1].description;
				
			//	console.log(description);
				
				var percentage = fkcount/fkTotalCount *100;
				//var percentage2 = fkcount2/(fkcount2 + fkcount1) *100;
			//	console.log(percentage);  
				
				var data = [{name:description, data:fkcount, percent:percentage}];
				managedAcctChart.getStore().loadData(data);	
			}
		});*/
	},

	arrangeStrategicSitesPieChart: function() {
		var me = this;
		var strategicSitesPieChartStore = Ext.create('Ext.data.JsonStore', {
		    fields: ['name', 'data', 'percent']
		});
		var period = me.getPeriod();
		var country = me.getSelectedCountryCode();
		var region = me.getRegion();
		var dataArray = { period: period, country: country, region: region };
		var encodedArray = Ext.encode(dataArray);
		var strategicSitesChart = this.getStrategicSitesPieChart()
		strategicSitesChart.setLoading(true);
	    //Ext.defer(function(){strategicSitesChart.setLoading(false);}, 6500);
		       			  	
		eRecon_web.direct.action.Dashboard2Service.getStrategicSitesPOCityChartData(encodedArray, function(p,response){
			
			var fkTotalCount = 0;
			for (var i=0; i < response.result.length; i++) {
				fkTotalCount = fkTotalCount + response.result[i].fkcount;
			}
			for (var i=0; i < response.result.length; i++) {
				var fkcount = response.result[i].fkcount;
				//var fkcount2 = response.result[1].fkcount;
				
				var description = response.result[i].description;
				//var description2 = response.result[1].description;
				
				console.log(description);
				
				var percentage = fkcount/fkTotalCount *100;
				//var percentage2 = fkcount2/(fkcount2 + fkcount1) *100;
				console.log(percentage);  
				
				strategicSitesPieChartStore.add({name: description, data: fkcount, percent: percentage});
				}
			
//		strategicSitesChart.getStore().loadData(data);
		strategicSitesChart.bindStore(strategicSitesPieChartStore);
		strategicSitesChart.setLoading(false);
		strategicSitesChart.setVisible(true);		
			
		  var sum = 0;
		  for(var i = 0; i<response.result.length; i++){
		    for(var key in response.result[i]){
  		    if(key == "fkcount"){
	  	      sum = sum + response.result[i][key];
		      }
		    }
		  }	
		 
		  Ext.get("total").update(Ext.util.Format.number(sum,'0,'));
		  
		});
	},
	
	strategicSiteDownloadExcel: function(){		
		var strategicSitesRawDataStore = this.getStore("eRecon_web.store.dashboard2.StrategicSitesRawDataStore");
		var me= this;
		//-----------------------------------------------------------------------------
		if (strategicSitesRawDataStore !== null) {
			var firstRec = strategicSitesRawDataStore.getAt(0);	
			var centralizedsite = firstRec.get("centralizedsite");
			for(var i=0; i<strategicSitesRawDataStore.getCount();i++){
				console.log(strategicSitesRawDataStore.getAt(i).get("centralizedsite"));
				if ( centralizedsite !== strategicSitesRawDataStore.getAt(i).get("centralizedsite") ){
					centralizedsite = null;
					break;
				}
			}			
			var userRole = 'GPO BSS DASHBOARD USER';		
			/* 
			//to validate user role
			var dataArray = { userRole: userRole };
			var encodedArray = Ext.encode(dataArray);
			eRecon_web.direct.action.Dashboard2Service.getUserRole(encodedArray, function(p,response){
				if(response.result == null ){
					userRole = null;
				}
	        });
	        */
			//reconperiod,region,country,centralizedsite

			var formdata;
			
			if(this.getRawDataGridPopup().ownerCt.total == true) {
				var countryCombo = me.getDashboard2Container().down('*[searchId=countryCombo]');
				
var r = countryCombo.getStore().find("values",countryCombo.getValue());
var country=null;
if(r>=0){
 country=  countryCombo.getStore().getAt(r).get("values");
}  
    
var region = me.getRegion();
				formdata = {
					reconPeriod:firstRec.get("reconperiod"),//"ALL",
				  region:region,
				  country:country,
				centralizedsite: centralizedsite,
  				userRole: userRole
				}
			}
			else {	
				var grid = Ext.ComponentQuery.query('strategicsitesmatrixgrid')[0];
			var selectedRow = grid.getSelectionModel().getSelection()[0];
			var period = selectedRow.get('reconperiod');
				var country = selectedRow.get('country_desc');
				var region = selectedRow.get('geocode');
		    formdata = {
  				reconPeriod: period ? period : firstRec.get("reconperiod"),
  				region: region,
  				country: country,
  				centralizedsite: centralizedsite,
  				userRole: userRole
			  }
			}
			Ext.Ajax.request({
				url : 'filedownloadtrigger.up?downloadType=BSS_EXCEL_EXPORT',
				method:'POST', 
				params : {
					formdata: Ext.encode(formdata)
				},
				scope : this,
				success : function(response, opts) {
					response = Ext.decode(response.responseText);
					if(response.success){
						Ext.MessageBox.alert('Successful', 
								"Your request has been submitted successfully with the request id " + response.scheduleId + ". You should receive an email on completion.");
					}
					else {
						Ext.MessageBox.alert('Failed', response.message);
					}
				},
				failure : function(err) {
					Ext.MessageBox.alert('Error occured during BSS Excel file download.', 'Please try again!');
				}
			}); 		
		
		} else {
			Ext.MessageBox.alert( "Alert", "No rows selected in the summary grid." );
		}
		//-----------------------------------------------------------------------------
	},
	
	getSelectedCountryCode : function(){
		var country =null;// me.getCountry();
		var me = this;
		
var countryCombo = me.getDashboard2Container().down('*[searchId=countryCombo]');

 var r = countryCombo.getStore().find("values",countryCombo.getValue());
 if(r>=0){
  country=  countryCombo.getStore().getAt(r).get("values");
 }  
 return country;
},

	strategicSiteTrendChart: function(){
		var me = this;
		    
	    /* site trend chart*/
	  var period =me.getPeriod();
		var country = me.getSelectedCountryCode();
		
		
	         
		var region = me.getRegion();
		var dataArray = { period: period, country: country, region: region };
		var encodedArray = Ext.encode(dataArray);
		
		this.getSsiteTrendChart().series.clear();
	  	this.getSsiteTrendChart().surface.removeAll();
	  	var sitechart = this.getSsiteTrendChart();
		
	  	sitechart.setLoading(true);
	   // Ext.defer(function(){sitechart.setLoading(false);}, 6500);
	    eRecon_web.direct.action.Dashboard2Service.getStrategicSiteTrendByPOCity(encodedArray, function(p,response){
	    	var resp2 = Ext.JSON.decode(response.result);
	    	var lineArr= new Array();
	    	for(var j=0;j<resp2.data.length;j++){
	        for(var k in resp2.data[j]){
		      if(k != "reconperiod"){
		        var entityName = k;
		        var lines = 
	   		      {
				      type: "line",
				      axis: "left",
				      xField: "reconperiod",
				      yField: entityName,
				      title:  entityName,
				      fill: false,
				      style: {
						 opacity: 1,
						 'stroke-width': 2
					  },
				      highlight: {
				        size: 7,
				        radius: 7
				      },
				      tips: {
			            width: 140,
			            renderer:chartTipsRenderer
			          }
				  };	
				  if(!Ext.Array.contains(lineArr,lines.title)){
		          sitechart.series.add(lines);	
		          lineArr.push(lines.title);
		          }
		           if(!(Ext.Array.contains(sitechart.getStore().getProxy().getModel().prototype.fields.keys,entityName))){		          
		          sitechart.getStore().getProxy().getModel().prototype.fields.add(Ext.create('Ext.data.Field', {
		              name: entityName
		          }));	
		          }
		         // chartYaxisAdded=true;
		      }
		    }
	       // if(chartYaxisAdded){break;}
	        }
		    sitechart.getStore().loadData(resp2.data);	
		    sitechart.setLoading(false);
	    });
	  	sitechart.redraw();
	},
	
	refreshCharts: function(_reconPeriod_Change){
		if(!_reconPeriod_Change){
			this.getSsiteTrendChart().series.clear();
			  this.getSsiteTrendChart().surface.removeAll();
			  this.strategicSiteTrendChart();
				console.log("loaded Trend report");
		}
		  			  	
	  	
		//me.arrangeManagedAccountsPieChart(store);  			    					
		console.log("loaded Matrix grid");
		this.arrangeStrategicSitesPieChart();
		console.log("loaded Pie chart");
		
	},
	
trendExportToPPT :function(){
	var me=this;
	var config= {width : 400, height : 300, url :"svgToImage", type : "image/png"};
	Ext.draw.engine.ImageExporter.generate(me.getSsiteTrendChart().surface,config);//trend 
	
},
pieExportToPPT :function(){
	var me=this;
	var config= {width : 400, height : 300, url :"svgToImage", type : "image/png"};
	
	Ext.draw.engine.ImageExporter.generate(me.getStrategicSitesPieChart().surface,config);//Pie chart
},
gridExportToPPT :function(){
	var me=this;
var grid= Ext.ComponentQuery.query('strategicsitesmatrixgrid')[0];
var store = grid.getStore();
var dataArray = [];
var headerArray = [];
var updateData = store.data.items;  
var headerData =  grid.columns;

if(updateData.length != 0)
	{
		Ext.each(updateData, function(item, index, array) {
        dataArray.push(
        	 item.data 
	        );
	    });
	}

if(headerData.length != 0)
	{
		Ext.each(headerData, function(item, index, array) {
			if(index==3){
				Ext.each(item.items.items, function(item, index, array) {
					headerArray.push({
			        	"dataIndex":item.dataIndex,
			        	"header": item.text
						
			        });	})
			}else{
			headerArray.push({
	        	"dataIndex":item.dataIndex,
	        	"header": item.text
				
	        });
			}
	})

			}
eRecon_web.direct.action.Dashboard2Service.sendSSReportData(headerArray,dataArray, function(p,response){
		//Ext.MessageBox.alert('Alert', response.result)
	});

	
}
	
});
	




Ext.define("eRecon_web.controller.UploadDownloadController", {
    extend: "Ext.app.Controller",
    /*stores: ['eRecon_web.store.upload.FileStore'],*/
    refs: [
        {
            ref: "uploadPanel",
            selector: "upload_panel"
        },
        {
            ref: "detailsPanel",
            selector: "detailsupload_panel"
        },
        {
            ref: "detailsDownloadPanel",
            selector: "detailsdownload_panel"
        },
        {
            ref: "aoPanel",
            selector: "aoupload_panel"
        },
        {
            ref: "aoDownloadPanel",
            selector: "aodownload_panel"
        },
        {
        	ref: "detailsFileHistoryGrid",
        	selector: "detailsupload_filehistorygrid"
        },
        {
        	ref: "aoFileHistoryGrid",
        	selector: "aoupload_filehistorygrid"
        },
        {
            ref: "contentCards",
            selector: "navigation_contentcards"
        },
        {
    		ref: 'jobStatusSummaryPanel',
    		selector: 'jobstatusgridpanel'
    	},
    	{
    		ref: 'jobStatusDetailPanel',
    		selector: 'jobstatusgriddetailspanel'
    	},
    	{
    		ref: 'jobStatusFilterPanel',
    		selector: 'jobstatus_filterform'
    	},
    	{
    		ref: 'detailsUploadTemplatePanel',
    		selector: 'detailsupload_template'
    	},
    	{
    		ref: 'detailsUploadContainer',
    		selector: 'detailsupload_container'
    	}
    ],
    init: function () {
        this.control({
            "upload_panel": {
                "uploadfile": this.handleFileUpload
            },
            "detailsupload_panel": {
                "detailsuploadfile": this.handleDetailsFileUpload
            },
            "detailsdownload_panel" : {
            	detailsdownloadfile: this.doTriggerDetailsFileDownload
            },
            "aoupload_panel": {
                "aouploadfile": this.handleAOFileUpload
            },
            "aodownload_panel": {
            	aodownloadfile: this.doTriggerAOFileDownload
            },
            "detailsupload_filehistorygrid" : {
            	detailsFileRunProfile: this.doHandleRunProfile,
            	detailsFileDiscardProfile: this.doHandleDiscardProfile,
            	clickevent : this.doHandleScheduleIdClick
            },
            "aoupload_filehistorygrid" : {
            	aoFileRunProfile: this.showVerbiage,
            	aoFileDiscardProfile: this.doHandleDiscardProfile,
            	clickevent : this.doHandleScheduleIdClick
            },
            "aoupload_container" : {
            	"activate": function () {
            		this.getAoFileHistoryGrid().getStore().loadPage(1);
                }
            },
            "aoattestation_verbiage_upload":{
            	"attestuploadsubmit": this.doHandleRunAOProfile,
            	"attestuploadcancel": this.doCancelAction
            },
            'detailsupload_template radiogroup[action=templateChange]':{
            	change:this.onTemplateChange
            },
            "detailsupload_container":{
            	activate:this.onLoad
            }

        });
    },
    win:null,
    handleFileUpload: function (o) {
        console.log("file upload");
        var form = o.cmp.getForm();
        if (form.isValid()) {
            form.submit({
                url: "fileupload.up",
                waitMsg: 'Uploading file...',
                scope: this,
                success: function (fp, o) {
                    Ext.Msg.show({
                        title: "Success",
                        msg: "File has been successfully saved in the server. Please click on Process File to load data",
                        buttons: Ext.Msg.OK,
                        icon: Ext.Msg.QUESTION
                    });
                },
                failure: function (fp, o) {
                    var errs = "";
                    for (var z = 0; z < o.result.inputError.length; z++) {
                        errs += "- " + o.result.inputError[z] + "<br>";
                    }
                    Ext.Msg.show({
                        title: "Error",
                        msg: "<b>The following errors occurred:</b><br>"
                            + errs,
                        buttons: Ext.Msg.OK,
                        icon: Ext.Msg.ERROR
                    });
                }
            });
        }

    },
    handleDetailsFileUpload: function (o) {
        console.log("Detail file upload");
        var form = o.cmp.getForm();
        var templatePanel = this.getDetailsUploadTemplatePanel();
        var template = templatePanel.down("#templateType");
        var value = template.getValue().template;
        var profileName;
        if(value==="legacy"){
    		profileName= "Legacy_Details_Upload";
    	}else if(value==="genesis"){
    		profileName= "Genesis_Details_Upload";
    	}
        var detailsForm = this.getDetailsPanel();
        var UploadFile = detailsForm.down("#fileupload-file").getValue();
        if (UploadFile !== '') {
            if (form.isValid()) {
                form.submit({
                    url: "fileuploadtrigger?UploadType="+profileName,
                    waitMsg: 'Uploading file...',
                    scope: this,
                    success: function (fp, o) {
                    	
                    	var grid = this.getDetailsFileHistoryGrid();
                    	
                    	grid.getView().getStore().load({
                            callback: function (records, operation, success) {
                            }
                        });
                    	
                        Ext.Msg.show({
                            title: "Success",
                            msg: "File has been successfully saved in the server. Please click on Process File to load data",
                            buttons: Ext.Msg.OK,
                            icon: Ext.Msg.QUESTION
                        });
                    },
                    failure: function (fp, o) {
                        var errs = "";
                        for (var z = 0; z < o.result.validationErrors.length; z++) {
                            errs += "- " + o.result.validationErrors[z] + "<br>";
                        }
                        Ext.Msg.show({
                            title: "Error",
                            msg: "<b>The following errors occurred:</b><br>" + errs,
                            buttons: Ext.Msg.OK,
                            icon: Ext.Msg.ERROR
                        });
                    }
                });
            }
        } else {
            Ext.Msg.show({
                title: "Success",
                msg: "No file to Upload",
                buttons: Ext.Msg.OK,
                icon: Ext.Msg.QUESTION
            });
        }
    },
    handleAOFileUpload: function (o) {
        console.log("AO file upload");
        var form = o.cmp.getForm();
        var detailsForm = this.getAoPanel();
        var UploadFile = detailsForm.down("#fileupload-file").getValue();
        if (UploadFile !== '') {
            if (form.isValid()) {
                form.submit({
                    url: "fileuploadtrigger?UploadType=AO",
                    waitMsg: 'Uploading file...',
                    scope: this,
                    success: function (fp, o) {
                    	
                    	var grid = this.getAoFileHistoryGrid();
                    	
                    	grid.getView().getStore().load({
                            callback: function (records, operation, success) {
                            }
                        });
                    	
                        Ext.Msg.show({
                            title: "Success",
                            msg: "File has been successfully saved in the server. Please click on Process File to load data",
                            buttons: Ext.Msg.OK,
                            icon: Ext.Msg.QUESTION
                        });
                    },
                    failure: function (fp, o) {
                        var errs = "Error: ";
                        if(o.result.validationErrors) {
	                        for (var z = 0; z < o.result.validationErrors.length; z++) {
	                            errs += "- " + o.result.validationErrors[z] + "<br>";
	                        }
                        } else {
                        	errs += "- " + o.result.error + "<br>";
                        }
                        
                        Ext.Msg.show({
                            title: "Error",
                            msg: "<b>The following errors occurred:</b><br>"
                                + errs,
                            buttons: Ext.Msg.OK,
                            icon: Ext.Msg.ERROR
                        });
                        
                        
                    }
                });
            }
        } else {
            Ext.Msg.show({
                title: "Success",
                msg: "No file to Upload",
                buttons: Ext.Msg.OK,
                icon: Ext.Msg.QUESTION
            });
        }
    },
    doTriggerAOFileDownload: function(o) {
    	console.log(o);

    	var form = o.cmp.getForm();
    	if (form.isValid()) {
    		Ext.Ajax.request({
    			url : 'filedownloadtrigger.up?downloadType=AO',
    			method:'POST', 
    			params : {
    				formdata: Ext.encode(form.getValues())
    			},
    			scope : this,
    			success : function(response, opts) {
    				response = Ext.decode(response.responseText);
    				if(response.success){
    					var grid = this.getAoFileHistoryGrid();
                    	
                    	grid.getView().getStore().load({
                            callback: function (records, operation, success) {
                            }
                        });
                    	
                    	Ext.MessageBox.alert('Successful', 
    							"Your request has been submitted successfully with the request id " + response.scheduleId + ". You should recieve an email on completion.");
    				}
    				else {
    					Ext.MessageBox.alert('Failed', "Error while submitting download request.");
    				}
    			},
    			failure : function(err) {
    				Ext.MessageBox.alert('Error occured during AO file download.', 'Please try again!');
    			}
    		}); 		


    	} 
    },
    doTriggerDetailsFileDownload: function(o) {
    	console.log(o);

    	var form = o.cmp.getForm();
    	var templatePanel = this.getDetailsUploadTemplatePanel();
        var template = templatePanel.down("#templateType");
        var value = template.getValue().template;
        var templateType;
        if(value != null || value != ""){
        	if(value==="legacy"){
        		templateType= "DETAILS_LEGACY_DOWNLOAD";
        	}else if(value==="genesis"){
        		templateType= "DETAILS_GENESIS_DOWNLOAD";
        	}
        }else{
        	 Ext.Msg.show({
                 title: "Error",
                 msg: "Please Select a template",
                 buttons: Ext.Msg.OK,
                 icon: Ext.Msg.QUESTION
             });
        }
    	if (form.isValid()) {
    		Ext.Ajax.request({
    			url : 'filedownloadtrigger.up?downloadType=DETAILS&templateType='+templateType,
    			method:'POST', 
    			params : {
    				formdata: Ext.encode(form.getValues())
    			},
    			scope : this,
    			success : function(response, opts) {
    				response = Ext.decode(response.responseText);
    				if(response.success){
    					var grid = this.getDetailsFileHistoryGrid();
                    	
                    	grid.getView().getStore().load({
                            callback: function (records, operation, success) {
                            }
                        });
                    	
                    	Ext.MessageBox.alert('Successful', 
    							"Your request has been submitted successfully with the request id " + response.scheduleId + ". You should recieve an email on completion.");
    				}
    				else {
    					Ext.MessageBox.alert('Failed', "Error while submitting download request.");
    				}
    			},
    			failure : function(err) {
    				Ext.MessageBox.alert('Error occured during details file download.', 'Please try again!');
    			}
    		}); 		


    	} 
    }, 
    doHandleRunProfile : function(column, recordIndex, record, view) {
    	var templatePanel = this.getDetailsUploadTemplatePanel();
        var template = templatePanel.down("#templateType");
        var value = template.getValue().template;
        var profileName;
        if(value != null || value != ""){
        	if(value==="legacy"){
        		profileName= "Legacy_Details_Upload";
        	}else if(value==="genesis"){
        		profileName= "Genesis_Details_Upload";
        	}
	    	var data = {
	    			"scheduleId" : record.get("scheduleId").toString(),
	    			"profileName" : profileName,
	    			"fileName" : record.get("fileName"),
	    			"soeId" : record.get("userId")
	    	}
	    	var encodedArray = Ext.encode(data);
	    	eRecon_web.direct.action.ProcessFileService.handleProcessFile(encodedArray, function(p, response) {
	    		if(response.result == "Success") {
	    			view.getStore().load();
	    			Ext.MessageBox.alert( "Status", "Request to process file has been queued in the system." );
	    		} else {
	    			Ext.MessageBox.alert( "Status", "Error submitting request to process the file." );
	    		}
	    	});
    	}else{
    		 Ext.Msg.show({
                 title: "Error",
                 msg: "Please Select a template",
                 buttons: Ext.Msg.OK,
                 icon: Ext.Msg.QUESTION
             });
    	}
    }, 
    doHandleRunAOProfile : function() {
    	var record = this.win.extraParams.rec;
    	var view = this.getAoFileHistoryGrid();
    	var data = {
    			"scheduleId" : record.get("scheduleId").toString(),
    			"profileName" : record.get("profileName"),
    			"fileName" : record.get("fileName"),
    			"soeId" : record.get("userId")
    	}
    	this.win.close();
    	
    	var encodedArray = Ext.encode(data);
    	eRecon_web.direct.action.ProcessFileService.handleProcessFile(encodedArray, function(p, response) {
    		if(response.result == "Success") {
    			view.getStore().reload();
    			Ext.MessageBox.alert( "Status", "Request to process file has been queued in the system." );
    		} else {
    			Ext.MessageBox.alert( "Status", "Error submitting request to process the file." );
    		}
    	});
    }, 
    doHandleDiscardProfile : function(column, recordIndex, record, view) {
    	var data = {
    			"scheduleId" : record.get("scheduleId").toString(),
    			"profileName" : record.get("profileName"),
    			"fileName" : record.get("fileName"),
    			"soeId" : record.get("userId")
    	}
    	var encodedArray = Ext.encode(data);
    	eRecon_web.direct.action.ProcessFileService.handleDiscardFile(encodedArray, function(p, response) {
    		if(response.result == "Success") {
    			view.getStore().load();
    			Ext.MessageBox.alert( "Status", "Successfully discarded the file." );
    		} else {
    			Ext.MessageBox.alert( "Status", "Error Discarding file" );
    		}
    	});
    },
    
    doHandleScheduleIdClick :function (column, record, rowIndex, colIndex, e) {
    	var me = this;
    	console.log(record.get("scheduleId"));
    	var jobStatusDetailPanel = me.getJobStatusDetailPanel();

    	me.getController('eRecon_web.controller.MainController')
    	  .activateCard({view: "eRecon_web.view.jobstatus.JobStatusContainer"},
			function() {	
				var filterPanel = me.getJobStatusFilterPanel();
				filterPanel.getForm().setValues({scheduleId: record.get("scheduleId")});
				
				var button = filterPanel.down("button[action=search]");
				button.fireEvent('click', button, Ext.EventObject);
			}
    	  );
    },
    
    loadFileHistoryGrid: function() {
    	var aoFileHistoryGrid = this.getAoFileHistoryGrid(); 
    	aoFileHistoryGrid.getStore().load();
    },
    showVerbiage : function(column, recordIndex, record, view)  {
    	this.win=Ext.create("eRecon_web.view.aoupload.AOAttestationVerbiageForUpload", {
    		applyTo: Ext.getBody(),
    	width: 1100,
   		height:300  ,
       		extraParams : {
       			rec : record
       		}
    	});
    	this.win.show();
    },
    doCancelAction :function(){
		this.win.close();
	
    },
    onLoad:function(){
		 var filterPanel = this.getDetailsDownloadPanel();
    	 var businessUnit = filterPanel.down("#bankinggroup-combo");
	     businessUnit.clearValue();
	     businessUnit.store.load({
	    	 params: {0: 'Legacy'}
	     });
    },
    onTemplateChange:function(){
    	var mask = new Ext.LoadMask(Ext.getBody(),{msg:"Please wait..."});
    	mask.show();
    	var filterPanel = this.getDetailsDownloadPanel();
    	var businessUnit = filterPanel.down("#bankinggroup-combo");
    	var templatePanel = this.getDetailsUploadTemplatePanel();
        var template = templatePanel.down("#templateType");
        var value = template.getValue().template;
	    businessUnit.clearValue();
	    if(value==='legacy'){
		    businessUnit.store.load({
		    	 params: {0: 'Legacy'}
		     });
	    }else if (value==='genesis'){
	    	businessUnit.store.load({
		    	 params: {0: 'Genesis'}
		     });
	    }
	    mask.hide();
    }
    
});

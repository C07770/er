Ext.define('eRecon_web.controller.ApplicationConfigController',{
	extend: 'Ext.app.Controller',	
	requires: ["eRecon_web.store.AppConfigStore"],
	stores:	["eRecon_web.store.AppConfigStore"],
	refs: [{
	       ref: 'ApplicationConfigGrid',
	       selector: 'ApplicationConfig_Grid'
	    },
	    {
	    	ref: 'searchForm',
	    	selector: 'ApplicationConfig_Search'
	    }],
	    
	init: function()
	{
		this.control({
			'ApplicationConfig_Search button[action=search]': {
	            click: this.ApplicationConfigSearch
	        },
	        'ApplicationConfig_Search button[action=INSERT]': {
	            click: this.ApplicationConfigInsert
	        },
	        'ApplicationConfig_Search button[action=clear]': {
	            click: this.clearSearchPanel
	        },
	        'ApplicationConfig_Grid button[action=save]': {
	        	click: this.saveRecords
	        },
	        'ApplicationConfig_Grid button[action=appConfig-Excel]': {
	        	click: this.appConfigExcelDownload
	        }
		});
	},
	
	ApplicationConfigInsert : function(){
		var dataArray = [];
		var flag = 0;
		var searchForm = this.getSearchForm();
		var searchFormValues = searchForm.getValues();
		
		var form = searchForm.getForm();
		var formdata = Ext.encode(form.getValues());
		var applicationConfigStore = this.getApplicationConfigGrid().getStore();
		applicationConfigStore.directOptions = {};
		applicationConfigStore.getProxy().extraParams = {
            0: formdata
        };
		
//		debugger;
		var param = searchForm.down("#parameter").getValue();
		var activeflag = searchForm.getForm().getFieldValues().activeflag;
		var dataType = searchForm.getForm().getFieldValues().datatype;
		var val = searchForm.getForm().getFieldValues().value;
		
		if (param == ""){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Parameter is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});	
			flag = 1;
		}
		if (activeflag == "" ||activeflag == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Active Flag is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});	
			flag = 1;
		}
		if (dataType == "" ||dataType == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Datatype is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});	
			flag = 1;
		}
		if (val == ""){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Value is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});	
			flag = 1;
		}
		
		if(flag == 0){
			Ext.Msg.show({
				title: "Confirmation",
				msg: "Do you want to insert a record?",
			    buttons: Ext.Msg.OKCANCEL,
			    fn: function(btn) {
					if (btn == 'ok') {
			searchFormValues.action = 'INSERT';
			dataArray.push({
				"newInsertData" : searchFormValues
	        });
			
			var encodedArray = Ext.encode(dataArray);			
			eRecon_web.direct.action.AppConfigService.saveRecords(encodedArray, function(p, response) {	
				if(response.result[0]!= null){
					if(response.result[0] == "Success") {
						applicationConfigStore.loadPage(1,{
			                callback: function (records, operation, success) {
			                }
			            });
			    		Ext.Msg.alert('Status','1 Record inserted successfully');
			    	}
					else{
						Ext.Msg.alert('Status','Record not inserted');
					}
				}		    	
		    	else {		    		
		    		Ext.Msg.alert('Status','Record not saved');
		    	}	    	
		    	});
					}
			    }
			});
		}//flag		 
	},
	saveRecords: function(){		
		var store = this.getStore('eRecon_web.store.AppConfigStore');
		var dataArray = [];
		var updateData = store.getUpdatedRecords(); 
		var deleteData = store.getRemovedRecords();
		
		if(updateData.length == 0 && deleteData.length == 0) 
		{
    		Ext.MessageBox.alert( "Alert", "No changes found");
    		return false;
		}
		if(updateData.length != 0)
			{
				Ext.each(updateData, function(item, index, array) {
		        dataArray.push({
					"newData" : item.data,
		        	"previousData" : item.raw,
		        	"modified" : item.modified 
			        });
			    });
			}
	
		if(deleteData.length != 0)
			{
			Ext.each(deleteData, function(item, index, array) {
		        dataArray.push({
					"deleteData" : item.data
		        });
		    });
			}
		var encodedArray = Ext.encode(dataArray);
		eRecon_web.direct.action.AppConfigService.saveRecords(encodedArray, function(p, response) {
			if(response.result[0]!= null){
				if(response.result[0] == "Success" || response.result[0] =="Exception") {
		    		Ext.MessageBox.alert( "Status", response.result[1] );
		    		store.load();		    		
		    	}
			}
			else if (response.result[0] == null || response.result[0] =="Fail"){
				Ext.MessageBox.alert( "Status", "Record(s) modification failed" );
			}
	    }); 
	},
	
	ApplicationConfigSearch: function(){					
		var searchPanel = this.getSearchForm();
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
        var userRoleGrid =this.getApplicationConfigGrid();
        if (searchPanel.getForm().isValid()) 
        {
        	var parameter = searchPanel.down("#parameter").getValue();
        	
        	var appConfigStore = this.getStore('eRecon_web.store.AppConfigStore');
        	appConfigStore.directOptions = {};
        	appConfigStore.getProxy().extraParams = {
                0: formdata
            };
        	
        	appConfigStore.load({
                callback: function (records, operation, success) {
                }
            });
        }		
	},
	clearSearchPanel: function(){
		var searchPanel = this.getSearchForm();
		searchPanel.getForm().reset();
		
//		searchPanel.down("#parameter").setValue("");
		var appConfigStore = this.getStore('eRecon_web.store.AppConfigStore');
    	appConfigStore.directOptions = {};
    	appConfigStore.getProxy().extraParams = {
            0: null
        };
    	
    	appConfigStore.load({
            callback: function (records, operation, success) {
            }
        });
	} ,
	appConfigExcelDownload : function(){
		var searchPanel = this.getSearchForm();
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var appConfigStore = this.getStore('eRecon_web.store.AppConfigStore');
		Ext.create('eRecon_web.common.ExportToExcelStatusPopup').launchExport(
			'eRecon_web.store.AppConfigStore',
			appConfigStore.total,
			null,
			{0: formdata}
		);
	}
		
});

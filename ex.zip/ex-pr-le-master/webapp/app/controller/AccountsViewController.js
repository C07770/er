Ext.define('eRecon_web.controller.AccountsViewController',{
	extend: 'Ext.app.Controller',
	stores:	['eRecon_web.store.AccountsViewStore'], 
	init: function(){
		var me = this;
		this.control({
			'accountsview_container': {
//				resize: function() {
//					console.log("aaaaaa");
//				},
//				
				boxready: function() {
					var store = me.getStore('eRecon_web.store.AccountsViewStore');
					store.load();
				}
			}
		
//			, 'accountsview_container grid': {
//				resize: function(grid) {
//					var rowHeight = 22;					
//					var height = grid.body.getHeight(true);
//					var	rows = Math.floor(height / rowHeight);
//					grid.getStore().pageSize = rows;
//					grid.getStore().load();
//				}
//			},
//			
//			, 'accountsview_container pagingtoolbar': {
//				beforeLoad: function() {
//					console.log("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
//				}
//			}
			
		})
	}

});

Ext.define('eRecon_web.controller.FeedLoadTemplateController',{
	extend: 'Ext.app.Controller',
	requires:	["eRecon_web.store.FeedLoadTemplateStore"],
	stores:	["eRecon_web.store.FeedLoadTemplateStore"],
	refs: [{
	       ref: 'feedtemplateGrid',
	       selector: 'feedloadtemplategrid'
	    },
	    {
	    	ref: 'searchForm',
	    	selector: 'feedloadtemplatesearch'
	    }],
	
	init: function()
	{
		this.control({
			'feedloadtemplatesearch button[action=feedtemplate-search]': {
	            click: this.feedTemplateSearch
	        },
	        'feedloadtemplatesearch button[action=feedtemplate-clear]': {
	            click: this.clearFilterForm
	        },
	        'feedloadtemplategrid button[action=feedtemplate-save]': {
	        	click: this.saveRecords
	        },
	        'feedloadtemplategrid  button[action=feedtemplate-excel]': {
	        	click: this.feedGTemplatedownlaodfile
	        },
	        'feedloadtemplatesearch  button[action=feedtemplate-add]': {
	        	click: this.feedTemplateAddRecord
	        }
		});
	},
	
	saveRecords: function(){
		
		var store = this.getStore('eRecon_web.store.FeedLoadTemplateStore');
		var dataArray = [];
		var updateData = store.getUpdatedRecords(); 
		var deleteData = store.getRemovedRecords();
		
		if(updateData.length == 0 && deleteData.length == 0) 
		{
    		Ext.MessageBox.alert( "Alert", "No changes found");
    		return false;
		}
		if(updateData.length != 0)
			{
				Ext.each(updateData, function(item, index, array) {
		        dataArray.push({
					"newData" : item.data,
		        	"previousData" : item.raw,
		        	"modified" : item.modified 
			        });
			    });
			}
		if(deleteData.length != 0)
			{
			Ext.each(deleteData, function(item, index, array) {
		        dataArray.push({
					"deleteData" : item.data
		        });
		    });
			}
		
		var encodedArray = Ext.encode(dataArray);
		eRecon_web.direct.action.FeedLoadTemplateService.saveRecords(encodedArray, function(p, response) {
	    	if(response.result !== "Error") {
	    		Ext.MessageBox.alert( "Status", response.result);
	    		store.load();
	    	}else{
	    		Ext.MessageBox.alert( "Status", response.result);
	    	}
	    }); 
	},
	
    feedGTemplatedownlaodfile: function(){
	     var searchPanel = this.getSearchForm();
	     var form = searchPanel.getForm();
	     var formdata = Ext.encode(form.getValues());
	     var feedLoadTemplateStore = this.getStore('eRecon_web.store.FeedLoadTemplateStore');
	     Ext.create('eRecon_web.common.ExportToExcelStatusPopup').launchExport(
			'eRecon_web.store.FeedLoadTemplateStore',
			feedLoadTemplateStore.total,
			null,
			{0: formdata}
		);
//	     window.location.href='\MaintainScreenExcelDownlaod?downloadType=FeedCalendarTemplate&formData='+formdata;
    },
	
	clearFilterForm: function(){
		var searchPanel = this.getSearchForm();
		searchPanel.getForm().reset();
		var feedTemplateStore = this.getFeedtemplateGrid().getStore();
		feedTemplateStore.directOptions = {};
		feedTemplateStore.getProxy().extraParams = {
            0: null
        };
        feedTemplateStore.load();
	},
	
	feedTemplateSearch: function(){
		var searchPanel = this.getSearchForm();
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var feedTemplateStore = this.getFeedtemplateGrid().getStore();
		feedTemplateStore.directOptions = {};
		feedTemplateStore.getProxy().extraParams = {
            0: formdata
        };
        feedTemplateStore.loadPage(1,{
            callback: function (records, operation, success) {
            }
        });
	},
	feedTemplatedownlaodfile: function(){
		var searchPanel = this.getSearchForm();
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var feedTemplateStore = this.getFeedtemplateGrid().getStore();
		Ext.create('eRecon_web.common.ExportToExcelStatusPopup').launchExport(
			'eRecon_web.store.FeedLoadTemplateStore',
			feedTemplateStore.total,
			null,
			{0: formdata}
		);
	},
	feedTemplateAddRecord: function(){
		var searchPanel = this.getSearchForm();
		var form = searchPanel.getForm();
		if(searchPanel.down('#profile_id-text').getValue()=='' || searchPanel.down('#profile_id-text').getValue()==null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Profile Id is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});
			return;
		} else if(searchPanel.down('#template_id-text').getValue()==''||searchPanel.down('#template_id-text').getValue()==null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Template Id is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});
			return;
		}
		var formdata = Ext.encode(form.getValues());
		var feedTemplateStore = this.getFeedtemplateGrid().getStore();
		feedTemplateStore.directOptions = {};
		feedTemplateStore.getProxy().extraParams = {
            0: formdata
        };
		
        Ext.Msg.show({
			title: "Confirmation",
			msg: "Do you want to insert a record?",
		    buttons: Ext.Msg.OKCANCEL,
		    fn: function(btn) {
				if (btn == 'ok') {
					eRecon_web.direct.action.FeedLoadTemplateService.doAddRecords(formdata, function(p, response) {
				    	if(response.result != "Error") {
				    		feedTemplateStore.loadPage(1,{
				                callback: function (records, operation, success) {
				                }
				            });
				            Ext.MessageBox.alert( "Status", response.result);
				    	}else{
				    		Ext.MessageBox.alert( "Status", response.result );
				    	}
				    }); 
				}
			}
		});
		
	}
	
});

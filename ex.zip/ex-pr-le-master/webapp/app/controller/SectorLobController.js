Ext.define('eRecon_web.controller.SectorLobController',{
	extend: 'Ext.app.Controller',
	requires:	["eRecon_web.store.SectorLobMappingStore"],
	stores:	["eRecon_web.store.SectorLobMappingStore"],
	refs: [{
	       ref: 'sectorLuGrid',
	       selector: 'sectorlobmappinggrid'
	    },
	    {
	    	ref: 'searchForm',
	    	selector: 'secadmin_sectorlobmappingsearch'
	    }],
	
	init: function()
	{
		this.control({
			'secadmin_sectorlobmappingsearch button[action=sectorLob-search]': {
	            click: this.sectorLobSearch
	        },
	        'secadmin_sectorlobmappingsearch button[action=sectorLob-clear]': {
	            click: this.clearFilterForm
	        },
	        'sectorlobmappinggrid button[action=sectorLob-save]': {
	        	click: this.saveRecords
	        },
	        'sectorlobmappinggrid  button[action=sectorLob-excel]': {
	        	click: this.sectorLobdownlaodfile
	        },
	        'secadmin_sectorlobmappingsearch  button[action=sectorLob-add]': {
	        	click: this.sectorLobAddRecord
	        }
		});
	},
	
	saveRecords: function(){
		
		var store = this.getStore('eRecon_web.store.SectorLobMappingStore');
		var dataArray = [];
		var updateData = store.getUpdatedRecords(); 
		var deleteData = store.getRemovedRecords();
		
		if(updateData.length == 0 && deleteData.length == 0) 
		{
    		Ext.MessageBox.alert( "Alert", "No changes found");
    		return false;
		}
		if(updateData.length != 0)
			{
				Ext.each(updateData, function(item, index, array) {
		        dataArray.push({
					"newData" : item.data,
		        	"previousData" : item.raw,
		        	"modified" : item.modified 
			        });
			    });
			}
		if(deleteData.length != 0)
			{
			Ext.each(deleteData, function(item, index, array) {
		        dataArray.push({
					"deleteData" : item.data
		        });
		    });
			}
		
		var encodedArray = Ext.encode(dataArray);
		eRecon_web.direct.action.SectorLobMappingService.saveRecords(encodedArray, function(p, response) {
	    	if(response.result !== "Error") {
	    		Ext.MessageBox.alert( "Status", response.result);
	    		store.load();
	    	}else{
	    		Ext.MessageBox.alert( "Status", response.result);
	    	}
	    }); 
	},
	
	clearFilterForm: function(){
		var searchPanel = this.getSearchForm();
		searchPanel.getForm().reset();
		var sectorLobStore = this.getSectorLuGrid().getStore();
		sectorLobStore.directOptions = {};
		sectorLobStore.getProxy().extraParams = {
            0: null
        };
        sectorLobStore.load();
	},
	
	sectorLobSearch: function(){
		var searchPanel = this.getSearchForm();
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var sectorLobStore = this.getSectorLuGrid().getStore();
		sectorLobStore.directOptions = {};
		sectorLobStore.getProxy().extraParams = {
            0: formdata
        };
        sectorLobStore.loadPage(1,{
            callback: function (records, operation, success) {
            }
        });
	},
	sectorLobdownlaodfile: function(){
		var searchPanel = this.getSearchForm();
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var sectorLobStore = this.getSectorLuGrid().getStore();
		Ext.create('eRecon_web.common.ExportToExcelStatusPopup').launchExport(
			'eRecon_web.store.SectorLobMappingStore',
			sectorLobStore.total,
			null,
			{0: formdata}
		);
	},
	sectorLobAddRecord: function(){
		var searchPanel = this.getSearchForm();
		var id = searchPanel.down("#id-text").getValue();
		var level2_descr = searchPanel.down("#level2_descr-combo").getValue();
		var lob_id = searchPanel.down("#lob_id-combo").getValue();
		var activeFlag = searchPanel.down("#activeFlag-combo").getValue();
		if(id == "" || id == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>ID is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		if(level2_descr == "" || level2_descr == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Level2_Descr is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		if(lob_id == "" || lob_id == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>LOB_ID is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		if(activeFlag == "" || activeFlag == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>ActiveFlag is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var sectorLobStore = this.getSectorLuGrid().getStore();
		sectorLobStore.directOptions = {};
		sectorLobStore.getProxy().extraParams = {
            0: formdata
        };
		
        Ext.Msg.show({
			title: "Confirmation",
			msg: "Do you want to insert a record?",
		    buttons: Ext.Msg.OKCANCEL,
		    fn: function(btn) {
				if (btn == 'ok') {
					eRecon_web.direct.action.SectorLobMappingService.doAddRecords(formdata, function(p, response) {
				    	if(response.result != "Error") {
				    		sectorLobStore.loadPage(1,{
				                callback: function (records, operation, success) {
				                }
				            });
				            Ext.MessageBox.alert( "Status", response.result);
				    	}else{
				    		Ext.MessageBox.alert( "Status", response.result );
				    	}
				    }); 
				}
			}
		});
		
	}
	
});

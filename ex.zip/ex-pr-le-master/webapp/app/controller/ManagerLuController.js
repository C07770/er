Ext.define('eRecon_web.controller.ManagerLuController',{
	extend: 'Ext.app.Controller',
	requires: ["eRecon_web.store.MangerLuStore"],
	stores:	["eRecon_web.store.MangerLuStore"],
	refs: [{
	       ref: 'managerLuGrid',
	       selector: 'secadmin_managerlugrid'
	    },
	    {
	    	ref: 'searchForm',
	    	selector: 'secadmin_managerlusearch'
	    }],
	
	init: function()
	{
		this.control({
			'secadmin_managerlusearch button[action=managerLu-search]': {
	            click: this.managerLuSearch
	        },
	        'secadmin_managerlusearch button[action=managerLu-clear]': {
	            click: this.clearFilterForm
	        },
	        'secadmin_managerlugrid button[action=managerlu-save]': {
	        	click: this.saveRecords
	        },
	        'secadmin_managerlugrid  button[action=managerLu-Excel-button]': {
	        	click: this.managerLudownloadfile
	        },
	        'secadmin_managerlusearch  button[action=managerLu-add]': {
	        	click: this.managerLuAddRecords
	        }
		});
	},
	
	saveRecords: function(){
		
		var store = this.getStore('eRecon_web.store.MangerLuStore');
		var dataArray = [];
		var updateData = store.getUpdatedRecords(); 
		var deleteData = store.getRemovedRecords();
		
		if(updateData.length == 0 && deleteData.length == 0) 
		{
    		Ext.MessageBox.alert( "Alert", "No changes found");
    		return false;
		}
		if(updateData.length != 0)
			{
				Ext.each(updateData, function(item, index, array) {
		        dataArray.push({
					"newData" : item.data,
		        	"previousData" : item.raw,
		        	"modified" : item.modified 
			        });
			    });
			}
		if(deleteData.length != 0)
			{
			Ext.each(deleteData, function(item, index, array) {
		        dataArray.push({
					"deleteData" : item.data
		        });
		    });
			}
		
		var encodedArray = Ext.encode(dataArray);
		eRecon_web.direct.action.ManagerLuService.saveRecords(encodedArray, function(p, response) {
	    	if(response.result != "Error") {
	    		Ext.MessageBox.alert( "Status", response.result);
	    		
	    	}else{
	    		Ext.MessageBox.alert( "Status", response.result);
	    	}
	    	store.load();
	    }); 
	},
	
	clearFilterForm: function(){
		var searchPanel = this.getSearchForm();
		searchPanel.getForm().reset();
		var managerlustore = this.getManagerLuGrid().getStore();
		managerlustore.directOptions = {};
		managerlustore.getProxy().extraParams = {
            0: null
        };
        managerlustore.load();
	},
	
	managerLuSearch:	function(){
		var searchPanel = this.getSearchForm();
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var managerlustore = this.getManagerLuGrid().getStore();
		managerlustore.directOptions = {};
		managerlustore.getProxy().extraParams = {
            0: formdata
        };
        managerlustore.loadPage(1,{
            callback: function (records, operation, success) {
            }
        });
	},
	managerLudownloadfile: function(){
		var searchPanel = this.getSearchForm();
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var managerStore = this.getManagerLuGrid().getStore();
		Ext.create('eRecon_web.common.ExportToExcelStatusPopup').launchExport(
			'eRecon_web.store.MangerLuStore',
			managerStore.total,
			null,
			{0: formdata}
		);
	},
	managerLuAddRecords: function(){
		var searchPanel = this.getSearchForm();
		var proofOwner = searchPanel.down("#proofOwner-text").getValue();
		var proofOwnerBackup = searchPanel.down("#proofOwnerBackup-text").getValue();
		if(proofOwner == "" || proofOwner == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Proof Owner is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		if(proofOwnerBackup == "" || proofOwnerBackup == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Proof  Owner  Backup is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var managerStore = this.getManagerLuGrid().getStore();
		managerStore.directOptions = {};
		managerStore.getProxy().extraParams = {
            0: formdata
        };
		
        Ext.Msg.show({
			title: "Confirmation",
			msg: "Do you want to insert a record?",
		    buttons: Ext.Msg.OKCANCEL,
		    fn: function(btn) {
				if (btn == 'ok') {
					eRecon_web.direct.action.ManagerLuService.doAddRecords(formdata, function(p, response) {
				    	if(response.result != "Error") {
				    		managerStore.loadPage(1,{
				                callback: function (records, operation, success) {
				                }
				            });
				            Ext.MessageBox.alert( "Status", response.result);
				    	}else{
				    		Ext.MessageBox.alert( "Status", response.result );
				    	}
				    }); 
				}
			}
		});
		
	}
	
});

Ext.define('eRecon_web.controller.UserRoleMappingController',{
	extend: 'Ext.app.Controller',
	requires:	["eRecon_web.store.UserRoleMappingStore"],
	stores:	["eRecon_web.store.UserRoleMappingStore"],
	refs: [{
	       ref: 'userRoleMappingGrid',
	       selector: 'secadmin_userrolemapping'
	    },
	    {
	    	ref: 'searchForm',
	    	selector: 'secadmin_userrolemappingsearch'
	    },
	    {
	    	ref: 'userRoleContainer',
	    	selector: 'secadmin_userrolemappingcontainer'
	    },
	    {
	    	ref: 'userSearchForm',
	    	selector: 'secadmin_usermaintenancesearch'
	    }],
	
	init: function()
	{
		this.control({
			'secadmin_userrolemappingsearch button[action=userRole-search]': {
	            click: this.userRoleMappingSearch
	        },
	        'secadmin_userrolemappingsearch button[action=userRole-clear]': {
	            click: this.clearUserRole
	        },
	        'secadmin_userrolemappingsearch button[action=userRole-insert]': {
	            click: this.doaddRecord
	        },
	        'secadmin_userrolemapping button[action=userRolemapping-save]': {
	        	click: this.saveRecords
	        },
	        'secadmin_userrolemapping  button[action=userRolemapping-excel]': {
	        	click: this.userRoledownloadfile
	        },
	        'secadmin_userrolemapping  button[action=userRolemapping-back]': {
	        	click: this.userRoleBackAction
	        }
	        /*'secadmin_userrolemappingcontainer': {
	        	activate: this.onLoad
	        }*/
		});
	},
	/*onLoad: function(){
		
		var searchPanel = this.getSearchForm();
        var userRoleGrid =this.getUserRoleMappingGrid();
        if (searchPanel.getForm().isValid()) 
        {
        	var form = searchPanel.getForm();
    		var formdata = Ext.encode(form.getValues());
        	var userRoleStore = this.getStore('eRecon_web.store.UserRoleMappingStore');
        	userRoleStore.directOptions = {};
        	userRoleStore.getProxy().extraParams = {
                0: formdata
            };
        	
        	userRoleStore.loadPage(1,{
	                callback: function (records, operation, success) {
	                }
	        });
        }		
		
	},*/
	saveRecords: function(){
		
		var store = this.getStore('eRecon_web.store.UserRoleMappingStore');
		var dataArray = [];
		var updateData = store.getUpdatedRecords(); 
		var deleteData = store.getRemovedRecords();
		
		if(updateData.length == 0  && deleteData.length == 0) 
		{
    		Ext.MessageBox.alert( "Alert", "No changes found");
    		return false;
		}
		if(updateData.length != 0)
			{
				Ext.each(updateData, function(item, index, array) {
		        dataArray.push({
					"newData" : item.data,
		        	"previousData" : item.raw,
		        	"modified" : item.modified 
			        });
			    });
			}
		if(deleteData.length != 0)
			{
			Ext.each(deleteData, function(item, index, array) {
		        dataArray.push({
					"deleteData" : item.data
		        });
		    });
			}
		
		var encodedArray = Ext.encode(dataArray);
		eRecon_web.direct.action.UserRoleMappingService.saveRecords(encodedArray, function(p, response) {
	    	if(response.result!== "Error") {
	    		store.load();
	    		Ext.MessageBox.alert( "Status", response.result );
	    	}
	    	Ext.MessageBox.alert( "Status", response.result );
	    }); 
	},
	
	clearUserRole: function(){
		var searchPanel = this.getSearchForm();
		searchPanel.getForm().reset();
		var userRoleStore = this.getStore('eRecon_web.store.UserRoleMappingStore');
    	userRoleStore.directOptions = {};
    	userRoleStore.getProxy().extraParams = {
            0: null
        };
    	
    	userRoleStore.load();
               
	},
	
	userRoleMappingSearch:	function(){					
		var searchPanel = this.getSearchForm();
        var userRoleGrid =this.getUserRoleMappingGrid();
        if (searchPanel.getForm().isValid()) 
        {
        	var form = searchPanel.getForm();
    		var formdata = Ext.encode(form.getValues());
        	var userRoleStore = this.getStore('eRecon_web.store.UserRoleMappingStore');
        	userRoleStore.directOptions = {};
        	userRoleStore.getProxy().extraParams = {
                0: formdata
            };
        	
        	userRoleStore.loadPage(1,{
	                callback: function (records, operation, success) {
	                }
	        });
        }		
	},
	userRoledownloadfile: function(){
		var searchPanel = this.getSearchForm();
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var userRoleStore = this.getStore('eRecon_web.store.UserRoleMappingStore');
		Ext.create('eRecon_web.common.ExportToExcelStatusPopup').launchExport(
			'eRecon_web.store.UserRoleMappingStore',
			userRoleStore.total,
			null,
			{0: formdata}
		);
	},
	doaddRecord: function(){
		var searchPanel = this.getSearchForm();
		var userid = searchPanel.down("#userid-text").getValue();
		var role = searchPanel.down("#Role-combo").getValue();
		var activeFlag = searchPanel.down("#Active-combo").getValue();
		if(userid == "" || userid == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Userid is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		if(role == "" || role == null || role=="<--Select-->"){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Role is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		if(activeFlag == "" || activeFlag == null ){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Active Flag is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var userRoleStore = this.getUserRoleMappingGrid().getStore();
		userRoleStore.directOptions = {};
		userRoleStore.getProxy().extraParams = {
            0: formdata
        };
		
        Ext.Msg.show({
			title: "Confirmation",
			msg: "Do you want to insert a record?",
		    buttons: Ext.Msg.OKCANCEL,
		    fn: function(btn) {
				if (btn == 'ok') {
					eRecon_web.direct.action.UserRoleMappingService.doAddRecords(formdata, function(p, response) {
				    	if(response.result!= "Error") {
				    		userRoleStore.loadPage(1,{
				                callback: function (records, operation, success) {
				                }
				            });
				            Ext.MessageBox.alert( "Status", response.result );
				    	}else{
				    		Ext.MessageBox.alert( "Status", response.result );
				    	}
				    	
				    }); 
				}
			}
		});
		
	},
	userRoleBackAction : function(){
		var me = this;
    	me.getController('eRecon_web.controller.MainController')
    	  .activateCard({view: "eRecon_web.view.userMaintenance.UserMaintenanceContainer"},
			function() {
				var filterPanel = me.getUserSearchForm();
				filterPanel.getForm().reset();
			}
    	  );
	}
	
	
});

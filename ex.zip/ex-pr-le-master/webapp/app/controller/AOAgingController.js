Ext.define('eRecon_web.controller.AOAgingController',{
	extend: 'Ext.app.Controller',	
    refs: [
        {
            ref: 'balanceTab',
            selector: 'aobalanceaging_container'
        },
        {
            ref: 'reconTab',
            selector: 'aoreconbreakaging_container'
        },
        {
            ref: "riskamountTab",
            selector: "aoamountatrisk_container"
        },
        {
        	ref:'tabContainer',
        	selector:'aoaging_tabcontainer'
        }
    ],
		
	init: function(){
		var me = this;
		this.control({
			'aoaging_tabcontainer':{
				beforerender: function() {
					me.loadData();
				}
			},
			
			'aobalanceaging_container field[customFormat=true], aoreconbreakaging_container field[customFormat=true]': {
				change: function(field) { 
					me.customFormat(field);
				}	
			}
		});
	},
	fullKey:'',
	glbalance:'',
	account_id:'',
	aging_type:'',
	recon_period:'',
		
loadData : function()
{
	
	var getParameters = Ext.getCmp("AOAgingDetails");
	
	var balanceAging=this.getBalanceTab();
	var reconAging=this.getReconTab();
	var form = this.getBalanceTab().getForm();
	var reconAgingform=this.getReconTab().getForm();
	var amountatriskform=this.getRiskamountTab().getForm();
	var account_id= getParameters.extraParams.AccountId;
	var aging_type= getParameters.extraParams.AgingType;
	var reconperiod= getParameters.extraParams.ReconPeriod;
	if(aging_type==='S'){
		var mytab= this.getTabContainer();
        mytab.child('aobalanceaging_container').hide();
        mytab.down('#aobalanceaging').tab.hide();
        mytab.child('aoreconbreakaging_container').show();	
		
	}
	var store = this.getStore('eRecon_web.store.AOAgingDetailStore');    	
	if(aging_type==='G'){
    	store.getProxy().extraParams = {	            
	            0:account_id,
	            1:aging_type,
	            2:reconperiod
	        };
	        store.load({
                callback: function (records, operation, success) {
	    			console.log("" + success);
	    			if(success) {
	    				form.loadRecord(store.getAt(0));
	    				amountatriskform.loadRecord(store.getAt(0));
	    				reconAgingform.loadRecord(store.getAt(1));
	    			} else {
	    				console.log("Error gettoing data");
	    			}
	    			
                }
            });
	}
	else if (aging_type==='S'){
				store.getProxy().extraParams = {	            
		        0:account_id,
		        1:aging_type,
		        2:reconperiod
		    };
		    store.load({
		        callback: function (records, operation, success) {
					console.log("" + success);
					if(success) {
						reconAgingform.loadRecord(store.getAt(0));
						amountatriskform.loadRecord(store.getAt(0));
						
					} else {
						console.log("Error gettoing data");
					}
					
		        }
		    });
	}
	    
},

	customFormat: function(field) {
		var val=field.value;
		var newValue;
		if(val === '' || val === null || val === undefined) {
			return null;
		}
		else{
			val= val.toString();
		}
		if(val.indexOf("(") >= 0) {
	    	return val;
	    }
		newValue = val.replace(new RegExp('[,]', 'g'), '');
		newValue = Ext.util.Format.number(newValue, '0,000.00/i');
		if(parseFloat(newValue) < 0){
			newValue = newValue.replace(new RegExp('[-]', 'g'), '');
			newValue = '(' + newValue + ')';
		}
		field.setValue(newValue);
	}
			
});
	

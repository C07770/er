Ext.define("eRecon_web.controller.MainController", {
    extend: "Ext.app.Controller",
    requires: ["Ext.ux.ActivityMonitor",
               "eRecon_web.store.CountriesStore",
               "eRecon_web.store.CurrenciesStore"
    ],
    refs: [
        {
            ref: "contentCards",
            selector: "navigation_contentcards"
        }
    ],
/**
 * menuId: the id connected to the clicked menu item (corresponds to the MENU_DESC in the MNU_MENU_LU table)
 *         There may be more than one record with the same menuId, in this case all the
 *         corresponding controllers and views will be created, and the last view will be activated.
 * controller: optional; controller to be created
 * view: view to be created and activated
 * xtype optional; required for the cards that were defined directly in the CintentCards
 */    
 
 	pageArr : [ {
		menuId : "home",
		view: "eRecon_web.view.homeview.HomeView"
 	}, {
		menuId : "loadsummary",
		controller : "eRecon_web.controller.LoadSummaryController",
		view : "eRecon_web.view.loadsummary.LoadSummaryContainer"
	}, {
		menuId : "rulesmaintenance",
		controller : "eRecon_web.controller.RulesMaintenanceController",
		view : "eRecon_web.view.rulesmaintenance.RulesMaintenanceContainer",
		refresh_data: true
	}, {
		menuId : "rulesapproval",
		controller : "eRecon_web.controller.RulesApprovalController",
		view : "eRecon_web.view.rulesapproval.RulesApprovalContainer",
		refresh_data: true
	}, {
		menuId : "accountsview",
		controller : "eRecon_web.controller.AccountsViewController",
		view : "eRecon_web.view.accountsview.AccountsViewContainer"
	}, {
		menuId : "userrolemapping",
		controller : "eRecon_web.controller.UserRoleMappingController",
		view : "eRecon_web.view.UserRoleMapping.UserRoleMappingContainer"
	}, {
		menuId : "openclosecycle",
		controller : "eRecon_web.controller.OpenCloseCycleController",
		view : "eRecon_web.view.OpenCloseCycle.OpenCloseCycleContainer"
	}, {
		menuId : "subledger",
		controller : "eRecon_web.controller.SubledgerController",
		view : "eRecon_web.view.subledger.Container"
	}, {
		menuId : "aoattestation",
		controller : "eRecon_web.controller.AOAttestationController",
		view : "eRecon_web.view.aoattestation.AOAttestationContainer"
	}, {
		menuId : "aoupload",
		controller : "eRecon_web.controller.UploadDownloadController",
		view : "eRecon_web.view.aoupload.AOUploadContainer"
	}, {
		menuId : "detailsupload",
		controller : "eRecon_web.controller.UploadDownloadController",
		view : "eRecon_web.view.detailsupload.DetailsUploadContainer"
	}, {
		menuId : "jobstatus",
		controller : "eRecon_web.controller.JobStatusController",
		view : "eRecon_web.view.jobstatus.JobStatusContainer"
	}, {
		menuId : "lemadjustments",
		controller : "eRecon_web.controller.LemAdjustmentsController",
		view : "eRecon_web.view.lemadjustments.Container"
	}, {
		menuId : "newassigned",
		controller : "eRecon_web.controller.NewAssignedController",
		view : "eRecon_web.view.newassigned.Container"
	}, {
		menuId : "ownershipalert",
		controller : "eRecon_web.controller.OwnershipAlertController",
		view : "eRecon_web.view.ownershipalert.OwnershipAlertContainer"
	}, {
		menuId : "transferaccounts",
		controller : "eRecon_web.controller.TransferAccountsController",
		view : "eRecon_web.view.transferaccounts.Container"
	}, {
		menuId : "upload",
		controller : "eRecon_web.controller.UploadDownloadController",
		view : "eRecon_web.view.upload.Container"
	}, {
		menuId : "ContactInformation",
		controller : "eRecon_web.controller.ContactInformationController",
		view : "eRecon_web.view.ContactInformation.Contacts"
	}, {
		menuId : "training",
		view : "eRecon_web.view.training.TrainingContainer"
	}, {
		menuId : "newsletters",
		view : "eRecon_web.view.newsletters.NewsLetterContainer"
	}, {
		menuId : "links",
		view : "eRecon_web.view.links.LinkContainer"
	}, {
		menuId : "BroadcastMessage",
		controller : "eRecon_web.controller.BroadcastMessageController",
		view : "eRecon_web.view.BroadcastMessage.BroadcastMessage"
	},{
		menuId : "accountmaintenanceview",
		controller : "eRecon_web.controller.AccountMaintenanceController",
		view : "eRecon_web.view.accountmaintenance.AccountMaintenanceContainer"
	},{
		menuId : "assignentitlement",
		controller : "eRecon_web.controller.AssignEntitlementController",
		view : "eRecon_web.view.assignEntitlement.Container"
		
	},{
		menuId : "ApplicationConfig",
		controller : "eRecon_web.controller.ApplicationConfigController",
		view : "eRecon_web.view.ApplicationConfig.ApplicationConfigContainer"
		
	},{
		menuId : "adhocquery",
		controller : "eRecon_web.controller.AdhocQueryController",
		view : "eRecon_web.view.AdhocQuery.AdhocQueryContainer"		
	},{
		menuId: "accounttypedefaultlu",
		controller: "eRecon_web.controller.AccountTypeDefaultController",
		view: "eRecon_web.view.AccountTypeDefaultLU.AccountTypeDefaultContainer"
	},{
		menuId: "accounttypelu",
		controller: "eRecon_web.controller.AccountTypeLUController",
		view: "eRecon_web.view.AccountTypeLU.AccountTypeLUContainer"
	},{
		menuId: "rollbackfeeds",
		controller: "eRecon_web.controller.RollbackFeedsController",
		view: "eRecon_web.view.RollbackFeeds.RollbackFeedsContainer"
	},{
		menuId: "exchangerate",
		controller: "eRecon_web.controller.ExchangeRateController",
		view: "eRecon_web.view.ExchangeRate.ExchangeRateContainer"
	},{
		menuId : "usermaintenance",
		controller : "eRecon_web.controller.UserMaintenanceController",
		view : "eRecon_web.view.userMaintenance.UserMaintenanceContainer"
	},{
		menuId : "acctownerlu",
		controller : "eRecon_web.controller.AccountOwnerLuController",
		view : "eRecon_web.view.accountOwnerLu.AccountOwnerLuContainer"
	},{
		menuId : "managerlu",
		controller : "eRecon_web.controller.ManagerLuController",
		view : "eRecon_web.view.managerLu.ManagerLuContainer"
	},{
		menuId : "archivebsd",
		controller : "eRecon_web.controller.ArchiveBSDController",
		view : "eRecon_web.view.archiveBSD.ArchiveBSDContainer"
	},{
		menuId : "cyclecalenderlu",
		controller : "eRecon_web.controller.CycleCalenderController",
		view : "eRecon_web.view.cyclecalenderlu.CycleCalenderContainer"
	},{
		menuId : "condilu",
		controller : "eRecon_web.controller.CondiLuController",
		view : "eRecon_web.view.condilu.CondiLuContainer"
	},
	{
		menuId : "broadcastmessageedit",
		controller : "eRecon_web.controller.BroadcastEditMessageController",
		view : "eRecon_web.view.broadCastMessageEdit.BroadCastMessageEditor"
	},
	{
		menuId : "sectorlobmapping",
		controller : "eRecon_web.controller.SectorLobController",
		view : "eRecon_web.view.sectorLobMapping.SectorLobMappingContainer"
		
	},
	{
		menuId : "adminopenclosecycle",
		controller : "eRecon_web.controller.AdminOpenCloseCycleController",
		view : "eRecon_web.view.adminOpenClose.AdminOpenCloseContainer"
	},
	{
		menuId : "feedload",
		controller : "eRecon_web.controller.FeedLoadController",
		view : "eRecon_web.view.feedLoad.feedLoadContainer"
	},
	{
		menuId : "glfeedcalennder",
		controller : "eRecon_web.controller.FeedCalenderController",
		view : "eRecon_web.view.glfeedCalender.GLFeedCalenderContainer"
	},
	{
		menuId : "feedloadtemplate",
		controller : "eRecon_web.controller.FeedLoadTemplateController",
		view : "eRecon_web.view.feedLoadTemplate.FeedLoadTemplateContainer"
	},
	{
		menuId : "linkslu",
		controller : "eRecon_web.controller.LinksLuController",
		view : "eRecon_web.view.linkslu.LinksLuContainer"
	},
	{
		menuId : "arcdashboard",
		controller : "eRecon_web.controller.DashboardController",
		view : "eRecon_web.view.dashboard.DashboardContainer"
	},
	{
		menuId : "strategicsite",	
		controller : "eRecon_web.controller.Dashboard2Controller",
		view : "eRecon_web.view.dashboard2.Dashboard2Container"
	},
	{
		menuId: "bssmetrics", 
	    controller: "eRecon_web.controller.CentralizedSiteMapController",
	    view: "eRecon_web.view.CentralizedSiteMap.CentralizedSiteMapContainer"
    },
    {
    	menuId:"metricsdashboard",
    	controller:"eRecon_web.controller.LegalVehicles",
    	view:"eRecon_web.view.lvsummaryreports.TabPanel"
    },
    {
    	menuId:"kpi",
    	controller:"eRecon_web.controller.KPI",
    	view:"eRecon_web.view.kpi.Panel"
    }
	
],
loadDashboard:"0",
init: function () {
	 	var me = this;
	 	me.getStore("eRecon_web.store.CountriesStore").load();
	 	me.getStore("eRecon_web.store.CurrenciesStore").load();
	 	me.startActivityMonitor();
        me.control({
        	"navigation_contentcards": {
        		boxready: function() {
        		
        		console.log('In main controller');
        			var isDashboardUserFlag= false;
        			var isBOUser=false;
        			Ext.util.Cookies.clear('Dashboard_Viewer');
        			Ext.util.Cookies.clear('Dashboard_User');
        			Ext.util.Cookies.clear('Governance_Dashboard_User');
        			Ext.util.Cookies.clear('Governance_Dashboard_Viewer');
        			 Ext.util.Cookies.clear('isDashboardUserFlag');
        			 Ext.util.Cookies.clear('eRecon_support');
        			eRecon_web.direct.action.LegalVehicleService.getAllUserRolesNew( function(p,response){
        				var result= response.result;
        				if(result!=null){
        				for(var i=0; i<result.length;i++){
        				
        					//if(result[i].active=='Yes'){
        						 if((result[i].role).trim()=='DASHBOARD USER'){
        							Ext.util.Cookies.set('Dashboard_User',true);
        							 isDashboardUserFlag=true;
        						}else if((result[i].role).trim()=='DASHBOARD VIEWER'){
        							Ext.util.Cookies.set('Dashboard_Viewer',true);
        							 isDashboardUserFlag=true;
        						}else if((result[i].role).trim()=='GOVERNANCE DASHBOARD USER'){
        						    Ext.util.Cookies.set('Governance_Dashboard_User',true);
        						    isDashboardUserFlag=true;
        						}else if((result[i].role).trim()=='GOVERNANCE DASHBOARD VIEWER'){
        						Ext.util.Cookies.set('Governance_Dashboard_Viewer',true);
        						 isDashboardUserFlag=true;
        						}else if((result[i].role).trim()=='eRecon Support'){
        						Ext.util.Cookies.set('eRecon_support',true);
        						}else if((result[i].role).trim()=='BOUser'){
        							isBOUser=true;
        						}
        						
        						 
        					}
        				if(isDashboardUserFlag)Ext.util.Cookies.set('isDashboardUserFlag',true);
        				
        				if(isBOUser||isDashboardUserFlag){

var t=Ext.ComponentQuery.query("button[action=loginSync]")[0];
    	 t.setIconCls('iconLoading');
    	  t.setTooltip(" Syncing entitlements is in progress");  
    	 eRecon_web.direct.action.LegalVehicleService.doEntRefresh( function(p,response){
         	  
     	      if(response.result!=null && response.result=="Succcess"){
     	    	 // t.update({iconCls:'iconAccept'});//<Object
     	    	  t.setIconCls('iconAccept');
     	    	  t.setTooltip("Entitlements in Sync");
     	      }else{
     	    	  t.setIconCls('iconCancel');
     	    	  t.setTooltip("Error Syncing entitlements, kindly eRecon contact Operations Support");  
     	      }
     	      //Ext.create("eRecon_web.view.Viewport");
     	    //  Ext.get('initial-loading-div').remove();
     			//Ext.get('initial-header').remove();
     	    	//Ext.get('initial-loading-mask').remove();
     		});
     	      
        				
        				}
        					}
        				//}
        				if(isDashboardUserFlag){
        					me.loadDashboard="1";
        			        			me.activateCard({view: "eRecon_web.view.lvsummaryreports.TabPanel"});
        			        			
        			        			}else{
        			        				me.activateCard({view: "eRecon_web.view.homeview.HomeView"});
        			        			}
        					});

        	}
        	},
        
            // TODO: Create subclass for menuitem and button so we specifically
            // listen for navigation items and not all menuitems/buttons
            "navigation_menuitem, navigation_menubutton[card=home],navigation_menubutton[card=bssmetrics] ": {
                "click": me.handleMenuItemClick
            },
            /*"navigation_menubutton": {
             "click": me.handleMenuItemClick
             },*/
            "navigation_menuitem[action='logout']": {
                "click": me.logout
            },
            "navigation_menuitem[card='Password Reset']": {
                "click": me.passwordRedirect
            }
            
        });
    },
    logout: function () {
        console.log("logout");

		var p = Ext.widget(
		{
			xtype: 'window', 
			x: 0,  y:0, 
			width: '100%', height: '100%', 
			modal: true, 
			header: false,
			items: [
			   {
				   xtype: 'label',
				   text: 'Logged Out'
			   }
			]
		});
		p.show();
				
        Ext.Ajax.request({
        	   url: 'LogoutServlet',
        	   callback: function(opts, success, response) {
        		   console.log("callback");
		           
        		   if (success) {
            		   var result = Ext.JSON.decode(response.responseText);
            		   location.href = result.redirectUrl;
        		   }
        		   else {
             	      Ext.Msg.show({
             	    	  title: 'Server-side failure',
             	    	  msg: 'Status Code: ' + response.status,
             	    	  modal: true,
             	    	  closable: false
             	      });
        		   }
        		   
        		 //Remove the cookie regardless of call success
        		 Ext.util.Cookies.set("SMSESSION", '', new Date(), '/', '.ssmb.com', true);
        	   }
        	});
    },
    
    passwordRedirect:function(){
    	window.location = '/../siteminderagent/forms/smpwservices.fcc?SMAUTHREASON=34&TARGET=/erecon/Content/WelcomeLogin.aspx'; //the location you want your browser to be  redirected.
    },

    handleMenuItemClick: function (item_, e_) {
    	var me = this;
    	Ext.each(me.pageArr, function(obj){
    		if (obj.menuId == item_.card) {
    			me.activateCard(obj);
    		}
    	});
        
        
        /**
		* Unable to figure out a way to disable activate
		* Listener for this screen. Having this until we 
		* find a good solution.
		*/
        if(item_.card === 'jobstatus') {
        	me.getController('eRecon_web.controller.JobStatusController').loadJobStatuses();
        }
    },
    
    activateCard: function(pageDefinitionObj, callback) {
console.log('activateCard');	
		var me = this;
		if (!pageDefinitionObj) {
			return;
		}
		if (!pageDefinitionObj.menuId) { // this means it is called from some other controller
			Ext.each(me.pageArr, function(item) {
				for (var prop in pageDefinitionObj) {
					if (item[prop] != pageDefinitionObj[prop]) {
						return;
					}
				}
				pageDefinitionObj = item;
				return false;
			});
		}
		var contentCards = me.getContentCards();
		contentCards.setLoading(true);
		Ext.defer(function() {
			try {
				var card = null;
				var xtype = pageDefinitionObj.xtype;
				if (xtype) {
					card = contentCards.down(xtype); 
				}
				if (pageDefinitionObj.controller) {
			    	var contr = me.getController(pageDefinitionObj.controller);
			    	if (!contr.wasInit) {
				    	contr.init();
				    	contr.wasInit = true;
				    	if(me.loadDashboard=="1"){me.loadDashboard="2";}
			    	}
		    	}
				if (!card) {
			    	card = Ext.create(pageDefinitionObj.view);
			    	pageDefinitionObj.xtype = card.getXType();
			    	contentCards.add(card);
				}
				else {
					card.fireEvent('refresh_data', card);
				}
		
			    me.getContentCards().getLayout().setActiveItem(card);
			    contentCards.doLayout();
			    if(me.loadDashboard=="2"){
			    	contr.getLvTabs().setActiveTab(1);
			    	contr.getLvTabs().setLoading(true);
			    	 Ext.Ajax.request({
			             url: eRecon_web.gbl.constants.CHECK_USER_CRED_URL, 
			             	scope: this, 
			             	success: function (resp_) {
			             		contr.getLvTabs().setLoading(false);
			             		var response = Ext.JSON.decode(resp_.responseText);
			             		if(response.status != "Failure") {
			             			if(!response.showAgreeDisagreePage) {
			             				var monthYearCombo=Ext.ComponentQuery.query("combo#lvreconperiodfld")[0];
			         					monthYearCombo.setValue(response.currentReconPeriod);
			         					//monthYearCombo.fireEvent("select");
			             			}}
			             		
			             		}   });
			    	

			    	
			    	me.loadDashboard="0";
			   // var runReportsBtn=contr.getRunKPIReportBtn();
		    	//if(runReportsBtn!=null){runReportsBtn.fireEvent('click');me.loadDashboard="0";}
		    	}
			    if (callback) {
			    	callback();
			    }
		    }
			finally {
				contentCards.setLoading(false);
			}
		},25,me);
    },
    
    startActivityMonitor: function() {
    	var me = this;
		Ext.Ajax.request({
			url: 'userSessionInfo?pingType=PING_UPDATE_SESSION',
			method:'POST', 
			scope : this,
			success : function(response, opts) {
				response = Ext.decode(response.responseText);
				if(response.success && response.sessionInterval){
					me.startActivityMonitor1(response.sessionInterval);
				}
				else {
					Ext.MessageBox.alert('Failed', response.message);
				}
			},
			failure : function(err) {
			}
		}); 	
    },
    
    startActivityMonitor1: function(maxInactivity) {
    	var me = this;
    	var warningDurationSeconds = 120;
    	if (maxInactivity < warningDurationSeconds) {
    		return;
    	}
    	var interv = maxInactivity - warningDurationSeconds;
		Ext.ux.ActivityMonitor.init({ 
			verbose : true, 
			interval: 1000*interv,
			maxInactive: 1000*(interv-5), 
			isActive: function() {
			// Prolong the session so it will not terminate during
				 Ext.Ajax.request({
						url: 'userSessionInfo?pingType=PING_UPDATE_SESSION',
						method:'POST'
					 });
			},
			isInactive: function() {
			// First, make sure to prolong the session so it will not terminate during
				 Ext.Ajax.request({
					url: 'userSessionInfo?pingType=PING_UPDATE_SESSION',
					method:'POST'
				 });
				 var warningDuration = 1000 * warningDurationSeconds;
				 var remainder = warningDuration + 1000;
				 function pad(num, size) {
					 var s = num+"";
					 while (s.length < size) s = "0" + s;
					 return s;
				 }
				 function updateTime() {
					 remainder -= 1000;
					 var minute = Math.floor(remainder / 60000);
					 var second = (remainder % 60000) / 1000;
					 var tm = pad(minute,2) + ':' + pad(second,2); 
					 var p = remainder / warningDuration;
					 if (p <= 0) {
						 task.destroy();
						 dlg.close();
						 Ext.ux.ActivityMonitor.stop();
						 me.logout();
					 }
					 dlg.updateProgress(p,tm,'Due to inactivity the session will terminate. To continue working please click the OK button');	 
				 }
				 var task = Ext.TaskManager.newTask({
				     interval: 1000,
				     run: updateTime
				 });
				var dlg = Ext.Msg.show({
					width: 300,
	                title: 'Warning',
	                msg: '_',
	                progress: true,
	                buttons: Ext.Msg.OK,
	                closable: false,
	                fn: function() {
						task.destroy();
						me.startActivityMonitor();
					}
				}); 
				updateTime();
				task.start();
			} 
		});
		Ext.ux.ActivityMonitor.start();
    },
    
    showStatus: function(msg, wait_interval) {
    	if (!wait_interval) {
    		wait_interval = 60000; //1 minute
    	}
		var cmp = Ext.getCmp('my-status')
		if (cmp) {
			cmp.setStatus({
			    text: '<p class="statusbar-success">'+msg+'</p>',
			    iconCls: 'iconAccept',
			    /*clear: false,*/
			    clear: {
			        wait: wait_interval,
			        anim: true,
			        useDefaults: false
			    }
			}); 
		}
    }

});

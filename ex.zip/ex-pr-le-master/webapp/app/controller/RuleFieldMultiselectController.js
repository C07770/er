Ext.define('eRecon_web.controller.RuleFieldMultiselectController', {
	extend: 'Ext.app.Controller',
	constructor: (function() {
		var wasInit = false;
		return function() {
			this.callParent(arguments);
			if (!wasInit) {
				this.init();
			}
		}
	})(),
	init: function(){
		var me = this;
		me.control({
			'rulesmaintenance_rulefieldmultiselectpopup button[searchId=up], rulesmaintenance_rulefieldmultiselectpopup button[searchId=down]': {
				click: function(btn) {
					var grid = btn.up("window").down("grid");
					var selectedRecords = grid.getSelectionModel().getSelection();
					if (selectedRecords.length != 1) {
						Ext.Msg.alert("", "Please select one record");
						return;
					}
					var selectedRecord = selectedRecords[0];
					var arr = grid.store.getRange();
					var idx = Ext.Array.indexOf(arr, selectedRecord);
					var idx1;
					if (btn.searchId == 'up') {
						idx1 = idx - 1;
					}
					else {
						idx1 = idx + 1;
					}
					if (idx1 < 0 || idx1 > arr.length - 1) {
						return;
					}
					var a = arr[idx1];
					arr[idx1] = arr[idx];
					arr[idx] = a;
					grid.store.loadData(arr);	
				}
			},
			
			'rulesmaintenance_rulefieldmultiselectpopup button[searchId=delete]': {
				click: function(btn) {
					var grid = btn.up("window").down("grid");
					var selectedRecords = grid.getSelectionModel().getSelection();
					if (selectedRecords.length == 0) {
						return;
					}
					Ext.Array.each(selectedRecords, function(rec){
						grid.store.remove(rec);
					});
				}
			},

			'rulesmaintenance_rulefieldmultiselectpopup button[searchId=clear]': {
				click: function(btn) {
					var grid = btn.up("window").down("grid");
					grid.store.removeAll();
				}
			},

			'rulesmaintenance_rulefieldmultiselectpopup button[searchId=add]': {
				click: function(btn) {
					var textBox = btn.up("window").down("combo");
					var popup = btn.up("window");
					var val;
					var fieldName= popup.fieldName;
					var geoCode =popup.geocode;
					if (me.isReferenceTableField(fieldName)) {
						val = textBox.rawValue;	
					}
					else {
						val = textBox.value;
					}
					if (!val) {
						if (me.isReferenceTableField(fieldName)) {
							Ext.Msg.alert('Warning','Please enter valid value in the textbox');
							return;
						}
						else {
							Ext.Msg.alert('Warning','Please select valid value from the drop down');
							return;
						}
					}
					val = val.toUpperCase();
					var store = btn.up("window").down("grid").getStore();
					if (store.find('val',val) >= 0) {
						Ext.Msg.alert("", "The value is already selected");
						return;
					}
					if (me.isReferenceTableField(fieldName)) {
						popup.setLoading('Checking Value. Please wait.');
						eRecon_web.direct.action.RulesMaintenanceService.checkReferenceValues(fieldName,geoCode,val, function(p, response) {
							    popup.setLoading(false);
					            if(response.result== 1) {
					            	store.add({val: val});	
					            	textBox.setValue("");
					        	}else if(response.result== 0){
					        		Ext.Msg.alert("", "Please enter valid value in the textbox");
					    		}else{
					    			Ext.Msg.alert("", "Operation Failed");
					    		}
					    });
					}else{
						store.add({val: val});	
						textBox.setValue("");
					}
				}
			},
			
			'rulesmaintenance_rulefieldmultiselectpopup button[searchId=apply]': {
				click: function(btn) {
					var popup = btn.up("window");
					var store = btn.up("window").down("grid").getStore();
					var arr1 = [];
					function valInLastParenthesis(s) {
						if (s.charAt(s.length - 1) == ')') {
							for (var i = s.length - 2; i >= 0; i--) {
								if (s.charAt(i) == '(') {
									return s.slice(i+1, -1);
								}
							}
						}
						return s;
					}
					store.each(function(rec){
						if (popup.fieldName == 'source') {
							var val = rec.get('val');
							var idx = val.indexOf('(');
							if (idx >= 0) {
								val = Ext.String.trim(val.substr(0,idx));
							}
							arr1.push(val);
							
						}
						else if (popup.fieldName != 'ctryCode' && popup.fieldName != 'ccyCode') {
							arr1.push(rec.get('val'));
						}
						else {
							arr1.push(valInLastParenthesis(rec.get('val')));
						}
					});
					popup.triggerField.setValue(arr1.join(","));
					popup.close();
				}
			}
			
			, 'rulesmaintenance_rulefieldmultiselectpopup combo': {
				beforequery: {
					fn: function(q) {
						var combo = q.combo;
						var w = combo.up('window');
						var fieldName = w.fieldName;
						if (me.isReferenceTableField(fieldName)) {
							return;
						}
						var geocode = w.geocode;
						var store = combo.store;
						var recalcTotal = false;
						var queryStr = q.query.toUpperCase();
						if (store.directOptions && store.directOptions.valStartsWith != queryStr) {
							store.currentPage = 1;
							recalcTotal = true;
						}
						store.directOptions = {fieldName: fieldName, geocode: geocode, valStartsWith: queryStr, recalcTotal: recalcTotal};
						if (fieldName != 'ctryCode' && fieldName != 'ccyCode') {
							store.load({
								callback: function() {
									if (store.getCount() > 0) {
										combo.expand();
										combo.onTypeAhead();
									}
								}
							});
						}
					},
					buffer: 700
				}
			}


		});
	},
	
	showMultiselectPopup: function(triggerField) {
		var me = this;
		if (me.isReferenceTableField(triggerField.name)) {
		    me.showMultiselectPopup1(triggerField);
		}
		else if (!me.dropdownPageSize) {
			eRecon_web.direct.action.RulesMaintenanceService.getDropdownPageSize(function(rslt,e) {
				me.dropdownPageSize = rslt;
				me.showMultiselectPopup1(triggerField);
			});
		}
		else {
			me.showMultiselectPopup1(triggerField);
		}
	},

	showMultiselectPopup1: function(triggerField) {
		var me = this;
		var lblFld = triggerField.up('window').down('*[searchId=' + triggerField.name + 'Label]');
		var descr = lblFld.getValue();
		var descrStyle = lblFld.fieldStyle;
		var geocode = triggerField.up('window').down('*[name=geocode]').getValue();
		var popup = Ext.create('eRecon_web.view.rulesmaintenance.RuleFieldMultiselectPopup');

		try {
			var combo = popup.down('combo');
			combo.store.removeAll();
			combo.store.directOptions = {}; 
			if (me.isReferenceTableField(triggerField.name)) {
				combo.store.pageSize = 0;
				combo.pageSize = 0;
				combo.setHideTrigger(true);
			}
			else {
				combo.store.currentPage = 1;
				combo.store.pageSize = me.dropdownPageSize;
				combo.pageSize = me.dropdownPageSize;
			}
		}
		catch(e) {}
		
		function arrangeDescription(rec, codeFieldName, descFieldName) {
			var desc = rec.get(descFieldName);
			if (desc && desc.toUpperCase() != 'NULL' && desc.toUpperCase() != '(NULL)') {
				return desc +' (' + rec.get(codeFieldName) + ')';
			}
			else {
				return rec.get(codeFieldName);
			}
		}
		
		if (triggerField.name == 'ctryCode') {
//			combo.matchFieldWidth=false;
//			combo.listConfig={width: 250};
			combo.typeAhead = true;
			combo.pageSize=0;
			countriesStore = me.getStore('eRecon_web.store.CountriesStore');
			var recArr = [];
			for (var i = 0; i < countriesStore.getCount(); i++) {
				var rec = countriesStore.getAt(i);
				if (geocode == 'ALL' || geocode == rec.get('geocode')) {
				   var mdl = combo.store.model.create();
				   mdl.set('val', arrangeDescription(rec,'countryCode','countryDesc'));
				   recArr.push(mdl)	  
				}
			}
			combo.store.loadRecords(recArr);
		}
		else if (triggerField.name == 'ccyCode') {
//			combo.matchFieldWidth=false;
//			combo.listConfig={width: 250};
			combo.typeAhead = true;
			combo.pageSize=0;
			currenciesStore = me.getStore('eRecon_web.store.CurrenciesStore');
			var recArr = [];
			for (var i = 0; i < currenciesStore.getCount(); i++) {
				var rec = currenciesStore.getAt(i);
 			    var mdl = combo.store.model.create();
// commenting b/c ops don't want description	 
 			    //mdl.set('val', arrangeDescription(rec,'currencyCode','currencyDesc'));
 			    mdl.set('val', arrangeDescription(rec,'currencyCode',''));
				recArr.push(mdl)	  
			}
			combo.store.loadRecords(recArr);
		}
		popup.fieldName = triggerField.name;
		popup.triggerField = triggerField;
		popup.geocode = geocode;
		popup.down('*[searchId=description]').setValue(descr);
		popup.down('*[searchId=description]').setFieldStyle(descrStyle);
		var valStr = Ext.String.trim(triggerField.getValue());
		var arr1 = [];
		if (valStr > "") {
			var arr = triggerField.getValue().split(",");
			arr1 = Ext.Array.map(arr, function(item) {
				if (triggerField.name == 'ctryCode') {
					var idx = countriesStore.findExact('countryCode', item);
					if (idx >= 0) {
						item = arrangeDescription(countriesStore.getAt(idx),'countryCode','countryDesc'); 
					}
				}
				else if (triggerField.name == 'ccyCode') {
					var idx = currenciesStore.findExact('currencyCode', item);
					if (idx >= 0) {
						item = arrangeDescription(currenciesStore.getAt(idx),'currencyCode','currencyDesc'); 
					}
				}
				return [item];
			});
		}
		if (triggerField.name == 'source' && arr1.length > 0) {
			triggerField.up('window').setLoading(true);
			var arr2 = Ext.Array.map(arr1, function(item) {
				return item[0];
			});
			eRecon_web.direct.action.RulesMaintenanceService.addGLSysIdDescription(arr2, function(dummy,rtnObj) {
				arr1 = Ext.Array.map(rtnObj.result, function(item) {
					return [item];
				});
				triggerField.up('window').setLoading(false);
				me.showMultiselectPopup2(popup,arr1);
			});
		}
		else {
			me.showMultiselectPopup2(popup,arr1);
		}
	},

	showMultiselectPopup2: function(popup, arr1) {
		var store = Ext.create('Ext.data.ArrayStore', 
			{
				fields: ['val'],
				data: arr1
			}
		);
		popup.down('grid').reconfigure(store);
		popup.show();
	},

	isReferenceTableField: function(fieldName) {
		return (fieldName != 'ccyCode' && fieldName != 'ctryCode' && fieldName != 'condi' && fieldName != 'source');
	}
	
	
	
});




Ext.define('eRecon_web.controller.AgingController', {
    extend: 'Ext.app.Controller',
    stores:['eRecon_web.store.SubledgerDetailStore','eRecon_web.store.BankingGroupStore'],
    refs: [
        {
            ref: 'balanceTab',
            selector: 'balanceagaing_container'
        },
        {
            ref: 'reconTab',
            selector: 'reconbreakagaing_container'
        },
        {
            ref: "riskamountTab",
            selector: "amountatrisk_container"
        },
        {
        	ref:'agingContainer',
        	selector:'aging_tabcontainer'
        },
        {
        	ref:'customWindow',
        	selector:'custom_dialog'
        },
        {
        	ref : 'summaryPanel',
            selector: 'subledger_summarygrid'
        },
        {
            ref: "filterPanel",
            selector: "subledger_filterform"
        }

    ],

    init: function () {
		var me = this;
        this.control(
        		{       			
        		
                'aging_tabcontainer button[action=submit]': {
                	click: {
	            		fn: this.agingsubmit,
	            		delay: 200  // to give time to apply the blur event of qty buckets
	        		}
                },
                'aging_tabcontainer button[action=cancel]': {
                    click: this.agingCancel
                },
                'aging_tabcontainer': {
                	afterrender: this.onLoad
                },
                
                'balanceagaing_container numberfield[changeTag=gl_dr_total]':{
                	change: {
                		fn: me.calculateDRGLTotalRedAmount,
                		buffer:500
                	}
                },
                'balanceagaing_container numberfield[changeTag=gl_cr_total]':{
                	change: {
                		fn: me.calculateCRGLTotalRedAmount,
                		buffer:500
                	}
                },
                'balanceagaing_container numberfield[changeTag=gl_dr]':{
                	change: {
                		fn: me.calculateDRGLSystemRedAmount,
                		buffer:500
                	}
                },
                'balanceagaing_container numberfield[changeTag=gl_cr]':{
                	change: {
                		fn: me.calculateCRGLSystemRedAmount,
                		buffer:500
                	}
                },
                
                'reconbreakagaing_container field[customFormat=true], balanceagaing_container field[customFormat=true]':{
					change: function(field) { 
						me.customFormat(field);
					}	
                },

                'reconbreakagaing_container numberfield[changeTag=sl_dr_total]':{
                	change: {
                		fn: me.calculateDRSLTotalRedAmount,
                		buffer:500
                	}	
                },
                'reconbreakagaing_container numberfield[changeTag=sl_cr_total]':{
                	change: {
                		fn: me.calculateCRSLTotalRedAmount,
                		buffer:500
                	}	
                },
                'reconbreakagaing_container numberfield[changeTag=sl_dr]':{
                	change: {
                		fn: me.calculateDRSLSystemRedAmount,
                		buffer:500
                	}	
                },
                'reconbreakagaing_container numberfield[changeTag=sl_cr]':{
                	change: {
                		fn: me.calculateCRSLSystemRedAmount,
                		buffer:500
                	}	
                },
                
                'amountatrisk_container numberfield[action=specificamtatriskdr_onChange]':{
                	change:this.calculateDRRptlAmount
                },
                'amountatrisk_container numberfield[action=specificamtatriskcr_onChange]':{
                	change:this.calculateCRRptlAmount
                },
                'amountatrisk_container checkbox[action=checkboxChange]':{
                	change:this.handleOnCheck
                }
                
            });
    },
    agingType :'',
	acctagingType: '',
	glControlTotal:0,
	slControlTotal:0,
	glBalance:'',
	slBalance:'',
	autorecontype:'',
	manualrecontype:'',
	agingBenchmark:'',
	account_id:'',
	recon_period:'',
	fullKey:'',
	statusIndicator:'',
	benchmarkViolation:'',
	lcl_ccy_threshold:'',
	sl_benchmark_dr:0,
    sl_benchmark_cr:0,
    sl_amt_abovebm_dr:0,
    sl_amt_abovebm_cr:0,
    sl_qty_abovebm_dr:0,
    sl_qty_abovebm_cr:0,
    comments:'',
    
    //Submit Action 
	//Check for All the Validations  and Submit the values 
    agingsubmit :function(){    	
    	var me=this;
    	var agingContainer = me.getAgingContainer();
    	var invalidField = agingContainer.down('numberfield:not({isValid()})');
    	if (invalidField) {
            Ext.Msg.show({
                title: "Error",
                msg: "Some input fields contain invalid data. Please fix before submission.",
                buttons: Ext.Msg.OK,
                icon: Ext.Msg.ERROR
            });
            return false;
    	}
    	

    	var validation  = true;
    	validation=this.bucketvalidation();
    	if(!validation){
    		return false;
    	}
    	validation=this.controltotalvalidation();
    	if(!validation){
    		return false;
    	}
    	validation = this.amountatriskvalidation();
    	if(!validation){
    		return false;
    	}
    	validation=this.redamountvalidation(); 
    	if(!validation){
    		return false;
    	}
    	var store = this.getStore('eRecon_web.store.SubledgerDetailStore');
    	var customWindow=this.getCustomWindow();
    	var balanceAging=this.getBalanceTab();
    	var reconAging=this.getReconTab();
    	var amountatrisk=this.getRiskamountTab();
    	amountatrisk.down("#AMT_AT_RISK_TYPE_DR_HIDDEN").setValue(amountatrisk.down("#AMT_AT_RISK_TYPE_DR").getSubmitValue());
    	amountatrisk.down("#AMT_AT_RISK_TYPE_CR_HIDDEN").setValue(amountatrisk.down("#AMT_AT_RISK_TYPE_CR").getSubmitValue());
    	var agingData=balanceAging.getForm().getValues();
    	var reconData=reconAging.getForm().getValues();
    	var amountatriskData= amountatrisk.getForm().getValues();
    	var summaryPanel = this.getSummaryPanel();
		var summaryPanelSelectedRecord = summaryPanel.getView().getSelectionModel().getSelection();
		var summaryPanelStore = this.getStore('eRecon_web.store.BankingGroupStore');
		var rowIndex = summaryPanelSelectedRecord[0].index;
		var filterPanel = this.getFilterPanel();
  		var fullKey = filterPanel.down("#fullKey-text").getValue();
  		var managerId = filterPanel.down("#mgrId-combo").getValue();
  		var filter = filterPanel.down("#fiter-combo").getValue();
  		var sortBy = filterPanel.down("#sortBy-combo").getValue();
  		var condi = filterPanel.down("#condi-text").getValue();
  		var description = filterPanel.down("#description-text").getValue();
  		var detailsStore = this.getStore('eRecon_web.store.SubledgerDetailStore');
    	if (this.agingType=='G') {
	    	var formData={
	    		"agingData":agingData,
	    		"reconAgingData":reconData,
	    		"amountatriskData":amountatriskData              
	    	
	    	};
	    	var encodedArray = Ext.encode(formData);
	    	eRecon_web.direct.action.SubledgerService.saveAgingDetails(encodedArray, function(p, response) {
	    		if(response.result == "Success") {
	    			customWindow.close();
	    			summaryPanelStore.load({
	                    callback : function(r, options, success) {
	                        summaryPanel.getView().getSelectionModel().select(rowIndex, false, true);
	                        detailsStore.directOptions = {};
	                  		detailsStore.getProxy().extraParams = {
	                  		     0: summaryPanel.store.getAt(rowIndex).data['bankingGroup'],
	                  		     1: summaryPanel.store.getAt(rowIndex).data['reconPeriod'],
	                  		     2: fullKey,
	                  		     3: managerId,
	                  		     4: filter,
	                  		     5: sortBy,
	                  		     6: description,
	                  		     7: condi,
	                  		     8: null, // no Submitted only
	                  		     9: summaryPanel.store.getAt(rowIndex).data['accounts'],
	                  		     10: summaryPanel.store.getAt(rowIndex).data['submittedAccounts'],
	                  		     11: summaryPanel.store.getAt(rowIndex).data['unSubmittedAccounts']
	                  		 };
	                  		detailsStore.load({
	                            callback: function (records, operation, success) {
	                            }
	                        });
	                    }
					});
	    		}
	    		me.getController('MainController').showStatus('Successfully submitted the record.');
	    	});
        }
        else {
        	var slFormData={
        		"agingData":null,
        		"reconAgingData":reconData,
        		"amountatriskData":amountatriskData              
        	
        	};
        	var slencodedArray = Ext.encode(slFormData);
        	eRecon_web.direct.action.SubledgerService.saveAgingDetails(slencodedArray, function(p, response) {
        		if(response.result == "Success") {
        			customWindow.close();
        			summaryPanelStore.load({
                        callback : function(r, options, success) {
                            summaryPanel.getView().getSelectionModel().select(rowIndex, false, true);
                            detailsStore.directOptions = {};
                      		detailsStore.getProxy().extraParams = {
                      		     0: summaryPanel.store.getAt(rowIndex).data['bankingGroup'],
                      		     1: summaryPanel.store.getAt(rowIndex).data['reconPeriod'],
                      		     2: fullKey,
                      		     3: managerId,
                      		     4: filter,
                      		     5: sortBy,
                      		     6: description,
                      		     7: condi,
                      		     8: null, // no Submitted only
                      		     9: summaryPanel.store.getAt(rowIndex).data['accounts'],
                      		     10: summaryPanel.store.getAt(rowIndex).data['submittedAccounts'],
                      		     11: summaryPanel.store.getAt(rowIndex).data['unSubmittedAccounts']
                      		 };
                      		detailsStore.load({
                                callback: function (records, operation, success) {
                                }
                            });
                        }
    				});
        		}
        		me.getController('MainController').showStatus('Successfully submitted the record.');
        	});      
       }
 },
    agingCancel : function(){
    	var customWindow=this.getCustomWindow();
    	customWindow.close();
},
   //AfterRender Function .
   onLoad : function(){	
	   //Fix to clear previous values of BMV
	    this.sl_benchmark_dr = 0;
	    this.sl_benchmark_cr = 0;
	    this.sl_amt_abovebm_dr = 0;
	    this.sl_amt_abovebm_cr = 0;
	    this.sl_qty_abovebm_dr = 0;
	    this.sl_qty_abovebm_cr = 0;
	    
		this.getParamValues();
		if(this.agingType=='S'){
			this.hideGLTab();
		}
		this.setFieldValues();		
},

// Get the Values from the Parent tab (SubledgerInit Page)
	getParamValues : function(){		
		var getParameters = Ext.getCmp("AgingDetails");
		this.agingType = getParameters.extraParams.AgingType;
		this.glBalance=parseFloat(getParameters.extraParams.GLBalance).toFixed(2);
		this.slBalance=parseFloat(getParameters.extraParams.SLBalance).toFixed(2);
		this.fullKey=getParameters.extraParams.FullKey;
		this.autorecontype=getParameters.extraParams.AutoReconType;
		this.manualrecontype=getParameters.extraParams.ManualReconType;
		this.account_id=getParameters.extraParams.AccountId;
		this.agingBenchmark=getParameters.extraParams.AgingBenchMark;
		this.recon_period=getParameters.extraParams.Reconperiod;
		this.benchmarkViolation=getParameters.extraParams.BenchMarkViolation;
		this.statusIndicator=getParameters.extraParams.StatusIndicator;
		this.lcl_ccy_threshold=getParameters.extraParams.LCL_CCY_Threshold;
		this.comments=getParameters.extraParams.Comments;
		
},

//Hide GL Tab for S type Record.

	hideGLTab : function(){
		var mytab= this.getAgingContainer();
        mytab.child('balanceagaing_container').hide();
        mytab.down('#balanceaging').tab.hide();
        mytab.child('reconbreakagaing_container').show();
},
//Set Fullkey ,ControlTotal,glBalance,slBalance values in the form.
	setFieldValues : function(){		
		//Balance Aging Tab
		var balanceAging=this.getBalanceTab();
		//Recon Aging Tab
		var reconAging=this.getReconTab();
		if(this.agingType=='G'){
		balanceAging.down("#GL_SLBALANCE").setValue(this.slBalance);	
		balanceAging.down("#GL_GLBALANCE").setValue(this.glBalance);
		balanceAging.down("#GL_FULLKEY").setValue(this.fullKey);
		balanceAging.down("#GL_CONTROLTOTAL").setValue(this.slBalance);
		this.glControlTotal=this.slBalance;
		balanceAging.down("#GL_GLBALANCE_HIDDEN").setValue(this.glBalance);	
		balanceAging.down("#GL_SLBALANCE_HIDDEN").setValue(this.slBalance);
		balanceAging.down("#GL_CONTROLTOTAL_HIDDEN").setValue(this.slBalance);
		balanceAging.down("#GL_LCL_CCY_THRESHLD_HIDDEN").setValue(this.lcl_ccy_threshold);
		balanceAging.down("#GL_ACCOUNT_ID").setValue(this.account_id);
		balanceAging.down("#GL_BENCHMARK").setValue('No items aged Over ' + this.agingBenchmark + ' days');
		balanceAging.down("#GL_RECONPERIOD").setValue(this.recon_period); 
		balanceAging.down("#GL_LCL_CCY_THRESHLD").setValue(this.lcl_ccy_threshold);
		balanceAging.down("#GL_STATUSINDICATOR").setFieldStyle('color: green; background-image: none;');
		balanceAging.down("#GL_STATUSINDICATOR").setValue("Green");
		balanceAging.down("#GL_BMKVIOLATION").setValue("No");
		if(this.autorecontype===1){
			balanceAging.down("#GL_RECONTYPE").setValue('A');
		}
		else if(this.manualrecontype===1){
			balanceAging.down("#GL_RECONTYPE").setValue('M');	
		}
		balanceAging.down("#GL_COMMENTS").setValue(this.comments);
		reconAging.down("#SL_SLBALANCE").setValue(this.slBalance);	
		reconAging.down("#SL_GLBALANCE").setValue(this.glBalance);	
		reconAging.down("#SL_FULLKEY").setValue(this.fullKey);
		reconAging.down("#SL_CONTROLTOTAL").setValue(this.glBalance-this.slBalance);
		this.slControlTotal=(this.glBalance-this.slBalance).toFixed(2);
		reconAging.down("#SL_GLBALANCE_HIDDEN").setValue(this.glBalance);	
		reconAging.down("#SL_SLBALANCE_HIDDEN").setValue(this.slBalance);	
		reconAging.down("#SL_CONTROLTOTAL_HIDDEN").setValue(this.glBalance-this.slBalance);
		reconAging.down("#SL_LCL_CCY_THRESHLD_HIDDEN").setValue(this.lcl_ccy_threshold);
		reconAging.down("#SL_ACCOUNT_ID").setValue(this.account_id);
		reconAging.down("#SL_BENCHMARK").setValue('No items aged Over ' + this.agingBenchmark + ' days');
		reconAging.down("#SL_RECONPERIOD").setValue(this.recon_period);
		reconAging.down("#SL_STATUSINDICATOR").setFieldStyle('color: green; background-image: none;');
		reconAging.down("#SL_STATUSINDICATOR").setValue("Green");
		if(this.autorecontype===1){
			reconAging.down("#SL_RECONTYPE").setValue('A');
		}
		else if(this.manualrecontype===1){
			reconAging.down("#SL_RECONTYPE").setValue('M');	
		}
		reconAging.down("#SL_BMKVIOLATION").setValue("No");
		reconAging.down("#SL_LCL_CCY_THRESHLD").setValue(this.lcl_ccy_threshold);
		}
		else{
		reconAging.down("#SL_SLBALANCE").setValue(this.slBalance);	
		reconAging.down("#SL_GLBALANCE").setValue(this.glBalance);	
		reconAging.down("#SL_FULLKEY").setValue(this.fullKey);	
		reconAging.down("#SL_CONTROLTOTAL").setValue(this.glBalance-this.slBalance);
		this.slControlTotal=(this.glBalance-this.slBalance).toFixed(2);
		reconAging.down("#SL_GLBALANCE_HIDDEN").setValue(this.glBalance);	
		reconAging.down("#SL_SLBALANCE_HIDDEN").setValue(this.slBalance);	
		reconAging.down("#SL_CONTROLTOTAL_HIDDEN").setValue(this.glBalance-this.slBalance);
		reconAging.down("#SL_LCL_CCY_THRESHLD_HIDDEN").setValue(this.lcl_ccy_threshold);
		reconAging.down("#SL_ACCOUNT_ID").setValue(this.account_id);
		reconAging.down("#SL_BENCHMARK").setValue('No items aged Over ' + this.agingBenchmark + ' days');
		reconAging.down("#SL_RECONPERIOD").setValue(this.recon_period);
		reconAging.down("#SL_STATUSINDICATOR").setFieldStyle('color: green; background-image: none;');
		reconAging.down("#SL_STATUSINDICATOR").setValue("Green");
		if(this.autorecontype===1){
			reconAging.down("#SL_RECONTYPE").setValue('A');
		}
		else if(this.manualrecontype===1){
			reconAging.down("#SL_RECONTYPE").setValue('M');	
		}
		reconAging.down("#SL_BMKVIOLATION").setValue("No");
		reconAging.down("#SL_LCL_CCY_THRESHLD").setValue(this.lcl_ccy_threshold);
		reconAging.down("#SL_COMMENTS").setValue(this.comments);
		}
},

	 //Calculation : Control Total Calculation;
	 //Aging Type : G - Control Total = SLBALANCE-(DebitAmt-CreditAmt) 
	 //Aging Type : S - Control Total = GLBALANCE-SLBALANCE-(DebitAmt-CreditAmt) 
     calculateControlTotal : function(obj) 
     	{ 
    	
    	var iDebitBucketAmt=0;
    	var iCreditBucketAmt=0;
    	//Balance Tab
    	var balanceAging = this.getBalanceTab();
    	var glSLBalance;
    	//Balance Tab
    	var reconAging= this.getReconTab();
    	var slGLBalance;
    	var slSLBalance;
    	if (this.agingType === "G") {
    		
	    	iDebitBucketAmt = this.getGLDebitBucketAmt();
	    	iCreditBucketAmt = this.getGLCreditBucketAmt();
	    	this.glControlTotal= this.slBalance -(iDebitBucketAmt - Math.abs(iCreditBucketAmt));
	    	this.glControlTotal=this.glControlTotal.toFixed(2);
	    	if(this.glControlTotal==="-0.00"){
	    		this.glControlTotal= 0.00;
	    	}
	    	balanceAging.down("#GL_CONTROLTOTAL").setValue(this.glControlTotal);
    	
    	}
    	iDebitBucketAmt = this.getSLDebitBucketAmt();
    	iCreditBucketAmt =this.getSLCreditBucketAmt();
    	this.slControlTotal= this.glBalance - this.slBalance - (iDebitBucketAmt - Math.abs(iCreditBucketAmt));
    	this.slControlTotal=this.slControlTotal.toFixed(2);
    	if(this.slControlTotal==="-0.00"){
    		this.slControlTotal= 0.00;
    	}
    	reconAging.down("#SL_CONTROLTOTAL").setValue(this.slControlTotal);
    	
     }
    ,
    //Validation : Control Total;
	//Cannot Submit an Account if the control total is not equal to zero.
    controltotalvalidation : function() 
    {
        
        if (this.agingType === "G")
        {
            if ( this.glControlTotal!== "0.00" && this.glControlTotal!==0)
            {       
                Ext.Msg.show({
		                title: "Error",
		                msg: "<b>Account cannot be submitted until the balance aging control total amount has been aged. Please navigate to the Balance Aging Tab and continue to age the amount.</b><br>",
		                buttons: Ext.Msg.OK,
		                icon: Ext.Msg.ERROR
		         });
              
                return false;
               
            }
            else if (this.glControlTotal === "0.00" || this.glControlTotal === 0)
            {
                if (this.slControlTotal!== "0.00"  && this.slControlTotal !== 0)
                {                   
                 	Ext.Msg.show({
	                title: "Error",
	                msg: "<b>Account cannot be submitted until the recon break aging control total amount has been aged. Please navigate to the Recon Break Aging Tab and continue to age the amount.</b><br>",
	                buttons: Ext.Msg.OK,
	                icon: Ext.Msg.ERROR
                     });
              
                    return false;
                }
            }
        }
        else
        {
            if (this.slControlTotal!== "0.00" && this.slControlTotal!== 0)
            {
            	
            	
                 Ext.Msg.show({
		                title: "Error",
		                msg: "<b> Account cannot be submitted until the control total amount has been aged. Please continue to age the amount.</b><br>",
		                buttons: Ext.Msg.OK,
		                icon: Ext.Msg.ERROR
		         });
              
                return false;
            }
        }
        return true;
    }
    ,
    
    //Calculation : To get GL tab Debit Bucket Amount;
    getGLDebitBucketAmt: function()
    {
    	 var iTotal = 0;
    	 
    	 //Balance Aging Tab
    	 var balanceAging=this.getBalanceTab();
    	 var glAMTLTDR=balanceAging.down("#GL_AMT0-7DR").getSubmitValue();
         var glAMT8_30DR=balanceAging.down("#GL_AMT8-30DR").getSubmitValue();
         var glAMT31_60DR=balanceAging.down("#GL_AMT31-60DR").getSubmitValue();
         var glAMT61_90DR=balanceAging.down("#GL_AMT61-90DR").getSubmitValue();
         var glAMT91_120DR=balanceAging.down("#GL_AMT91-120DR").getSubmitValue();
         var glAMT121_150DR=balanceAging.down("#GL_AMT121-150DR").getSubmitValue();
         var glAMT151_180DR=balanceAging.down("#GL_AMT151-180DR").getSubmitValue();
         var glAMTABOVE180DR=balanceAging.down("#GL_AMTABOVE180DR").getSubmitValue();
         var glAMTUNKNOWNDR=balanceAging.down("#GL_AMTUNKNOWNDR").getSubmitValue();
         
         iTotal = Math.abs (glAMTLTDR) +
        		  Math.abs (glAMT8_30DR) +
        		  Math.abs (glAMT31_60DR) +
        		  Math.abs (glAMT61_90DR) +
        		  Math.abs (glAMT91_120DR) +
        		  Math.abs (glAMT121_150DR) +
        		  Math.abs (glAMT151_180DR) +
        		  Math.abs (glAMTABOVE180DR) +
        		  Math.abs (glAMTUNKNOWNDR);
         return parseFloat(iTotal).toFixed(2);
	}
    ,
    
    //Calculation : To get Recon Break Aging Debit Bucket Amount;
    
    getSLDebitBucketAmt: function()
    {
    	 var iTotal = 0;
    	//Recon Aging Tab
    	 var reconAging=this.getReconTab();
    	 var slAMTLTDR=reconAging.down("#SL_AMT0-7DR").getSubmitValue();
         var slAMT8_30DR=reconAging.down("#SL_AMT8-30DR").getSubmitValue();
         var slAMT31_60DR=reconAging.down("#SL_AMT31-60DR").getSubmitValue();
         var slAMT61_90DR=reconAging.down("#SL_AMT61-90DR").getSubmitValue();
         var slAMT91_120DR=reconAging.down("#SL_AMT91-120DR").getSubmitValue();
         var slAMT121_150DR=reconAging.down("#SL_AMT121-150DR").getSubmitValue();
         var slAMT151_180DR=reconAging.down("#SL_AMT151-180DR").getSubmitValue();
         var slAMTABOVE180DR=reconAging.down("#SL_AMTABOVE180DR").getSubmitValue();
         var slAMTUNKNOWNDR=reconAging.down("#SL_AMTUNKNOWNDR").getSubmitValue();
         
         iTotal = Math.abs (slAMTLTDR) +
        		  Math.abs (slAMT8_30DR) +
        		  Math.abs (slAMT31_60DR) +
        		  Math.abs (slAMT61_90DR) +
        		  Math.abs (slAMT91_120DR) +
        		  Math.abs (slAMT121_150DR) +
        		  Math.abs (slAMT151_180DR) +
        		  Math.abs (slAMTABOVE180DR) +
        		  Math.abs (slAMTUNKNOWNDR);
         return parseFloat(iTotal).toFixed(2);
	}
    ,
    //Calculation : To get GL tab Credit Bucket Amount;
    getGLCreditBucketAmt: function()
    {
    	var iTotal = 0;
    	//Balance Aging tab
    	var balanceAging=this.getBalanceTab();
    	
    	var glAMTLTCR=balanceAging.down("#GL_AMT0-7CR").getSubmitValue();
        var glAMT8_30CR=balanceAging.down("#GL_AMT8-30CR").getSubmitValue();
        var glAMT31_60CR=balanceAging.down("#GL_AMT31-60CR").getSubmitValue();
        var glAMT61_90CR=balanceAging.down("#GL_AMT61-90CR").getSubmitValue();
        var glAMT91_120CR=balanceAging.down("#GL_AMT91-120CR").getSubmitValue();
        var glAMT121_150CR=balanceAging.down("#GL_AMT121-150CR").getSubmitValue();
        var glAMT151_180CR=balanceAging.down("#GL_AMT151-180CR").getSubmitValue();
        var glAMTABOVE180CR=balanceAging.down("#GL_AMTABOVE180CR").getSubmitValue();
        var glAMTUNKNOWNCR=balanceAging.down("#GL_AMTUNKNOWNCR").getSubmitValue();
    	
        if (glAMTLTCR > 0)
         {
        	  iTotal=iTotal + parseFloat(glAMTLTCR) * -1;
         }
         else{
        	 iTotal=iTotal + parseFloat(glAMTLTCR);
        
        }
	    if (glAMT8_30CR > 0)
         {
	    	  iTotal=iTotal + parseFloat(glAMT8_30CR) * -1;
         }else{
        	 iTotal=iTotal + parseFloat(glAMT8_30CR);
         
         }
    	 if (glAMT31_60CR > 0)
          {
    		  iTotal=iTotal + parseFloat(glAMT31_60CR) * -1;
          }
          else{
        	  iTotal=iTotal + parseFloat(glAMT31_60CR);
         
         }
   
    	  if (glAMT61_90CR > 0)
    	  {
    		  iTotal=iTotal + parseFloat(glAMT61_90CR) * -1;
    	  }
    	  else{
    		  iTotal=iTotal + parseFloat(glAMT61_90CR);
          
          }
		   if (glAMT91_120CR > 0)
	       {
	      	   iTotal=iTotal + parseFloat(glAMT91_120CR) * -1;
	       }
	       else{
	    	   iTotal=iTotal + parseFloat(glAMT91_120CR);
	       }
	      if (glAMT121_150CR > 0)
	       {
	      	 iTotal=iTotal + parseFloat(glAMT121_150CR) * -1;
	       }
	       else{
	    	   iTotal=iTotal + parseFloat(glAMT121_150CR);
	       }
    	   if (glAMT151_180CR > 0)
           {
          	  iTotal=iTotal + parseFloat(glAMT151_180CR) * -1;
           }
           else{
        	   iTotal=iTotal + parseFloat(glAMT151_180CR);
           }
    	   if (glAMTABOVE180CR > 0)
           {
          	 iTotal=iTotal + parseFloat(glAMTABOVE180CR) * -1;
           }
           else{
        	   iTotal=iTotal + parseFloat(glAMTABOVE180CR);
           }
    	   if (glAMTUNKNOWNCR > 0)
           {
          	 iTotal=iTotal + parseFloat(glAMTUNKNOWNCR) * -1;
           }
           else{
            iTotal=iTotal + parseFloat(glAMTUNKNOWNCR);
           }
        return (iTotal.toFixed(2));
	}
    ,
    //Calculation : To get SL tab Credit Bucket Amount;
    getSLCreditBucketAmt: function()
    {
    	 var iTotal = 0;
    	 var reconAging=this.getReconTab();
		 var slAMTLTCR=reconAging.down("#SL_AMT0-7CR").getSubmitValue();
	     var slAMT8_30CR=reconAging.down("#SL_AMT8-30CR").getSubmitValue();
	     var slAMT31_60CR=reconAging.down("#SL_AMT31-60CR").getSubmitValue();
	     var slAMT61_90CR=reconAging.down("#SL_AMT61-90CR").getSubmitValue();
	     var slAMT91_120CR=reconAging.down("#SL_AMT91-120CR").getSubmitValue();
	     var slAMT121_150CR=reconAging.down("#SL_AMT121-150CR").getSubmitValue();
	     var slAMT151_180CR=reconAging.down("#SL_AMT151-180CR").getSubmitValue();
	     var slAMTABOVE180CR=reconAging.down("#SL_AMTABOVE180CR").getSubmitValue();
	     var slAMTUNKNOWNCR=reconAging.down("#SL_AMTUNKNOWNCR").getSubmitValue();
         
        if (slAMTLTCR > 0)
         {
        	  iTotal=iTotal + parseFloat(slAMTLTCR) * -1;
         }
         else{
        	 iTotal=iTotal + parseFloat(slAMTLTCR);
        
        }
	    if (slAMT8_30CR > 0)
         {
	    	  iTotal=iTotal + parseFloat(slAMT8_30CR) * -1;
         }else{
        	 iTotal=iTotal + parseFloat(slAMT8_30CR);
         
         }
    	 if (slAMT31_60CR > 0)
          {
    		  iTotal=iTotal + parseFloat(slAMT31_60CR) * -1;
          }
          else{
        	  iTotal=iTotal + parseFloat(slAMT31_60CR);
         
         }
   
    	  if (slAMT61_90CR > 0)
    	  {
    		  iTotal=iTotal + parseFloat(slAMT61_90CR) * -1;
    	  }
    	  else{
    		  iTotal=iTotal + parseFloat(slAMT61_90CR);
          
          }
		   if (slAMT91_120CR > 0)
	       {
	      	   iTotal=iTotal + parseFloat(slAMT91_120CR) * -1;
	       }
	       else{
	    	   iTotal=iTotal + parseFloat(slAMT91_120CR);
	       }
	      if (slAMT121_150CR > 0)
	       {
	      	 iTotal=iTotal + parseFloat(slAMT121_150CR) * -1;
	       }
	       else{
	    	   iTotal=iTotal + parseFloat(slAMT121_150CR);
	       }
    	   if (slAMT151_180CR > 0)
           {
          	  iTotal=iTotal + parseFloat(slAMT151_180CR) * -1;
           }
           else{
        	   iTotal=iTotal + parseFloat(slAMT151_180CR);
           }
    	   if (slAMTABOVE180CR > 0)
           {
          	 iTotal=iTotal + parseFloat(slAMTABOVE180CR) * -1;
           }
           else{
        	   iTotal=iTotal + parseFloat(slAMTABOVE180CR);
           }
    	   if (slAMTUNKNOWNCR > 0)
           {
          	 iTotal=iTotal + parseFloat(slAMTUNKNOWNCR) * -1;
           }
           else{
            iTotal=iTotal + parseFloat(slAMTUNKNOWNCR);
           }
        return (iTotal.toFixed(2));
	}
    ,
    
     //Calculation : To get GL Tab Amount Greater Than Benchmark Value(Debit);
    getGLAmtGtrBechmarkDr : function()
    { 
        var iTotal=0;       
        var balanceAging = this.getBalanceTab(); 
        var glAMTLTDR=balanceAging.down("#GL_AMT0-7DR").getSubmitValue();
        var glAMT8_30DR=balanceAging.down("#GL_AMT8-30DR").getSubmitValue();
        var glAMT31_60DR=balanceAging.down("#GL_AMT31-60DR").getSubmitValue();
        var glAMT61_90DR=balanceAging.down("#GL_AMT61-90DR").getSubmitValue();
        var glAMT91_120DR=balanceAging.down("#GL_AMT91-120DR").getSubmitValue();
        var glAMT121_150DR=balanceAging.down("#GL_AMT121-150DR").getSubmitValue();
        var glAMT151_180DR=balanceAging.down("#GL_AMT151-180DR").getSubmitValue();
        var glAMTABOVE180DR=balanceAging.down("#GL_AMTABOVE180DR").getSubmitValue();
        var glAMTUNKNOWNDR=balanceAging.down("#GL_AMTUNKNOWNDR").getSubmitValue();
        
        switch(parseInt(this.agingBenchmark))
        {
           case 0: 
                    iTotal=iTotal + Math.abs (glAMTLTDR); //Math.abs function added for correct calculation of system red amount 
           case 7:
                    iTotal=iTotal + Math.abs (glAMT8_30DR);
           case 30:
                    iTotal=iTotal + Math.abs (glAMT31_60DR);
           case 60:
                    iTotal=iTotal + Math.abs (glAMT61_90DR);
           case 90:
                    iTotal=iTotal + Math.abs (glAMT91_120DR);
           case 120:
                    iTotal=iTotal + Math.abs (glAMT121_150DR);
           case 150:
                    iTotal=iTotal + Math.abs (glAMT151_180DR);
           case 180:
                    iTotal=iTotal + Math.abs (glAMTABOVE180DR);
           default:
                    iTotal=iTotal + Math.abs (glAMTUNKNOWNDR);                 
        }
        return Math.abs(iTotal.toFixed(2));  //toFixed added for Decimal Point Issue                      
        
    },
    
      //Calculation : To get GL Tab QTY Greater Than Benchmark Value(Debit);
    getGLQtyGtrBechmarkDr : function()
    { 
        var iTotal=0;       
        var balanceAging = this.getBalanceTab(); 
        var glQTYLTDR=this.checkNull(balanceAging.down("#GL_QTY0-7DR").getSubmitValue());
        var glQTY8_30DR=this.checkNull(balanceAging.down("#GL_QTY8-30DR").getSubmitValue());
        var glQTY31_60DR=this.checkNull(balanceAging.down("#GL_QTY31-60DR").getSubmitValue());
        var glQTY61_90DR=this.checkNull(balanceAging.down("#GL_QTY61-90DR").getSubmitValue());
        var glQTY91_120DR=this.checkNull(balanceAging.down("#GL_QTY91-120DR").getSubmitValue());
        var glQTY121_150DR=this.checkNull(balanceAging.down("#GL_QTY121-150DR").getSubmitValue());
        var glQTY151_180DR=this.checkNull(balanceAging.down("#GL_QTY151-180DR").getSubmitValue());
        var glQTYABOVE180DR=this.checkNull(balanceAging.down("#GL_QTYABOVE180DR").getSubmitValue());
        var glQTYUNKNOWNDR=this.checkNull(balanceAging.down("#GL_QTYUNKNOWNDR").getSubmitValue());
        
        switch(parseInt(this.agingBenchmark))
        {
           case 0: 
                    iTotal=iTotal + Math.abs(glQTYLTDR); //Math.abs function added for correct calculation of system red amount 
           case 7:
                    iTotal=iTotal + Math.abs(glQTY8_30DR);
           case 30:
                    iTotal=iTotal + Math.abs(glQTY31_60DR);
           case 60:
                    iTotal=iTotal +  Math.abs(glQTY61_90DR);
           case 90:
                    iTotal=iTotal +  Math.abs(glQTY91_120DR);
           case 120:
                    iTotal=iTotal +  Math.abs(glQTY121_150DR);
           case 150:
                    iTotal=iTotal +  Math.abs(glQTY151_180DR);
           case 180:
                    iTotal=iTotal +  Math.abs(glQTYABOVE180DR);
           default:
                    iTotal=iTotal +  Math.abs(glQTYUNKNOWNDR);                 
        }
        return Math.abs(iTotal);                      
        
    },
    
    //Calculation : To get GL Tab Amount Greater Than Benchmark Value(Credit);
   getGLAmtGtrBechmarkCr : function()
    {
        var iTotal=0;
        
        var balanceAging = this.getBalanceTab(); 
        var glAMTLTCR=balanceAging.down("#GL_AMT0-7CR").getSubmitValue();
        var glAMT8_30CR=balanceAging.down("#GL_AMT8-30CR").getSubmitValue();
        var glAMT31_60CR=balanceAging.down("#GL_AMT31-60CR").getSubmitValue();
        var glAMT61_90CR=balanceAging.down("#GL_AMT61-90CR").getSubmitValue();
        var glAMT91_120CR=balanceAging.down("#GL_AMT91-120CR").getSubmitValue();
        var glAMT121_150CR=balanceAging.down("#GL_AMT121-150CR").getSubmitValue();
        var glAMT151_180CR=balanceAging.down("#GL_AMT151-180CR").getSubmitValue();
        var glAMTABOVE180CR=balanceAging.down("#GL_AMTABOVE180CR").getSubmitValue();
        var glAMTUNKNOWNCR=balanceAging.down("#GL_AMTUNKNOWNCR").getSubmitValue();
        switch(parseInt(this.agingBenchmark))
        {
           case 0:
           { 
                    if (glAMTLTCR > 0)
                     {
                    	 iTotal=iTotal + glAMTLTCR * -1;
                     }
                     else{
                    	 iTotal=iTotal + glAMTLTCR;
                     }
           }
           case 7:
           {
	        	    if (glAMT8_30CR > 0)
	                 {
	        	    	iTotal=iTotal + glAMT8_30CR * -1;
	                 }
	                 else{
	                	iTotal=iTotal + glAMT8_30CR;
	                 }
           }
           case 30:
           {
	        	   if (glAMT31_60CR > 0)
	               {
	              	 	iTotal=iTotal + glAMT31_60CR * -1;
	               }
	               else{
	            	   iTotal=iTotal + glAMT31_60CR;
	               }
           }
           case 60:
           {
	        	   if (glAMT61_90CR > 0)
	               {
	              	 	iTotal=iTotal + glAMT61_90CR * -1;
	               }
	               else{
	            	   iTotal=iTotal + glAMT61_90CR;
	               }
           }
           case 90:
           {
	        	   if (glAMT91_120CR > 0)
	               {
	        		   iTotal=iTotal + glAMT91_120CR * -1;
	               }
	               else{
	            	   iTotal=iTotal + glAMT91_120CR;
	               }
           }
           case 120:
           {
	        	   if (glAMT121_150CR > 0)
	               {
	              	   iTotal=iTotal + glAMT121_150CR * -1;
	               }
	               else{
	            	   iTotal=iTotal + glAMT121_150CR;
	               }
           }
           case 150:
           {
	        	   if (glAMT151_180CR > 0)
	               {
	              	   iTotal=iTotal + glAMT151_180CR * -1;
	               }
	               else{
	            	   iTotal=iTotal + glAMT151_180CR;
	               }
           }
           case 180:
           {
	        	   if (glAMTABOVE180CR > 0)
	               {
	              	 	iTotal=iTotal + glAMTABOVE180CR * -1;
	               }
	               else{
	            	   iTotal=iTotal + glAMTABOVE180CR;
	               }
           } 
           default:
           {
	        	   if (glAMTUNKNOWNCR > 0)
	               {
	              	  iTotal=iTotal + glAMTUNKNOWNCR * -1;
	               }
	               else{
	            	   iTotal=iTotal + glAMTUNKNOWNCR;
	               }
           }       
        }
        return (iTotal);   //toFixed added for Decimal Point Issue                   
    }  ,
    
    
     //Calculation : To get GL Tab QTY Greater Than Benchmark Value(Credit);
    getGLQtyGtrBechmarkCr : function()
    { 
        var iTotal=0;       
        var balanceAging = this.getBalanceTab(); 
        var glQTYLTCR=this.checkNull(balanceAging.down("#GL_QTY0-7CR").getSubmitValue());
        var glQTY8_30CR=this.checkNull(balanceAging.down("#GL_QTY8-30CR").getSubmitValue());
        var glQTY31_60CR=this.checkNull(balanceAging.down("#GL_QTY31-60CR").getSubmitValue());
        var glQTY61_90CR=this.checkNull(balanceAging.down("#GL_QTY61-90CR").getSubmitValue());
        var glQTY91_120CR=this.checkNull(balanceAging.down("#GL_QTY91-120CR").getSubmitValue());
        var glQTY121_150CR=this.checkNull(balanceAging.down("#GL_QTY121-150CR").getSubmitValue());
        var glQTY151_180CR=this.checkNull(balanceAging.down("#GL_QTY151-180CR").getSubmitValue());
        var glQTYABOVE180CR=this.checkNull(balanceAging.down("#GL_QTYABOVE180CR").getSubmitValue());
        var glQTYUNKNOWNCR=this.checkNull(balanceAging.down("#GL_QTYUNKNOWNCR").getSubmitValue());
        
        switch(parseInt(this.agingBenchmark))
        {
           case 0: 
                    iTotal=iTotal + Math.abs(glQTYLTCR);  
           case 7:
                    iTotal=iTotal + Math.abs(glQTY8_30CR);
           case 30:
                    iTotal=iTotal + Math.abs(glQTY31_60CR);
           case 60:
                    iTotal=iTotal +  Math.abs(glQTY61_90CR);
           case 90:
                    iTotal=iTotal +  Math.abs(glQTY91_120CR) ;
           case 120:
                    iTotal=iTotal +  Math.abs(glQTY121_150CR);
           case 150:
                    iTotal=iTotal +  Math.abs(glQTY151_180CR);
           case 180:
                    iTotal=iTotal +  Math.abs(glQTYABOVE180CR);
           default:
                    iTotal=iTotal +  Math.abs(glQTYUNKNOWNCR);                 
        }
        return Math.abs(iTotal);                      
        
    },
    
    //Calculation : To get SL Tab Amount Greater Than Benchmark Value(Debit);
    getSLAmtGtrBechmarkDr : function()
    {     	
        var iTotal=0;
        var iTotalforBenchmark=0;
        var reconAging = this.getReconTab(); 
        var benchmark;
        if(this.agingType=='G'){
        	benchmark='7';
        }
        else{
        	benchmark=this.agingBenchmark;
        }
        var slAMTLTDR=reconAging.down("#SL_AMT0-7DR").getSubmitValue();
        var slAMT8_30DR=reconAging.down("#SL_AMT8-30DR").getSubmitValue();
        var slAMT31_60DR=reconAging.down("#SL_AMT31-60DR").getSubmitValue();
        var slAMT61_90DR=reconAging.down("#SL_AMT61-90DR").getSubmitValue();
        var slAMT91_120DR=reconAging.down("#SL_AMT91-120DR").getSubmitValue();
        var slAMT121_150DR=reconAging.down("#SL_AMT121-150DR").getSubmitValue();
        var slAMT151_180DR=reconAging.down("#SL_AMT151-180DR").getSubmitValue();
        var slAMTABOVE180DR=reconAging.down("#SL_AMTABOVE180DR").getSubmitValue();
        var slAMTUNKNOWNDR=reconAging.down("#SL_AMTUNKNOWNDR").getSubmitValue();
        switch(parseInt(benchmark))
        {
           case 0: 
                    iTotal=iTotal + Math.abs (slAMTLTDR); //Math.abs function added for correct calculation of system red amount 
           case 7:
                    iTotal=iTotal + Math.abs (slAMT8_30DR);
           case 30:
                    iTotal=iTotal + Math.abs (slAMT31_60DR);
           case 60:
                    iTotal=iTotal + Math.abs (slAMT61_90DR);
           case 90:
                    iTotal=iTotal + Math.abs (slAMT91_120DR);
           case 120:
                    iTotal=iTotal + Math.abs (slAMT121_150DR);
           case 150:
                    iTotal=iTotal + Math.abs (slAMT151_180DR);
           case 180:
                    iTotal=iTotal + Math.abs (slAMTABOVE180DR);
           default:
                    iTotal=iTotal + Math.abs (slAMTUNKNOWNDR);                 
        }
        switch(parseInt(this.agingBenchmark))
        {
           case 0: 
        	   		iTotalforBenchmark=iTotalforBenchmark + Math.abs (slAMTLTDR); //Math.abs function added for correct calculation of system red amount 
           case 7:
        	   		iTotalforBenchmark=iTotalforBenchmark + Math.abs (slAMT8_30DR);
           case 30:
        	   		iTotalforBenchmark=iTotalforBenchmark + Math.abs (slAMT31_60DR);
           case 60:
        	   		iTotalforBenchmark=iTotalforBenchmark + Math.abs (slAMT61_90DR);
           case 90:
        	   		iTotalforBenchmark=iTotalforBenchmark + Math.abs (slAMT91_120DR);
           case 120:
        	   		iTotalforBenchmark=iTotalforBenchmark + Math.abs (slAMT121_150DR);
           case 150:
        	   		iTotalforBenchmark=iTotalforBenchmark + Math.abs (slAMT151_180DR);
           case 180:
        	   		iTotalforBenchmark=iTotalforBenchmark + Math.abs (slAMTABOVE180DR);
           default:
        	   		iTotalforBenchmark=iTotalforBenchmark + Math.abs (slAMTUNKNOWNDR);                 
        }
        this.sl_amt_abovebm_dr=iTotalforBenchmark;
        
        if(iTotalforBenchmark > 0){
        	this.sl_benchmark_dr = 1;
        }else{
        	this.sl_benchmark_dr = 0;
        }
        return Math.abs(iTotal);  //toFixed added for Decimal Point Issue                      
        
    }
    ,
    //Calculation : To get SL Tab QTY Greater Than Benchmark Value(Debit);
    
    getSLQtyGtrBechmarkDr : function()
    { 
        var iTotal=0; 
        var iTotalforQtyAboveBM=0; 
        var reconAging = this.getReconTab(); 
        var benchmark;
        if(this.agingType=='G'){
        	benchmark='7';
        }
        else{
        	benchmark=this.agingBenchmark;
        }
        var slQTYLTDR=this.checkNull(reconAging.down("#SL_QTY0-7DR").getSubmitValue());
        var slQTY8_30DR=this.checkNull(reconAging.down("#SL_QTY8-30DR").getSubmitValue());
        var slQTY31_60DR=this.checkNull(reconAging.down("#SL_QTY31-60DR").getSubmitValue());
        var slQTY61_90DR=this.checkNull(reconAging.down("#SL_QTY61-90DR").getSubmitValue());
        var slQTY91_120DR=this.checkNull(reconAging.down("#SL_QTY91-120DR").getSubmitValue());
        var slQTY121_150DR=this.checkNull(reconAging.down("#SL_QTY121-150DR").getSubmitValue());
        var slQTY151_180DR=this.checkNull(reconAging.down("#SL_QTY151-180DR").getSubmitValue());
        var slQTYABOVE180DR=this.checkNull(reconAging.down("#SL_QTYABOVE180DR").getSubmitValue());
        var slQTYUNKNOWNDR=this.checkNull(reconAging.down("#SL_QTYUNKNOWNDR").getSubmitValue());
        
        switch(parseInt(benchmark))
        {
           case 0: 
                    iTotal=iTotal + Math.abs(slQTYLTDR); //Math.abs function added for correct calculation of system red amount 
           case 7:
                    iTotal=iTotal + Math.abs(slQTY8_30DR);
           case 30:
                    iTotal=iTotal + Math.abs(slQTY31_60DR);
           case 60:
                    iTotal=iTotal +  Math.abs(slQTY61_90DR);
           case 90:
                    iTotal=iTotal +  Math.abs(slQTY91_120DR);
           case 120:
                    iTotal=iTotal +  Math.abs(slQTY121_150DR);
           case 150:
                    iTotal=iTotal +  Math.abs(slQTY151_180DR);
           case 180:
                    iTotal=iTotal +  Math.abs(slQTYABOVE180DR);
           default:
                    iTotal=iTotal +  Math.abs(slQTYUNKNOWNDR);                 
        }
        
        switch(parseInt(this.agingBenchmark))
        {
           case 0: 
        	   iTotalforQtyAboveBM=iTotalforQtyAboveBM + Math.abs(slQTYLTDR); //Math.abs function added for correct calculation of system red amount 
           case 7:
        	   iTotalforQtyAboveBM=iTotalforQtyAboveBM + Math.abs(slQTY8_30DR);
           case 30:
        	   iTotalforQtyAboveBM=iTotalforQtyAboveBM + Math.abs(slQTY31_60DR);
           case 60:
        	   iTotalforQtyAboveBM=iTotalforQtyAboveBM +  Math.abs(slQTY61_90DR);
           case 90:
        	   iTotalforQtyAboveBM=iTotalforQtyAboveBM +  Math.abs(slQTY91_120DR);
           case 120:
        	   iTotalforQtyAboveBM=iTotalforQtyAboveBM +  Math.abs(slQTY121_150DR);
           case 150:
        	   iTotalforQtyAboveBM=iTotalforQtyAboveBM +  Math.abs(slQTY151_180DR);
           case 180:
        	   iTotalforQtyAboveBM=iTotalforQtyAboveBM +  Math.abs(slQTYABOVE180DR);
           default:
        	   iTotalforQtyAboveBM=iTotalforQtyAboveBM +  Math.abs(slQTYUNKNOWNDR);                 
        }
        	this.sl_qty_abovebm_dr=iTotalforQtyAboveBM;
        
        return Math.abs(iTotal);                      
        
    },
  //Calculation : To get SL Tab Amount Greater Than Benchmark Value(Credit);
     getSLAmtGtrBechmarkCr : function()
    {    
        var iTotal=0;
        var iTotalforBenchmark=0;
        var reconAging = this.getReconTab(); 
        var benchmark;
        if(this.agingType=='G'){
        	benchmark='7';
        }
        else{
        	benchmark=this.agingBenchmark;
        }
        var slAMTLTCR=reconAging.down("#SL_AMT0-7CR").getSubmitValue();
        var slAMT8_30CR=reconAging.down("#SL_AMT8-30CR").getSubmitValue();
        var slAMT31_60CR=reconAging.down("#SL_AMT31-60CR").getSubmitValue();
        var slAMT61_90CR=reconAging.down("#SL_AMT61-90CR").getSubmitValue();
        var slAMT91_120CR=reconAging.down("#SL_AMT91-120CR").getSubmitValue();
        var slAMT121_150CR=reconAging.down("#SL_AMT121-150CR").getSubmitValue();
        var slAMT151_180CR=reconAging.down("#SL_AMT151-180CR").getSubmitValue();
        var slAMTABOVE180CR=reconAging.down("#SL_AMTABOVE180CR").getSubmitValue();
        var slAMTUNKNOWNCR=reconAging.down("#SL_AMTUNKNOWNCR").getSubmitValue();
        
        switch(parseInt(benchmark))
        {
           case 0:
           { 
                    if (slAMTLTCR > 0)
                     {
                    	 iTotal=iTotal + slAMTLTCR * -1;
                     }
                     else{
                    iTotal=iTotal + slAMTLTCR;
                     }
           }
           case 7:
           {
	        	    if (slAMT8_30CR > 0)
	                 {
	              	 iTotal=iTotal + slAMT8_30CR * -1;
	                 }
	                 else{
	                iTotal=iTotal + slAMT8_30CR;
	                 }
           }
           case 30:
           {
	        	   if (slAMT31_60CR > 0)
	               {
	              	 iTotal=iTotal + slAMT31_60CR * -1;
	               }
	               else{
	            	   iTotal=iTotal + slAMT31_60CR;
	               }
           }
           case 60:
           {
	        	   if (slAMT61_90CR > 0)
	               {
	              	 iTotal=iTotal + slAMT61_90CR * -1;
	               }else{
	            	   iTotal=iTotal + slAMT61_90CR;
	               }
           }
           case 90:
           {
	        	   if (slAMT91_120CR > 0)
	               {
	              	 iTotal=iTotal + slAMT91_120CR * -1;
	               }
	               else{
	              iTotal=iTotal + slAMT91_120CR;
	               }
           }
           case 120:
           {
	        	   if (slAMT121_150CR > 0)
	               {
	              	 iTotal=iTotal + slAMT121_150CR * -1;
	               }
	               else{
	              iTotal=iTotal + slAMT121_150CR;
	               }
           }
           case 150:
           {
	        	   if (slAMT151_180CR > 0)
	               {
	              	 iTotal=iTotal + slAMT151_180CR * -1;
	               }
	               else{
	              iTotal=iTotal + slAMT151_180CR;
	               }
           }
           case 180:
           {
	        	   if (slAMTABOVE180CR > 0)
	               {
	              	 iTotal=iTotal + slAMTABOVE180CR * -1;
	               }
	               else{
	              iTotal=iTotal + slAMTABOVE180CR;
	               }
           } 
           default:
           {
	        	   if (slAMTUNKNOWNCR > 0)
	               {
	              	 iTotal=iTotal + slAMTUNKNOWNCR * -1;
	               }
	               else{
	              iTotal=iTotal + slAMTUNKNOWNCR;
	               }
           }       
        }
        
        switch(parseInt(this.agingBenchmark))
        {
           case 0:
           { 
                    if (slAMTLTCR > 0)
                     {
                    	 iTotalforBenchmark=iTotalforBenchmark + slAMTLTCR * -1;
                     }
                     else{
                    	 iTotalforBenchmark=iTotalforBenchmark + slAMTLTCR;
                     }
           }
           case 7:
           {
	        	    if (slAMT8_30CR > 0)
	                 {
	                	 iTotalforBenchmark=iTotalforBenchmark + slAMT8_30CR * -1;
	                 }
	                 else{
	                	 iTotalforBenchmark=iTotalforBenchmark + slAMT8_30CR;
	                 }
           }
           case 30:
           {
	        	   if (slAMT31_60CR > 0)
	               {
	            	   iTotalforBenchmark=iTotalforBenchmark + slAMT31_60CR * -1;
	               }
	               else{
	            	   iTotalforBenchmark=iTotalforBenchmark + slAMT31_60CR;
	               }
           }
           case 60:
           {
	        	   if (slAMT61_90CR > 0)
	               {
	            	   iTotalforBenchmark=iTotalforBenchmark + slAMT61_90CR * -1;
	               }else{
	            	   iTotalforBenchmark=iTotalforBenchmark + slAMT61_90CR;
	               }
           }
           case 90:
           {
	        	   if (slAMT91_120CR > 0)
	               {
	            	   iTotalforBenchmark=iTotalforBenchmark + slAMT91_120CR * -1;
	               }
	               else{
	            	   iTotalforBenchmark=iTotalforBenchmark + slAMT91_120CR;
	               }
           }
           case 120:
           {
	        	   if (slAMT121_150CR > 0)
	               {
	            	   iTotalforBenchmark=iTotalforBenchmark + slAMT121_150CR * -1;
	               }
	               else{
	            	   iTotalforBenchmark=iTotalforBenchmark + slAMT121_150CR;
	               }
           }
           case 150:
           {
	        	   if (slAMT151_180CR > 0)
	               {
	            	   iTotalforBenchmark=iTotalforBenchmark + slAMT151_180CR * -1;
	               }
	               else{
	            	   iTotalforBenchmark=iTotalforBenchmark + slAMT151_180CR;
	               }
           }
           case 180:
           {
	        	   if (slAMTABOVE180CR > 0)
	               {
	            	   iTotalforBenchmark=iTotalforBenchmark + slAMTABOVE180CR * -1;
	               }
	               else{
	            	   iTotalforBenchmark=iTotalforBenchmark + slAMTABOVE180CR;
	               }
           } 
           default:
           {
	        	   if (slAMTUNKNOWNCR > 0)
	               {
	            	   iTotalforBenchmark=iTotalforBenchmarkiTotalforBenchmark + slAMTUNKNOWNCR * -1;
	               }
	               else{
	            	   iTotalforBenchmark=iTotalforBenchmark + slAMTUNKNOWNCR;
	               }
           }       
        }
        this.sl_amt_abovebm_cr = iTotalforBenchmark;
        if(Math.abs(iTotalforBenchmark) > 0){
        	this.sl_benchmark_cr = 1;
        }else{
        	this.sl_benchmark_cr = 0;
        }
        return (iTotal);   //toFixed added for Decimal Point Issue                   
    } ,
    
     //Calculation : To get SL Tab QTY Greater Than Benchmark Value(Credit);
    getSLQtyGtrBechmarkCr : function()
    { 
        var iTotal=0;
        var iTotalforQtyAboveBM=0; 
        var reconAging = this.getReconTab(); 
        var benchmark;
        if(this.agingType=='G'){
        	benchmark='7';
        }
        else{
        	benchmark=this.agingBenchmark;
        }
        var slQTYLTCR=this.checkNull(reconAging.down("#SL_QTY0-7CR").getSubmitValue());
        var slQTY8_30CR=this.checkNull(reconAging.down("#SL_QTY8-30CR").getSubmitValue());
        var slQTY31_60CR=this.checkNull(reconAging.down("#SL_QTY31-60CR").getSubmitValue());
        var slQTY61_90CR=this.checkNull(reconAging.down("#SL_QTY61-90CR").getSubmitValue());
        var slQTY91_120CR=this.checkNull(reconAging.down("#SL_QTY91-120CR").getSubmitValue());
        var slQTY121_150CR=this.checkNull(reconAging.down("#SL_QTY121-150CR").getSubmitValue());
        var slQTY151_180CR=this.checkNull(reconAging.down("#SL_QTY151-180CR").getSubmitValue());
        var slQTYABOVE180CR=this.checkNull(reconAging.down("#SL_QTYABOVE180CR").getSubmitValue());
        var slQTYUNKNOWNCR=this.checkNull(reconAging.down("#SL_QTYUNKNOWNCR").getSubmitValue());
        
        switch(parseInt(benchmark))
        {
           case 0: 
                    iTotal=iTotal + Math.abs(slQTYLTCR); //Math.abs function added for correct calculation of system red amount 
           case 7:
                    iTotal=iTotal + Math.abs(slQTY8_30CR);
           case 30:
                    iTotal=iTotal + Math.abs(slQTY31_60CR);
           case 60:
                    iTotal=iTotal +  Math.abs(slQTY61_90CR);
           case 90:
                    iTotal=iTotal +  Math.abs(slQTY91_120CR );
           case 120:
                    iTotal=iTotal +  Math.abs(slQTY121_150CR);
           case 150:
                    iTotal=iTotal +  Math.abs(slQTY151_180CR);
           case 180:
                    iTotal=iTotal +  Math.abs(slQTYABOVE180CR);
           default:
                    iTotal=iTotal +  Math.abs(slQTYUNKNOWNCR);                 
        }
        
        switch(parseInt(this.agingBenchmark))
        {
           case 0: 
        	   iTotalforQtyAboveBM=iTotalforQtyAboveBM + Math.abs(slQTYLTCR); //Math.abs function added for correct calculation of system red amount 
           case 7:
        	   iTotalforQtyAboveBM=iTotalforQtyAboveBM + Math.abs(slQTY8_30CR);
           case 30:
        	   iTotalforQtyAboveBM=iTotalforQtyAboveBM + Math.abs(slQTY31_60CR);
           case 60:
        	   iTotalforQtyAboveBM=iTotalforQtyAboveBM +  Math.abs(slQTY61_90CR);
           case 90:
        	   iTotalforQtyAboveBM=iTotalforQtyAboveBM +  Math.abs(slQTY91_120CR );
           case 120:
        	   iTotalforQtyAboveBM=iTotalforQtyAboveBM +  Math.abs(slQTY121_150CR);
           case 150:
        	   iTotalforQtyAboveBM=iTotalforQtyAboveBM +  Math.abs(slQTY151_180CR);
           case 180:
        	   iTotalforQtyAboveBM=iTotalforQtyAboveBM +  Math.abs(slQTYABOVE180CR);
           default:
        	   iTotalforQtyAboveBM=iTotalforQtyAboveBM +  Math.abs(slQTYUNKNOWNCR);                 
        }
        this.sl_qty_abovebm_cr=iTotalforQtyAboveBM;
        return Math.abs(iTotal);                      
        
    },
    
    //Validation : Amount at Risk
    //if Specific Amount at Risk has value ,then user has to select Amount at Risk Type.
    
    amountatriskvalidation : function(){
      var balanceAging = this.getBalanceTab();
      var reconAging=this.getReconTab();
      var mytab= this.getAgingContainer();
      var glComments=balanceAging.down("#GL_COMMENTS").getSubmitValue();
      var slComments=reconAging.down("#SL_COMMENTS").getSubmitValue();
	  var amountatriskpanel = this.getRiskamountTab();
	  var specificamtatriskdr=amountatriskpanel.down("#SPECIFICAMTATRISKDR").getSubmitValue();
	  var amtatrisktypedr=amountatriskpanel.down("#AMT_AT_RISK_TYPE_DR").getSubmitValue();
	  var specificamtatriskcr=amountatriskpanel.down("#SPECIFICAMTATRISKCR").getSubmitValue();
	  var amtatrisktypecr=amountatriskpanel.down("#AMT_AT_RISK_TYPE_CR").getSubmitValue();
	  var rptblamtatriskdr = amountatriskpanel.down("#AMT_AT_RISK_RPTL_DR").getSubmitValue();
	  var rptblamtatriskcr = amountatriskpanel.down("#AMT_AT_RISK_RPTL_CR").getSubmitValue();
      if ( specificamtatriskdr!== 0)
      {
          if ( amtatrisktypedr=== null || amtatrisktypedr ==="0"){
        	  
	              Ext.Msg.alert('Error', 'Please Select Risk Category for Debit Amount at Risk', function(btn, text){
	                  if (btn == 'ok'){
	                	amountatriskpanel.down("#AMT_AT_RISK_TYPE_DR").focus(false,200);
	                  }
	              });
	              return false;
          }
          else{
		        if ((amountatriskpanel.down("#RISKTARGETDT").getValue()==="") || (amountatriskpanel.down("#RISKTARGETDT").getValue()===null) || (!amountatriskpanel.down("#RISKTARGETDT").isValid())){
	                 
		        	  Ext.Msg.alert('Error', 'Please enter Valid Target Resolution Date for Debit Amount at Risk ', function(btn, text){
		                  if (btn == 'ok'){
		                	  amountatriskpanel.down("#RISKTARGETDT").focus(false,200);
		                  }
		              });
		              return false;
		          }
          }
      }
      else
      {
    	  
          if (amtatrisktypedr !== null && amtatrisktypedr!=="0")
          {
              Ext.Msg.alert('Error', 'Please enter Debit Amount at Risk', function(btn, text){
		                  if (btn == 'ok'){
		                	  amountatriskpanel.down("#SPECIFICAMTATRISKDR").focus(false,200);
		                  }
		              });
		      return false;
          }
          
          if (amountatriskpanel.down("#RISKTARGETDT").getValue() !== null)
          {
        	  Ext.Msg.alert('Error', 'Please enter Debit Amount at Risk', function(btn, text){
                  if (btn == 'ok'){
                	  amountatriskpanel.down("#SPECIFICAMTATRISKDR").focus(false,200);
                  }
              });
        	  return false;
          }
      }
      
      //CR
      if (specificamtatriskcr!== 0)
      {
          if (amtatrisktypecr=== null || amtatrisktypecr ==="0")
          {
        	  Ext.Msg.alert('Error', 'Please Select Risk Category for Credit Amount at Risk', function(btn, text){
                  if (btn == 'ok'){
                	  amountatriskpanel.down("#AMT_AT_RISK_TYPE_CR").focus(false,200);
                  }
              });
        	  return false;
          }               
      }
      else
      {
      
          if (amountatriskpanel.down("#AMT_AT_RISK_TYPE_CR ").getSubmitValue()!== null && amountatriskpanel.down("#AMT_AT_RISK_TYPE_CR ").getSubmitValue()!== "0")
          {
        	  Ext.Msg.alert('Error', 'Please enter Credit Amount at Risk', function(btn, text){
                  if (btn == 'ok'){
                	  amountatriskpanel.down("#SPECIFICAMTATRISKCR").focus(false,200);
                  }
              });
        	  return false;
          }   
      }
      
      if (parseFloat(rptblamtatriskdr) !==0 || parseFloat(rptblamtatriskcr) !==0){
        	if(this.agingType==="G"){
                if (eRecon_web.gbl.constants.trim(glComments)=== "" )
                {
	                Ext.Msg.alert('Error', 'Please enter a comment in  Balance Aging Tab as the Reportable Amount At Risk is not equal to zero.', function(btn, text){
	                    if (btn == 'ok'){
	                    	mytab.setActiveTab('balanceaging');
	                    	balanceAging.down("#GL_COMMENTS").focus(false,200);
	                    }
	                });
                    return false;
                }
           }
           else if (this.agingType==="S"){
        	   if (eRecon_web.gbl.constants.trim(slComments)=== "" )
               {
	                Ext.Msg.alert('Error', 'Please enter a comment in  Recon Aging Tab as the Reportable Amount At Risk is not equal to zero.', function(btn, text){
	                    if (btn == 'ok'){
	                    	mytab.setActiveTab('reconbreakaging');
	                    	reconAging.down("#SL_COMMENTS").focus(false,200);
	                    }
	                });
                   return false;
               }
           }
      }
      
  return true;
}
,	

	//Validation : Red amount Validation
    //if Specific Amount at Risk has value ,then user has to select Amount at Risk Type.
    
	redamountvalidation : function(){
		var balanceAging = this.getBalanceTab();
		var reconAging=this.getReconTab();
		var mytab= this.getAgingContainer();
		var glrptlredamtdr=balanceAging.down("#GL_RPTLREDAMTDR").getSubmitValue();
		var glrptlredamtcr=balanceAging.down("#GL_RPTLREDAMTCR").getSubmitValue();
		var glComments=balanceAging.down("#GL_COMMENTS").getSubmitValue();
		var slrptlredamtdr=reconAging.down("#SL_RPTLREDAMTDR").getSubmitValue();
		var slrptlredamtcr=reconAging.down("#SL_RPTLREDAMTCR").getSubmitValue();
		var slComments=reconAging.down("#SL_COMMENTS").getSubmitValue();
        if (this.agingType == "G")
        {
            if (parseFloat(glrptlredamtdr) !==0 || parseFloat(glrptlredamtcr) !==0)
            {
                if (eRecon_web.gbl.constants.trim(glComments) === "" )
                {
	                Ext.Msg.alert('Error', 'Please enter a comment in  Balance Aging Tab as the Reportable Red Amount is not equal to zero.', function(btn, text){
	                    if (btn == 'ok'){
	                    	mytab.setActiveTab('balanceaging');
	                    	balanceAging.down("#GL_COMMENTS").focus(false,200);
	                    }
	                });
                    return false;
                }   
            }
            if (parseFloat(slrptlredamtdr)!==0 || parseFloat(slrptlredamtcr)!==0 )
            {
               if (eRecon_web.gbl.constants.trim(slComments) === "" )
               {
            	   
	                Ext.Msg.alert('Error', 'Please enter a comment in Recon Break Aging Tab as the Reportable Red Amount is not equal to zero.', function(btn, text){
	                    if (btn == 'ok'){
	                    	mytab.setActiveTab('reconbreakaging');
	                    	reconAging.down("#SL_COMMENTS").focus(false,200);
	                    }
	                });
	                return false;
               } 
            }
        }
        else
        {
        	if (parseFloat(slrptlredamtdr)!==0 || parseFloat(slrptlredamtcr)!==0 )
            {
               if (eRecon_web.gbl.constants.trim(slComments) === "" )
               {
            	   
            	  Ext.Msg.alert('Error', 'Please enter a comment in Recon Break Aging Tab as the Reportable Red Amount is not equal to zero.', function(btn, text){
	                    if (btn == 'ok'){
	                    	mytab.setActiveTab('reconbreakaging');
	                    	reconAging.down("#SL_COMMENTS").focus(false,200);
	                    }
	                });
	               return false;
               } 
            }
        }
        return true;        	
}
    ,
    bucketvalidation : function(){
	
    	var balanceAging= this.getBalanceTab();
    	var ReconAging=this.getReconTab();
    	var mytab= this.getAgingContainer();
    	if(this.agingType==="G"){
    	if(this.checkNull(balanceAging.down("#GL_QTY0-7DR").getValue())===0 && (balanceAging.down("#GL_AMT0-7DR").getSubmitValue() !=0))
    	{
            Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (0-7) in Balance Aging. Gross debit Amount(+) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_QTY0-7DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY0-7DR").getValue())>0 && (balanceAging.down("#GL_AMT0-7DR").getSubmitValue()===0))
    	{
    		
            Ext.Msg.alert('Error', 'Please enter the Gross debit Amount(+) for Aging Bucket (0-7) in Balance Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_AMT0-7DR").focus(false,200);
                }
            });
    		
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY0-7CR").getValue())===0 && (balanceAging.down("#GL_AMT0-7CR").getSubmitValue() !=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (0-7) in Balance Aging. Gross Credit Amount(-) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_QTY0-7CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY0-7CR").getValue())>0 && (balanceAging.down("#GL_AMT0-7CR").getSubmitValue()===0))
    	{
    		
            Ext.Msg.alert('Error', 'Please enter the Gross Credit Amount(-) for Aging Bucket (0-7) in Balance Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_AMT0-7CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY8-30DR").getValue())===0 && (balanceAging.down("#GL_AMT8-30DR").getSubmitValue()!=0))
    	{
            Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (8-30) in Balance Aging. Gross debit Amount(+) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_QTY8-30DR").focus(false,200);
                }
            });
    		
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY8-30DR").getValue())>0 && (balanceAging.down("#GL_AMT8-30DR").getSubmitValue() ===0))
    	{
    		
    		Ext.Msg.alert('Error', 'Please enter the Gross debit Amount(+) for Aging Bucket (8-30) in Balance Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_AMT8-30DR").focus(false,200);
                }
            });
    		
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY8-30CR").getValue())===0 && (balanceAging.down("#GL_AMT8-30CR").getSubmitValue()!=0))
    	{
    		
            Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (8-30) in Balance Aging. Gross Credit Amount(-) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_QTY8-30CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY8-30CR").getValue())>0 && (balanceAging.down("#GL_AMT8-30CR").getSubmitValue()===0))
    	{
    		
            Ext.Msg.alert('Error', 'Please enter the Gross Credit Amount(-) for Aging Bucket (8-30) in Balance Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_AMT8-30CR").focus(false,200);
                }
            });
    		return false;
    		
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY31-60DR").getValue())===0 && (balanceAging.down("#GL_AMT31-60DR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (31-60) in Balance Aging. Gross debit Amount(+) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_QTY31-60DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY31-60DR").getValue())>0 && (balanceAging.down("#GL_AMT31-60DR").getSubmitValue()===0))
    	{
            Ext.Msg.alert('Error', 'Please enter the Gross debit Amount(+) for Aging Bucket (31-60) in Balance Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_AMT31-60DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY31-60CR").getValue())===0 && (balanceAging.down("#GL_AMT31-60CR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (31-60) in Balance Aging. Gross Credit Amount(-) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_QTY31-60CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY31-60CR").getValue())>0 && (balanceAging.down("#GL_AMT31-60CR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Credit Amount(-) for Aging Bucket (31-60) in Balance Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_AMT31-60CR").focus(false,200);
                }
            });
    		return false;
    	}if(this.checkNull(balanceAging.down("#GL_QTY61-90DR").getValue())===0 && (balanceAging.down("#GL_AMT61-90DR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (61-90) in Balance Aging. Gross debit Amount(+) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_QTY61-90DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY61-90DR").getValue())>0 && (balanceAging.down("#GL_AMT61-90DR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross debit Amount(+) for Aging Bucket (61-90) in Balance Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_AMT61-90DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY61-90CR").getValue())===0 && (balanceAging.down("#GL_AMT61-90CR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (61-90) in Balance Aging. Gross Credit Amount(-) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_QTY61-90CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY61-90CR").getValue())>0 && (balanceAging.down("#GL_AMT61-90CR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Credit Amount(-) for Aging Bucket (61-90) in Balance Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_AMT61-90CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY91-120DR").getValue())===0 && (balanceAging.down("#GL_AMT91-120DR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (91-120) in Balance Aging. Gross debit Amount(+) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_QTY91-120DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY91-120DR").getValue())>0 && (balanceAging.down("#GL_AMT91-120DR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross debit Amount(+) for Aging Bucket (91-120) in Balance Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_AMT91-120DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY91-120CR").getValue())===0 && (balanceAging.down("#GL_AMT91-120CR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (91-120) in Balance Aging. Gross Credit Amount(-) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_QTY91-120CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY91-120CR").getValue())>0 && (balanceAging.down("#GL_AMT91-120CR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Credit Amount(-) for Aging Bucket (91-120) in Balance Aging. A total items quantity has been entered for this bucket', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_AMT91-120CR").focus(false,200);
                }
            });
    		return false;
    	}if(this.checkNull(balanceAging.down("#GL_QTY121-150DR").getValue())===0 && (balanceAging.down("#GL_AMT121-150DR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (121-150) in Balance Aging. Gross debit Amount(+) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_QTY121-150DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY121-150DR").getValue())>0 && (balanceAging.down("#GL_AMT121-150DR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross debit Amount(+) for Aging Bucket (121-150) in Balance Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_AMT121-150DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY121-150CR").getValue())===0 && (balanceAging.down("#GL_AMT121-150CR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (121-150) in Balance Aging. Gross Credit Amount(-) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_QTY121-150CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY121-150CR").getValue())>0 && (balanceAging.down("#GL_AMT121-150CR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Credit Amount(-) for Aging Bucket (121-150) in Balance Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_AMT121-150CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY151-180DR").getValue())===0 && (balanceAging.down("#GL_AMT151-180DR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (151-180) in Balance Aging. Gross debit Amount(+) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_QTY151-180DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY151-180DR").getValue())>0 && (balanceAging.down("#GL_AMT151-180DR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross debit Amount(+) for Aging Bucket (151-180) in Balance Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_AMT151-180DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY151-180CR").getValue())===0 && (balanceAging.down("#GL_AMT151-180CR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (151-180) in Balance Aging. Gross Credit Amount(-) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_QTY151-180CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTY151-180CR").getValue())>0 && (balanceAging.down("#GL_AMT151-180CR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Credit Amount(-) for Aging Bucket (151-180) in Balance Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_AMT151-180CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTYABOVE180DR").getValue())>0 && (balanceAging.down("#GL_AMTABOVE180DR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross debit Amount(+) for Aging Bucket (181-365) in Balance Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_AMTABOVE180DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTYABOVE180DR").getValue())===0 && (balanceAging.down("#GL_AMTABOVE180DR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (181-365) in Balance Aging. Gross debit Amount(+) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_QTYABOVE180DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTYABOVE180CR").getValue())>0 && (balanceAging.down("#GL_AMTABOVE180CR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Credit Amount(-) for Aging Bucket (181-365) in Balance Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_AMTABOVE180CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTYABOVE180CR").getValue())===0 && (balanceAging.down("#GL_AMTABOVE180CR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (181-365) in Balance Aging. Gross Credit Amount(-) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_QTYABOVE180CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTYUNKNOWNDR").getValue())===0 && (balanceAging.down("#GL_AMTUNKNOWNDR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (365+) in Balance Aging. Gross debit Amount(+) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_QTYUNKNOWNDR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTYUNKNOWNDR").getValue())>0 && (balanceAging.down("#GL_AMTUNKNOWNDR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross debit Amount(+) for Aging Bucket (365+) in Balance Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_AMTUNKNOWNDR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTYUNKNOWNCR").getValue())===0 && (balanceAging.down("#GL_AMTUNKNOWNCR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (365+) in Balance Aging. Gross Credit Amount(-) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_QTYUNKNOWNCR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(balanceAging.down("#GL_QTYUNKNOWNCR").getValue())>0 && (balanceAging.down("#GL_AMTUNKNOWNCR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Credit Amount(-) for Aging Bucket (365+) in Balance Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('balanceaging');
                	balanceAging.down("#GL_AMTUNKNOWNCR").focus(false,200);
                }
            });
    		return false;
    	}
    	
    	}
    	/******************************* end of g type ***************************************/
    	
    	if(this.checkNull(ReconAging.down("#SL_QTY0-7DR").getValue())===0 && (ReconAging.down("#SL_AMT0-7DR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (0-7) in Recon Break Aging. Gross debit Amount(+) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_QTY0-7DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY0-7DR").getValue())>0 && (ReconAging.down("#SL_AMT0-7DR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross debit Amount(+) for Aging Bucket (0-7) in Recon Break Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_AMT0-7DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY0-7CR").getValue())===0 && (ReconAging.down("#SL_AMT0-7CR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (0-7) in Recon Break Aging. Gross Credit Amount(-) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_QTY0-7CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY0-7CR").getValue())>0 && (ReconAging.down("#SL_AMT0-7CR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Credit Amount(-) for Aging Bucket (0-7) in Recon Break Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_AMT0-7CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY8-30DR").getValue())===0 && (ReconAging.down("#SL_AMT8-30DR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (8-30) in Recon Break Aging. Gross debit Amount(+) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_QTY8-30DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY8-30DR").getValue())>0 && (ReconAging.down("#SL_AMT8-30DR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross debit Amount(+) for Aging Bucket (8-30) in Recon Break Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_AMT8-30DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY8-30CR").getValue())===0 && (ReconAging.down("#SL_AMT8-30CR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (8-30) in Recon Break Aging. Gross Credit Amount(-) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_QTY8-30CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY8-30CR").getValue())>0 && (ReconAging.down("#SL_AMT8-30CR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Credit Amount(-) for Aging Bucket (8-30) in Recon Break Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_AMT8-30CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY31-60DR").getValue())===0 && (ReconAging.down("#SL_AMT31-60DR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (31-60) in Recon Break Aging. Gross debit Amount(+) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_QTY31-60DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY31-60DR").getValue())>0 && (ReconAging.down("#SL_AMT31-60DR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross debit Amount(+) for Aging Bucket (31-60) in Recon Break Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_AMT31-60DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY31-60CR").getValue())===0 && (ReconAging.down("#SL_AMT31-60CR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (31-60) in Recon Break Aging. Gross Credit Amount(-) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_QTY31-60CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY31-60CR").getValue())>0 && (ReconAging.down("#SL_AMT31-60CR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Credit Amount(-) for Aging Bucket (31-60) in Recon Break Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_AMT31-60CR").focus(false,200);
                }
            });
    		return false;
    	}if(this.checkNull(ReconAging.down("#SL_QTY61-90DR").getValue())===0 && (ReconAging.down("#SL_AMT61-90DR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (61-90) in Recon Break Aging. Gross debit Amount(+) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_QTY61-90DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY61-90DR").getValue())>0 && (ReconAging.down("#SL_AMT61-90DR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross debit Amount(+) for Aging Bucket (61-90) in Recon Break Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_AMT61-90DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY61-90CR").getValue())===0 && (ReconAging.down("#SL_AMT61-90CR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (61-90) in Recon Break Aging. Gross Credit Amount(-) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_QTY61-90CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY61-90CR").getValue())>0 && (ReconAging.down("#SL_AMT61-90CR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Credit Amount(-) for Aging Bucket (61-90) in Recon Break Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_AMT61-90CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY91-120DR").getValue())===0 && (ReconAging.down("#SL_AMT91-120DR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (91-120) in Recon Break Aging. Gross debit Amount(+) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_QTY91-120DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY91-120DR").getValue())>0 && (ReconAging.down("#SL_AMT91-120DR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross debit Amount(+) for Aging Bucket (91-120) in Recon Break Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_AMT91-120DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY91-120CR").getValue())===0 && (ReconAging.down("#SL_AMT91-120CR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (91-120) in Recon Break Aging. Gross Credit Amount(-) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_QTY91-120CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY91-120CR").getValue())>0 && (ReconAging.down("#SL_AMT91-120CR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Credit Amount(-) for Aging Bucket (91-120) in Recon Break Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_AMT91-120CR").focus(false,200);
                }
            });
    		return false;
    	}if(this.checkNull(ReconAging.down("#SL_QTY121-150DR").getValue())===0 && (ReconAging.down("#SL_AMT121-150DR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (121-150) in Recon Break Aging. Gross debit Amount(+) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_QTY121-150DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY121-150DR").getValue())>0 && (ReconAging.down("#SL_AMT121-150DR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross debit Amount(+) for Aging Bucket (121-150) in Recon Break Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_AMT121-150DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY121-150CR").getValue())===0 && (ReconAging.down("#SL_AMT121-150CR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (121-150) in Recon Break Aging. Gross Credit Amount(-) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_QTY121-150CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY121-150CR").getValue())>0 && (ReconAging.down("#SL_AMT121-150CR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Credit Amount(-) for Aging Bucket (121-150) in Recon Break Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_AMT121-150CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY151-180DR").getValue())===0 && (ReconAging.down("#SL_AMT151-180DR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (151-180) in Recon Break Aging. Gross debit Amount(+) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_QTY151-180DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY151-180DR").getValue())>0 && (ReconAging.down("#SL_AMT151-180DR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross debit Amount(+) for Aging Bucket (151-180) in Recon Break Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_AMT151-180DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY151-180CR").getValue())===0 && (ReconAging.down("#SL_AMT151-180CR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (151-180) in Recon Break Aging. Gross Credit Amount(-) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_QTY151-180CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTY151-180CR").getValue())>0 && (ReconAging.down("#SL_AMT151-180CR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Credit Amount(-) for Aging Bucket (151-180) in Recon Break Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_AMT151-180CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTYABOVE180DR").getValue())>0 && (ReconAging.down("#SL_AMTABOVE180DR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross debit Amount(+) for Aging Bucket (181-365) in Recon Break Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_AMTABOVE180DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTYABOVE180DR").getValue())===0 && (ReconAging.down("#SL_AMTABOVE180DR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (181-365) in Recon Break Aging. Gross debit Amount(+) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_QTYABOVE180DR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTYABOVE180CR").getValue())>0 && (ReconAging.down("#SL_AMTABOVE180CR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Credit Amount(-) for Aging Bucket (181-365) in Recon Break Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_AMTABOVE180CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTYABOVE180CR").getValue())===0 && (ReconAging.down("#SL_AMTABOVE180CR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (181-365) in Recon Break Aging. Gross Credit Amount(-) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_QTYABOVE180CR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTYUNKNOWNDR").getValue())===0 && (ReconAging.down("#SL_AMTUNKNOWNDR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (365+) in Recon Break Aging. Gross debit Amount(+) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_QTYUNKNOWNDR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTYUNKNOWNDR").getValue())>0 && (ReconAging.down("#SL_AMTUNKNOWNDR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross debit Amount(+) for Aging Bucket (365+) in Recon Break Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_AMTUNKNOWNDR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTYUNKNOWNCR").getValue())===0 && (ReconAging.down("#SL_AMTUNKNOWNCR").getSubmitValue()!=0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Number of Items for Aging Bucket (365+) in Recon Break Aging. Gross Credit Amount(-) has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_QTYUNKNOWNCR").focus(false,200);
                }
            });
    		return false;
    	}
    	if(this.checkNull(ReconAging.down("#SL_QTYUNKNOWNCR").getValue())>0 && (ReconAging.down("#SL_AMTUNKNOWNCR").getSubmitValue()===0))
    	{
    		Ext.Msg.alert('Error', 'Please enter the Gross Credit Amount(-) for Aging Bucket (365+) in Recon Break Aging. A total items quantity has been entered for this bucket.', function(btn, text){
                if (btn == 'ok'){
                	mytab.setActiveTab('reconbreakaging');
                	ReconAging.down("#SL_AMTUNKNOWNCR").focus(false,200);
                }
            });
    		return false;
    	}
    	return true;
    
    },

    checkNull : function(value)
    {
          var iRetrun = value;
          if (value===null || value==='')  
            return 0;
          else
            return iRetrun;
    },
    
    //Calculation :Reportable Amount at Risk amount  Calculation;
	//if Amount at Risk > Local Ccy Threshold then Reportable Amount at Risk= Amount at Risk 
    //Else Reportable Amount at Risk=0
    calculateDRRptlAmount : function() 
    { 
        var iLCL_CCY_THRESHOLD =parseFloat(this.checkNull(this.lcl_ccy_threshold)); 
        var balanceAging=this.getBalanceTab();
        var reconAging = this.getReconTab();
        var amountatriskpanel = this.getRiskamountTab();
        
        var specificamtatriskdr=Math.abs(amountatriskpanel.down("#SPECIFICAMTATRISKDR").getSubmitValue());
        if(balanceAging!==null || reconAging!==null || amountatriskpanel!==null){     
	        if ( specificamtatriskdr >= iLCL_CCY_THRESHOLD)
	            amountatriskpanel.down("#AMT_AT_RISK_RPTL_DR").setValue (specificamtatriskdr);
	        else
	            amountatriskpanel.down("#AMT_AT_RISK_RPTL_DR").setValue(0);
	            
	           this.updateStatusndicator();
        }
        
         
    },
    
    calculateCRRptlAmount : function() 
    { 
        var iLCL_CCY_THRESHOLD =parseFloat(this.checkNull(this.lcl_ccy_threshold)); 
        var balanceAging=this.getBalanceTab();
        var reconAging = this.getReconTab();
        var amountatriskpanel = this.getRiskamountTab();
        
        var specificamtatriskcr=Math.abs(amountatriskpanel.down("#SPECIFICAMTATRISKCR").getSubmitValue());
        var specificamtatriskcrval = amountatriskpanel.down("#SPECIFICAMTATRISKCR").getSubmitValue();
        if(balanceAging!==null || reconAging!==null || amountatriskpanel!==null){     
            
	         if (specificamtatriskcr >= iLCL_CCY_THRESHOLD)
	         {
	            if (specificamtatriskcrval >0 )
	            {
	            	 amountatriskpanel.down("#AMT_AT_RISK_RPTL_CR").setValue(specificamtatriskcrval * -1);
	            }
	            else
	            {
	            	 amountatriskpanel.down("#AMT_AT_RISK_RPTL_CR").setValue(specificamtatriskcrval);
	            }
	         }
	         else
	            amountatriskpanel.down("#AMT_AT_RISK_RPTL_CR").setValue(0);
	            
	           this.updateStatusndicator();
        }
        
    }
    ,
    
    //Calculation : Total Red Amount   Calculation;
	//Total Red Amount = System red Amount + User red Amount 
   
    
    calculateCRGLTotalRedAmount : function() 
    {
    	var balanceAging= this.getBalanceTab();
    	
	    if(balanceAging!==null){
	    	var glSystemredamtcr= balanceAging.down("#GL_SYSREDAMTCR").getSubmitValue();
	    	var glUserredamtcr=balanceAging.down("#GL_USERREDAMTCR").getSubmitValue();
	    	var totredcr = parseFloat(glSystemredamtcr) +  parseFloat(glUserredamtcr);
	    	if(totredcr!= balanceAging.down("#GL_TOTREDAMTCR").getSubmitValue()){
	    		balanceAging.down("#GL_TOTREDAMTCR").setValue(totredcr.toFixed(2));
	        }
	        var lclccythreshld=parseFloat(this.checkNull(this.lcl_ccy_threshold));
	        if (Math.abs(totredcr) >= lclccythreshld)
	        {
	        	 if(totredcr!= balanceAging.down("#GL_RPTLREDAMTCR").getSubmitValue()){
	        		 balanceAging.down("#GL_RPTLREDAMTCR").setValue(this.checkNull(balanceAging.down("#GL_TOTREDAMTCR").getSubmitValue()));
	        	 }
	        }
	        else
	        {
	        	 balanceAging.down("#GL_RPTLREDAMTCR").setValue(0);
	        }
	        this.updateStatusndicator();
        }
    },

    calculateDRGLTotalRedAmount : function() 
    {
    	var balanceAging= this.getBalanceTab();
    	
    	if(balanceAging!==null){
	    	var glSystemredamtdr= balanceAging.down("#GL_SYSREDAMTDR").getSubmitValue();
	    	var glUserredamtdr=Math.abs(balanceAging.down("#GL_USERREDAMTDR").getSubmitValue());
	    	var totreddr = parseFloat(glSystemredamtdr) +  parseFloat(glUserredamtdr);
	    	if(totreddr!= balanceAging.down("#GL_TOTREDAMTDR").getSubmitValue()){
	    		balanceAging.down("#GL_TOTREDAMTDR").setValue(totreddr.toFixed(2));//Added forDecimal Point Issue 
	    	}
	        var lclccythreshld=parseFloat(this.checkNull(this.lcl_ccy_threshold));
	        if (totreddr >= lclccythreshld)
	        {
	            if(totreddr!=balanceAging.down("#GL_RPTLREDAMTDR").getSubmitValue()){
	            	balanceAging.down("#GL_RPTLREDAMTDR").setValue(balanceAging.down("#GL_TOTREDAMTDR").getSubmitValue());
	            }
	        }
	        else
	        {
	         
	        balanceAging.down("#GL_RPTLREDAMTDR").setValue(0);
	        }
	        this.updateStatusndicator();
        }
          
    },
    
    
    //Calculation : Total Red Amount   Calculation;
	//Total Red Amount = System red Amount + User red Amount 
    
	
     calculateDRSLTotalRedAmount : function() 
    {
    	var reconAging= this.getReconTab();
    	if(reconAging!==null){
    		
	    	var slSystemredamtdr= reconAging.down("#SL_SYSREDAMTDR").getSubmitValue();
	    	var slUserredamtdr=Math.abs(reconAging.down("#SL_USERREDAMTDR").getSubmitValue());
	    	var totreddr=parseFloat(slSystemredamtdr) +  parseFloat(slUserredamtdr);
	    	if(totreddr != reconAging.down("#SL_TOTREDAMTDR").getSubmitValue()){
	    		reconAging.down("#SL_TOTREDAMTDR").setValue(totreddr.toFixed(2));//Added forDecimal Point Issue   
	        }
	        var lclccythreshld=this.checkNull(reconAging.down("#SL_LCL_CCY_THRESHLD").getValue());
	        var lclccythreshld=parseFloat(this.checkNull(this.lcl_ccy_threshold));
	        if (totreddr >= lclccythreshld)
	        {
	            if(totreddr!=reconAging.down("#SL_RPTLREDAMTDR").getSubmitValue()){
	            	reconAging.down("#SL_RPTLREDAMTDR").setValue(reconAging.down("#SL_TOTREDAMTDR").getSubmitValue());
	            }
	        }
	        else
	        {
	         
	        reconAging.down("#SL_RPTLREDAMTDR").setValue(0);
	        }
	            
	        this.updateStatusndicator();
        }
          
    }
    ,
    calculateCRSLTotalRedAmount : function() 
    {
    	var reconAging= this.getReconTab();
    	if(reconAging!==null){
    		
    	var slSystemredamtcr= reconAging.down("#SL_SYSREDAMTCR").getSubmitValue();
    	var slUserredamtcr=reconAging.down("#SL_USERREDAMTCR").getSubmitValue();
        var totredcr=parseFloat(slSystemredamtcr) +  parseFloat(slUserredamtcr);
        if(totredcr!=reconAging.down("#SL_TOTREDAMTCR").getSubmitValue()){
        	reconAging.down("#SL_TOTREDAMTCR").setValue(totredcr.toFixed(2));
        }
        var lclccythreshld=this.checkNull(reconAging.down("#SL_LCL_CCY_THRESHLD").getValue());
        var lclccythreshld=parseFloat(this.checkNull(this.lcl_ccy_threshold));
        if (Math.abs(totredcr)>= lclccythreshld)
        {
        	if(totredcr!=reconAging.down("#SL_RPTLREDAMTCR").getSubmitValue()){ 
        		reconAging.down("#SL_RPTLREDAMTCR").setValue(reconAging.down("#SL_TOTREDAMTCR").getSubmitValue());
        	}
        }
        else
        {
        	 reconAging.down("#SL_RPTLREDAMTCR").setValue(0);
        }
        this.updateStatusndicator();
        }
          
    }
    ,
    //GL System Red Amount Calculation
    calculateDRGLSystemRedAmount : function() 
    {
    	
    	var balanceAging= this.getBalanceTab();
    	if(balanceAging!==null){
    	var AMT_GTBM_DR=0;
    	var QTY_GTBM_DR=0;
      
	    AMT_GTBM_DR  = this.getGLAmtGtrBechmarkDr();
	    QTY_GTBM_DR =  this.getGLQtyGtrBechmarkDr();
	    
	    balanceAging.down("#GL_AMT_GTBM_DR").setValue(AMT_GTBM_DR.toFixed(2));
	    balanceAging.down("#GL_QTY_GTBM_DR").setValue(QTY_GTBM_DR);
	    if(AMT_GTBM_DR!== balanceAging.down("#GL_SYSREDAMTDR").getSubmitValue()){
	    	balanceAging.down("#GL_SYSREDAMTDR").setValue(AMT_GTBM_DR.toFixed(2));
	    }
	    this.calculateDRGLTotalRedAmount();
	    this.calculateControlTotal();
    	}
	  
    }
    ,
    calculateCRGLSystemRedAmount : function() 
    {
    	
    	var balanceAging= this.getBalanceTab();
    	if(balanceAging!==null){
    	var AMT_GTBM_CR=0;
    	var QTY_GTBM_CR=0;
	    AMT_GTBM_CR =  this.getGLAmtGtrBechmarkCr();
	    QTY_GTBM_CR =  this.getGLQtyGtrBechmarkCr();
	    
	    balanceAging.down("#GL_AMT_GTBM_CR").setValue(AMT_GTBM_CR.toFixed(2));
	    balanceAging.down("#GL_QTY_GTBM_CR").setValue(QTY_GTBM_CR);
	    if(AMT_GTBM_CR!== balanceAging.down("#GL_SYSREDAMTCR").getSubmitValue()){
	    	balanceAging.down("#GL_SYSREDAMTCR").setValue(AMT_GTBM_CR.toFixed(2));
	    }
	    this.calculateCRGLTotalRedAmount();
	    this.calculateControlTotal();
    	}
	  
    }
    ,
    
     //SL System Red Amount Calculation
    
    calculateDRSLSystemRedAmount : function() 
    {
    	
    	var reconAging= this.getReconTab();
    	if(reconAging!==null){
    	var AMT_GTBM_DR=0;
    	var QTY_GTBM_DR=0;
    	
	    AMT_GTBM_DR  = this.getSLAmtGtrBechmarkDr();
	    QTY_GTBM_DR = this.getSLQtyGtrBechmarkDr();
	    if(this.agingType=='G'){
		    reconAging.down("#SL_AMT_GTBM_DR").setValue(this.sl_amt_abovebm_dr.toFixed(2));
		    reconAging.down("#SL_QTY_GTBM_DR").setValue(this.sl_qty_abovebm_dr);
	    }else{
	    	reconAging.down("#SL_AMT_GTBM_DR").setValue(AMT_GTBM_DR.toFixed(2));
		    reconAging.down("#SL_QTY_GTBM_DR").setValue(QTY_GTBM_DR);
	    }
	    if(AMT_GTBM_DR!== reconAging.down("#SL_SYSREDAMTDR").getSubmitValue()){
	    	reconAging.down("#SL_SYSREDAMTDR").setValue(AMT_GTBM_DR.toFixed(2));
	    }
	    this.calculateDRSLTotalRedAmount();
	    this.calculateControlTotal();
    	}
	  
    },
    
    calculateCRSLSystemRedAmount : function() 
    {
    	
    	var reconAging= this.getReconTab();
    	if(reconAging!==null){
    	var AMT_GTBM_CR=0;
    	var QTY_GTBM_CR=0;
	    AMT_GTBM_CR =  this.getSLAmtGtrBechmarkCr();
	    QTY_GTBM_CR =  this.getSLQtyGtrBechmarkCr();
	    if(this.agingType=='G'){
		    reconAging.down("#SL_AMT_GTBM_CR").setValue(this.sl_amt_abovebm_cr.toFixed(2));
		    reconAging.down("#SL_QTY_GTBM_CR").setValue(this.sl_qty_abovebm_cr);
	    }else{
	    	reconAging.down("#SL_AMT_GTBM_CR").setValue(AMT_GTBM_CR.toFixed(2));
		    reconAging.down("#SL_QTY_GTBM_CR").setValue(QTY_GTBM_CR);
	    }
	    if(AMT_GTBM_CR!== reconAging.down("#SL_SYSREDAMTCR").getSubmitValue()){
	    	reconAging.down("#SL_SYSREDAMTCR").setValue(AMT_GTBM_CR.toFixed(2));
	    }
	    this.calculateCRSLTotalRedAmount();
	    this.calculateControlTotal();
    	}
	  
    },
    
    //Calculation Status Indicator Updation based on  value of Reportable red amount and Amount at
    //Risk reportable Red amount Values
   updateStatusndicator : function () {	  
    	var balanceAging = this.getBalanceTab();
    	var reconAging=this.getReconTab();
    	var amountatriskpanel=this.getRiskamountTab();
    	var glsysredamountdr= balanceAging.down("#GL_SYSREDAMTDR").getSubmitValue();
    	var glsysredamountcr= Math.abs(balanceAging.down("#GL_SYSREDAMTCR").getSubmitValue());
    	var slsysredamountdr= reconAging.down("#SL_SYSREDAMTDR").getSubmitValue();
    	var slsysredamountcr= Math.abs(reconAging.down("#SL_SYSREDAMTCR").getSubmitValue());
    	var glrptlredamountdr=balanceAging.down("#GL_RPTLREDAMTDR").getSubmitValue();
    	var glrptlredamountcr= Math.abs(balanceAging.down("#GL_RPTLREDAMTCR").getSubmitValue());
    	var slrptlredamountdr=reconAging.down("#SL_RPTLREDAMTDR").getSubmitValue();
    	var slrptlredamountcr= Math.abs(reconAging.down("#SL_RPTLREDAMTCR").getSubmitValue());
    	var amtatriskrptldr=amountatriskpanel.down("#AMT_AT_RISK_RPTL_DR").getSubmitValue();
    	var amtatriskrptlcr=Math.abs(amountatriskpanel.down("#AMT_AT_RISK_RPTL_CR").getSubmitValue());
    	if(balanceAging!==null || reconAging!==null || amountatriskpanel!==null){
    		 if (this.agingType === "G") {
        		//Status Indicator 
                if ( glrptlredamountdr > 0 || glrptlredamountcr > 0 ||  amtatriskrptldr > 0 || amtatriskrptlcr  > 0) {
                	balanceAging.down("#GL_STATUSINDICATOR").setFieldStyle('color: red; background-image: none;');    	
                	balanceAging.down("#GL_STATUSINDICATOR").setValue("Red");
                }
                else {               	
                   balanceAging.down("#GL_STATUSINDICATOR").setFieldStyle('color: green; background-image: none;');
                   balanceAging.down("#GL_STATUSINDICATOR").setValue("Green");
                }
            
            
                if (slrptlredamountdr > 0 ||
                    slrptlredamountcr > 0) {
                    	reconAging.down("#SL_STATUSINDICATOR").setFieldStyle('color: red; background-image: none;');
                    	reconAging.down("#SL_STATUSINDICATOR").setValue("Red");
                }
                else {
                	reconAging.down("#SL_STATUSINDICATOR").setFieldStyle('color: green; background-image: none;');
                	reconAging.down("#SL_STATUSINDICATOR").setValue("Green");
                }
                
                //BenchMark Calculation
                if(glsysredamountdr > 0 || glsysredamountcr > 0){
			    	  balanceAging.down("#GL_BMKVIOLATION").setValue("Yes");
			    }else{
			    	  balanceAging.down("#GL_BMKVIOLATION").setValue("No");
			    }
			    if(this.sl_benchmark_dr===1 || this.sl_benchmark_cr===1){
		    		  reconAging.down("#SL_BMKVIOLATION").setValue("Yes");
		    	}else if (this.sl_benchmark_dr===0 && this.sl_benchmark_cr===0){
		    		  reconAging.down("#SL_BMKVIOLATION").setValue("No");
		    	}
            }

	        else if (this.agingType === "S") {
	        	//Status Indicator 
	            if (slrptlredamountdr > 0 || slrptlredamountcr > 0 ||  amtatriskrptldr > 0 ||
	                amtatriskrptlcr > 0) {
	                	reconAging.down("#SL_STATUSINDICATOR").setFieldStyle('color: red; background-image: none;');
	                	reconAging.down("#SL_STATUSINDICATOR").setValue("Red");
	            }
	            else {
	            	reconAging.down("#SL_STATUSINDICATOR").setFieldStyle('color: green; background-image: none;');
	            	reconAging.down("#SL_STATUSINDICATOR").setValue("Green");
	            }
	            
	            //BenchMark Calculation
	            if(slsysredamountdr > 0 || slsysredamountcr > 0){
			    	  reconAging.down("#SL_BMKVIOLATION").setValue("Yes");
			    }else{
			    	  reconAging.down("#SL_BMKVIOLATION").setValue("No");
			    }
	        }
    }
},
    handleOnCheck : function(){
    	var amountatrisk=this.getRiskamountTab();
    	var tbdCheckBox = amountatrisk.down("#AMT_AT_RISK_TARGET_DT_DR");
    	var targetDate = amountatrisk.down("#RISKTARGETDT");
    	var checkBoxval= amountatrisk.down("#AMT_AT_RISK_TARGET_DATE_DR_HIDDEN");
    	if(tbdCheckBox.checked){
    		targetDate.setValue("");
    		checkBoxval.setValue("1");
			targetDate.disabled = true;	
    		
    	}
    	else{
    		targetDate.disabled = false;
    		checkBoxval.setValue("0");
    	}
    
    },
    
	customFormat: function(field) {
		var val=field.value;
		var newValue;
		if(val === '' || val === null || val === undefined) {
			return null;
		}
		else{
			val= val.toString();
		}
		if(val.indexOf("(") >= 0) {
	    	return val;
	    }
		newValue = val.replace(new RegExp('[,]', 'g'), '');
		newValue = Ext.util.Format.number(newValue, '0,000.00/i');
		if(parseFloat(newValue) < 0){
			newValue = newValue.replace(new RegExp('[-]', 'g'), '');
			newValue = '(' + newValue + ')';
		}
		field.setValue(newValue);
	}
    
});
	

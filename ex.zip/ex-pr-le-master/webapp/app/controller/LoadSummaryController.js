Ext.define('eRecon_web.controller.LoadSummaryController',{
	extend: 'Ext.app.Controller',
	requires:	['eRecon_web.store.LoadSummaryStore', 'eRecon_web.store.LoadSummaryForGridStore'],
	stores:	['eRecon_web.store.LoadSummaryStore', 'eRecon_web.store.LoadSummaryForGridStore'],
	init: function(){
		var me = this;
		this.control({
			'loadsummary_form': {
				boxready: function(cont) {
					me.refresh(cont);
				}
			},
			
			'loadsummary_form button[searchId="refreshButton"]': {
				click: function(btn) {
					var cont = btn.up('loadsummary_form');
					me.refresh(cont);
				}
			},
			
			'loadsummary_form button[searchId="exportToExcelButton"]': {
				click: function(btn) {
					var cont = btn.up('loadsummary_form');
					cont.setLoading("Please wait...");
					Ext.Ajax.request({
						url: 'filedownloadtrigger.up?downloadType=LOADSUMMARY',
						method:'POST', 
						scope : this,
						success : function(response, opts) {
							cont.setLoading(false);
							response = Ext.decode(response.responseText);
							if(response.success){
								Ext.MessageBox.alert('Successful', 
		    							"Your request has been submitted successfully with the request id " + response.scheduleId + ". You should recieve an email on completion.");
							}
							else {
								Ext.MessageBox.alert('Failed', response.message);
							}
						},
						failure : function(err) {
							cont.setLoading(false);
							Ext.MessageBox.alert('Error occured during Load Summary file download.', 'Please try again!');
						}
					}); 
				}
			},

			'loadsummary_form combo': {
				beforequery: function(q) {
					var combo = q.combo;
					combo.store.load({
						callback: function() {
							if (combo.store.getCount() > 0) {
								combo.expand();
								combo.onTypeAhead();
							}
						}
					});
				},
				
				change: function(combo, newValue, oldValue) {
					
					var rec = combo.findRecordByValue(newValue);
					if (rec) {
						var cont = combo.up('loadsummary_form');
						me.refresh(cont, {reconPeriod: newValue, scheduleId: rec.get('scheduleId')});
						me.refreshGrid(newValue);
					}
				}
			},
			
			'loadsummarygridpanel button[action=Refresh]':{
				click: me.refreshGrid
			},	
			
			'loadsummarygridpanel': {
            	load: me.onLoad()
            }
		})
	},
	
	onLoad: function() {
		var store = this.getStore('eRecon_web.store.LoadSummaryForGridStore');
		store.getProxy().extraParams = {
            0: null
        };
		store.load();
	},
	
	refreshGrid: function(reconPeriod) {
		console.log("refresh");
		
		var store = this.getStore('eRecon_web.store.LoadSummaryForGridStore');
		store.getProxy().extraParams = {
            0: reconPeriod
        };
		store.load();
	},
	
	refresh: function(cont, directOptions) {
		var me = this;
		var dirOpt = directOptions || {};
		cont.setLoading(true);
		var store = me.getStore('eRecon_web.store.LoadSummaryStore');
		store.load({
			directOptions: dirOpt,
			callback: function() {
				try {
					Ext.suspendLayouts();
					var rec = store.getAt(0);
					var loadStatus = rec.get('loadStatus').toUpperCase();
					switch (loadStatus) {
						case 'C':
							rec.set('loadStatus','Completed');
							break;
						case 'F':
							rec.set('loadStatus','Failed');
							break;
						case 'R':
							rec.set('loadStatus','Running');
							break;
						case 'E':
							rec.set('loadStatus','Exception');
							break;
					}
					if (!rec) {
						cont.down('form').getForm().reset();
						return;
					}
					var frm = cont.down('form');  
					frm.loadRecord(rec);
	
					/**
					 * Drawing of the statuses starts.
					 */
				
					var drawContainer = cont.down('*[searchId=drawContainer]');
					var currentFields = drawContainer.query('field');
					for (var k = 0; k < currentFields.length; k++) {
						drawContainer.remove(currentFields[k], true);
					}
					var drawComponent = drawContainer.down('draw');
					drawComponent.surface.removeAll(true);
					for (var i = 0; i < store.getCount(); i++) {
						var status;
						var fillColor;
						var strokeColor;
						var fieldStyle;
						var item = store.getAt(i);
						var tooltip = item.get('description');
						var title = item.get('title');
						var status1 = (item.get('status1') || "").toUpperCase();
						var status2 = (item.get('status2') || "").toUpperCase();
						if (status1 == 'SUCCESS' && status2 == 'SUCCESS') {
							strokeColor= "#0B3B0B";
							status = "Success";
							fillColor = "url(#green_2E35EA61193144C0A2FAF17F0F1E4219)";  // gradient, defined in LoadSummaryContainer
							fieldStyle = "color: #FFFFFF; cursor: pointer; !important;";
						}
						else if (status1 == 'FAILED' || status2 == 'FAILED') {
							strokeColor = "#8A0808";
							status = "Failure";
							fillColor = "url(#red_2E35EA61193144C0A2FAF17F0F1E4219)";    // gradient, defined in LoadSummaryContainer
							fieldStyle = "color: #FFFFFF; cursor: pointer; !important;";
						}
						else if (status1 == 'SUCCESS' && status2 != 'SUCCESS') {
							status = "Running";
							strokeColor= "#8A4B08";
							fillColor = "url(#orange_2E35EA61193144C0A2FAF17F0F1E4219)";  // gradient, defined in LoadSummaryContainer
							fieldStyle = "color: #FFFFFF; cursor: pointer; !important;";
						}
						else {
							status = "Not Started";
							fillColor = "url(#gray_2E35EA61193144C0A2FAF17F0F1E4219)";   // gradient, defined in LoadSummaryContainer
							strokeColor = "#AAAAAA";
							fieldStyle = "cursor: pointer; !important;";
						}
	
						var offset = 10 + i*105;
						var path;
						if (i == 0) {
							path = "M "+ offset + " 0 l100 0 l12.5 25 l-12.5 25 l-100 0 c-10 -10 -10 -40 0 -50 z"; 
						}
						else if (i == store.getCount() - 1 ){
							path = "M "+ offset + " 0 l100 0 c12.5 10 12.5 40 0 50 l-100 0 l12.5 -25 l-12.5 -25 z";
						}
						else {
							path = "M "+ offset + " 0 l100 0 l12.5 25 l-12.5 25 l-100 0 l12.5 -25 l-12.5 -25 z";
						}
						var sprite = Ext.create('Ext.draw.Sprite', {
							type: 'path',
							fill: fillColor,
							path: path,
							stroke: strokeColor
						});
						drawComponent.surface.add(sprite);
						sprite.show(true);
						sprite.setStyle({cursor: 'pointer'});
	
						var titleField = Ext.create('Ext.form.field.Display', {
							value: title,
							fieldStyle: fieldStyle,
							x: offset + 15
						});
	
						var statusField = Ext.create('Ext.form.field.Display', {
							value: status,
							fieldStyle: fieldStyle,
							x: offset + 15, y: 25
						});
	
						drawContainer.add([titleField, statusField]);
	
						if (tooltip) {
							titleField.tooltip = tooltip;
							statusField.tooltip = tooltip;
	 					    Ext.create('Ext.tip.ToolTip', {
							    target: sprite.id,
							    html: tooltip,
							    dismissDelay: 0
							});
					    }
					}
					drawContainer.setWidth(105 * store.getCount() + 50);
					cont.doLayout();
				}
				finally {
					Ext.resumeLayouts(true);
					try {
						var arr = drawContainer.query('field');
						for (var j = 0; j < arr.length; j++) {
							if (arr[j].tooltip) {
							    Ext.create('Ext.tip.ToolTip', {
								    target: arr[j].id,
								    html: arr[j].tooltip,
								    dismissDelay: 0
								});
							}    
						}
					}
					catch(e){}
					cont.setLoading(false);
				}
		    } // end of callback
		});
	}


});




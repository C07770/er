Ext.define('eRecon_web.controller.UserMaintenanceController',{
	extend: 'Ext.app.Controller',
	requires:["eRecon_web.store.UserMaintenanceStore"],
	stores:	["eRecon_web.store.UserMaintenanceStore"],
	refs: [{
	       ref: 'userMaintenanceGrid',
	       selector: 'secadmin_usermaintenancegrid'
	    },
	    {
	    	ref: 'searchForm',
	    	selector: 'secadmin_usermaintenancesearch'
	    },
	    {
	    	ref: 'roleSearchForm',
	    	selector: 'secadmin_userrolemappingsearch'
	    }
	    
],
	
	init: function()
	{
		this.control({
			'secadmin_usermaintenancesearch button[action=userMaintenance-search]': {
	            click: this.userMaintenanceSearch
	        },
	        'secadmin_usermaintenancesearch button[action=userMaintenance-add]': {
	            click: this.doAddRecords
	        },
	        'secadmin_usermaintenancesearch button[action=userMaintenance-clear]': {
	            click: this.clearFilterForm
	        },
	        'secadmin_usermaintenancegrid button[action=userMaintenanceExcel-save-button]': {
	        	click: this.saveRecords
	        },
	        'secadmin_usermaintenancegrid  button[action=userMaintenanceExcel-excel]': {
	        	click: this.userMaintenancedownloadfile
	        },
	        "secadmin_usermaintenancegrid": {
	        	clickevent : this.redirectUserRoleMapping
            }
		});
	},
	
	saveRecords: function(){
		
		var store = this.getStore('eRecon_web.store.UserMaintenanceStore');
		var dataArray = [];
		var updateData = store.getUpdatedRecords(); 
		var deleteData = store.getRemovedRecords();
		
		if(updateData.length == 0 && deleteData.length == 0) 
		{
    		Ext.MessageBox.alert( "Alert", "No changes found");
    		return false;
		}
		if(updateData.length != 0)
			{
				Ext.each(updateData, function(item, index, array) {
		        dataArray.push({
					"newData" : item.data,
		        	"previousData" : item.raw,
		        	"modified" : item.modified 
			        });
			    });
			}
		if(deleteData.length != 0)
			{
			Ext.each(deleteData, function(item, index, array) {
		        dataArray.push({
					"deleteData" : item.data
		        });
		    });
			}
		
		var encodedArray = Ext.encode(dataArray);
		eRecon_web.direct.action.UserMaintenanceService.saveRecords(encodedArray, function(p, response) {
	    	store.load();
	    	Ext.MessageBox.alert( "Status", response.result );
	    }); 
	},
	
	clearFilterForm: function(){
		var searchPanel = this.getSearchForm();
		searchPanel.getForm().reset();
		var userMaintenanceStore = this.getUserMaintenanceGrid().getStore();
		userMaintenanceStore.directOptions = {};
		userMaintenanceStore.getProxy().extraParams = {
            0: null
        };
        userMaintenanceStore.load();
	},
	
	userMaintenanceSearch:	function(){
		var searchPanel = this.getSearchForm();
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var userMaintenanceStore = this.getUserMaintenanceGrid().getStore();
		userMaintenanceStore.directOptions = {};
		userMaintenanceStore.getProxy().extraParams = {
            0: formdata
        };
        userMaintenanceStore.loadPage(1,{
            callback: function (records, operation, success) {
            }
        });
	},
	userMaintenancedownloadfile: function(){
		var searchPanel = this.getSearchForm();
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var userMaintenanceStore = this.getUserMaintenanceGrid().getStore();
		Ext.create('eRecon_web.common.ExportToExcelStatusPopup').launchExport(
			'eRecon_web.store.UserMaintenanceStore',
			userMaintenanceStore.total,
			null,
			{0: formdata}
		);
	},
	doAddRecords : function(){
		var searchPanel = this.getSearchForm();
		var userid = searchPanel.down("#soeid-text").getValue();
		var firstName = searchPanel.down("#firstname-text").getValue();
		var lastName  = searchPanel.down("#lastname-text").getValue();
		var country = searchPanel.down("#country-text").getValue();
		var region = searchPanel.down("#region-combo").getValue();
		var email = searchPanel.down("#email-text").getValue();
		var activeFlag = searchPanel.down("#Active-combo").getValue();
		var role = searchPanel.down("#Role-combo").getValue();
		
		if(userid == "" || userid == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>SOEID is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		if(firstName == "" || firstName == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>FirstName is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		if(lastName == "" || lastName == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>LastName is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		if(country == "" || country == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Country is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		if(region == "" || region == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Region is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		if(email == "" || email == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Email is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		if(activeFlag == "" || activeFlag == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>ActiveFlag is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		if(role == "" || role == null){
			Ext.Msg.show({
				title: "Error",
				msg: "<b>Role is required.</b><br>",
				buttons: Ext.Msg.OK,
				icon: Ext.Msg.ERROR
			});						
			return false;
		}
		var form = searchPanel.getForm();
		var formdata = Ext.encode(form.getValues());
		var userMaintenanceStore = this.getUserMaintenanceGrid().getStore();
		userMaintenanceStore.directOptions = {};
		userMaintenanceStore.getProxy().extraParams = {
            0: formdata
        };
        Ext.Msg.show({
			title: "Confirmation",
			msg: "Do you want to insert a record?",
		    buttons: Ext.Msg.OKCANCEL,
		    fn: function(btn) {
				if (btn == 'ok') {
					eRecon_web.direct.action.UserMaintenanceService.doAddRecords(formdata, function(p, response) {
				    	if(response.result != "Error") {
				    		userMaintenanceStore.loadPage(1,{
				                callback: function (records, operation, success) {
				                }
				            });
				            Ext.MessageBox.alert( "Status", response.result);
				    	}else{
				    		Ext.MessageBox.alert( "Status", response.result );
				    	}
				    }); 
				}
			}
		});
		
	},
	redirectUserRoleMapping : function(column, record, rowIndex, colIndex, e){
				var me = this;
		    	console.log(record.get("userid"));
		
		    	me.getController('eRecon_web.controller.MainController')
		    	  .activateCard({view: "eRecon_web.view.UserRoleMapping.UserRoleMappingContainer"},
					function() {	
						var filterPanel = me.getRoleSearchForm();
						filterPanel.getForm().setValues({userid: record.get("userid")});
						var button = filterPanel.down("button[action=userRole-search]");
						button.fireEvent('click', button, Ext.EventObject);
					}
		    	  );
	}
	
});

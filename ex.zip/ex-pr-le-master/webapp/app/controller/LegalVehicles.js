Ext.define("eRecon_web.controller.LegalVehicles", {
  extend:"Ext.app.Controller",
  
  stores:["eRecon_web.store.dashboard.DetailedDataStore", "eRecon_web.store.legalVehicle.LVReportRawDataStore"],
  refs:[{ref:"numOfFullKeys", selector:"ereconweb_dashboard_panel_lvreportsummarypanel grid#numoffullkeys"},
        {ref:"sumOfActivity", selector:"ereconweb_dashboard_panel_lvreportsummarypanel grid#sumofactivity"},
        {ref:"allFullkeysDb",selector:"ereconweb_dashboard_panel_lvreportsummarypanel grid#dbbaloffullkeysgrid"},
        {ref:"allFullkeysCr", selector:"ereconweb_dashboard_panel_lvreportsummarypanel grid#crbalfullkeysgrid"},
        {ref:"allFullkeysNb", selector:"ereconweb_dashboard_panel_lvreportsummarypanel grid#netbalfullkeysgrid"},
        {ref:"numUnSubAcct", selector:"ereconweb_dashboard_panel_lvreportsummarypanel grid#numunsubacctsgrid"},
        {ref:"proofOwnerUn", selector:"ereconweb_dashboard_panel_lvreportsummarypanel grid#unassignedproofowneracctgrid"},
        {ref:"unAssignedAcctOwner", selector:"ereconweb_dashboard_panel_lvreportsummarypanel grid#unassignedacctowneracctsgrid"},
        {ref:"numUnAtstAcct", selector:"ereconweb_dashboard_panel_lvreportsummarypanel grid#numunattacctsgrid"},
        {ref:"numDsgAcct", selector:"ereconweb_dashboard_panel_lvreportsummarypanel grid#numdisagreedacctsgrid"},
        {ref:"rptRedAcct", selector:"ereconweb_dashboard_panel_lvreportsummarypanel grid#reportableredacctgrid"},
        {ref:"rptAtRiskAcct", selector:"ereconweb_dashboard_panel_lvreportsummarypanel grid#reportableatriskgrid"},
        {ref:"acctOver180", selector:"ereconweb_dashboard_panel_lvreportsummarypanel grid#acctover180grid"},
        {ref:"gridsPanel", selector:"ereconweb_dashboard_panel_lvreportsummarypanel"},
        {ref:"lvFiltersForm", selector:"ereconweb_lvsummaryreports_lvfilters"},
        {ref: "filterCrumb", selector: "filtercrumb"},
        {ref:"lvTabs", selector:"erecon_lvsummaryreports_tabpanel"},
        {ref:"lvCbo", selector:"clearablecombobox#lvidfilterfld"},
        {ref:"lvCbo", selector:"clearablecombobox#lvidfilterfld"},
        {ref:"regionCbo", selector:"clearablecombobox#regionfilterfld"},
        {ref:"countryCbo", selector:"clearablecombobox#countryfilterfld"},
        {ref:"bssacctCbo", selector:"clearablecombobox#bssacctfilterfld"},
        {ref:"centsiteCbo", selector:"clearablecombobox#centsitefilterfld"},
        {ref:"ssiglCbo", selector:"clearablecombobox#ssidglfilterfld"},
        {ref:"frsbizunitCbo", selector:"clearablecombobox#frsbizunitfilterfld"},
        {ref:"lrptnumvCbo", selector:"clearablecombobox#lvrptnumfilterfld"},
        {ref:"pocityCbo", selector:"clearablecombobox#pocityfilterfld"},
        {ref:"proofownerCbo", selector:"clearablecombobox#proofownerfilterfld"},
        {ref:"acctownerCbo", selector:"clearablecombobox#acctownerfilterfld"},
        {ref:"contdelegateCbo", selector:"clearablecombobox#contdelegatefilterfld"},
        {ref:"fincontnameCbo", selector:"clearablecombobox#fincontnamefilterfld"},
        {ref:"frsacctCbo", selector:"clearablecombobox#frsacctfilterfld"},
        {ref:"reconperiodCbo", selector:"combo#lvreconperiodfld"},
        
        {ref:"recontypeCbo", selector:"clearablecombobox#recontypefilterfld"},
        {ref:"ccCbo", selector:"clearablecombobox#ccfilterfld"},
        {ref:"glsidCbo", selector:"clearablecombobox#glsidfilterfld"},
        {ref:"aodmdn05Cbo", selector:"clearablecombobox#aodmdn05filterfld"},
        {ref:"arcmemberCbo", selector:"clearablecombobox#arcmemberfilterfld"},
      //{ref:"glsinCbo", selector:"clearablecombobox#glsinfilterfld"},
        {ref:"aodmdn04Cbo", selector:"clearablecombobox#aodmn04filterfld"},
        {ref:"strategicPartnerCbo", selector:"clearablecombobox#strategicPartnerfilterfld"},
        {ref:'detailedpopup', selector: 'detailedpopup'},
        {ref:'runKPIReportBtn', selector: 'ereconweb_lvsummaryreports_lvfilters button#runkpireports'}
        
        
  ],
 headers : [{text:"", dataIndex:"eReconP0Data", flex:2, align:"left"}],
  
  init: function() {
	  this.control({
	    "ereconweb_lvsummaryreports_lvfilters button#runkpireports": {
	      "click": this.handleFilters
	     },
	     "erecon_lvsummaryreports_tabpanel":{
	    	 "boxready":this.handleReconPeriodFilter
	     },
	     "ereconweb_dashboard_panel_lvreportsummarypanel grid": {
	    	 "itemclick": this.handleDetailedPopup
	     },
	     "ereconweb_dashboard_panel_lvreportsummarypanel button#kpiemailbtn": {
	    	 "click": this.handleEmailBtnClick
	     },
	     "ereconweb_dashboard_panel_lvreportsummarypanel button#pptExportBtn": {
    	 "click": this.handlePptExportBtnClick
     },
	     "ereconweb_dashboard_panel_lvreportsummarypanel toolbar combo#lvreconperiodfld": {
	    	 "reconperiodfilter": this.handleFilters
	     },
	     "ereconweb_dashboard_panel_lvreportsummarypanel toolbar combo#lvreconperiodfld": {
	    	 "change": this.handleReconPeriodSelecct
	     },
	     
        'detailedpopup button[action=KPIDetailsExcel]': {
        	click: this.kpiDetailsExcelDownload
       },
       "ereconweb_lvsummaryreports_lvfilters clearablecombobox": {
      	 "keyup":this.handleLVFiltersTypeAhead
       }
	  });
  },
  handleReconPeriodSelecct : function(combo,newVal,oldVal){
	  var oRec=combo.findRecordByValue(oldVal);
	  oRec && combo.inputEl.removeCls('comboSelectedItem');
	  if(newVal==Ext.util.Cookies.get('currentReconPeriod')){var nRec=combo.findRecordByValue(newVal);
	  nRec && combo.inputEl.addCls('comboSelectedItem');}
	  if(this.getLvTabs().getActiveTab().title=="Metrics Dashboard"){
		  this.handleFilters();
	  }
  },
  
  handleFilters: function(o_) {  	
  	//if(o_!=undefined && !o_.reconperiod) {}
  	if(o_!=undefined && !o_.reconperiod){
      this.getLvTabs().setActiveTab(1); 
      this.assembleFilterCrumbs(); 
    }
    this.assembleDynamicCols();
    
    //this.getGridsPanel().setLoading(true);    
                         
  	var numFullKeysGrid = this.getNumOfFullKeys();
  	var sumOfActivityGrid = this.getSumOfActivity(), allFullkeysDbGrid = this.getAllFullkeysDb(), allFullkeysCrGrid= this.getAllFullkeysCr(),
      	allFullkeysNbGrid = this.getAllFullkeysNb(), unassignedProofOwnerGrid = this.getProofOwnerUn(), numUnSubAcctGrid = this.getNumUnSubAcct(),
      	unAssignedAcctOwnerGrid = this.getUnAssignedAcctOwner(), numUnAtstAcctGrid = this.getNumUnAtstAcct(), numDsgAcctGrid = this.getNumDsgAcct(),
      	rptRedAcctGrid = this.getRptRedAcct(), rptAtRiskAcctGrid = this.getRptAtRiskAcct(), acctOver180Grid = this.getAcctOver180();
  	    
    var lvCboVal = this.getLvCbo().getValue() ? this.getLvCbo().getValue() : "";
  	
  	var regionCboVal = this.getRegionCbo().getValue() ? this.getRegionCbo().getValue() : "";
  	
  	var countryCboVal = this.getCountryCbo().getValue() ? this.getCountryCbo().getValue() : "";
  	
  	var bssacctCboVal = this.getBssacctCbo().getValue() ? this.getBssacctCbo().getValue() : "";
  	
  	var centsiteCboVal = this.getCentsiteCbo().getValue() ? this.getCentsiteCbo().getValue() : "";
  	
  	var ssiglCboVal = this.getSsiglCbo().getValue() ? this.getSsiglCbo().getValue() : "";
  	
  	var frsbizunitCboVal = this.getFrsbizunitCbo().getValue() ? this.getFrsbizunitCbo().getValue() : "";
  	
  	var lrptnumvCboVal = this.getLrptnumvCbo().getValue() ? this.getLrptnumvCbo().getValue() : "";
  	
  	var pocityCboVal = this.getPocityCbo().getValue() ? this.getPocityCbo().getValue() : "";
  	var proofownerCboVal = this.getProofownerCbo().getValue() ? this.getProofownerCbo().getValue() : "";
  	var acctownerCboVal = this.getAcctownerCbo().getValue() ? this.getAcctownerCbo().getValue() : "";
  	var contdelegateCboVal = this.getContdelegateCbo().getValue() ? this.getContdelegateCbo().getValue() : "";
  	var fincontnameCboVal = this.getFincontnameCbo().getValue() ? this.getFincontnameCbo().getValue() : "";
  	var frsacctCboVal = this.getFrsacctCbo().getValue() ? this.getFrsacctCbo().getValue() : "";
  	var reconperiodCboVal = this.getReconperiodCbo().getValue() ? this.getReconperiodCbo().getValue() : "";  	
  	var recontypeCboVal = this.getRecontypeCbo().getValue() ? this.getRecontypeCbo().getValue() : ""; 
  	var ccCboVal = this.getCcCbo().getValue() ? this.getCcCbo().getValue() : "";
  	var glsidCboVal = this.getGlsidCbo().getValue() ? this.getGlsidCbo().getValue() : ""; 
  	var aodmdn05CboVal = this.getAodmdn05Cbo().getValue() ? this.getAodmdn05Cbo().getValue() : "";
  	var arcmemberCboVal = this.getArcmemberCbo().getValue() ? this.getArcmemberCbo().getValue() : "";
  	//var glsinCboVal = this.getGlsinCbo().getValue() ? this.getGlsinCbo().getValue() : "";
  	var aodmdn04CboVal = this.getAodmdn04Cbo().getValue() ? this.getAodmdn04Cbo().getValue() : "";   	
  	var strategicPartnerCboVal = this.getStrategicPartnerCbo().getValue() ? this.getStrategicPartnerCbo().getValue() : "";
  	
  	var maskSofAcGrid = new Ext.LoadMask(sumOfActivityGrid.getEl(),{msg:"Loading..."});
  	
  	sumOfActivityGrid.getStore().on('beforeload',function(){
  		//maskSofAcGrid.center();	maskSofAcGrid.show();
  		//Ext.ComponentQuery.query("ereconweb_lvsummaryreports_lvfilters#filtersTab")[0].setLoading("Preparing Filters...");
  	});
  	sumOfActivityGrid.getStore().on('load',function(){
  		//var mask = new Ext.LoadMask(Ext.getBody(),{msg:"Please wait..."});
  		//mask.show();
  		//maskSofAcGrid.hide();
//  		if(sumOfActivityGrid.loadflag){
//  			var mask = new Ext.LoadMask(Ext.getBody(),{msg:""});
//  			mask.hide();
//  		}
//  		sumOfActivityGrid.loadflag=true;
  	});
  	
  	
  	sumOfActivityGrid.getStore().load({params:["GLOBAL", lvCboVal, regionCboVal, countryCboVal, bssacctCboVal, centsiteCboVal, ssiglCboVal, frsbizunitCboVal, lrptnumvCboVal, pocityCboVal, proofownerCboVal, acctownerCboVal, contdelegateCboVal, fincontnameCboVal, frsacctCboVal, reconperiodCboVal,recontypeCboVal,ccCboVal,glsidCboVal,aodmdn05CboVal,arcmemberCboVal,aodmdn04CboVal,strategicPartnerCboVal]});
  	
  	/*var masknumGrid = new Ext.LoadMask(numFullKeysGrid.getEl(),{msg:"Loading..."});
  	
  	numFullKeysGrid.getStore().on('beforeload',function(){
  		masknumGrid.center(); masknumGrid.show();
  	});
  	numFullKeysGrid.getStore().on('load',function(){
  		
  	});
  	
  	var maskSofAcGrid = new Ext.LoadMask(sumOfActivityGrid.getEl(),{msg:"Loading..."});
  	
  	sumOfActivityGrid.getStore().on('beforeload',function(){
  		maskSofAcGrid.center();	maskSofAcGrid.show();
  	});
  	sumOfActivityGrid.getStore().on('load',function(){
  		maskSofAcGrid.hide();
  	});
  	
  	
    var maskallFullkeysDbGrid = new Ext.LoadMask(allFullkeysDbGrid.getEl(),{msg:"Loading..."});
  	
  	allFullkeysDbGrid.getStore().on('beforeload',function(){
  		maskallFullkeysDbGrid.center();	maskallFullkeysDbGrid.show();
  	});
  	allFullkeysDbGrid.getStore().on('load',function(){
  		maskallFullkeysDbGrid.hide();
  	});
  	
  	var maskallFullkeysCrGrid = new Ext.LoadMask(allFullkeysCrGrid.getEl(),{msg:"Loading..."});
  	
  	allFullkeysCrGrid.getStore().on('beforeload',function(){
  		maskallFullkeysCrGrid.center();	maskallFullkeysCrGrid.show();
  	});
  	allFullkeysCrGrid.getStore().on('load',function(){
  		maskallFullkeysCrGrid.hide();
  	});
  	
  	var maskallFullkeysNbGrid = new Ext.LoadMask(allFullkeysNbGrid.getEl(),{msg:"Loading..."});
  	
  	allFullkeysNbGrid.getStore().on('beforeload',function(){
  		maskallFullkeysNbGrid.center();	maskallFullkeysNbGrid.show();
  	});
  	allFullkeysNbGrid.getStore().on('load',function(){
  		maskallFullkeysNbGrid.hide();
  	});
  	
  	var maskunassignedProofOwnerGrid = new Ext.LoadMask(unassignedProofOwnerGrid.getEl(),{msg:"Loading..."});
  	
  	unassignedProofOwnerGrid.getStore().on('beforeload',function(){
  		maskunassignedProofOwnerGrid.center();	maskunassignedProofOwnerGrid.show();
  	});
  	unassignedProofOwnerGrid.getStore().on('load',function(){
  		maskunassignedProofOwnerGrid.hide();
  	});
  	
  	var masknumUnSubAcctGrid = new Ext.LoadMask(numUnSubAcctGrid.getEl(),{msg:"Loading..."});
  	
  	numUnSubAcctGrid.getStore().on('beforeload',function(){
  		masknumUnSubAcctGrid.center();	masknumUnSubAcctGrid.show();
  	});
  	numUnSubAcctGrid.getStore().on('load',function(){
  		masknumUnSubAcctGrid.hide();
  	});
  	
  	var maskunAssignedAcctOwnerGrid = new Ext.LoadMask(unAssignedAcctOwnerGrid.getEl(),{msg:"Loading..."});
  	
  	unAssignedAcctOwnerGrid.getStore().on('beforeload',function(){
  		maskunAssignedAcctOwnerGrid.center();	maskunAssignedAcctOwnerGrid.show();
  	});
  	unAssignedAcctOwnerGrid.getStore().on('load',function(){
  		maskunAssignedAcctOwnerGrid.hide();
  	});
  	
  	var masknumUnAtstAcctGrid = new Ext.LoadMask(numUnAtstAcctGrid.getEl(),{msg:"Loading..."});
  	
  	numUnAtstAcctGrid.getStore().on('beforeload',function(){
  		masknumUnAtstAcctGrid.center();	masknumUnAtstAcctGrid.show();
  	});
  	numUnAtstAcctGrid.getStore().on('load',function(){
  		masknumUnAtstAcctGrid.hide();
  	});
  	
  	var masknumDsgAcctGrid = new Ext.LoadMask(numDsgAcctGrid.getEl(),{msg:"Loading..."});
  	
  	numDsgAcctGrid.getStore().on('beforeload',function(){
  		masknumDsgAcctGrid.center();	masknumDsgAcctGrid.show();
  	});
  	numDsgAcctGrid.getStore().on('load',function(){
  		masknumDsgAcctGrid.hide();
  	});
  	
  	var maskrptRedAcctGrid = new Ext.LoadMask(rptRedAcctGrid.getEl(),{msg:"Loading..."});
  	
  	rptRedAcctGrid.getStore().on('beforeload',function(){
  		maskrptRedAcctGrid.center();	maskrptRedAcctGrid.show();
  	});
  	rptRedAcctGrid.getStore().on('load',function(){
  		maskrptRedAcctGrid.hide();
  	});
  	
  	var maskrptAtRiskAcctGrid = new Ext.LoadMask(rptAtRiskAcctGrid.getEl(),{msg:"Loading..."});
  	
  	rptAtRiskAcctGrid.getStore().on('beforeload',function(){
  		maskrptAtRiskAcctGrid.center();	maskrptAtRiskAcctGrid.show();
  	});
  	rptAtRiskAcctGrid.getStore().on('load',function(){
  		maskrptAtRiskAcctGrid.hide();
  	});
  	
  	var maskacctOver180Grid = new Ext.LoadMask(acctOver180Grid.getEl(),{msg:"Loading..."});
  	
  	acctOver180Grid.getStore().on('beforeload',function(){
  		maskacctOver180Grid.center();	maskacctOver180Grid.show();
  	});
  	acctOver180Grid.getStore().on('load',function(){
  		maskacctOver180Grid.hide();
  	});
  	
  	 	 
 
  	numFullKeysGrid.getStore().load({params:["GLOBAL", lvCboVal, regionCboVal, countryCboVal, bssacctCboVal, centsiteCboVal, ssiglCboVal, frsbizunitCboVal, lrptnumvCboVal, pocityCboVal, proofownerCboVal, acctownerCboVal, contdelegateCboVal, fincontnameCboVal, frsacctCboVal, reconperiodCboVal,recontypeCboVal,ccCboVal,glsidCboVal,aodmdn05CboVal,arcmemberCboVal,aodmdn04CboVal,strategicPartnerCboVal],
  		scope:this,
 		  callback:function(){
 			// this.getLvTabs().setLoading(false);
  		masknumGrid.hide();
		}}); 	  
  		 
    allFullkeysDbGrid.getStore().load({params:["GLOBAL", lvCboVal, regionCboVal, countryCboVal, bssacctCboVal, centsiteCboVal, ssiglCboVal, frsbizunitCboVal, lrptnumvCboVal, pocityCboVal, proofownerCboVal, acctownerCboVal, contdelegateCboVal, fincontnameCboVal, frsacctCboVal, reconperiodCboVal,recontypeCboVal,ccCboVal,glsidCboVal,aodmdn05CboVal,arcmemberCboVal,aodmdn04CboVal,strategicPartnerCboVal]});
    allFullkeysCrGrid.getStore().load({params:["GLOBAL", lvCboVal, regionCboVal, countryCboVal, bssacctCboVal, centsiteCboVal, ssiglCboVal, frsbizunitCboVal, lrptnumvCboVal, pocityCboVal, proofownerCboVal, acctownerCboVal, contdelegateCboVal, fincontnameCboVal, frsacctCboVal, reconperiodCboVal,recontypeCboVal,ccCboVal,glsidCboVal,aodmdn05CboVal,arcmemberCboVal,aodmdn04CboVal,strategicPartnerCboVal]});
    allFullkeysNbGrid.getStore().load({params:["GLOBAL", lvCboVal, regionCboVal, countryCboVal, bssacctCboVal, centsiteCboVal, ssiglCboVal, frsbizunitCboVal, lrptnumvCboVal, pocityCboVal, proofownerCboVal, acctownerCboVal, contdelegateCboVal, fincontnameCboVal, frsacctCboVal, reconperiodCboVal,recontypeCboVal,ccCboVal,glsidCboVal,aodmdn05CboVal,arcmemberCboVal,aodmdn04CboVal,strategicPartnerCboVal]});
    unassignedProofOwnerGrid.getStore().load({params:["GLOBAL", lvCboVal, regionCboVal, countryCboVal, bssacctCboVal, centsiteCboVal, ssiglCboVal, frsbizunitCboVal, lrptnumvCboVal, pocityCboVal, proofownerCboVal, acctownerCboVal, contdelegateCboVal, fincontnameCboVal, frsacctCboVal, reconperiodCboVal,recontypeCboVal,ccCboVal,glsidCboVal,aodmdn05CboVal,arcmemberCboVal,aodmdn04CboVal,strategicPartnerCboVal]});
    numUnSubAcctGrid.getStore().load({params:["GLOBAL", lvCboVal, regionCboVal, countryCboVal, bssacctCboVal, centsiteCboVal, ssiglCboVal, frsbizunitCboVal, lrptnumvCboVal, pocityCboVal, proofownerCboVal, acctownerCboVal, contdelegateCboVal, fincontnameCboVal, frsacctCboVal, reconperiodCboVal,recontypeCboVal,ccCboVal,glsidCboVal,aodmdn05CboVal,arcmemberCboVal,aodmdn04CboVal,strategicPartnerCboVal]});
    //unassignedProofOwnerGrid.getStore().load({params:["UN_AO", lvCboVal, regionCboVal, countryCboVal, bssacctCboVal, centsiteCboVal, ssiglCboVal, frsbizunitCboVal, lrptnumvCboVal, pocityCboVal, proofownerCboVal, acctownerCboVal, contdelegateCboVal, fincontnameCboVal, frsacctCboVal, reconperiodCboVal]});
    //numUnSubAcctGrid.getStore().load({params:["UNSUBMITTED", lvCboVal, regionCboVal, countryCboVal, bssacctCboVal, centsiteCboVal, ssiglCboVal, frsbizunitCboVal, lrptnumvCboVal, pocityCboVal, proofownerCboVal, acctownerCboVal, contdelegateCboVal, fincontnameCboVal, frsacctCboVal, reconperiodCboVal]});
    unAssignedAcctOwnerGrid.getStore().load({params:["GLOBAL", lvCboVal, regionCboVal, countryCboVal, bssacctCboVal, centsiteCboVal, ssiglCboVal, frsbizunitCboVal, lrptnumvCboVal, pocityCboVal, proofownerCboVal, acctownerCboVal, contdelegateCboVal, fincontnameCboVal, frsacctCboVal, reconperiodCboVal,recontypeCboVal,ccCboVal,glsidCboVal,aodmdn05CboVal,arcmemberCboVal,aodmdn04CboVal,strategicPartnerCboVal]});
    numUnAtstAcctGrid.getStore().load({params:["GLOBAL", lvCboVal, regionCboVal, countryCboVal, bssacctCboVal, centsiteCboVal, ssiglCboVal, frsbizunitCboVal, lrptnumvCboVal, pocityCboVal, proofownerCboVal, acctownerCboVal, contdelegateCboVal, fincontnameCboVal, frsacctCboVal, reconperiodCboVal,recontypeCboVal,ccCboVal,glsidCboVal,aodmdn05CboVal,arcmemberCboVal,aodmdn04CboVal,strategicPartnerCboVal]});
    numDsgAcctGrid.getStore().load({params:["GLOBAL", lvCboVal, regionCboVal, countryCboVal, bssacctCboVal, centsiteCboVal, ssiglCboVal, frsbizunitCboVal, lrptnumvCboVal, pocityCboVal, proofownerCboVal, acctownerCboVal, contdelegateCboVal, fincontnameCboVal, frsacctCboVal, reconperiodCboVal,recontypeCboVal,ccCboVal,glsidCboVal,aodmdn05CboVal,arcmemberCboVal,aodmdn04CboVal,strategicPartnerCboVal]});
    rptRedAcctGrid.getStore().load({params:["GLOBAL", lvCboVal, regionCboVal, countryCboVal, bssacctCboVal, centsiteCboVal, ssiglCboVal, frsbizunitCboVal, lrptnumvCboVal, pocityCboVal, proofownerCboVal, acctownerCboVal, contdelegateCboVal, fincontnameCboVal, frsacctCboVal, reconperiodCboVal,recontypeCboVal,ccCboVal,glsidCboVal,aodmdn05CboVal,arcmemberCboVal,aodmdn04CboVal,strategicPartnerCboVal]});
    rptAtRiskAcctGrid.getStore().load({params:["GLOBAL", lvCboVal, regionCboVal, countryCboVal, bssacctCboVal, centsiteCboVal, ssiglCboVal, frsbizunitCboVal, lrptnumvCboVal, pocityCboVal, proofownerCboVal, acctownerCboVal, contdelegateCboVal, fincontnameCboVal, frsacctCboVal, reconperiodCboVal,recontypeCboVal,ccCboVal,glsidCboVal,aodmdn05CboVal,arcmemberCboVal,aodmdn04CboVal,strategicPartnerCboVal]});
    acctOver180Grid.getStore().load({params:["GLOBAL", lvCboVal, regionCboVal, countryCboVal, bssacctCboVal, centsiteCboVal, ssiglCboVal, frsbizunitCboVal, lrptnumvCboVal, pocityCboVal, proofownerCboVal, acctownerCboVal, contdelegateCboVal, fincontnameCboVal, frsacctCboVal, reconperiodCboVal,recontypeCboVal,ccCboVal,glsidCboVal,aodmdn05CboVal,arcmemberCboVal,aodmdn04CboVal,strategicPartnerCboVal]});
*/
  },
  
  assembleDynamicCols: function() { 	 
//  	var mask = new Ext.LoadMask(Ext.getBody(),{msg:"Please wait..."});
  	var me=this;
//	  mask.show();
    console.log("assemble");  
    var grids = this.getGridsPanel(); 		  	     
    var reconperiodCboVal = this.getReconperiodCbo().getValue();
    this.headers = [{text:"Metric", dataIndex:"metric", flex:1.4,menuDisabled:true, align:"left",sortable:false, renderer:grids.metricsRenderer},{text:"Detail",menuDisabled:true, dataIndex:"detail",sortable:false, flex:2, renderer:grids.activeRenderer}];
    eRecon_web.direct.action.LegalVehicleService.getLVReportHeader(reconperiodCboVal ? reconperiodCboVal:"",function(p,response){
    	console.log(response);
      var counter = 0;
	    	    	   
	    for(var header in response.result[0]){	    		
  	    counter++;
	      me.headers.push({text:response.result[0][header], dataIndex:"eReconP"+counter+"Data", flex:1,sortable:false, align:"left",menuDisabled:true,menuDisabled:true, renderer:grids["monthRenderer"]
	      });	    
      }	
	    me.headers.push({text:"% Change", dataIndex:"change", flex:1,sortable:false, align:"left",menuDisabled:true, renderer:grids.changeRenderer},{text:"Amount Variance",menuDisabled:true, dataIndex:"amtVariance", flex:1,sortable:false, align:"left", renderer:grids.varianceRenderer},
	                    {text:"Trend", dataIndex:"trend", flex:0.5,sortable:false,menuDisabled:true, align:"left", renderer:grids.trendRenderer});
	    for(var i = 1; i<grids.items.items.length; i++) {
	    	if(grids.items.items[i].xtype === "grid") {	    		
	        grids.items.items[i].reconfigure(undefined,me.headers);	        
	    	}
	    }	    
    });             
//    mask.hide();
  },  
  
  handleDetailedPopup: function(t, rec, item, index, e, eOpts) {
		if (e.target.className == 'cell-expand') {
			
			var lvCboVal = this.getLvCbo().getValue() ? this.getLvCbo().getValue() : "";
			var regionCboVal = this.getRegionCbo().getValue() ? this.getRegionCbo().getValue() : "";
			var countryCboVal = this.getCountryCbo().getValue() ? this.getCountryCbo().getValue() : "";
			var bssacctCboVal = this.getBssacctCbo().getValue() ? this.getBssacctCbo().getValue() : "";
			var centsiteCboVal = this.getCentsiteCbo().getValue() ? this.getCentsiteCbo().getValue() : "";
			var ssiglCboVal = this.getSsiglCbo().getValue() ? this.getSsiglCbo().getValue() : "";
			var frsbizunitCboVal = this.getFrsbizunitCbo().getValue() ? this.getFrsbizunitCbo().getValue() : "";
			var lrptnumvCboVal = this.getLrptnumvCbo().getValue() ? this.getLrptnumvCbo().getValue() : "";
			var pocityCboVal = this.getPocityCbo().getValue() ? this.getPocityCbo().getValue() : "";
			var proofownerCboVal = this.getProofownerCbo().getValue() ? this.getProofownerCbo().getValue() : "";
			var acctownerCboVal = this.getAcctownerCbo().getValue() ? this.getAcctownerCbo().getValue() : "";
			var contdelegateCboVal = this.getContdelegateCbo().getValue() ? this.getContdelegateCbo().getValue() : "";
			var fincontnameCboVal = this.getFincontnameCbo().getValue() ? this.getFincontnameCbo().getValue() : "";
			var frsacctCboVal = this.getFrsacctCbo().getValue() ? this.getFrsacctCbo().getValue() : "";
			var reconperiodCboVal = this.getReconperiodCbo().getValue() ? this.getReconperiodCbo().getValue() : "";  	
			var recontypeCboVal = this.getRecontypeCbo().getValue() ? this.getRecontypeCbo().getValue() : ""; 
			var ccCboVal = this.getCcCbo().getValue() ? this.getCcCbo().getValue() : "";
			var glsidCboVal = this.getGlsidCbo().getValue() ? this.getGlsidCbo().getValue() : ""; 
			var aodmdn05CboVal = this.getAodmdn05Cbo().getValue() ? this.getAodmdn05Cbo().getValue() : "";
			var arcmemberCboVal = this.getArcmemberCbo().getValue() ? this.getArcmemberCbo().getValue() : "";
			//	var glsinCboVal = this.getGlsinCbo().getValue() ? this.getGlsinCbo().getValue() : "";
			var aodmdn04CboVal = this.getAodmdn04Cbo().getValue() ? this.getAodmdn04Cbo().getValue() : ""; 
			var strategicPartnerCboVal = this.getStrategicPartnerCbo().getValue() ? this.getStrategicPartnerCbo().getValue() : "";	
	  	
		  	var utility = e.target.getAttribute("dataIndex");
		    var coulmnPeriod = "";
	    	//var gridId=e.target.getAttribute("gridId");	
		    var gridHeaders= this.headers;
		    
		   Ext.defer(function() {
				var v = Ext.create('eRecon_web.view.dashboard.DetailedPopup');		
	  			var grid= v.items.items[0];
	  			//grid.store= 'eRecon_web.store.legalVehicle.LVReportRawDataStore';
	  			for (var i=0; i<gridHeaders.length; i++) {
					if(gridHeaders[i].dataIndex==utility){
						coulmnPeriod = gridHeaders[i].text;
						break;
					}
				}
	    			
				var s  = 'Detailed data for ';
					s += 'Utility: ' + coulmnPeriod;
					v.setTitle(s)
	  			v.center();
	  			var mask = new Ext.LoadMask(Ext.getBody(),{msg:"Please wait..."});
	 			mask.show();
	 			v.show();
	 			var otherValues=rec.data.eReconP7Data;
			  	var otherValuesArr=otherValues.split("+");
			  	
			  	var lvReportRawDataStore = grid.getStore('eRecon_web.store.legalVehicle.LVReportRawDataStore');
			  	lvReportRawDataStore.currentPage = 1;
			  	lvReportRawDataStore.savedDirectOptions = {};
			  	lvReportRawDataStore.on('beforeload', function(){
					var dataArray={
						dashboardType: otherValuesArr[1], 
						LVID: lvCboVal, 
						REGION: regionCboVal, 
						COUNTRY: countryCboVal, 
						BSS_ACCT_TYPE: bssacctCboVal, 
						CENTRALIZED_SITE: centsiteCboVal, 
						SSID_GL: ssiglCboVal, 
						FRS_BU: frsbizunitCboVal, 
						LV_RPT_NUM: lrptnumvCboVal, 
						PO_CITY: pocityCboVal, 
						PROOF_OWNER: proofownerCboVal, 
						ACCT_OWNER: acctownerCboVal, 
						CONTROLLER_DELEGATE: contdelegateCboVal, 
						FINANCIAL_CONTROLLER: fincontnameCboVal, 
						FRS_ACCOUNT: frsacctCboVal, 
						RECONPERIOD: coulmnPeriod,
						RECONTYPE: recontypeCboVal,
						COSTCENTER: ccCboVal,
						GLSI_DESCR: glsidCboVal,
						AO_MANAGER_L05: aodmdn05CboVal,
						ARC: arcmemberCboVal,
						AO_MANAGER_L04: aodmdn04CboVal,
						STRATEGIC_PARTNER: strategicPartnerCboVal,
						ROWTYPE: otherValuesArr[0] ? otherValuesArr[0]: ""         
				    };
				    var encodedArray = Ext.encode(dataArray);
				    lvReportRawDataStore.getProxy().extraParams = {0 : encodedArray
				    };
				});
				lvReportRawDataStore.load();
				mask.hide();
	 		},100);
	 	
		}
  },
  
  handleReconPeriodFilter:function(){
  	this.getLvTabs().setActiveTab(0);
  	//if(!(this.getLvTabs().getActiveTab().title=="Metrics Dashboard")){
  	//this.getLvTabs().getActiveTab().setLoading("Preparing Filters...");}
  	Ext.ComponentQuery.query("ereconweb_lvsummaryreports_lvfilters#filtersTab")[0].setLoading("Preparing Filters...");
  	this.getReconperiodCbo().getStore().load({params:"RECONPERIOD", scope:this,
  		callback:function(){  			
  			//var selectRecord = this.getReconperiodCbo().getStore().getAt(0);
  			//this.getReconperiodCbo().setValue(selectRecord);
  			Ext.ComponentQuery.query("ereconweb_lvsummaryreports_lvfilters#filtersTab")[0].setLoading(false);
  			// this.getLvTabs().getActiveTab().setLoading(false); 		  	    
  			//this.handleFilters({reconperiod:true});
  		}
  	});
  },
  
  assembleFilterCrumbs: function() {
	
  	this.getFilterCrumb().removeFilter();
  	var valid, labelValue, values = this.getLvFiltersForm().getForm()._fields.items;
    for(var i = 0; i<values.length; i++) {  	  
		  if(values[i].value) {
		  	if(values[i].name == "Strategic Site" || values[i].name == "LVID" || values[i].name == "FRS Business Unit" || values[i].name == "GL System ID Description") {
	  			labelValue = values[i].name +": " + values[i].getRawValue();
	  		}
		  	
		  	else if(values[i].value === values[i].getRawValue()) {
		  		labelValue = values[i].name +": "+values[i].getValue();
		  	}
		  
		    else {
		  		labelValue = values[i].name +": "+values[i].getValue() + "("+values[i].getRawValue()+")";
		  	}		  
			  valid = true;
			  this.getFilterCrumb().addFilter({labelCategory: "", labelValue: labelValue,
		    filterValue: "", filterParam: ""});
		  }
		  if(valid) {
  		  this.getFilterCrumb().show();this.getFilterCrumb().enable();
		  }else if(this.getFilterCrumb().filtersExists()){
			  
			  this.getFilterCrumb().hide();this.getFilterCrumb().disable();
		  }
  	}
  },
	
	kpiDetailsExcelDownload: function(){
		var lvReportRawDataStore = this.getStore("eRecon_web.store.legalVehicle.LVReportRawDataStore");
		//-----------------------------------------------------------------------------
		if (lvReportRawDataStore !== null) {
			var firstRec = lvReportRawDataStore.getAt(0);
			//var otherValues=firstRec.data.eReconP7Data;
			//var otherValuesArr=otherValues.split("+");
			
			var reconPeriod = firstRec.get("reconperiod");
			var dashboardType = firstRec.get("dashboardType");
			var rowType = firstRec.get("rowType");
			var lvCboVal = this.getLvCbo().getValue();
			var regionCboVal = this.getRegionCbo().getValue();
			var countryCboVal = this.getCountryCbo().getRawValue();
			var bssacctCboVal = this.getBssacctCbo().getValue();
			var centsiteCboVal = this.getCentsiteCbo().getRawValue();
			var ssiglCboVal = this.getSsiglCbo().getValue();
			var frsbizunitCboVal = this.getFrsbizunitCbo().getValue();
			var lrptnumvCboVal = this.getLrptnumvCbo().getValue();
			var pocityCboVal = this.getPocityCbo().getValue();
			var proofownerCboVal = this.getProofownerCbo().getValue();
			var acctownerCboVal = this.getAcctownerCbo().getValue();
			var contdelegateCboVal = this.getContdelegateCbo().getValue();
			var fincontnameCboVal = this.getFincontnameCbo().getValue();
			var frsacctCboVal = this.getFrsacctCbo().getValue();
			var recontypeCboVal = this.getRecontypeCbo().getValue(); 
			var ccCboVal = this.getCcCbo().getValue();
			var glsidCboVal = this.getGlsidCbo().getValue(); 
			var aodmdn05CboVal = this.getAodmdn05Cbo().getValue();
			var arcmemberCboVal = this.getArcmemberCbo().getValue();
			var aodmdn04CboVal = this.getAodmdn04Cbo().getValue(); 
			var strategicPartnerCboVal = this.getStrategicPartnerCbo().getValue();	
			

			var userRole = 'GPO BSS DASHBOARD USER';
			/* 
			//to validate user role
			var dataArray = { userRole: userRole };
			var encodedArray = Ext.encode(dataArray);
			eRecon_web.direct.action.LegalVehicleService.getUserRole(encodedArray, function(p,response){
				if(response.result == null ){
					userRole = null;
				}
	        });
			*/
			//reconperiod,region,country,centralizedsite
			var formdata = {
				reportType: dashboardType,
				reconPeriod: reconPeriod,
				lvId: lvCboVal,
				region: regionCboVal,
				country: countryCboVal,
				bssAccountType: bssacctCboVal,
				centralizedsite: centsiteCboVal,
				ssidGL: ssiglCboVal,
				frsBusinessUnit: frsbizunitCboVal,
				lvRptNum: lrptnumvCboVal,
				poCity: pocityCboVal,
				proofOwner: proofownerCboVal,
				acctOwner: acctownerCboVal,
				controllername: contdelegateCboVal,
				arcmember: arcmemberCboVal,
				frsAccount: frsacctCboVal,
				reconType: recontypeCboVal,
				strategicPartner: strategicPartnerCboVal,
				financialController: fincontnameCboVal,
				costCenter: ccCboVal,
				glsiDescr: glsidCboVal,
				aoManagerL04: aodmdn04CboVal,
				aoManagerL05: aodmdn05CboVal,
				rowType: rowType,
				userRole: userRole
			}
			Ext.Ajax.request({
				url : 'filedownloadtrigger.up?downloadType=BSS_EXCEL_EXPORT',
				method:'POST', 
				params : {
					formdata: Ext.encode(formdata)
				},
				scope : this,
				success : function(response, opts) {
					response = Ext.decode(response.responseText);
					if(response.success){
						Ext.MessageBox.alert('Successful', 
								"Your request has been submitted successfully with the request id " + response.scheduleId + ". You should receive an email on completion.");
					}
					else {
						Ext.MessageBox.alert('Failed', response.message);
					}
				},
				failure : function(err) {
					Ext.MessageBox.alert('Error occured during KPI Excel file download.', 'Please try again!');
				}
			}); 		
		
		} else {
			Ext.MessageBox.alert( "Alert", "No rows selected in the summary grid." );
		}
		//-----------------------------------------------------------------------------
	},
	handleEmailBtnClick : function(){
		eRecon_web.direct.action.LegalVehicleService.sendEmail( function(p,response){
			Ext.MessageBox.alert('Alert', response.result)
		});
	},
	
	handleLVFiltersTypeAhead:function(cbo_) {
		cbo_.expand();
		delete cbo_.lastQuery;
		var store = cbo_.getStore();
		store.clearFilter();
		store.filter({
			property: 'description',
      anyMatch: true,
      value: cbo_.getValue()
    });
		if(!cbo_.getValue()) {
			store.clearFilter();
			cbo_.expand();
		}
	},
	
handlePptExportBtnClick : function(){
	var store = this.getSumOfActivity().getStore();
	var dataArray = [];
	var headerArray = [];
	var updateData =  store.data.items;  
	var headerData =  this.headers;
	
	if(updateData.length != 0)
		{
			Ext.each(updateData, function(item, index, array) {
	        dataArray.push(
	        	 item.data 
		        );
		    });
		}
	
	if(headerData.length != 0)
		{
			Ext.each(headerData, function(item, index, array) {
				headerArray.push({
		        	"dataIndex":item.dataIndex,
		        	"header": item.text
					
		        });
		    });
		}
	
	
eRecon_web.direct.action.LegalVehicleService.sendKPIReportData(headerArray,dataArray, function(p,response){
			//Ext.MessageBox.alert('Alert', response.result)
		});
},

handleReconPeriodChange: function(combo,newVal,oldVal){
	var oRec=combo.findRecordByValue(oldVal), newVal=combo.findRecordByValue(newVal);
	newVal && combo.inputEl.addCls('comboSelectedItem');

}
  
});

Ext.namespace( 'eRecon_web.direct.config');
Ext.namespace( 'eRecon_web.direct.action');

eRecon_web.direct.config.PROVIDER_BASE_URL='djn/directprovider';

eRecon_web.direct.config.POLLING_URLS = {
}

eRecon_web.direct.config.REMOTING_API = {
	url: eRecon_web.direct.config.PROVIDER_BASE_URL,
	type: 'remoting',
	namespace: eRecon_web.direct.action,
	actions: {
		AOAttestationSummaryService:[
			{
				name: 'getAOAttestationSummaryValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOAttestationSummaryValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOAttestationSummaryValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOAttestationSummaryValues',
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOListForAOB_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOListForAOB_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOListForAOB_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOListForAOB',
				len: 0,
				formHandler: false
			},
			{
				name: 'getAOAttestationProofOwnerValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOAttestationProofOwnerValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOAttestationProofOwnerValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOAttestationProofOwnerValues',
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOAttestationBusinessGroupValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOAttestationBusinessGroupValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOAttestationBusinessGroupValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOAttestationBusinessGroupValues',
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOAttestationDetailValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOAttestationDetailValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOAttestationDetailValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOAttestationDetailValues',
				len: 6,
				formHandler: false
			},
			{
				name: 'getAOAgingDetailValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOAgingDetailValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOAgingDetailValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOAgingDetailValues',
				len: 3,
				formHandler: false
			},
			{
				name: 'submitAttestationDetails_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'submitAttestationDetails_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'submitAttestationDetails_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'submitAttestationDetails',
				len: 1,
				formHandler: false
			}
		],
		AOUploadFilterService:[
			{
				name: 'getAOUploadBusinessunitValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOUploadBusinessunitValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOUploadBusinessunitValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOUploadBusinessunitValues',
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOUploadProofOwnerValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOUploadProofOwnerValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOUploadProofOwnerValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOUploadProofOwnerValues',
				len: 2,
				formHandler: false
			},
			{
				name: 'getAOUploadAccountOwnerValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOUploadAccountOwnerValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOUploadAccountOwnerValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAOUploadAccountOwnerValues',
				len: 0,
				formHandler: false
			}
		],
		AccountMaintenanceService:[
			{
				name: 'getReferenceData_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getReferenceData_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getReferenceData_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getReferenceData',
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountTypeData_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountTypeData_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountTypeData_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountTypeData',
				len: 0,
				formHandler: false
			},
			{
				name: 'getActiveFlag_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getActiveFlag_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getActiveFlag_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getActiveFlag',
				len: 0,
				formHandler: false
			},
			{
				name: 'getAgingBenchmark_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAgingBenchmark_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAgingBenchmark_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAgingBenchmark',
				len: 0,
				formHandler: false
			},
			{
				name: 'getProofOwner_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getProofOwner_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getProofOwner_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getProofOwner',
				len: 0,
				formHandler: false
			},
			{
				name: 'getTransToProofOwner_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransToProofOwner_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransToProofOwner_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransToProofOwner',
				len: 0,
				formHandler: false
			},
			{
				name: 'getAccountOwner_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountOwner_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountOwner_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountOwner',
				len: 0,
				formHandler: false
			},
			{
				name: 'getTransToAccountOwner_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransToAccountOwner_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransToAccountOwner_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransToAccountOwner',
				len: 0,
				formHandler: false
			},
			{
				name: 'getBusinessStore_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getBusinessStore_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getBusinessStore_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getBusinessStore',
				len: 0,
				formHandler: false
			},
			{
				name: 'getCurrencyCode_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCurrencyCode_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCurrencyCode_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCurrencyCode',
				len: 0,
				formHandler: false
			},
			{
				name: 'getLOB_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLOB_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLOB_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLOB',
				len: 0,
				formHandler: false
			},
			{
				name: 'getCountryCode_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCountryCode_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCountryCode_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCountryCode',
				len: 0,
				formHandler: false
			},
			{
				name: 'getGeoCode_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getGeoCode_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getGeoCode_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getGeoCode',
				len: 0,
				formHandler: false
			},
			{
				name: 'getSourceCode_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSourceCode_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSourceCode_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSourceCode',
				len: 0,
				formHandler: false
			},
			{
				name: 'getFundCode_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getFundCode_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getFundCode_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getFundCode',
				len: 0,
				formHandler: false
			},
			{
				name: 'getSubAccttypeId_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSubAccttypeId_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSubAccttypeId_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSubAccttypeId',
				len: 0,
				formHandler: false
			},
			{
				name: 'getRiskType_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getRiskType_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getRiskType_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getRiskType',
				len: 0,
				formHandler: false
			}
		],
		AccountOwnerLuService:[
			{
				name: 'getAccountOwners_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountOwners_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountOwners_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountOwners',
				len: 1,
				formHandler: false
			}
		],
		AccountTypeDefaultService:[
			{
				name: 'getAccountTypeDefaults_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountTypeDefaults_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountTypeDefaults_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountTypeDefaults',
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountTypeTree_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountTypeTree_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountTypeTree_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountTypeTree',
				len: 0,
				formHandler: false
			}
		],
		AccountTypeLUService:[
			{
				name: 'getAccountTypeLU_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountTypeLU_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountTypeLU_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountTypeLU',
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountTypeID_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountTypeID_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountTypeID_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccountTypeID',
				len: 0,
				formHandler: false
			}
		],
		AccountsViewService:[
			{
				name: 'getAllAccounts_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllAccounts_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllAccounts_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllAccounts',
				len: 0,
				formHandler: false
			}
		],
		AdhocQueryService:[
			{
				name: 'getAdhocResult_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAdhocResult_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAdhocResult_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAdhocResult',
				len: 4,
				formHandler: false
			},
			{
				name: 'getUserQuery_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserQuery_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserQuery_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserQuery',
				len: 0,
				formHandler: false
			},
			{
				name: 'SaveQuery_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'SaveQuery_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'SaveQuery_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'SaveQuery',
				len: 1,
				formHandler: false
			},
			{
				name: 'SaveModifiedRecords_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'SaveModifiedRecords_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'SaveModifiedRecords_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'SaveModifiedRecords',
				len: 1,
				formHandler: false
			},
			{
				name: 'DeleteTempQueries_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'DeleteTempQueries_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'DeleteTempQueries_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'DeleteTempQueries',
				len: 0,
				formHandler: false
			},
			{
				name: 'getQueryType_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getQueryType_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getQueryType_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getQueryType',
				len: 0,
				formHandler: false
			}
		],
		AdminOpenCloseCycleService:[
			{
				name: 'getOpenCloseDetails_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getOpenCloseDetails_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getOpenCloseDetails_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getOpenCloseDetails',
				len: 1,
				formHandler: false
			},
			{
				name: 'getOpenCloseReconDetails_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getOpenCloseReconDetails_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getOpenCloseReconDetails_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getOpenCloseReconDetails',
				len: 0,
				formHandler: false
			},
			{
				name: 'getOpenCloseBusinessUnits_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getOpenCloseBusinessUnits_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getOpenCloseBusinessUnits_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getOpenCloseBusinessUnits',
				len: 0,
				formHandler: false
			}
		],
		AppConfigService:[
			{
				name: 'getApplicationConfig_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getApplicationConfig_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getApplicationConfig_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getApplicationConfig',
				len: 1,
				formHandler: false
			}
		],
		ApplicationConfigService:[
			{
				name: 'getApplicationConfig_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getApplicationConfig_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getApplicationConfig_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getApplicationConfig',
				len: 0,
				formHandler: false
			}
		],
		ArchiveBSDService:[
			{
				name: 'getReconPeriod_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getReconPeriod_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getReconPeriod_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getReconPeriod',
				len: 0,
				formHandler: false
			},
			{
				name: 'getAssignedUnAssignedValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignedUnAssignedValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignedUnAssignedValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignedUnAssignedValues',
				len: 1,
				formHandler: false
			}
		],
		AssignEntitlementService:[
			{
				name: 'getAssignEntitlementCountryValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementCountryValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementCountryValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementCountryValues',
				len: 0,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementRegionValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementRegionValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementRegionValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementRegionValues',
				len: 0,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementLobValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementLobValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementLobValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementLobValues',
				len: 0,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementCondiValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementCondiValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementCondiValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementCondiValues',
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementCorpValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementCorpValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementCorpValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementCorpValues',
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementFullkeyValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementFullkeyValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementFullkeyValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignEntitlementFullkeyValues',
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignedUnAssignedValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignedUnAssignedValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignedUnAssignedValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAssignedUnAssignedValues',
				len: 2,
				formHandler: false
			}
		],
		BroadcastMessageService:[
			{
				name: 'getBroadcastMessage_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getBroadcastMessage_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getBroadcastMessage_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getBroadcastMessage',
				len: 0,
				formHandler: false
			},
			{
				name: 'saveRecords_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveRecords_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveRecords_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveRecords',
				len: 1,
				formHandler: false
			}
		],
		CentralizedSiteMapService:[
			{
				name: 'getCentralizedSiteMap_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCentralizedSiteMap_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCentralizedSiteMap_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCentralizedSiteMap',
				len: 1,
				formHandler: false
			},
			{
				name: 'getCentralizedSiteType_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCentralizedSiteType_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCentralizedSiteType_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCentralizedSiteType',
				len: 0,
				formHandler: false
			},
			{
				name: 'getreconPeriod_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getreconPeriod_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getreconPeriod_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getreconPeriod',
				len: 0,
				formHandler: false
			},
			{
				name: 'getProposedSite_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getProposedSite_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getProposedSite_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getProposedSite',
				len: 0,
				formHandler: false
			},
			{
				name: 'getStrategicPartner_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicPartner_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicPartner_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicPartner',
				len: 0,
				formHandler: false
			},
			{
				name: 'getsodTypes_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getsodTypes_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getsodTypes_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getsodTypes',
				len: 0,
				formHandler: false
			},
			{
				name: 'getComboData_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getComboData_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getComboData_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getComboData',
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccntReviewRating_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccntReviewRating_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccntReviewRating_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAccntReviewRating',
				len: 0,
				formHandler: false
			},
			{
				name: 'getMcaRating_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getMcaRating_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getMcaRating_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getMcaRating',
				len: 0,
				formHandler: false
			},
			{
				name: 'getUserRole_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserRole_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserRole_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserRole',
				len: 1,
				formHandler: false
			},
			{
				name: 'doBssMetricsSync_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'doBssMetricsSync_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'doBssMetricsSync_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'doBssMetricsSync',
				len: 0,
				formHandler: false
			}
		],
		CommonOpsService:[
			{
				name: 'getUUID_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUUID_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUUID_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUUID',
				len: 0,
				formHandler: false
			}
		],
		CondiLuService:[
			{
				name: 'getCondiLuDetails_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCondiLuDetails_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCondiLuDetails_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCondiLuDetails',
				len: 1,
				formHandler: false
			},
			{
				name: 'getCondiLuLevel3Mgr_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCondiLuLevel3Mgr_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCondiLuLevel3Mgr_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCondiLuLevel3Mgr',
				len: 0,
				formHandler: false
			},
			{
				name: 'getCondiLuLevel4Mgr_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCondiLuLevel4Mgr_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCondiLuLevel4Mgr_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCondiLuLevel4Mgr',
				len: 0,
				formHandler: false
			}
		],
		ContactsService:[
			{
				name: 'getContactInformation_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getContactInformation_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getContactInformation_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getContactInformation',
				len: 0,
				formHandler: false
			}
		],
		CycleCalenderLuService:[
			{
				name: 'getCalenderdetails_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCalenderdetails_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCalenderdetails_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCalenderdetails',
				len: 1,
				formHandler: false
			}
		],
		Dashboard2Service:[
			{
				name: 'getStrategicSitesMatrix_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSitesMatrix_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSitesMatrix_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSitesMatrix',
				len: 0,
				formHandler: false
			},
			{
				name: 'getStrategicSitesRawData_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSitesRawData_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSitesRawData_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSitesRawData',
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSitesReconPeriods_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSitesReconPeriods_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSitesReconPeriods_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSitesReconPeriods',
				len: 0,
				formHandler: false
			},
			{
				name: 'getStrategicSitesCentralizationChartData_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSitesCentralizationChartData_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSitesCentralizationChartData_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSitesCentralizationChartData',
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSitesPOCityChartData_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSitesPOCityChartData_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSitesPOCityChartData_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSitesPOCityChartData',
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSiteTrendByPeriod_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSiteTrendByPeriod_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSiteTrendByPeriod_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSiteTrendByPeriod',
				len: 0,
				formHandler: false
			},
			{
				name: 'getStrategicSiteTrendByPOCity_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSiteTrendByPOCity_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSiteTrendByPOCity_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getStrategicSiteTrendByPOCity',
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserRole_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserRole_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserRole_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserRole',
				len: 1,
				formHandler: false
			},
			{
				name: 'getCountryByRegion_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCountryByRegion_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCountryByRegion_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCountryByRegion',
				len: 1,
				formHandler: false
			}
		],
		DashboardService:[
			{
				name: 'getAllTabsChartInfo_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllTabsChartInfo_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllTabsChartInfo_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllTabsChartInfo',
				len: 3,
				formHandler: false
			},
			{
				name: 'getAllArcMembersChartDetails_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllArcMembersChartDetails_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllArcMembersChartDetails_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllArcMembersChartDetails',
				len: 3,
				formHandler: false
			},
			{
				name: 'getDashboardArcInfo_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getDashboardArcInfo_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getDashboardArcInfo_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getDashboardArcInfo',
				len: 3,
				formHandler: false
			},
			{
				name: 'getAllAOGLBalanceDrChartDetails_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllAOGLBalanceDrChartDetails_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllAOGLBalanceDrChartDetails_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllAOGLBalanceDrChartDetails',
				len: 3,
				formHandler: false
			},
			{
				name: 'getAllAOGLBalanceCrChartDetails_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllAOGLBalanceCrChartDetails_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllAOGLBalanceCrChartDetails_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllAOGLBalanceCrChartDetails',
				len: 3,
				formHandler: false
			},
			{
				name: 'getAllAOGLBalanceReserveChartDetails_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllAOGLBalanceReserveChartDetails_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllAOGLBalanceReserveChartDetails_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllAOGLBalanceReserveChartDetails',
				len: 3,
				formHandler: false
			},
			{
				name: 'getArcMembersBalances_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getArcMembersBalances_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getArcMembersBalances_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getArcMembersBalances',
				len: 3,
				formHandler: false
			},
			{
				name: 'getDetailedData_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getDetailedData_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getDetailedData_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getDetailedData',
				len: 0,
				formHandler: false
			},
			{
				name: 'getFilterValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getFilterValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getFilterValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getFilterValues',
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserRole_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserRole_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserRole_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserRole',
				len: 1,
				formHandler: false
			},
			{
				name: 'getreconPeriod_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getreconPeriod_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getreconPeriod_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getreconPeriod',
				len: 0,
				formHandler: false
			}
		],
		DetailsUploadBankingGroup:[
			{
				name: 'getBankingGroup_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getBankingGroup_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getBankingGroup_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getBankingGroup',
				len: 1,
				formHandler: false
			}
		],
		ExchangeRateService:[
			{
				name: 'getExchangeRate_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getExchangeRate_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getExchangeRate_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getExchangeRate',
				len: 1,
				formHandler: false
			}
		],
		FeedLoadService:[
			{
				name: 'getFeedLoadType_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getFeedLoadType_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getFeedLoadType_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getFeedLoadType',
				len: 0,
				formHandler: false
			},
			{
				name: 'handleProcessFile_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'handleProcessFile_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'handleProcessFile_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'handleProcessFile',
				len: 1,
				formHandler: false
			},
			{
				name: 'handleDiscardFile_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'handleDiscardFile_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'handleDiscardFile_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'handleDiscardFile',
				len: 1,
				formHandler: false
			}
		],
		FeedLoadTemplateService:[
			{
				name: 'getFeedLoadTemplate_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getFeedLoadTemplate_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getFeedLoadTemplate_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getFeedLoadTemplate',
				len: 1,
				formHandler: false
			}
		],
		FilterService:[
			{
				name: 'getSubledgerFilterValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSubledgerFilterValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSubledgerFilterValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSubledgerFilterValues',
				len: 0,
				formHandler: false
			},
			{
				name: 'getSubledgerSortByValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSubledgerSortByValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSubledgerSortByValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSubledgerSortByValues',
				len: 0,
				formHandler: false
			}
		],
		GLFeedCalenderService:[
			{
				name: 'getGLfeedCalenderDetails_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getGLfeedCalenderDetails_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getGLfeedCalenderDetails_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getGLfeedCalenderDetails',
				len: 1,
				formHandler: false
			}
		],
		JobStatusService:[
			{
				name: 'getAllJobStatus_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllJobStatus_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllJobStatus_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllJobStatus',
				len: 2,
				formHandler: false
			},
			{
				name: 'getJobStatusByScheduleId_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getJobStatusByScheduleId_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getJobStatusByScheduleId_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getJobStatusByScheduleId',
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllJobStatusDetails_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllJobStatusDetails_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllJobStatusDetails_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllJobStatusDetails',
				len: 1,
				formHandler: false
			},
			{
				name: 'getJobStatusForProfile_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getJobStatusForProfile_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getJobStatusForProfile_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getJobStatusForProfile',
				len: 1,
				formHandler: false
			}
		],
		LegalVehicleService:[
			{
				name: 'getFilterValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getFilterValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getFilterValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getFilterValues',
				len: 1,
				formHandler: false
			},
			{
				name: 'getLVReportData_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLVReportData_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLVReportData_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLVReportData',
				len: 1,
				formHandler: false
			},
			{
				name: 'getLVReportHeader_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLVReportHeader_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLVReportHeader_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLVReportHeader',
				len: 1,
				formHandler: false
			},
			{
				name: 'getLVReportRawData_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLVReportRawData_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLVReportRawData_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLVReportRawData',
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserRole_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserRole_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserRole_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserRole',
				len: 1,
				formHandler: false
			},
			{
				name: 'sendEmail_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'sendEmail_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'sendEmail_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'sendEmail',
				len: 0,
				formHandler: false
			},
			{
				name: 'getAjaxTimeout_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAjaxTimeout_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAjaxTimeout_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAjaxTimeout',
				len: 0,
				formHandler: false
			},
			{
				name: 'getAllUserRoles_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllUserRoles_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllUserRoles_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getAllUserRoles',
				len: 0,
				formHandler: false
			}
		],
		LemAdjustmentsService:[
			{
				name: 'getLemAdjustmentsAccounts_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLemAdjustmentsAccounts_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLemAdjustmentsAccounts_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLemAdjustmentsAccounts',
				len: 4,
				formHandler: false
			},
			{
				name: 'getBankingGroup_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getBankingGroup_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getBankingGroup_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getBankingGroup',
				len: 0,
				formHandler: false
			},
			{
				name: 'getLemAdjustmentsAgingDetails_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLemAdjustmentsAgingDetails_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLemAdjustmentsAgingDetails_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLemAdjustmentsAgingDetails',
				len: 1,
				formHandler: false
			},
			{
				name: 'getLemReconPeriodState_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLemReconPeriodState_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLemReconPeriodState_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLemReconPeriodState',
				len: 0,
				formHandler: false
			},
			{
				name: 'getFullkey_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getFullkey_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getFullkey_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getFullkey',
				len: 1,
				formHandler: false
			},
			{
				name: 'saveLemAdjustmentsDetails_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveLemAdjustmentsDetails_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveLemAdjustmentsDetails_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveLemAdjustmentsDetails',
				len: 1,
				formHandler: false
			}
		],
		LinksDetailService:[
			{
				name: 'getLinks_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLinks_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLinks_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLinks',
				len: 0,
				formHandler: false
			}
		],
		LinksLuService:[
			{
				name: 'getLinksLuDetails_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLinksLuDetails_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLinksLuDetails_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLinksLuDetails',
				len: 1,
				formHandler: false
			},
			{
				name: 'getLinksTypes_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLinksTypes_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLinksTypes_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLinksTypes',
				len: 0,
				formHandler: false
			}
		],
		LoadSummaryService:[
			{
				name: 'getLoadSummary_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLoadSummary_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLoadSummary_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLoadSummary',
				len: 0,
				formHandler: false
			},
			{
				name: 'getLoadSummaryList_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLoadSummaryList_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLoadSummaryList_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLoadSummaryList',
				len: 0,
				formHandler: false
			},
			{
				name: 'getLoadSummaryForGrid_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLoadSummaryForGrid_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLoadSummaryForGrid_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getLoadSummaryForGrid',
				len: 1,
				formHandler: false
			}
		],
		ManagerLuService:[
			{
				name: 'getManagers_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getManagers_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getManagers_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getManagers',
				len: 1,
				formHandler: false
			}
		],
		NewAssignedService:[
			{
				name: 'getApprovalAccounts_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getApprovalAccounts_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getApprovalAccounts_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getApprovalAccounts',
				len: 2,
				formHandler: false
			},
			{
				name: 'acceptAllAccounts_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'acceptAllAccounts_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'acceptAllAccounts_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'acceptAllAccounts',
				len: 1,
				formHandler: false
			},
			{
				name: 'declineAllAccounts_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'declineAllAccounts_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'declineAllAccounts_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'declineAllAccounts',
				len: 1,
				formHandler: false
			},
			{
				name: 'acceptdeclineAccounts_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'acceptdeclineAccounts_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'acceptdeclineAccounts_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'acceptdeclineAccounts',
				len: 2,
				formHandler: false
			}
		],
		NewsLetterService:[
			{
				name: 'getNewsLetters_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getNewsLetters_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getNewsLetters_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getNewsLetters',
				len: 0,
				formHandler: false
			}
		],
		OpenCloseCycleService:[
			{
				name: 'getCycleStatistics_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCycleStatistics_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCycleStatistics_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCycleStatistics',
				len: 16,
				formHandler: false
			}
		],
		OwnershipAlertService:[
			{
				name: 'getOwnership_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getOwnership_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getOwnership_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getOwnership',
				len: 10,
				formHandler: false
			},
			{
				name: 'getOwnershipEmail_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getOwnershipEmail_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getOwnershipEmail_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getOwnershipEmail',
				len: 1,
				formHandler: false
			}
		],
		ProcessFileService:[
			{
				name: 'handleProcessFile_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'handleProcessFile_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'handleProcessFile_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'handleProcessFile',
				len: 1,
				formHandler: false
			},
			{
				name: 'handleDiscardFile_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'handleDiscardFile_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'handleDiscardFile_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'handleDiscardFile',
				len: 1,
				formHandler: false
			}
		],
		RollbackFeedsService:[
			{
				name: 'getRollbackFeeds_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getRollbackFeeds_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getRollbackFeeds_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getRollbackFeeds',
				len: 7,
				formHandler: false
			}
		],
		RulesMaintenanceService:[
			{
				name: 'getRules_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getRules_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getRules_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getRules',
				len: 0,
				formHandler: false
			},
			{
				name: 'getReferenceValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getReferenceValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getReferenceValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getReferenceValues',
				len: 0,
				formHandler: false
			},
			{
				name: 'getCountries_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCountries_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCountries_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCountries',
				len: 0,
				formHandler: false
			},
			{
				name: 'getCurrencies_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCurrencies_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCurrencies_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getCurrencies',
				len: 0,
				formHandler: false
			}
		],
		SectorLobMappingService:[
			{
				name: 'getSectorLobMapping_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSectorLobMapping_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSectorLobMapping_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSectorLobMapping',
				len: 1,
				formHandler: false
			},
			{
				name: 'getSectorLobLevel2Descr_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSectorLobLevel2Descr_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSectorLobLevel2Descr_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSectorLobLevel2Descr',
				len: 0,
				formHandler: false
			},
			{
				name: 'getSectorLobLobId_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSectorLobLobId_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSectorLobLobId_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSectorLobLobId',
				len: 0,
				formHandler: false
			}
		],
		SubledgerService:[
			{
				name: 'getBankingGroup_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getBankingGroup_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getBankingGroup_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getBankingGroup',
				len: 0,
				formHandler: false
			},
			{
				name: 'getSubledgerDetail_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSubledgerDetail_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSubledgerDetail_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSubledgerDetail',
				len: 12,
				formHandler: false
			},
			{
				name: 'getSubledgerDescription_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSubledgerDescription_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSubledgerDescription_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getSubledgerDescription',
				len: 1,
				formHandler: false
			},
			{
				name: 'getManagers_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getManagers_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getManagers_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getManagers',
				len: 0,
				formHandler: false
			},
			{
				name: 'saveSubledgerDetails_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveSubledgerDetails_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveSubledgerDetails_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveSubledgerDetails',
				len: 1,
				formHandler: false
			},
			{
				name: 'submitSubledgerDetails_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'submitSubledgerDetails_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'submitSubledgerDetails_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'submitSubledgerDetails',
				len: 1,
				formHandler: false
			},
			{
				name: 'unSubmitSubledgerDetails_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'unSubmitSubledgerDetails_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'unSubmitSubledgerDetails_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'unSubmitSubledgerDetails',
				len: 1,
				formHandler: false
			},
			{
				name: 'saveAgingDetails_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveAgingDetails_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveAgingDetails_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveAgingDetails',
				len: 1,
				formHandler: false
			}
		],
		TransferService:[
			{
				name: 'getTransferSummary_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferSummary_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferSummary_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferSummary',
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferFilterValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferFilterValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferFilterValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferFilterValues',
				len: 0,
				formHandler: false
			},
			{
				name: 'getTransferSortByValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferSortByValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferSortByValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferSortByValues',
				len: 0,
				formHandler: false
			},
			{
				name: 'getTransferAcctOwnerValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferAcctOwnerValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferAcctOwnerValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferAcctOwnerValues',
				len: 0,
				formHandler: false
			},
			{
				name: 'getTransferSubmitProofOwnerValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferSubmitProofOwnerValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferSubmitProofOwnerValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferSubmitProofOwnerValues',
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferSubmitAccountOwnerValues_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferSubmitAccountOwnerValues_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferSubmitAccountOwnerValues_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferSubmitAccountOwnerValues',
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferDetail_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferDetail_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferDetail_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getTransferDetail',
				len: 9,
				formHandler: false
			},
			{
				name: 'transferAccounts_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'transferAccounts_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'transferAccounts_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'transferAccounts',
				len: 3,
				formHandler: false
			},
			{
				name: 'recallAccounts_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'recallAccounts_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'recallAccounts_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'recallAccounts',
				len: 2,
				formHandler: false
			},
			{
				name: 'transferAllAccounts_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'transferAllAccounts_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'transferAllAccounts_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'transferAllAccounts',
				len: 8,
				formHandler: false
			},
			{
				name: 'recallAllAccounts_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'recallAllAccounts_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'recallAllAccounts_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'recallAllAccounts',
				len: 7,
				formHandler: false
			},
			{
				name: 'saveComments_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveComments_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveComments_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveComments',
				len: 1,
				formHandler: false
			}
		],
		UserMaintenanceService:[
			{
				name: 'getUsers_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUsers_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUsers_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUsers',
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserMaintenanceRegion_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserMaintenanceRegion_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserMaintenanceRegion_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserMaintenanceRegion',
				len: 0,
				formHandler: false
			},
			{
				name: 'saveRecords_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveRecords_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveRecords_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveRecords',
				len: 1,
				formHandler: false
			},
			{
				name: 'doAddRecords_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'doAddRecords_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'doAddRecords_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'doAddRecords',
				len: 1,
				formHandler: false
			}
		],
		UserRoleMappingService:[
			{
				name: 'getUserRoleMapping_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserRoleMapping_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserRoleMapping_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUserRoleMapping',
				len: 1,
				formHandler: false
			},
			{
				name: 'getUser_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUser_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUser_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getUser',
				len: 0,
				formHandler: false
			},
			{
				name: 'getRole_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getRole_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getRole_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'getRole',
				len: 0,
				formHandler: false
			},
			{
				name: 'saveRecords_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveRecords_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveRecords_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'saveRecords',
				len: 1,
				formHandler: false
			}
		],
		UserService:[
			{
				name: 'logout_updateItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'logout_deleteItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'logout_insertItems'/*(java.util.List) => java.util.List */,
				len: 1,
				formHandler: false
			},
			{
				name: 'logout',
				len: 0,
				formHandler: false
			}
		]
	}
}
	

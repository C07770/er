Ext.define("eRecon_web.view.ApplicationConfig.ApplicationConfigSearch", {
    extend: "Ext.form.Panel",
    alias: "widget.ApplicationConfig_Search",
    defaults: {labelAlign: "side"},
    bodyPadding: 10,

    initComponent: function () {
	    
    	 this.dataTypeStore = Ext.create('Ext.data.Store', {
             fields: ['DataTypeName', 'DataTypeValue'],
             data: [{
                 "DataTypeName": "VARCHAR2",
                 "DataTypeValue": "VARCHAR2"
             }, {
                 "DataTypeName": "NUMBER",
                 "DataTypeValue": "NUMBER"
             }, {
                 "DataTypeName": "CHAR(1)",
                 "DataTypeValue": "CHAR(1)"
             }, {
                 "DataTypeName": "INTEGER",
                 "DataTypeValue": "INTEGER"
             }]
         	});
         
         this.activeStore = Ext.create('Ext.data.Store', {
             fields: ['ActiveName', 'ActiveValue'],
             data: [{
                 "ActiveName": "Yes",
                 "ActiveValue": "Y"
             }, {
                 "ActiveName": "No",
                 "ActiveValue": "N"
             }]
         	});
         
        this.items = [            
            {
                name: "parameter",
                itemId: "parameter",
                xtype: "textfield",
                fieldLabel: 'Parameter<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>'
            },
            {
            	name: "datatype", 
            	fieldLabel: 'DataType<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>', 
            	itemid: "datatype",            	
        		xtype: 'combo',
        		typeAhead:true,
                store: this.dataTypeStore,
                valueField: "DataTypeValue",
                displayField: "DataTypeName"            	
            },
            {
            	name: "value", 
            	fieldLabel: 'Value<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>', 
            	itemid: "value",
            	xtype: 'textfield'            	
            },
            {	name: "description", 
            	fieldLabel: "Description",
            	itemid: "description",
            	xtype: 'textfield'
            },
            {
            	name: "allowedvalues", 
            	fieldLabel: "Allowed Values", 
            	itemId: "allowedvalues",            	
            	xtype: 'textfield'            	
            },
            {
            	xtype: 'combobox',
				searchId: 'cmbAgingOverride',
				name: 'activeflag',
				fieldLabel: 'Active Flag<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>',
				typeAhead:true,
			    displayField: 'ActiveName',
			    valueField: 'ActiveValue',
	            store: this.activeStore
            }
            /*{
            	name: "activeflag",
            	fieldLabel: 'Active Flag<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>',
            	itemId: "activeflag",
        		xtype: 'combo',    
        		editable: false,
                store: this.activeStore,
                valueField: "ActiveValue",
                displayField: "ActiveName"
            }*/
        ];
        
        this.dockedItems = [
            {
                dock: "top", 
                xtype: "toolbar",
                items: [
                {
                    xtype: "button",
                    text: "Insert",
                    iconCls: 'iconAdd',
                    scope: this,
                    action:'INSERT'
                },
                "-",
                {
                    xtype: "button",
                    text: "Search",
                    scope: this,
                    iconCls: 'iconMagnifier',
                    action: "search"
                },
                "-",
                {
                	xtype: "button",
                    text: "Clear",
                    scope: this,
                    iconCls: 'iconTableDelete',
                    action: "clear"
                }
            ]
            },{
				dock: "bottom", 
				xtype: "toolbar",
				items: [
					{
					    xtype: "label",
					    text: "* Indicates Mandatory fields while inserting a new record"
					}
				]
	        }
        ];

        this.callParent(arguments);
    }
});

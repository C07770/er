Ext.define("eRecon_web.view.ApplicationConfig.ApplicationConfigGrid", {
    extend: "Ext.grid.Panel",
    alias: "widget.ApplicationConfig_Grid",    
    autoScroll: true,
    forceFit: true,    
    columnLines: true,
    multiSelect:true,
    store: "eRecon_web.store.AppConfigStore",
    enableColumnMove: true,    
    border: false,
    
    viewConfig: {
        emptyText: "No details available."},
                

    initComponent: function () {
        var me = this;
        me.stateful = false;               
                
        this.dataTypeStore = Ext.create('Ext.data.Store', {
            fields: ['DataTypeName', 'DataTypeValue'],
            data: [{
                "DataTypeName": "VARCHAR2",
                "DataTypeValue": "VARCHAR2"
            }, {
                "DataTypeName": "NUMBER",
                "DataTypeValue": "NUMBER"
            }, {
                "DataTypeName": "CHAR(1)",
                "DataTypeValue": "CHAR(1)"
            }, {
                "DataTypeName": "INTEGER",
                "DataTypeValue": "INTEGER"
            }]
        	});
        
        this.activeStore = Ext.create('Ext.data.Store', {
            fields: ['ActiveName', 'ActiveValue'],
            data: [{
                "ActiveName": "Yes",
                "ActiveValue": "Y"
            }, {
                "ActiveName": "No",
                "ActiveValue": "N"
            }]
        	});
        me.plugins= [
                     Ext.create('Ext.grid.plugin.CellEditing', {
                         clicksToEdit: 1,
                         allowBlank:false,
                         listeners:{
                        	 beforeedit: function(editor,event,opts){
                        		 if(!event.record.phantom && event.column.dataIndex=='parameter')   
                        			 {
                        			 	return false;
                        			 }
                        	 }
                        	 
                         }
                     })
        ];
        
        var rowEditing = Ext.create('Ext.grid.plugin.RowEditing', {
            clicksToMoveEditor: 2,
            autoCancel: false
        });
                                                    
        me.dockedItems = [
             {
              	dock: "top", 
              	xtype: "toolbar", 
              	items: [/*{
                   	xtype: "button",
                   	tooltip: "Add",
                   	icon:"/static/assets/famfamfam/icons/application_add.png",
                   	handler : function() {
                        rowEditing.cancelEdit(); 
                   	                      
                        // Create a model instance
                        var appConfigModel = Ext.create('eRecon_web.model.AppConfigModel', {                                                                                    
                            activeflag:'',
                            allowedvalues:'',
                            datatype:'',
                            description:'',
                            parameter:'',                            
                            value:'',
                            action:'INSERT'
                        });
                        
                        var appConfigStore = this.up('grid').getStore();                       
                        appConfigStore.insert(0, appConfigModel);
                        rowEditing.startEdit(0, 0);                  
                   	}
                   },
                   "-"
                   ,*/
              	   {
                   	xtype: "button",
                   	tooltip: "Save",
                   	text:"Save",
                   	icon: "/static/assets/famfamfam/icons/disk.png",                   	
                   	action:"save",
                   	scope:this
                   },
                   "-"
                   ,
                   {
                   	xtype: "button",
                   	tooltip: "Export to Excel",
                   	text:"Export to Excel",
                   	icon: "/static/assets/famfamfam/icons/page_white_excel.png",                   
                    action:"appConfig-Excel"
                   },
                   "-"                   
                   ,
                   {
                   	xtype: "button",
                   	tooltip: "Delete",
                   	text:"Delete",
                    iconCls: 'iconDelete',
                   	handler : function() {
                   		var i;
                   		var selModel = this.up('grid').getSelectionModel();
                   		var selRec = selModel.getSelection();
                   		for(i=0;i<selRec.length;i++)
                   			{
                   				selRec[i].data.action = "DELETE";
                   				this.up('grid').store.remove(selRec[i]);
                   			}
                   	}
                   }]
             },                  
             {
                xtype: "pagingtoolbar",
                dock: "bottom",
                displayInfo: true,
                store: me.store,
                plugins: [Ext.create("eRecon_web.plugins.PageSize")]

            }
            ];
        
          me.columns = [
                      
            {	header: "Parameter", 
            	dataIndex: "parameter",
            	renderer: function setFontColor(value, meta, record){	            	
            		var newvalue;
            		newvalue = "<span style='color:#989898' >"+value+"</span>";            			          		            		            		
            		return newvalue;
            	}
            }
            ,
            {	header: "DataType", 
            	dataIndex: "datatype",
            	editor: 
            	{
            		xtype: 'combo',            	
	                store: this.dataTypeStore,
	                valueField: "DataTypeValue",
	                displayField: "DataTypeName"
            	}
            }
            ,
            {	header: "Value", 
            	dataIndex: "value",
	            width:110,
	            renderer:function(val,meta,record,rowIndex,colIndex,store){
	       		return '<div style="white-space:normal !important;">' + val + '</div>'
	       	 	},
	       	 	editor:{
            		xtype: 'textfield'
            	}
            }
            ,
            {	header: "Description", 
            	dataIndex: "description",
            	editor:{
            		xtype: 'textfield'
            	}
            }
            ,
            {	header: "Allowed Values", 
            	dataIndex: "allowedvalues",
            	editor:{
            		xtype: 'textfield'
            	}
            }
            ,
            {	header: "Active Flag",
            	dataIndex: "activeflag",
            	editor: 
            	{
            		xtype: 'combo',            	
	                store: this.activeStore,
	                valueField: "ActiveValue",
	                displayField: "ActiveName"
            	}
            }
                              
        ];         
          
        me.callParent(arguments);
        }
    });

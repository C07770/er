Ext.define("eRecon_web.view.ApplicationConfig.ApplicationConfigContainer",{
	extend: "Ext.container.Container", 
	alias: "widget.ApplicationConfig_Container",   
    layout: "border",
    
 initComponent: function (config) {

    	this.searchForm = Ext.create("eRecon_web.view.ApplicationConfig.ApplicationConfigSearch", {
            title: "Search/Insert Application Configuration ",
            region: "west",
            split: true,
            flex: 1.5,
            collapsible: true,
            animCollapse: false,
            collapsed: false

        });
    	
    	this.applicationConfigGrid = Ext.create("eRecon_web.view.ApplicationConfig.ApplicationConfigGrid", {
    		title: "Application Configuration",
            region: "center",
            flex: 4
            });
    	
    	this.items = [    	              
    	              this.applicationConfigGrid,
    	              this.searchForm
    	             ];
    	    	    	    	
    	this.listeners =
        {
        		scope: this,
                "activate": function () {                        	
                	var appConfigStore = this.applicationConfigGrid.getStore();
                	appConfigStore.directOptions = {};
                	appConfigStore.getProxy().extraParams = {
    	                0: null
    	            };
                	appConfigStore.load({
    	                callback: function (records, operation, success) {
    	                }
    	            });
              }  
        };
    	
    	this.callParent(config);
	}
	
});

Ext.define("eRecon_web.view.assignEntitlement.FilterForm", {
    extend: "Ext.form.Panel",
    alias: "widget.assign_filterform",
    defaults: {labelAlign: "side"},
    bodyPadding: 10,

    initComponent: function () {
	
    	this.assignCountryStore = Ext.create("eRecon_web.store.AssignEntitlementCountryStore", {
            // autoLoad: true
        });
    	
        this.assignRegionStore = Ext.create("eRecon_web.store.AssignEntitlementRegionStore", {
            // autoLoad: true
        });
        
         this.assignLobStore = Ext.create("eRecon_web.store.AssignEntitlementLobStore", {
            // autoLoad: true
        });
         
        this.assignCondiStore = Ext.create("eRecon_web.store.AssignEntitlementCondiStore", {
            // autoLoad: true
        });
    	
        this.items = [
            {
            	listConfig: {
            	multiSelect:false
            	},
            	xtype: 'multiselect',
            	msgTarget: 'side',
            	itemId:'multiselect-control',
            	name: 'multiselect-control',
            	allowBlank: false,
                changeTag:'multiselect-control',
            	action:'multiselect-control',
            	store: this.assignCountryStore,
            	ddReorder: false,
            	valueField:'key',
            	height:330,
            	displayField:'value',
            	overflowY:'scroll',
            	hidden:true
            },
            {
            	name: "combo-control",
	            itemId: "combo-control",
	            id: "entitlementAutocomplete",
	            xtype: "combo",
	            valueField: "key",
	            displayField: "value",
	            queryMode:'remote',
	            action:"autocomplete-entitlement",
	            mouseEnabled:true,
	            minChars:1,
	            hideTrigger:true,
	            hidden:true
            },
            {
                name: "profile_type",
                itemId: "profile_type",
                xtype: "textfield",
                fieldLabel:"Profile Type",
                hidden:true
            }
        ];

        this.callParent(arguments);
    }
});

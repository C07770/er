Ext.define("eRecon_web.view.assignEntitlement.Container", {
    extend: "Ext.container.Container", alias: "widget.assignentitlement_container",
    requires: ["eRecon_web.view.assignEntitlement.entityForm","eRecon_web.view.assignEntitlement.assignOwnershipForm","eRecon_web.view.assignEntitlement.FilterForm"],
    layout: "border",
    defaults: {
        collapsible: true,
        split: true
    },
    initComponent: function (config) {

        this.entityForm = Ext.create("eRecon_web.view.assignEntitlement.entityForm", {
            region: "north",
            title: "Assign Entitlement",
            split: true,
            flex: 1,
            listeners: {
                scope: this
            }
        });
        
        this.assignSelector = Ext.create("eRecon_web.view.assignEntitlement.assignOwnershipForm", {
        	region: "center",
        	flex: 5
        });
        
        this.filterForm = Ext.create("eRecon_web.view.assignEntitlement.FilterForm", {
            title: "Filter",
            region: "west",
            split: true,
            flex: 2,
            collapsible: true,
            animCollapse: false 
            //disabled: true,
        });

        this.items = [
            this.entityForm,
            this.assignSelector,
            this.filterForm
        ];

        this.callParent(config);
    }
});

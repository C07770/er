Ext.define("eRecon_web.view.assignEntitlement.assignOwnershipForm", {
    extend: "Ext.form.Panel",
    alias: "widget.assignentitlement_assignform",
    defaults: {labelAlign: "side"},
    requires: ['eRecon_web.view.assignEntitlement.AssignEntitlementItemSelector','Ext.ux.form.MultiSelect','Ext.ux.form.ItemSelector'],
    bodyPadding: 10,
    height:50,

    initComponent: function () {
    	
        this.assignunassignstore = Ext.create("eRecon_web.store.AssignedUnAssignedStore", {
            // autoLoad: true
        });

        this.items = [
            {
                name: "assignSelector",
                itemId: "assignSelector",
                xtype: "assignentitlementitemselector",
                store:this.assignunassignstore,
                valueField:'userid',
                displayField:'name',
                changeTag:'itemselect',
                buttons:['addall','add','remove','removeall'],
                overflowY:'scroll',
                height:350,
                listTitle:'Selected',
                imagePath: 'ux/images/',
                fromTitle: 'UnAssigned',
                toTitle:'Assigned'
            }
        ];
        
        this.callParent(arguments);
}
   
});

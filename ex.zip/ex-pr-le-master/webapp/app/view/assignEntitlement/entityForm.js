Ext.define("eRecon_web.view.assignEntitlement.entityForm", {
    extend: "Ext.form.Panel",
    alias: "widget.assignentitlement_entityform",
    defaults: {labelAlign: "side"},
    bodyPadding: 10,
    height:50,

    initComponent: function () {
    	
    	var entity = Ext.create('Ext.data.Store', {
        fields: ['abbr', 'name'],
        data: [
        {
            "abbr": "<--SELECT-->",
            "name": "select"
        },
        
        {
            "abbr": "Country",
            "name": "country"
        },{
            "abbr": "FRS Business Unit",
            "name": "condi"
        },
        {
            "abbr": "Corp",
            "name": "corp"
        },
        {
            "abbr": "LOB",
            "name": "lob"
        },
        {
            "abbr": "Region",
            "name": "region"
        },{
            "abbr": "FULLKEY",
            "name": "fullkey"
        },{
        	"abbr": "ProfileGroup",
        	"name": "profilegroup"
        }
        ]
    	});
    	
        this.items = [
            {
                name: "entity",
                itemId: "entity-combo",
                xtype: "combo",
                fieldLabel: "Select an entity",
                valueField: "name",
                displayField: "abbr",
                store: entity,
                editable: false,
                action:"select"
            }
        ];
        
        this.callParent(arguments);
}
   
});

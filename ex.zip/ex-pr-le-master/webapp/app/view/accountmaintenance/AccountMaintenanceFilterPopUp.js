Ext.define("eRecon_web.view.accountmaintenance.AccountMaintenanceFilterPopUp", {
    extend: "Ext.form.Panel",
    alias: "widget.accountmaintenance_filterpopup",
    title: "Advanced Filter",
    layout: 'fit',
    floating:true,
    closable:true,
    initComponent: function (){
	
    	this.acctTypeStore = Ext.create("eRecon_web.store.AccountTypeStore", {
        });
        var agingType = Ext.create('Ext.data.Store', {
    		fields: ['key', 'value'],
    		data: [{
    		    "key": "G",
    		    "value": "GL"
    		}, {
    		    "key": "S",
    		    "value": "SL"
    		}
    		]
    		});
        
    	this.activeFlagStore = Ext.create("eRecon_web.store.ActiveFlagStore", {
        });
    	
        this.agingBenchmarkStore = Ext.create("eRecon_web.store.AgingBenchmarkStore", {
        });
        
        this.proofOwnerStore = Ext.create("eRecon_web.store.AcctMaintenanceProofOwnerStore", {
        });
        
        this.transfertoproofownerstore =  Ext.create("eRecon_web.store.AcctMaintenanceTransToProofOwnerStore", {
        });
        
        this.acctOwnerStore =  Ext.create("eRecon_web.store.AcctMaintenanceAccountOwnerStore", {
        });
        
        this.transfertoaccountownerstore =  Ext.create("eRecon_web.store.AcctMaintenanceTransToAccountOwnerStore", {
        });
        
        this.acctmaintenancebusinessstore =  Ext.create("eRecon_web.store.AcctMaintenanceBusinessStore", {
        });
        
        this.acctmaintenanceccystore =  Ext.create("eRecon_web.store.AcctMaintenanceCcyStore", {
        });
        
        this.acctmaintenancelobstore =  Ext.create("eRecon_web.store.AcctMaintenanceLOBStore", {
        });
        
        this.acctmaintenancegeocodestore =  Ext.create("eRecon_web.store.AcctMaintenanceGeoCodeStore", {
        });
        
        this.acctmaintenancecountrystore =  Ext.create("eRecon_web.store.AcctMaintenanceCountryStore", {
        });
        
        this.acctmaintenancesourcestore =  Ext.create("eRecon_web.store.AcctMaintenanceSourceStore", {
        });
        
        this.acctmaintenancefundstore =  Ext.create("eRecon_web.store.AcctMaintenanceFundStore", {
        });
        
        this.acctmaintenancesubacctypestore = Ext.create("eRecon_web.store.AcctMaintenanceSubAccttypeId",{
        });
        this.acctmaintenancerisktypestore = Ext.create("eRecon_web.store.AcctMaintenancetRisktypeId",{
        });
	    this.dockedItems = [
	    {
	    	xtype: 'toolbar',
	    	dock: 'bottom',
	    	items: [
	    	{
	    		xtype: 'button',
	    		searchId: 'applyButton',
	    		text: 'Apply',
	    		iconCls: 'iconAccept',
	    		searchId: 'apply',
	    		action:'filter'
	    	},
	    	{
	    		xtype: 'tbspacer',
	    		width: 10
	    	},
	    	{
	    		xtype: 'button',
	    		text: 'Cancel',
	    		iconCls: 'iconCancel',
	    		handler: function(btn) {
	    			btn.up('form').close();
	    		}
	    	}
	    	]
	    }    
	    ];
	    this.items =[{xtype: 'form',layout: 'fit', items: [
	    { 
		    xtype: 'container',
		    margin: '0 0 0 20',
		    layout: {
				type: 'table',
				columns: 6 
		    },
		    defaultType: 'textfield',
		    defaults: {
		        	hideLabel: true, 
		        	hideEmptyLabel: false,
		        	margin: '0 15 1 0'
		    },
	
	
		    items: [
	        {
	        	xtype: 'displayfield',
	        	value: 'Fullkey:',
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'fullkey'
	        	, width: 150
	        },//1
	        {
	        	xtype: 'displayfield',
	        	value: 'Schedule ID:',
	        	width: 175
	        },
	        {
	        	xtype: 'numberfield',
	        	name: 'scheduleId',
	        	colspan: 1,
	        	width: 150
	        }//2
	        ,
	        {
	        	xtype: 'displayfield',
	        	value: 'Account ID:',
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'accountId',
	        	colspan: 1,
	        	width: 150
	        }//3
	        ,
	        {
	        	xtype: 'displayfield',
	        	value: 'FRS Business Unit:',
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'condi',
	        	colspan: 1,
	        	width: 150
	        }//4
	        ,
	        {
	        	xtype: 'displayfield',
	        	value: 'Account Type:',
	        	width: 175
	        	
	        },
	        {
	        	xtype: 'combo',
	        	name: 'accountType',
	        	colspan: 1,
	        	store:this.acctTypeStore,
	        	displayField: 'value',
	        	valueField: 'key',
	        	editable: false
	        	
	        }//5
	        ,
	        {
	        	xtype: 'displayfield',
	        	value: "FRS Account:",
	        	width: 175
	        },
	        {
	        	xtype: 'combo',
	        	name: 'subAcctTypeId',
	        	colspan: 1,
		        editable: false,
			    displayField: 'value',
			    valueField: 'key',
	            store: this.acctmaintenancesubacctypestore
	        }//6
	         ,
	        {
	        	xtype: 'displayfield',
	        	value: 'Aging Type:',
	        	width: 175
	        },
	        {
	        	xtype: 'combobox',
	        	name: 'acctAgingType',
	        	colspan: 1,
	        	store:agingType,
	        	displayField: 'value',
	        	valueField: 'key',
	        	editable: false
	        	
	        }//6
	        ,
	        {
	        	xtype: 'displayfield',
	        	value: 'Aging Type Overridden:',
	        	width: 175
	        },
	        {
				xtype: 'combobox',
				searchId: 'cmbAgingOverride',
				width: 150,
				name: 'acctAgingTypeOverride',
				editable: false,
			    displayField: 'value',
			    valueField: 'key',
	            store: this.activeFlagStore
		    },
		    {
		    	xtype: 'displayfield',
		    	value: 'Risk Factor',
		    	width: 175
	        },
	        {
	        	xtype: 'combobox',
	        	store: this.acctmaintenancerisktypestore,
	        	displayField: 'value',
	        	name:'riskType',
			    valueField: 'key',
			    editable: false
	        }//6
	        ,
	        {
	        	xtype: 'displayfield',
	        	value: 'Risk Factor Overridden:',
	        	width: 175
	        },
	        {
				xtype: 'combobox',
				searchId: 'cmbRiskTypeOverride',
				width: 150,
				name: 'riskTypeOverride',
				editable: false,
			    displayField: 'value',
			    valueField: 'key',
			    store:this.activeFlagStore
		    },
		    {
	        	xtype: 'displayfield',
	        	value: 'Benchmark:',
	        	width: 175
	        },
	        {
	        	xtype: 'combobox',
				searchId: 'cmbBenchmark',
				width: 150,
				name: 'agingBenchmark',
				editable: false,
			    displayField: 'value',
			    valueField: 'key',
		        store: this.agingBenchmarkStore
	        }//6
	        ,
	        {
	        	xtype: 'displayfield',
	        	value: 'Benchmark Overridden:',
	        	width: 175
	        },
	        {
				xtype: 'combobox',
				searchId: 'cmbBenchmarkOverride',
				width: 150,
				name: 'agingBenchmarkOverride',
				editable: false,
			    displayField: 'value',
			    valueField: 'key',
	            store: this.activeFlagStore
		    },
	        {
	        	xtype: 'displayfield',
	        	value: 'IN Genesis:',
	        	width: 175
	        },
	        {
				xtype: 'combobox',
				searchId: 'cmbGenesis',
				width: 150,
				name: 'inGenesis',
				editable: false,
			    displayField: 'value',
			    valueField: 'key',
	            store:this.activeFlagStore
		    },
		    
	        
		    {
	        	xtype: 'displayfield',
	        	value: 'USD Threshold:',
	        	width: 175
	        },
	        {
	        	xtype: 'numberfield',
	        	name: 'usdThreshold',
	        	colspan: 1,
	        	width: 150
	        }
	        
	        ,
	        {
	        	xtype: 'displayfield',
	        	value: 'USD Threshold Overridden:',
	        	width: 175
	        },
	        {
				xtype: 'combobox',
				searchId: 'cmbUSDThresholdOverride',
				width: 150,
				name: 'usdThresholdOverride',
				editable: false,
			    displayField: 'value',
			    valueField: 'key',
	            store:this.activeFlagStore
		    }
	        ,
	        {
	        	xtype: 'displayfield',
	        	value: 'Proof Owner:',
	        	width: 175
	        },
	        {
				xtype: 'combobox',
				searchId: 'cmbProofOwner',
				width: 150,
				name: 'mgrUserId',
				editable: false,
			    displayField: 'value',
			    valueField: 'key',
	            store: this.proofOwnerStore
		    }
	        ,
	        {
	        	xtype: 'displayfield',
	        	value: 'Transfer to Proof Owner:',
	        	width: 175
	        },
	        {
				xtype: 'combobox',
				searchId: 'cmdtransfertoproofowner',
				width: 150,
				name: 'transferToUserId',
				editable: false,
			    displayField: 'value',
			    valueField: 'key',
	            store: this.transfertoproofownerstore
		    }
	        ,
	        {
	        	xtype: 'displayfield',
	        	value: 'Account Owner:',
	        	width: 175
	        },
	        {
				xtype: 'combobox',
				searchId: 'cmbAccountOwner',
				width: 150,
				name: 'acctOwner',
				editable: false,
			    displayField: 'value',
			    valueField: 'key',
	            store: this.acctOwnerStore
		    }
	        ,
	        {
	        	xtype: 'displayfield',
	        	value: 'Transfer to Account Owner:',
	        	width: 175
	        },
	        {
				xtype: 'combobox',
				searchId: 'cmbTransfertoAccountOwner',
				width: 150,
				name: 'transferToAcctOwnerId',
				editable: false,
			    displayField: 'value',
			    valueField: 'key',
	            store: this.transfertoaccountownerstore
		    }
		    ,
		    {
	        	xtype: 'displayfield',
	        	value: 'Controller Delegate:',
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'lem',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: 'Financial Controller:',
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'fc',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: 'Banking Group:',
	        	width: 175
	        },
	        {
				xtype: 'combobox',
				searchId: 'cmbBusinessUnit',
				width: 150,
				name: 'businessUnit',
				editable: false,
			    displayField: 'value',
			    valueField: 'key',
	            store: this.acctmaintenancebusinessstore
		    }
	        ,
		    {
	        	xtype: 'displayfield',
	        	value: "<p style='color:red;'>Account Comments:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'acctComments',
	        	colspan: 1,
	        	width: 150
	        }//6
	        ,
		    {
	        	xtype: 'displayfield',
	        	value: 'Description:',
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'description',
	        	colspan: 1,
	        	width: 150
	        }//6
	        ,
		    {
	        	xtype: 'displayfield',
	        	value: "<p style='color:red;'>Account Nature:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'acctnature',
	        	colspan: 1,
	        	width: 150
	        }//6
	        ,
	        {
	        	xtype: 'displayfield',
	        	value: 'CCY Code:',
	        	width: 175
	        },
	        {
				xtype: 'combobox',
				searchId: 'cmbCcycode',
				width: 150,
				name: 'ccyCode',
				editable: false,
			    displayField: 'key',
			    valueField: 'key',
	            store: this.acctmaintenanceccystore
		    }
	        ,
	        {
	        	xtype: 'displayfield',
	        	value: 'Foreign Currency Code:',
	        	width: 175
	        },
	        {
				xtype: 'combobox',
				searchId: 'cmbForiegncurrencycode',
				width: 150,
				name: 'fcyCode',
				editable: false,
			    displayField: 'value',
			    valueField: 'key',
	            store: this.acctmaintenanceccystore
		    }
	        ,
		    {
	        	xtype: 'displayfield',
	        	value: 'Legal Vehicle:',
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'legalVehicle',
	        	colspan: 1,
	        	width: 150
	        }//6
	         ,
	        {
	        	xtype: 'displayfield',
	        	value: 'LOB:',
	        	width: 175
	        },
	        {
				xtype: 'combobox',
				searchId: 'cmbLob',
				width: 150,
				name: 'lob',
				editable: false,
			    displayField: 'value',
			    valueField: 'key',
	            store: this.acctmaintenancelobstore
		    }
	        ,
	        {
	        	xtype: 'displayfield',
	        	value: 'Region:',
	        	width: 175
	        },
	        {
				xtype: 'combobox',
				searchId: 'cmbGeocode',
				width: 150,
				name: 'geoCode',
				editable: false,
			    displayField: 'value',
			    valueField: 'key',
	            store: this.acctmaintenancegeocodestore
		    }
	 	     ,
	        {
	        	xtype: 'displayfield',
	        	value: 'Country:',
	        	width: 175
	        },
	        {
				xtype: 'combobox',
				searchId: 'cmbCountry',
				width: 150,
				name: 'ctryCode',
				editable: false,
			    displayField: 'value',
			    valueField: 'key',
	            store: this.acctmaintenancecountrystore
		    }
	        ,
	        {
	        	xtype: 'displayfield',
	        	value: 'General Ledger System Identifier:',
	        	width: 175
	        },
	        {
				xtype: 'combobox',
				searchId: 'cmbsource',
				width: 150,
				name: 'source',
				editable: false,
			    displayField: 'value',
			    valueField: 'key',
	            store: this.acctmaintenancesourcestore
		    }
	        ,
	        {
	        	xtype: 'displayfield',
	        	value: 'Recon Level:',
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'reconLevel',
	        	colspan: 1,
	        	width: 150
	        }//6
	        ,
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:red;'>Fund Code:</p>",
	        	width: 175
	        },
	       {
				xtype: 'combobox',
				searchId: 'cmbFunCode',
				width: 150,
				name: 'fundCode',
				editable: false,
			    displayField: 'value',
			    valueField: 'key',
	            store: this.acctmaintenancefundstore
		    }
	        ,{
	        	xtype: 'displayfield',
	        	value: "<p style='color:red;'>Account Highlighting:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'spIndicator',
	        	colspan: 1,
	        	width: 150
	        }//6
	        ,
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:red;'>Exception On File:</p>",
	        	width: 175
	        },
	       {
				xtype: 'combobox',
				searchId: 'cmbExceptionOnFile',
				width: 150,
				name: 'exceptionOnFile',
				editable: false,
				forceSelection: true,
			    displayField: 'value',
			    valueField: 'key',
	            store: this.activeFlagStore
		    }
	       ,
	        {
	        	xtype: 'displayfield',
	        	value: 'Active Flag:',
	        	width: 175
	        },
	       {
				xtype: 'combobox',
				searchId: 'cmbActiveFlag',
				width: 150,
				name: 'activeFlag',
				editable: false,
			    displayField: 'value',
			    valueField: 'key',
	            store: this.activeFlagStore
		    },
		    {
	        	xtype: 'displayfield',
	        	value: 'GL Account 1:',
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'account',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: 'Local Product Code:',
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'product',
	        	colspan: 1,
	        	width: 150
	        },
		    {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>SID:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'sid',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>Source System ID:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'glSrcSysId',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>Booking Ledger Branch Code:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'bkgLdgrBrCd',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>Balance Type:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'timeBalance',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>Local Legal Vehicle ID:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'lclLvId',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>GAAP Indicator:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'gaapInd',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>GL Account 1 Description:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'glAcct1Desc',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>GL Account 2:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'glAcct2',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>GL Account 2 Description:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'glAcct2Desc',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>Global Standard GL Account:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'globStdGlAcct',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>Local Cost Code:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'glLclCostCd',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>Local Cost Code Description:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'lclCostCdDesc',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>Local Product Code Description:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'lclProdCdDesc',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>Intercompany Account ID:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'icAcctId',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>Open Field 3:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'glOpenfld3',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>Open Field 3 Description:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'openfld3Desc',
	        	colspan: 1,
	        	width: 150
	        },
	        /*{
	        	xtype: 'displayfield',
	        	value: 'Fullkey Status:',
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'fullKeySta',
	        	colspan: 1,
	        	width: 150
	        },*/
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>Last Transaction Date:</p>",
	        	width: 175
	        },
	        {
		        xtype : "datefield",
	        	format : "d-M-y",
		        name: 'lstTranDt',
				emptyText : "d-M-y",
				width:150,
				allowBlank : true
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>Input Control:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'inpCntl',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>GOC:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'glGoc',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>FRS Operating Unit:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'frsOperUnitCd',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>LVID:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'leLvId',
	        	colspan: 1,
	        	width: 150
	        },
	        {
	        	xtype: 'displayfield',
	        	value: "<p style='color:green;'>Reporting Country Code:</p>",
	        	width: 175
	        },
	        {
	        	xtype: 'textfield',
	        	name: 'frsBsunitDomCntry',
	        	colspan: 1,
	        	width: 150
	        }
	        ]
	        }]
	     }];
	    this.callParent(arguments);  
	}

});

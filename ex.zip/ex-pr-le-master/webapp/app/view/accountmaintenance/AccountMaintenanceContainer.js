Ext.define("eRecon_web.view.accountmaintenance.AccountMaintenanceContainer", {
	    extend: "Ext.container.Container",
	    alias: "widget.acctmaintenance_container",
	    requires: ["eRecon_web.view.accountmaintenance.AccountMaintenanceGrid", 
	               "eRecon_web.view.accountmaintenance.AccountMaintenanceFilterForm"],
	    layout: "border",

	    initComponent: function (config) {
        this.AcctMaintenanceGrid = Ext.create("eRecon_web.view.accountmaintenance.AccountMaintenanceGrid", {
        	title: 'Account Maintenance View',
        	region: "center",
        	/*split: true,*/
            flex: 3,
            animCollapse: false/*,
            listeners: {
                scope: 'session'
            }*/
        });
       
        this.filterForm = Ext.create("eRecon_web.view.accountmaintenance.AccountMaintenanceFilterForm", {
        	title: 'Filter',
        	region: "north",
        	flex: 1.2,
            collapsible: true
        });
        
        this.items = [
            this.AcctMaintenanceGrid, 
            this.filterForm
        ];
        
       this.listeners = {
            scope: this,
            "activate": function () { 
	        	var acctmaintenanceStore = this.AcctMaintenanceGrid.getStore();
	        	acctmaintenanceStore.directOptions = {};
	        	acctmaintenanceStore.getProxy().extraParams = {
	        		0: null
	        	};
	        	acctmaintenanceStore.loadPage(1);
        	}
        }; 
        this.callParent(config);
    }
});

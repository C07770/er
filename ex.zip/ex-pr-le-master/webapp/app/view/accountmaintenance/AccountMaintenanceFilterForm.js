Ext.define("eRecon_web.view.accountmaintenance.AccountMaintenanceFilterForm", {
	extend : "Ext.form.Panel",
	alias : "widget.acctmaintenance_filterform",
	// defaults: {labelAlign: "side"},
	bodyPadding : 10,
	items : [  
		{
			name : "fullkey",
			xtype : "textfield",
			fieldLabel : "FullKey",
			width: 200
		},
		{
			name : "scheduleId",
			xtype : "numberfield",
			fieldLabel : "Schedule Id",
			width: 200
		}
	],
	dockedItems : [ {
		dock : "bottom",
		xtype : "toolbar",
		items : [ "->", {
			xtype : "button",
			text : "Search",
			scope : this,
			iconCls: 'iconMagnifier',
			action : "search"
		},
		"-"
		,{
			xtype : "button",
			text : "Clear",
			scope : this,
			action : "reset"
		},
		"-",{
			xtype : "button",
			text : "Advanced Filter",
			scope : this,
			action : "filter"
		}]
	} ],

	initComponent : function() {
		this.callParent(arguments);
	}
});

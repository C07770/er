Ext.define("eRecon_web.view.accountmaintenance.AccountMaintenanceGrid", {
    extend: "Ext.grid.Panel",
    alias: "widget.acctmaintenance_grid",
    autoScroll: true,
    columnLines: true,
    layout: 'fit',
    autoLoad : false,
    
    initComponent: function () {
        var me = this;
        me.stateful = false;
        
       
        
        me.store = Ext.create("eRecon_web.store.AccountMaintenanceStore", {});
        me.columns = [
                      
        {
        	text: 'Fullkey', 
        	dataIndex: 'fullkey',
        	width: 400
        },
		{
			text: 'Schedule Id', 
			dataIndex: 'scheduleId'
		},
		{
			text: 'Account Id', 
			dataIndex: 'accountId'
		},
		{
			text: 'FRS Business Unit', 
			dataIndex: 'condi'
		},
		{
			text: 'Account Type', 
			dataIndex: 'accountType'
		}, // need to change
		{
			text: 'FRS Account', 
			dataIndex: 'subAcctTypeId'
		},
		{
			text: 'Aging Type', 
			dataIndex: 'acctAgingType'
		},
		{
			text: 'Aging Type Overridden', 
			dataIndex: 'acctAgingTypeOverride'
		},
		{
			text: 'Risk Factor', 
			dataIndex: 'riskType'
		},
		{
			text: 'Risk Factor Overridden', 
			dataIndex: 'riskTypeOverride'
		},
		{
			text: 'Benchmark', 
			dataIndex: 'agingBenchmark'
		},
		{
			text: 'Benchmark Overridden', 
			dataIndex: 'agingBenchmarkOverride'
		},
		{
			text: 'IN GENESIS', 
			dataIndex: 'inGenesis'
		},
		{
			text: 'USD Threshold', 
			dataIndex: 'usdThreshold'
	    },
		{
			text: 'USD Threshold Overridden', 
			dataIndex: 'usdThresholdOverride'
		},
		{
			text: 'Proof Owner', 
			dataIndex: 'mgrUserId'
		},
		{
			text: 'Transfer to Proof Owner', 
			dataIndex: 'transferToUserId'
		},
		{
			text: 'Account Owner', 
			dataIndex: 'acctOwner'
		},
		{
			text: 'Transfer To Account Owner', 
			dataIndex: 'transferToAcctOwnerId'
		},
		{
			text: "Controller Delegate" ,
			dataIndex: "lem"
		},
		{
			text: "Financial Controller" ,
			dataIndex: "fc"
		},
		{
			text: 'Banking Group', 
			dataIndex: 'businessUnit'
		},
		{
			text: "Account Comments" ,
			dataIndex: "acctComments"
			
		},
		{
			text: "Description" ,
			dataIndex: "description"
			
		},
		{
			text: "Account Nature" ,
			dataIndex: "acctnature"
		},
		{
			text: "CCY Code",
			dataIndex: "ccyCode"
		},
		{
			text: "Foreign Currency Code" ,
			dataIndex: "fcyCode"
		},
		{
			text: "Legal Vehicle" ,
			dataIndex: "legalVehicle"
		},
		{
			text: "LOB" ,
			dataIndex: "lob"
		},
		{
			text: "Region" ,
			dataIndex: "geoCode"
		},
		{text: "Country" ,dataIndex: "ctryCode"},
		{
			text: "General Ledger System Identifier" ,
			dataIndex: "source"
		},
		{
			text: "Recon Level" ,
			dataIndex: "reconLevel"
		},
		{
			text: "Fund Code" ,
			dataIndex: "fundCode"
		},
		{
			text: "Account Highlighting" ,
			dataIndex: "spIndicator"
		},
		{
			text: "Exception On File" ,
			dataIndex: "exceptionOnFile"
		},
		{
			text: "Active Flag" ,
			dataIndex: "activeFlag",
	    	hidden: true
		},
		{
			text: "GL Account 1" , 
			dataIndex: "account"
		},{
			text: "Local Product Code" ,
			dataIndex: "product"
		},
		{
			text: "SID" ,
			dataIndex: "sid"
		},
		{
			text: "Source System ID" ,
			dataIndex: "glSrcSysId"
		},
		{
			text: "Booking Ledger Branch Code" ,
			dataIndex: "bkgLdgrBrCd"
		},
		{
			text: "Balance Type" ,
			dataIndex: "timeBalance"
		},
		{
			text: "Local Legal Vehicle ID" ,
			dataIndex: "lclLvId"
		},
		{
			text: "GAAP Indicator" ,
			dataIndex: "gaapInd"
		},
		{
			text: "GL Account 1 Description" ,
			dataIndex: "glAcct1Desc"
		},
		{
			text: "GL Account 2" ,
			dataIndex: "glAcct2"
		},
		{
			text: "GL Account 2 Description" ,
			dataIndex: "glAcct2Desc"
		},
		{
			text: "Global Standard GL Account" ,
			dataIndex: "globStdGlAcct"
		},
		{
			text:"Local Cost Code" ,
			dataIndex: "glLclCostCd"
		},
		{
			text: "Local Cost Code Description" ,
			dataIndex: "lclCostCdDesc"
		},
		{
			text: "Local Product Code Description" ,
			dataIndex: "lclProdCdDesc"
		},
		{
			text: "Intercompany Account ID" ,
			dataIndex: "icAcctId"
		},
		{
			text: "Open Field 3" ,
			dataIndex: "glOpenfld3"
		},
		{
			text: "Open Field 3 Description" ,
			dataIndex: "openfld3Desc"
		},
		{
			text: "Last Transaction Date" ,
			dataIndex: "lstTranDt"
		},
		{
			text: "Input Control" ,
			dataIndex: "inpCntl"
		},
		{
			text: "GOC" ,
			dataIndex: "glGoc"
		},
		{
			text: "FRS Operating Unit" ,
			dataIndex: "frsOperUnitCd"
		},
		{
			text: "LVID" ,
			dataIndex: "leLvId"
		},
		{
			text: "Reporting Country Code" ,
			dataIndex: "frsBsunitDomCntry"
		},
		{
			text: "Change By" ,
			dataIndex: "changeBy",
	    	hidden: true
		}
         ];
        
        me.dockedItems = [
                          {
                        	  dock: "top", xtype: "toolbar", items: [
                             {
                            	 xtype: "button",
                            	 action: "export",
                            	 text: "Export",
                            	 icon: "/static/assets/famfamfam/icons/page_excel.png",
                            	 tooltip: "Export to Excel",
                            	 id: "accountMaintenance_export"
                             }
                             ]
                          },{
                        	  xtype: "pagingtoolbar",
                        	  store: me.store,
                        	  dock: "bottom",
                        	  displayInfo: true
                          }
                          ];
        me.callParent(arguments);
    }

});

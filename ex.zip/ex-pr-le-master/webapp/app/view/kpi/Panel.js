Ext.define("eRecon_web.view.kpi.Panel",{
  extend:"Ext.panel.Panel",
  alias:"widget.erecon_kpi_panel",  
  requires:["eRecon_web.view.dashboard.AllTabsPieChart"],
  
  layout:"border",
  
  initComponent:function() {
	
    this.items = [
      {
    	xtype:"panel",
    	region:"west",
        title: 'KPIs',
        collapsible:true,
		collapseDirection:"top",
    	border:false,
    	items:[
    	  {    		  
 	    	 xtype: 'panel',
    		 layout: 'fit',    		 
    		 height:"auto",
    		 items: [{xtype: 'allTabsPieChart', height: 220}]   	    		        
    	  }
    	]
      },
      {
    	xtype:"panel",
    	region:"center",
    	layout:"fit",
    	border:false,
    	items:[
    	  {
    		xtype:"grid",
    		title:"TEST",
    		columns:[{text:"1",flex:1},{text:2,flex:1}]
    	  }
    	]
      }
    ];
    
    this.callParent(arguments);
  }
	  
});

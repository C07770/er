Ext.define("eRecon_web.view.aoattestation.AOAttestationFilterForm", {
    extend: "Ext.form.Panel",
    alias: "widget.aoattestation_filterform",
    id: "aoattestationFilterForm",
    defaults: {labelAlign: "side"},
    bodyPadding: 10,

    initComponent: function () {
	
    	this.mgrStore = Ext.create("eRecon_web.store.AOAttestationProofOwnerStore", {
            // autoLoad: true
        });
    	
        this.businessunitStore = Ext.create("eRecon_web.store.AOAttestationBusinessGroupStore", {
            // autoLoad: true
        });
        
        var filterValues = Ext.create('Ext.data.Store', {
            fields: ['FilterName', 'FilterValue'],
            data: [{
                "FilterName": "All",
	            "FilterValue": "All"
	        },
            {
                "FilterName": "Submitted",
                "FilterValue": "Submitted"
            },{
                "FilterName": "UnSubmitted",
	            "FilterValue": "UnSubmitted"
	        },
            {
                "FilterName": "GL Aging Accounts",
                "FilterValue": "GLAccounts"
            },
            {
                "FilterName": "SL Aging Accounts",
                "FilterValue": "SLAccounts"
            },
            {
                "FilterName": "$0 Balance",
                "FilterValue": "ZeroGLBalance"
            },
            {
            	"FilterName": "GLBalance <> 0",
            	"FilterValue": "GLBalanceNotZero"
            }
            ]
        	});

        this.items = [
                      
            {
                name: "filter",
                itemId: "fiter-combo",
                xtype: "combo",
                id:'attestation-filter',
                fieldLabel: "Filter",
                valueField: "FilterValue",
                displayField: "FilterName",
                editable: false,
                store: filterValues
                
            },
            {
                name: "mgrId",
	            itemId: "mgrId-combo",
	            xtype: "combo",
	            fieldLabel: "Proof Owner",
	            valueField: "soeId",
	            displayField: "soeId",
	            editable: false,
	            queryMode:'local',
	            store: this.mgrStore
            }
             ,
            {
                name: "busineesunit",
	            itemId: "busineesunit-combo",
	            xtype: "combo",
	            fieldLabel: "Banking Group",
	            valueField: "bankingGroup",
	            displayField: "bankingGroup",
	            editable: false,
	            queryMode:'local',
	            store: this.businessunitStore
            }
            ,
            {
                name: "fullKey",
                itemId: "fullKey-text",
                xtype: "textfield",
                fieldLabel: "Full Key"
            }
            
        ];

        this.dockedItems = [
            {
                dock: "bottom", xtype: "toolbar", items: ["->",
                {
                    xtype: "button",
                    text: "Search",
                    scope: this,
                    action: "search"
                },
                {
                    xtype: "button",
                    text: "Clear",
                    scope: this,
                    action: "clear"
                }
            ]
            }
        ];

        this.callParent(arguments);
    }
});

Ext.define("eRecon_web.view.aoattestation.AOSummaryForm",
		{
	extend : "Ext.form.Panel",
	alias : "widget.aoattestation_aosummaryform",
	id : "aoattestationAOSummaryForm",
	defaults : {
		labelAlign : "side",
		labelWidth: 150
	},
	layout: {
        align: 'stretch',
        type: 'hbox'
    },
	bodyPadding : 10,

	items: [
	        {
	        	xtype: 'fieldset',
	        	flex: 1,
	        	border: 0,
	        	padding: 10,
	        	width: 249,
	        	layout: {
	        		align: 'stretch',
	        		type: 'vbox'
	        	},
	        	title: '',
	        	items: [
	        	        {
	        	        	xtype: 'displayfield',
	        	        	fieldLabel: 'Agreed',
	        	        	value: '',
	        	        	name: 'agreedCnt',
	        	        	listeners : {
	        	        		afterrender : function(component) {
	        	        			component.getEl().on('click',function() {
	        	        				component.up().up().fireEvent("clickReviewLink", 'Agreed');
	        	        			});
	        	        		}
	        	        	},
	        	        	renderer : function(val) {
	        	        		if(val==='AOB'){
	        	        			return "";
	        	        			
	        	        		}else{
	        	        			return "<p class='labelLinkCls'>" + val + "</p>";
	        	        		}
	        	        		
	        	        	}
	        	        },
	        	        {
	        	        	xtype: 'displayfield',
	        	        	fieldLabel: 'Disagreed',
	        	        	value: '',
	        	        	name : 'disagreedCnt',
	        	        	listeners : {
	        	        		afterrender : function(component) {
	        	        			component.getEl().on('click',function() {
	        	        				component.up().up().fireEvent("clickReviewLink", 'Disagreed');
	        	        			});
	        	        		}
	        	        	},
	        	        	renderer : function(val) {
	        	        		if(val==='AOB'){
	        	        			return "";
	        	        			
	        	        		}else{
	        	        			return "<p class='labelLinkCls'>" + val + "</p>";
	        	        		}
	        	        	}

	        	        },
	        	        {
	        	        	xtype: 'displayfield',
	        	        	fieldLabel: 'Unreviewed',
	        	        	value: '',
	        	        	name: 'unreviewedCnt',
	        	        	listeners : {
	        	        		afterrender : function(component) {
	        	        			component.getEl().on('click',function() {
	        	        				component.up().up().fireEvent("clickReviewLink", 'Unreviewed');
	        	        			});
	        	        		}
	        	        	},
	        	        	renderer : function(val) {
	        	        		if(val==='AOB'){
	        	        			return "";
	        	        			
	        	        		}else{
	        	        			return "<p class='labelLinkCls'>" + val + "</p>";
	        	        		}
	        	        	}

	        	        },
	        	        {
	        	        	xtype: 'displayfield',
	        	        	fieldLabel: '',
	        	        	value: '',
	        	        	name:'viewAll',
	        	        	itemId: "viewAll",
	        	        	listeners : {
	        	        		afterrender : function(component) {
	        	        			component.getEl().on('click', function() {
	        	        				component.up().up().fireEvent("clickReviewLink",'All');
	        	        			});
	        	        		}
	        	        	},
	        	        	renderer : function(val) {
	        	        		if(val==='AOB'){
	        	        			return "";
	        	        			
	        	        		}else{
	        	        			return "<p class='labelLinkCls'> View All</p>";
	        	        		}
	        	        	}
	        	        }
	        	        ]
	        },
	        {
	        	xtype: 'fieldset',
	        	flex: 1,
	        	border: 0,
	        	width: 483,
	        	title: '',
	        	items: [
	        	        {
	        	        	xtype: 'displayfield',
	        	        	anchor: '100%',
	        	        	fieldLabel: 'Total Accounts',
	        	        	labelWidth: 150,
	        	        	name: 'totalAcctCnt',
	        	        	value: ''
	        	        },
	        	        {
	        	        	xtype: 'displayfield',
	        	        	anchor: '100%',
	        	        	fieldLabel: 'Accounts Submitted',
	        	        	labelWidth: 150,
	        	        	name: 'acctsubmittedCnt',
	        	        	value: ''
	        	        },
	        	        {
	        	        	xtype: 'displayfield',
	        	        	anchor: '100%',
	        	        	fieldLabel: 'Accounts Unsubmitted',
	        	        	labelWidth: 150,
	        	        	name:'acctunsubmittedCnt',
	        	        	value: ''
	        	        },
	        	        {
	        	        	xtype: 'displayfield',
	        	        	anchor: '100%',
	        	        	fieldLabel: 'Accounts Attested',
	        	        	labelWidth: 150,
	        	        	name: 'attestedCnt',
	        	        	value: ''
	        	        },
	        	        {
	        	        	xtype: 'displayfield',
	        	        	anchor: '100%',
	        	        	fieldLabel: 'Accounts UnAttested',
	        	        	labelWidth: 150,
	        	        	name: 'unattestedCnt',
	        	        	value: ''
	        	        }
	        	        ]
	        },
	        {
	        	xtype: 'fieldset',
	        	flex: 1,
	        	border: 0,
	        	title: '',
	        	items: [
	        	        {
	        	        	xtype: "button",
	        	        	text: "<p style='color:blue;'>AO Upload/Download</p>",
	        	        	scope: this,
	        	        	width:150,
	        	        	height:25,
	        	        	action: "redirect" 
	        	        }
	        	        ]
	        }
	        ],

	        initComponent : function() {
	        	this.callParent(arguments);
	        }

		});

Ext.define("eRecon_web.view.aoattestation.DetailGrid", {
    extend: "Ext.grid.Panel",
    alias: "widget.aoattestation_detailgrid",
    autoScroll: true,
    columnLines: true,
    store: "eRecon_web.store.AOAttestationDetailStore",
    id: "aoattestationDetailId",
    enableColumnMove: true,
    selModel: "cellmodel",
    border: false,
    requires: [
	"eRecon_web.view.aoattestation.AOCheckColumn",
	"eRecon_web.view.common.AOCustomDialog",
	"eRecon_web.view.aoattestation.aoaging.Container",
	 "eRecon_web.view.aoattestation.AOCustomCellEditing",
	 "eRecon_web.plugins.PageSize"
	],
    viewConfig: {
        emptyText: "No details available.",
	    stripeRows: false,
	    listeners: {
	        beforecellmousedown: function (view, cell, cellIdx, record, row, rowIdx, eOpts) {
	            if (record.get("status_code") === "Unsubmitted") {
	                return true;
	            } else {
	                return false;
	            }
	        	return false;
	        }
	    },
	    getRowClass: function (record, index) {
            var statusCode = record.get("status_code");
            if (statusCode == 'Unsubmitted') {
                return "attestation-unsubmitted-record";
            } else {
                return "attestation-submitted-record";
            }
        }
    },
    initComponent: function () {
        var me = this;
        me.stateful = false;
        me.plugins= [
	        {
	            ptype: 'myaocellediting',
	            clicksToEdit: 1
	        }
        ];

        me.dockedItems = [
        {
            dock: "top", xtype: "toolbar", items: [
            {
            	xtype: "button",
            	tooltip: "Submit",
            	text:"Submit",action:"submit",iconCls: "iconSaveAll",scope:this
            }            ]
        },
        {
            xtype: "pagingtoolbar",
            store: me.store,
            dock: "bottom",
            displayInfo: true,
            plugins: [Ext.create("eRecon_web.plugins.PageSize")]

        }
    ];
        
        me.columns = [
            {header: "Full Key", 
             dataIndex: "fullkey",
             width:110,
             renderer:function(val,meta,record,rowIndex,colIndex,store){
        		return '<div style="white-space:normal !important;">' + val + '</div>'
        	 }
            }
            ,
            {header: "Description", 
	            dataIndex: "description",
	            width:110,
	            renderer: function(val) {
        		val = val.replace(/\n/g, '<br />');
				return '<div style="white-space:normal !important;">' + val + '</div>'
			}
            },
            {header: "Proof<br/>Owner", dataIndex: "mgruserid",flex:2.5}
            ,
            {header: "Banking group", dataIndex: "businessunit",width:80}
            ,
            {header: "GL Balance", dataIndex: "glbalance",flex:2,renderer: eRecon_web.gbl.constants.doubleValueRenderer}
            ,
            {header: "SL Balance", dataIndex: "slbalance",flex:2,renderer: eRecon_web.gbl.constants.doubleValueRenderer}
            ,
            {header: "Red/<br/>Green", dataIndex: "statusindicator",flex:2}
            ,
            {header: "Submitted/<br/>Unsubmitted", dataIndex: "status_code",flex:2.3}
            ,
            {header: "Currency<br/>Code", dataIndex: "ccycode",flex:2}
            ,
            {text: "Reportable Red amount", columns: [
				{header: 'Dr', dataIndex: 'amt_rptl_red_dr', align: 'center',width: 55,
				 align: 'left',sortable:true,
				 renderer: eRecon_web.gbl.constants.doubleValueRenderer},
				{header: 'Cr', dataIndex: 'amt_rptl_red_cr', align: 'center',width: 55,
			     align: 'left',sortable:true,
	             renderer: eRecon_web.gbl.constants.doubleValueRenderer}
			]
            },
            {text: "Amount at risk", columns: [
				{header: 'Dr', dataIndex: 'adjusted_amt_at_risk_dr', align: 'center',width: 55,
				 align: 'left',sortable:true,
	             renderer: eRecon_web.gbl.constants.doubleValueRenderer},
				{header: 'Cr', dataIndex: 'adjusted_amt_at_risk_cr', align: 'center',width: 55,
				 align: 'left',sortable:true,
	             renderer: eRecon_web.gbl.constants.doubleValueRenderer}
			]
            },
            {
            	header: "PO Comments", dataIndex: "comments",width:80
            },
            {
             header: "Agree <input type='checkbox' id='aoagreeSelectAllCb'> ", 
             dataIndex: "agree",
             flex:3,
             sortable:false,
             xtype:"aocheckcolumn"
            ,listeners: {
                checkchange: function (column, rowIndex, checked) {
                me.store.getAt(rowIndex).set('agree', 1);
                me.store.getAt(rowIndex).set('disagree', 0);
                me.store.getAt(rowIndex).set('unreviewed', 0);
                //console.log(checked);
            	}
              }	
            }
            ,
            {header: "Disagree",
             dataIndex: "disagree",
             flex:2,
             sortable: false,
             xtype:"aocheckcolumn"
             ,listeners: {
                checkchange: function (column, rowIndex, checked) {
                me.store.getAt(rowIndex).set('agree', 0);
                me.store.getAt(rowIndex).set('disagree', 1);
                me.store.getAt(rowIndex).set('unreviewed', 0);
                //console.log(checked);
            	}
              }		 
            
            }
            ,
            {header: "Unreviewed", 
             dataIndex: "unreviewed",
             flex:2.5,
             sortable: false,
             xtype:"aocheckcolumn"
             ,listeners: {
                checkchange: function (column, rowIndex, checked) {
                me.store.getAt(rowIndex).set('agree', 0);
                me.store.getAt(rowIndex).set('disagree', 0);
                me.store.getAt(rowIndex).set('unreviewed', 1);
                //console.log(checked);
            	}
              }		 
            },
            {
            	header:"AO Comments",
            	dataIndex:"disagreed_comments",
            	editor: {
              	 xtype: 'textarea',
              	 resizable:false,
              	 width:60,
              	 height:40
             	}
            },
            {
            	header:"View Additional Details",
            	sortable: false,
            	xtype: 'actioncolumn',
            	menuText:"View Additional Details",
            	align: 'center',
            	items: [{
                icon: 'resources/images/details.png',  
                tooltip: 'Details',
            	handler: function(grid, rowIndex, colIndex) {
            		var rec = grid.getStore().getAt(rowIndex);
                    var isSubmitted = rec.get('status_code');
                    if(isSubmitted === 'Unsubmitted') {
                    	Ext.MessageBox.alert("Alert",  "Record is not Submitted yet.");
                    	return false;
                    }
            		me.showAOAgingDialog(grid, rowIndex)
                   
                }
                
            }]
            },
            {header: "AccountId", dataIndex: "account_id",hidden:true},
            {header: "Recon Period", dataIndex: "reconperiod",hidden:true},
            {header: "AcctAgingType", dataIndex: "acct_aging_type",hidden:true}
            
            
            
        ];
        
        Ext.getBody().on('click', this.handleSelectAllAOAgreeCheckBox, "#aoattestationDetailId", {
        	delegate: '#aoagreeSelectAllCb'
        });
        
        me.callParent(arguments);
    },handleSelectAllAOAgreeCheckBox : function(event, target){
    	var aoagreeSelectAllCb = Ext.query('#aoagreeSelectAllCb');
    	var aoattestationGridPanel = Ext.getCmp('aoattestationDetailId');
    	var store = aoattestationGridPanel.getStore();
    	var records = store.getRange();
    	if(aoagreeSelectAllCb[0].checked) {
    		for(var i=0; i< records.length; i++) {
    			if(records[i].get("status_code") != 'Unsubmitted' && records[i].get("disagree")!='1'){
    				records[i].set('agree', 1);
    				records[i].set('disagree', 0);
    				records[i].set('unreviewed', 0);
    			}
    		}
    	} else {
    		for(var i=0; i< records.length; i++) {
    			if(records[i].get("status_code") != 'Unsubmitted' && records[i].get("disagree")!='1'){
    				records[i].set('agree', 0);
    				records[i].set('unreviewed', 1);
    			}
    	  }
        }
}, 

showAOAgingDialog: function(grid, rowIndex) {
	var me = this;
	cont = grid.up('aoattestation_container');
	cont.setLoading(true);
	Ext.defer(function() {cont.setLoading(false);}, 2000);
	Ext.defer(function() {
		me.fireEvent("showAOAttestationAgingDialog", grid, rowIndex);
	}, 100);
}
});

Ext.define("eRecon_web.view.aoattestation.AOAttestationContainer", {
    extend: "Ext.container.Container",
    alias: "widget.aoattestation_container",
    requires: ["eRecon_web.view.aoattestation.AOSummaryForm",
               "eRecon_web.view.aoattestation.DetailGrid",
               "eRecon_web.view.aoattestation.AOAttestationFilterForm",
               "eRecon_web.view.aoattestation.AccountOwnerForm"],
    layout: "border",
    initComponent: function (config) {
		this.acctownerform=Ext.create("eRecon_web.view.aoattestation.AccountOwnerForm",{
			region: "north",
			split: true,
			title: "AO Ownership",
			flex: 1,
        	collapsible: true,
        	animCollapse: false
		});

        this.detailGrid = Ext.create("eRecon_web.view.aoattestation.DetailGrid", {
            title: "AO Detailed Records",
            region: "center",
            flex: 3
        });
        
        this.aosummaryform= Ext.create("eRecon_web.view.aoattestation.AOSummaryForm", {
            region: "north",
            title: "AO Summary Statistics",
            split: true,
            flex: 2.7,
        	collapsible: true,
        	animCollapse: false
        });

         this.filterForm = Ext.create("eRecon_web.view.aoattestation.AOAttestationFilterForm", {
            title: "Filter",
            region: "west",
            split: true,
            flex: 1.3,
            collapsible: true,
            animCollapse: false,
            collapsed: true
        });

        this.items = [
            this.acctownerform,
            this.aosummaryform,
            this.detailGrid,
            this.filterForm
        ];

        this.callParent(config);
    }
});

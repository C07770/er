Ext.define('eRecon_web.view.aoattestation.AOCheckColumn', {
    extend: 'Ext.ux.CheckColumn',
    alias: 'widget.aocheckcolumn',

    /**
     * @cfg {Boolean} [stopSelection=true]
     * Prevent grid selection upon mousedown.
     */
    stopSelection: true,

    tdCls: Ext.baseCSSPrefix + 'grid-cell-checkcolumn',

    constructor: function () {
        this.addEvents(
            /**
             * @event beforecheckchange
             * Fires when before checked state of a row changes.
             * The change may be vetoed by returning `false` from a listener.
             * @param {Ext.ux.CheckColumn} this CheckColumn
             * @param {Number} rowIndex The row index
             * @param {Boolean} checked True if the box is to be checked
             */
            'beforecheckchange',
            /**
             * @event checkchange
             * Fires when the checked state of a row changes
             * @param {Ext.ux.CheckColumn} this CheckColumn
             * @param {Number} rowIndex The row index
             * @param {Boolean} checked True if the box is now checked
             */
            'checkchange'
        );
        this.callParent(arguments);
    },

    /**
     * @private
     * Process and refire events routed from the GridView's processEvent method.
     */
    
     processEvent : function(type, view, cell, recordIndex,
			cellIndex, e) {
		if (type == 'mousedown'
				|| (type == 'keydown' && (e.getKey() == e.ENTER || e
						.getKey() == e.SPACE))) {
			var record = view.panel.store.getAt(recordIndex);
			
			// do not change data and fire checkchange event if
			// it's iOS
			var allow = false;
			if(record.get('status_code') != 'Unsubmitted') {
				allow = true;
			}
			if (allow) {
				dataIndex = this.dataIndex;
				checked = !record.get(dataIndex);
				record.set(dataIndex, checked);
				this.fireEvent('checkchange', this,	recordIndex, checked);
			}
			return false;
		} else {
			return this.callParent(arguments);
		}
	},

    // Note: class names are not placed on the prototype bc renderer scope
    // is not in the header.
    renderer: function (value) {
        var cssPrefix = Ext.baseCSSPrefix,
            cls = [cssPrefix + 'grid-checkheader'];

        if (value === "1") {
            cls.push(cssPrefix + 'grid-checkheader-checked');
        }
        return '<div class="' + cls.join(' ') + '">&#160;</div>';
    }
});

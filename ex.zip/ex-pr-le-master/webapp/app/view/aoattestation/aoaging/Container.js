Ext.define('eRecon_web.view.aoattestation.aoaging.Container', {
    extend: 'Ext.tab.Panel',
    alias: 'widget.aoaging_tabcontainer',
    requires: [
        'eRecon_web.view.aoattestation.aoaging.BalanceAging',
        'eRecon_web.view.aoattestation.aoaging.ReconBreakAging',
        'eRecon_web.view.aoattestation.aoaging.AmountAtRisk'
        
    ],
    border: true,
    initComponent: function (config) {
        var me = this;
        me.items = [
            {
                title: 'Balance Aging',
                xtype: 'aobalanceaging_container',
                name: 'baging',
                html: 'balanceaging',
                itemId:'aobalanceaging'
                
            },
            {
                title: 'Recon Break Aging',
                xtype: 'aoreconbreakaging_container',
                name: 'rbaging',
                html: 'reconbreakaging',
                itemId:'aoreconaging'
            }
        ];

        me.dockedItems = [
            {
            	xtype: "aoamountatrisk_container",
            	dock: "bottom"
            	
            }
                        
        ];

        this.callParent(arguments);
    }

});

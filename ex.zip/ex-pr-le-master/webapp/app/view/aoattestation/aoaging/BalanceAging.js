Ext.define('eRecon_web.view.aoattestation.aoaging.BalanceAging', {
    extend: 'Ext.form.Panel',
    alias: 'widget.aobalanceaging_container',
    requires : [ "eRecon_web.common.CustomCreditNumericField","eRecon_web.common.CustomDebitNumericField","eRecon_web.common.CustomNumericField"],
    store:'eRecon_web.store.AOAgingDetailStore',
    items : [ {
		xtype : 'form',
		bodyPadding : 10,
		title : '',
		items : [ {
			xtype : 'fieldset',
			padding : '4px 5px 5px 5px',
			height: 80,
			layout : {
				columns : 3,
				type : 'table'
			},
			title : '',
			items : [ {
				xtype : 'displayfield',
				colspan : 2,
				itemId : 'GL_FULLKEY',
				minWidth : 200,
				padding : '4px 5px 0px 5px',
				fieldLabel : 'Fullkey',
				labelWidth : 150,
				name:'FULLKEY',
				value : ''
			}, {
				xtype : 'displayfield',
				itemId : 'GL_LCL_CCY_THRESHLD',
				minWidth : 200,
				padding : '4px 5px 0px 5px',
				fieldLabel : 'Local Ccy Threshold',
				labelWidth : 150,
				name:'LCL_CCY_THRESHOLD',
				value : '',
				customFormat: true

			}, 
			
			{
				xtype : 'displayfield',
				itemId : 'GL_GLBALANCE',
				minWidth : 200,
				padding : '4px 5px 0px 5px',
				fieldLabel : 'GL Balance',
				labelWidth : 150,
				name:'GLBALANCE',
				value : '',
				customFormat: true
			}, 
			
			{
				xtype : 'displayfield',
				itemId : 'GL_SLBALANCE',
				minWidth : 200,
				padding : '4px 5px 0px 5px',
				fieldLabel : 'SL Balance',
				labelWidth : 150,
				name:'SLBALANCE',
				value : '',
				customFormat: true
			}, 
			
			{
				xtype : 'displayfield',
				itemId : 'GL_CONTROLTOTAL',
				minWidth : 200,
				padding : '4px 5px 0px 5px',
				fieldLabel : 'Control Total',
				labelWidth : 150,
				name:'CONTROLTOTAL',
				value : '',
				customFormat: true
			} 
		]},  

		{
			xtype : 'fieldset',
			padding : '4px 5px 5px 5px',
			/* width : 786, */
			height: 330,
			layout : {
				columns : 5,
				type : 'table'
			},
			title : '',
			items : [ {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				text : 'Aging Buckets',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				text : 'Gross Debit Number of Items',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				text : 'Gross Debit Amount (+)',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				text : 'Gross Credit Number of Items',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				text : 'Gross Credit Amount (-)',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : '0-7',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'numberfield',
				hideTrigger : true,
				itemId : 'GL_QTY0-7DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'QTYLT7DR',
				readOnly:true,
				fieldCls:"disabledTextField",
				fieldStyle: 'text-align:right'
			}, {
				xtype : 'customDebitNumericField',
				hideTrigger : true,
				itemId : 'GL_AMT0-7DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMTLT7DR',
				readOnly:true,
				fieldCls:"disabledTextField",
				fieldStyle: 'text-align:right',
				listeners : {
	    		    change: function() {
	    		    	this.onBlur();
	    		    }
	    		}
			}, {
				xtype : 'numberfield',
				hideTrigger : true,
				itemId : 'GL_QTY0-7CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'QTYLT7CR',
				readOnly:true,
				fieldCls:"disabledTextField",
				fieldStyle: 'text-align:right'
			}, {
				xtype : 'customCreditNumericField',
				hideTrigger : true,
				itemId : 'GL_AMT0-7CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMTLT7CR',
				readOnly:true,
				fieldCls:"disabledTextField",
				listeners : {
	    		    change: function() {
	    		    	this.onBlur();
	    		    }
	    		}
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : '8-30',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'numberfield',
				hideTrigger : true,
				itemId : 'GL_QTY8-30DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'QTY8_30DR',
				fieldStyle: 'text-align:right',
				fieldCls:"disabledTextField",
				readOnly:true
			}, {
				xtype : 'customDebitNumericField',
				hideTrigger : true,
				itemId : 'GL_AMT8-30DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT8_30DR',
				fieldStyle: 'text-align:right',
				fieldCls:"disabledTextField",
				readOnly:true,
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'numberfield',
				hideTrigger : true,
				itemId : 'GL_QTY8-30CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'QTY8_30CR',
				fieldCls:"disabledTextField",
				readOnly: true,
				fieldStyle: 'text-align:right'
			}, {
				xtype : 'customCreditNumericField',
				hideTrigger : true,
				itemId : 'GL_AMT8-30CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT8_30CR',
				readOnly : true,
				fieldCls:"disabledTextField",
				listeners : {
	      		    change: function() {
	      		    	this.onBlur();
	      		    }
	      		}
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : '31-60',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'numberfield',
				hideTrigger : true,
				itemId : 'GL_QTY31-60DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'QTY31_60DR',
				fieldStyle: 'text-align:right',
				readOnly:true,
				fieldCls:"disabledTextField"
			}, {
				xtype : 'customDebitNumericField',
				hideTrigger : true,
				itemId : 'GL_AMT31-60DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT31_60DR',
				fieldStyle: 'text-align:right',
				fieldCls:"disabledTextField",
				readOnly:true,
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'numberfield',
				hideTrigger : true,
				itemId : 'GL_QTY31-60CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'QTY31_60CR',
				fieldStyle: 'text-align:right',
				fieldCls:"disabledTextField",
				readOnly:true
			}, {
				xtype : 'customCreditNumericField',
				hideTrigger : true,
				itemId : 'GL_AMT31-60CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT31_60CR',
				readOnly:true,
				fieldCls:"disabledTextField",
				listeners : {
	    		    change: function() {
	    		    	this.onBlur();
	    		    }
	    		}
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : '61-90',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'numberfield',
				hideTrigger : true,
				itemId : 'GL_QTY61-90DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'QTY61_90DR',
				fieldStyle: 'text-align:right',
				readOnly : true,
				fieldCls:"disabledTextField"
			}, {
				xtype : 'customDebitNumericField',
				hideTrigger : true,
				itemId : 'GL_AMT61-90DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT61_90DR',
				fieldStyle: 'text-align:right',
				fieldCls:"disabledTextField",
				readOnly : true,
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'numberfield',
				hideTrigger : true,
				itemId : 'GL_QTY61-90CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'QTY61_90CR',
				fieldCls:"disabledTextField",
				fieldStyle: 'text-align:right',
				readOnly:true
			}, {
				xtype : 'customCreditNumericField',
				hideTrigger : true,
				itemId : 'GL_AMT61-90CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT61_90CR',
				fieldCls:"disabledTextField",
				readOnly:true,
				listeners : {
	      		    change: function() {
	      		    	this.onBlur();
	      		    }
	      		}
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : '91-120',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'numberfield',
				hideTrigger : true,
				itemId : 'GL_QTY91-120DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'QTY91_120DR',
				fieldStyle: 'text-align:right',
				readOnly:true,
				fieldCls:"disabledTextField"
			}, {
				xtype : 'customDebitNumericField',
				hideTrigger : true,
				itemId : 'GL_AMT91-120DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT91_120DR',
				fieldStyle: 'text-align:right',
				readOnly:true,
				fieldCls:"disabledTextField",
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'numberfield',
				hideTrigger : true,
				itemId : 'GL_QTY91-120CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'QTY91_120CR',
				fieldStyle: 'text-align:right',
				readOnly:true,
				fieldCls:"disabledTextField"
			}, {
				xtype : 'customCreditNumericField',
				hideTrigger : true,
				itemId : 'GL_AMT91-120CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT91_120CR',
				readOnly:true,
				fieldCls:"disabledTextField",
				listeners : {
	    		    change: function() {
	    		    	this.onBlur();
	    		    }
	    		}
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : '121-150',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'numberfield',
				hideTrigger : true,
				itemId : 'GL_QTY121-150DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'QTY121_150DR',
				fieldStyle: 'text-align:right',
				readOnly:true,
				fieldCls:"disabledTextField"
			}, {
				xtype : 'customDebitNumericField',
				hideTrigger : true,
				itemId : 'GL_AMT121-150DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT121_150DR',
				fieldStyle: 'text-align:right',
				readOnly:true,
				fieldCls:"disabledTextField",
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
				
			}, {
				xtype : 'numberfield',
				hideTrigger : true,
				itemId : 'GL_QTY121-150CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'QTY121_150CR',
				fieldStyle: 'text-align:right',
				readOnly:true,
				fieldCls:"disabledTextField"
				
			}, {
				xtype : 'customCreditNumericField',
				hideTrigger : true,
				itemId : 'GL_AMT121-150CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT121_150CR',
				readOnly:true,
				fieldCls:"disabledTextField",
				listeners : {
	      		    change: function() {
	      		    	this.onBlur();
	      		    	}
	      		}
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : '151-180',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'numberfield',
				hideTrigger : true,
				itemId : 'GL_QTY151-180DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'QTY151_180DR',
				fieldStyle: 'text-align:right',
				readOnly:true,
				fieldCls:"disabledTextField"
			}, {
				xtype : 'customDebitNumericField',
				hideTrigger : true,
				itemId : 'GL_AMT151-180DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT151_180DR',
				fieldStyle: 'text-align:right',
				readOnly:true,
				fieldCls:"disabledTextField",
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
				
			}, {
				xtype : 'numberfield',
				hideTrigger : true,
				itemId : 'GL_QTY151-180CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'QTY151_180CR',
				fieldStyle: 'text-align:right',
				readOnly:true,
				fieldCls:"disabledTextField"
			}, {
				xtype : 'customCreditNumericField',
				hideTrigger : true,
				itemId : 'GL_AMT151-180CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT151_180CR',
				readOnly:true,
				fieldCls:"disabledTextField",
				listeners : {
	    		    change: function() {
	    		    	this.onBlur();
	    		    }
	            }
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : '181-365',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'numberfield',
				hideTrigger : true,
				itemId : 'GL_QTYABOVE180DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'QTYGT181DR',
				readOnly:true,
				fieldCls:"disabledTextField",
				fieldStyle: 'text-align:right'
				
			}, {
				xtype : 'customDebitNumericField',
				hideTrigger : true,
				itemId : 'GL_AMTABOVE180DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMTGT181DR',
				fieldStyle: 'text-align:right',
				readOnly:true,
				fieldCls:"disabledTextField",
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
				
			}, {
				xtype : 'numberfield',
				hideTrigger : true,
				itemId : 'GL_QTYABOVE180CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'QTYGT181CR',
				fieldStyle: 'text-align:right',
				readOnly:true,
				fieldCls:"disabledTextField"
			}, {
				xtype : 'customCreditNumericField',
				hideTrigger : true,
				itemId : 'GL_AMTABOVE180CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMTGT181CR',
				readOnly:true,
				fieldCls:"disabledTextField",
				listeners : {
	    		    change: function() {
	    		    	this.onBlur();
	    		    }
	            }
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : '365+',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'numberfield',
				hideTrigger : true,
				itemId : 'GL_QTYUNKNOWNDR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'QTYGROSSUNKNOWNDR',
				fieldStyle: 'text-align:right',
				readOnly:true,
				fieldCls:"disabledTextField"
			}, {
				xtype : 'customDebitNumericField',
				hideTrigger : true,
				itemId : 'GL_AMTUNKNOWNDR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMTGROSSUNKNOWNDR',
				fieldStyle: 'text-align:right',
				readOnly:true,
				fieldCls:"disabledTextField",
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'numberfield',
				hideTrigger : true,
				itemId : 'GL_QTYUNKNOWNCR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'QTYGROSSUNKNOWNCR',
				fieldStyle: 'text-align:right',
				fieldCls:"disabledTextField",
            	readOnly:true
			}, {
				xtype : 'customCreditNumericField',
				hideTrigger : true,
				itemId : 'GL_AMTUNKNOWNCR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMTGROSSUNKNOWNCR',
				fieldCls:"disabledTextField",
				readOnly:true,
				listeners : {
	    		    change: function() {
	    		    	this.onBlur();
	    		    }
	            }
			} ]
		}, {
			xtype : 'fieldset',
			padding : '4px 5px 5px 5px',
			height: 120,
			layout : {
				columns : 4,
				type : 'table'
			},
			title : '',
			items : [ {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : ''
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : 'User Entered Red',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				html : 'Controller Delegate RED <br/> Adjustment',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : 'Adjusted User Red',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : 'DR'
			}, {
				xtype : 'customDebitNumericField',
				hideTrigger : true,
				itemId : 'GL_USERREDAMTDR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT_USER_RED_DR',
				readOnly:true,
		        fieldStyle: 'text-align:right',
		        fieldCls:"disabledTextField",
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'customNumericField',
				hideTrigger : true,
				itemId : 'GL_LEMUSERREDADJDR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'LEM_RED_ADJ_DR',
				readOnly:true,
				fieldStyle: 'text-align:right',
				fieldCls:"disabledTextField",
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
				
			}, {
				xtype : 'customDebitNumericField',
				hideTrigger : true,
				itemId : 'GL_ADJUSERREDDR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'ADJUST_USER_RED_DR',
				readOnly:true,
				fieldStyle: 'text-align:right',
				fieldCls:"disabledTextField",
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : 'CR'
			}, {
				xtype : 'customCreditNumericField',
				hideTrigger : true,
				itemId : 'GL_USERREDAMTCR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT_USER_RED_CR',
				fieldCls:"disabledTextField",
				readOnly:true,
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'customNumericField',
				hideTrigger : true,
				itemId : 'GL_LEMUSERREDADJCR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'LEM_RED_ADJ_CR',
				fieldCls:"disabledTextField",
				readOnly:true,
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'customCreditNumericField',
				hideTrigger : true,
				itemId : 'GL_ADJUSERREDCR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'ADJUST_USER_RED_CR',
				fieldCls:"disabledTextField",
				readOnly:true,
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			} ]
		}, {
			xtype : 'fieldset',
			padding : '4px 5px 5px 5px',
			height: 110,
			layout : {
			columns : 4,
			type : 'table'
			},
			title : '',
			items : [ {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : ''
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : 'System Red',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : 'Total Red',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : 'Reportable Red',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : 'DR'
			}, {
				xtype : 'customDebitNumericField',
				hideTrigger : true,
				itemId : 'GL_AMTSYSREDDR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT_SYS_RED_DR',
				readOnly:true,
		        fieldStyle: 'text-align:right',
		        fieldCls:"disabledTextField",
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'customDebitNumericField',
				hideTrigger : true,
				itemId : 'GL_AMTTOTREDDR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT_TOT_RED_DR',
				readOnly:true,
				fieldStyle: 'text-align:right',
				fieldCls:"disabledTextField",
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			
			}, {
				xtype : 'customDebitNumericField',
				hideTrigger : true,
				itemId : 'GL_AMTRPTLREDDR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT_RPTL_RED_DR',
				readOnly:true,
				fieldStyle: 'text-align:right',
				fieldCls:"disabledTextField",
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : 'CR'
			}, {
				xtype : 'customCreditNumericField',
				hideTrigger : true,
				itemId : 'GL_AMTSYSREDCR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT_SYS_RED_CR',
				fieldCls:"disabledTextField",
				readOnly:true,
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
				}
			}, {
				xtype : 'customCreditNumericField',
				hideTrigger : true,
				itemId : 'GL_AMTTOTREDCR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT_TOT_RED_CR',
				fieldCls:"disabledTextField",
				readOnly:true,
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'customCreditNumericField',
				hideTrigger : true,
				itemId : 'GL_AMTRPTLREDCR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT_RPTL_RED_CR',
				fieldCls:"disabledTextField",
				readOnly:true,
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			} ]
		},
		
		{
			xtype : 'fieldset',
			padding : '4px 5px 5px 5px',
			height: 80,
			layout : {
				columns : 4,
				type : 'table'
			},
			title : '',
			items : [ {
				xtype : 'textfield',
				colspan : 2,
				itemId : 'GL_STATUSINDICATOR',
				padding : '4px 5px 0px 5px',
				fieldLabel : 'Status Indicator',
				labelWidth : 150,
				name : 'STATUSINDICATOR',
				readOnly:true,
				fieldCls:"disabledTextField"
			}, {
				xtype : 'textfield',
				colspan : 2,
				itemId : 'GL_BENCHMARKVIOLATION',
				padding : '4px 5px 0px 5px',
				fieldLabel : 'BenchMark Violation',
				labelWidth : 150,
				name : 'BENCHMARKVIOLATION',
				readOnly:true,
				fieldCls:"disabledTextField"
			}, {
				xtype : 'textfield',
				colspan : 4,
				padding : '4px 5px 0px 5px',
				width : 532,
				fieldLabel : 'BenchMark',
				readOnly:true,
				fieldCls:"disabledTextField",
				name : 'BENCHMARK_DESCRIPTION',
				labelWidth : 150
			} ]
		 },
		 
		 {
			xtype : 'fieldset',
			padding : '4px 5px 5px 5px',
			height: 140,
			layout : {
			columns : 3,
			type : 'table'
			},
			title : '',
			items : [ {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : 'PO Comments',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : 'AO Comments',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 150,
				text : 'Controller Delegate Comments',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'textareafield',
				itemId : 'GL_PO_COMMENTS',
				padding : '4px 5px 0px 5px',
				width : 150,
				name : 'COMMENTS',
				readOnly:true,
				fieldStyle: "background: #F0F0F0 none repeat scroll 0 0 !important;"
			}, {
				xtype : 'textareafield',
				itemId : 'GL_AO_COMMENTS',
				padding : '4px 5px 0px 5px',
				width : 150,
				name : 'AO_COMMENTS',
				readOnly:true,
				fieldStyle: "background: #F0F0F0 none repeat scroll 0 0 !important;"
			}, {
				xtype : 'textareafield',
				itemId : 'GL_LEM_COMMENTS',
				padding : '4px 5px 0px 5px',
				width : 150,
				name : 'LEM_COMMENTS',
				readOnly:true,
				fieldStyle: "background: #F0F0F0 none repeat scroll 0 0 !important;"
			} ]
		} ]
	  }
	],
    initComponent: function (config) {
        this.callParent(arguments);
    }
})
;

Ext.define('eRecon_web.view.aoattestation.aoaging.AmountAtRisk', {
    extend: 'Ext.form.Panel',
    alias: 'widget.aoamountatrisk_container',
    store:'eRecon_web.store.AOAgingDetailStore',
    requires : [ "eRecon_web.common.CustomCreditNumericField","eRecon_web.common.CustomDebitNumericField","eRecon_web.common.CustomNumericField"],
    items : [ {
		xtype : 'form',
		bodyPadding : 10,
		title : '',
		items : [
		   {
			xtype : 'fieldset',
			height: 180,
			padding : '4px 5px 5px 5px',
			layout : {
				columns : 7,
				type : 'table'
			},
			title : '',
			items : [ {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				text : ''
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 120,
				text : 'Amount At Risk',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 120,
				text : 'Controller Delegate Amt at Risk Adj',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 120,
				text : 'Adj Amt at Risk',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 120,
				text : 'Reportable Amt at Risk',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 120,
				text : 'Category',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 120,
				text : 'Target Resolution date',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				text : 'DR'
			}, {
				xtype : 'customDebitNumericField',
				hideTrigger : true,
				itemId : 'SPECIFICAMTATRISKDR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'SPECIFICAMTATRISKDR',
				width : 120,
				fieldStyle: 'text-align:right',
				readOnly:true,
				fieldCls:"disabledTextField",
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'customNumericField',
				hideTrigger : true,
				itemId : 'LEM_AMT_AT_RISK_ADJ_DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'LEM_AMT_AT_RISK_ADJ_DR',
				fieldCls:"disabledTextField",
				width : 120,
				readOnly:true,
				fieldStyle: 'text-align:right',
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'customDebitNumericField',
				hideTrigger : true,
				itemId : 'ADJUST_AMOUNT_AT_RISK_DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'ADJUST_AMOUNT_AT_RISK_DR',
				width : 120,
				fieldCls:"disabledTextField",
				readOnly:true,
				fieldStyle: 'text-align:right',
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'customDebitNumericField',
				hideTrigger : true,
				itemId : 'AMT_AT_RISK_RPTL_DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT_AT_RISK_RPTL_DR',
				fieldCls:"disabledTextField",
				width : 120,
				readOnly:true,
				fieldStyle: 'text-align:right',
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'textfield',
				itemId : 'AMT_AT_RISK_TYPE_DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT_AT_RISK_TYPE_DR',
				fieldCls:"disabledTextField",
				width : 120,
				readOnly:true,
				fieldStyle: 'text-align:right'
			}, {
				xtype : 'textfield',
				itemId : 'AMT_AT_RISK_TARGET_DATE_DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT_AT_RISK_TARGET_DT_DR',
				fieldCls:"disabledTextField",
				width : 120,
				readOnly:true,
				fieldStyle: 'text-align:right'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				text : 'CR'
			}, {
				xtype : 'customCreditNumericField',
				hideTrigger : true,
				itemId : 'SPECIFICAMTATRISKCR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'SPECIFICAMTATRISKCR',
				fieldStyle : 'text-align:right',
				width : 120,
				readOnly:true,
				fieldCls:"disabledTextField",
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'customNumericField',
				hideTrigger : true,
				itemId : 'LEM_AMT_AT_RISK_ADJ_CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'LEM_AMT_AT_RISK_ADJ_CR',
				fieldCls:"disabledTextField",
				width : 120,
				fieldStyle: 'text-align:right',
				readOnly:true,
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'customCreditNumericField',
				hideTrigger : true,
				itemId : 'ADJUST_AMOUNT_AT_RISK_CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'ADJUST_AMOUNT_AT_RISK_CR',
				fieldCls:"disabledTextField",
				fieldStyle: 'text-align:right',
				readOnly:true,
				width : 120,
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'customCreditNumericField',
				hideTrigger : true,
				itemId : 'AMT_AT_RISK_RPTL_CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT_AT_RISK_RPTL_CR',
				fieldCls:"disabledTextField",
				width : 120,
				fieldStyle: 'text-align:right',
				readOnly:true,
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'textfield',
				itemId : 'AMT_AT_RISK_TYPE_CR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT_AT_RISK_TYPE_CR',
				fieldCls:"disabledTextField",
				width : 120,
				readOnly:true,
				fieldStyle: 'text-align:right'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 120,
				text : ''
			},{
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 120,
				text : ''
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 120,
				text : 'Reserve',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 120,
				text : 'Controller Delegate Reserve Adj',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 120,
				text : 'Adjusted Reserve',
				style: 'display:block;text-align:center'
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 120,
				text : ''
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 120,
				text : ''
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 120,
				text : ''
			},{
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 120,
				text : ''
			},{
				xtype : 'customDebitNumericField',
				hideTrigger : true,
				itemId : 'AMT_AT_RISK_RESERVE_DR',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'AMT_AT_RISK_RESERVE_DR',
				fieldStyle: 'text-align:right',
				readOnly:true,
				width : 120,
				fieldCls:"disabledTextField",
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'customNumericField',
				hideTrigger : true,
				itemId : 'LEM_RESERVE_ADJUST',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'LEM_RESERVE_ADJUST',
				fieldCls:"disabledTextField",
				readOnly:true,
				width : 120,
				fieldStyle: 'text-align:right',
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'customDebitNumericField',
				hideTrigger : true,
				itemId : 'ADJUST_RESERVE',
				padding : '4px 5px 0px 5px',
				fieldLabel : '',
				name : 'ADJUST_RESERVE',
				width : 120,
				fieldCls:"disabledTextField",
				readOnly:true,
				fieldStyle: 'text-align:right',
				listeners : {
			        change: function() {
			        	this.onBlur();
			        }
		        }
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 120,
				text : ''
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 120,
				text : ''
			}, {
				xtype : 'label',
				padding : '4px 5px 0px 5px',
				width : 120,
				text : ''
			} ]
		}     
    	       
   		]
   		}],
   initComponent : function(config) {
   		this.callParent(arguments);
   	}
});

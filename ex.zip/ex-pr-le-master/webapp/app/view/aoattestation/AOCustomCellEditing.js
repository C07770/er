Ext.define('eRecon_web.view.aoattestation.AOCustomCellEditing', {
    extend: 'Ext.grid.plugin.CellEditing',
    alias: 'plugin.myaocellediting',

    constructor: function () {
        this.callParent(arguments);
        this.toReselectAfterEdit = [];
    },

    showEditor: function (ed, context, value) {
        var me = this,
            record = context.record,
            columnHeader = context.column,
            sm = me.grid.getSelectionModel(),
            selection = sm.getCurrentPosition();
        
        if(record.get('status_code') === 'Unsubmitted') {
        	return false;
        }

        if (sm.isSelected(context.record)) this.toReselectAfterEdit.push(context.record);
        me.context = context;
        me.setActiveEditor(ed);
        me.setActiveRecord(record);
        me.setActiveColumn(columnHeader);

        /*
         // The absence of this piece of code from the parent method is key.
         if (sm.selectByPosition && (!selection || selection.column !== context.colIdx || selection.row !== context.rowIdx)) {
         sm.selectByPosition({
         row: context.rowIdx,
         column: context.colIdx
         });
         }
         */

        ed.startEdit(me.getCell(record, columnHeader), value);
        me.editing = true;
        me.scroll = me.view.el.getScroll();
    },

    completeEdit: function () {
        this.callParent(arguments);
        this.reselectRowsThatShouldNeverHaveBeenDeselected();
        /*this.fireEvent('completeEditing');*/
    },

    onEditComplete: function () {
        this.callParent(arguments);
        this.reselectRowsThatShouldNeverHaveBeenDeselected();
    },

    reselectRowsThatShouldNeverHaveBeenDeselected: function () {
        if (this.toReselectAfterEdit) {
            var record;
            while (record = this.toReselectAfterEdit.pop()) {
                this.grid.getSelectionModel().deselect(record);
                this.grid.getSelectionModel().select(record, true);
            }
        }
    }
});

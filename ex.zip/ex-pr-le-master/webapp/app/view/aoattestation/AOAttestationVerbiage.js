Ext.define("eRecon_web.view.aoattestation.AOAttestationVerbiage", {
    extend: "Ext.window.Window",
    alias: "widget.aoattestation_verbiage",
    bodyPadding: 10,
    floating:true,
    closable:true,
    closeAction:'hide',
    border:true,
    modal:true,
    initComponent: function () {
		
        this.items = [
            {
            	name: "transfermessage",
	            itemId: "transferToList-label",
	            xtype: "label",
            html: "<table>" +
			"<tr><td>" +
                "<br />" +
                //"<center>" +
                    "<b><i>ACCOUNT OWNER ATTESTATION</i></b>" +
                "<br />" +
                "<br />" +
                "<i>I ____________________ am the Account Owner for the population of accounts as identified within the eRecon system. As the Account Owner, I play a critical role in the overall control process over the</i> " +
                "<i>balance sheet to ensure that the balances are properly stated in the General Ledger. I attest that I am responsible to understand the nature of these accounts and based on my understanding of the</i> " +
                "<i>balances and/or the processes, depending on account type, that impact the account (except for the accounts I noted as exceptions) I attest to the best of my knowledge that the following is true:</i> <br />" +
                " <br />" +
                "<ul>" +
                "<li><i>&nbsp;&nbsp;&nbsp;&middot;&nbsp;The Amounts at Risk reported in eRecon represent amounts that have a reasonable possibility for P&L impact. Where applicable, any reserve balances have been reported in eRecon.</i></li>" +
                 "<li><i>&nbsp;&nbsp;&nbsp;&middot;&nbsp;Outstanding items or reconciliation breaks have corrective actions in place to resolve the items on a timely basis</i></li>" +
                  "<li><i>&nbsp;&nbsp;&nbsp;&middot;&nbsp;Significant management estimates, where applicable, that are required to determine the proper balances have been reviewed and are based on timely assumptions</i></li>" +
               "</ul>" +
                "<br />" +
                 "<i>Note:  All reconciliations require a maker and a checker. Where the reconciliation is performed in a strategic site the checker function is centrally performed and the Account Owner is not required to</i> <br /> " +
                 "<i>review the reconciliation as part of the attestation process.</i>" +
                "<br />" +
            "</td></tr>" +
      "</table>"
            }
        ];
        
        this.dockedItems = [
            {
                dock: "bottom", xtype: "toolbar", items: [
                {
                    xtype: "button",
                    text: "I Attest",
                    iconCls: "iconSaveAll",
                    scope: this,
                    handler: function () {
                    	this.fireEvent("attestsubmit", {clientApp: this.clientApp, cmp: this});
                	}
           
                }
                ,
                "-"
                ,
                {
                	xtype: "button",
	                text: "Return to Account Reviews",
	                scope: this,
	                iconCls: 'iconCancel',
	                handler: function () {
                		this.fireEvent("attestcancel", {clientApp: this.clientApp, cmp: this});
            		}
                }
            ]
            }
        ];
        this.callParent(arguments);
    }

});

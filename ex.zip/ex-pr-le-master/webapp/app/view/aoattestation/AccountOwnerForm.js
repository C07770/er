Ext.define("eRecon_web.view.aoattestation.AccountOwnerForm", {
    extend: "Ext.form.Panel",
    alias: "widget.aoattestation_acctownerform",
    id: "aoattestationAOForm",
    store: 'eRecon_web.store.AOAttestationAccountOwnerStore',
    defaults: {labelAlign: "side"},
    bodyPadding: 10,

    initComponent: function () {
	
    	this.acctownerStore = Ext.create("eRecon_web.store.AOAttestationAccountOwnerStore", {
            // autoLoad: true
        });
    	
    	this.addEvents({
    		ownershipSelectionChange: true
        });
        this.items = [
            {
        	 name: "acct_owner",
             itemId: "acct_owner-combo",
             xtype: "combo",
             labelWidth: 200,
             fieldLabel: "Select your Account Owner",
             valueField: "soeId",
             displayField: "name",
             store: this.acctownerStore,
             action:"select",
             editable: false
            }
        ];
        
        this.callParent(arguments);
}
   
});

Ext.define("eRecon_web.view.UserRoleMapping.UserRoleMappingContainer",{
	extend: "Ext.container.Container", 
	alias: "widget.secadmin_userrolemappingcontainer",   
    layout: "border",
    
 initComponent: function (config) {
    	this.userRoleMappingGrid = Ext.create("eRecon_web.view.UserRoleMapping.UserRoleMapping", {
    		title: "User Role Mapping",
            region: "center",
            flex: 4
            });

    	this.searchForm = Ext.create("eRecon_web.view.UserRoleMapping.UserRoleMappingSearch", {
            title: "Insert/Search User Role Mapping",
            region: "west",
            split: true,
            flex: 1.5,
            collapsible: true,
            animCollapse: false

        });
    	
    	this.items = [    	              
    	              this.userRoleMappingGrid,
    	              this.searchForm
    	             ];
    	    	
    	this.callParent(config);
	}
	
});

Ext.define("eRecon_web.view.UserRoleMapping.UserRoleMappingSearch", {
    extend: "Ext.form.Panel",
    alias: "widget.secadmin_userrolemappingsearch",
    defaults: {labelAlign: "side"},
    bodyPadding: 10,

    initComponent: function () {
	    	 
    	this.UserStore = Ext.create("eRecon_web.store.UserStore", {});
    	this.RoleStore = Ext.create("eRecon_web.store.RoleStore", {});
    	
    	var activeStore = Ext.create('Ext.data.Store', {
            fields: ['ActiveName', 'ActiveValue'],
            data: [
            {
                "ActiveName": "<--Select-->",
                "ActiveValue": ""
            },       
            {
                "ActiveName": "Yes",
                "ActiveValue": "Y"
            }, {
                "ActiveName": "No",
                "ActiveValue": "N"
            }
            ]
        	});

        this.items = [            
            {
            	name: "userid",
	            itemId: "userid-text",
	            xtype: "combo",
	            valueField: "user",
	            displayField: "user",
//	            editable: false,
	            typeAhead:true,
	            store: this.UserStore,
	            fieldLabel: 'User ID<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>'
            },
            {
                name: "role",
                itemId: "Role-combo",
                xtype: "combo",
                fieldLabel: 'Role<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>',
                valueField: "role",
                displayField: "role",
//                editable: false,
                typeAhead:true,
                queryMode:'remote',
                store: this.RoleStore
            }
            ,
            {
                name: "active",
	            itemId: "Active-combo",
	            xtype: "combo",
//	            editable: false,
	            typeAhead:true,
	            queryMode:'local',
	            fieldLabel: 'Active Flag<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>',
	            valueField: "ActiveValue",
	            displayField: "ActiveName",
	            store: activeStore
            }
                       
        ];

        this.dockedItems = [
            {
                dock: "top", 
                xtype: "toolbar",
                items: [
                {
                    xtype: "button",
                    text: "Insert",
                    iconCls: 'iconAdd',
                    scope: this,
                    action: "userRole-insert"
                },
                "-",
                {
                    xtype: "button",
                    text: "Search",
                    iconCls: 'iconMagnifier',	
                    scope: this,
                    action: "userRole-search"
                },
                "-",
                {
                	xtype: "button",
                    text: "Clear",
                    iconCls: 'iconTableDelete',
                    scope: this,
                    action: "userRole-clear"
                }
            ]
            },{
				dock: "bottom", 
				xtype: "toolbar",
				items: [
					{
					    xtype: "label",
					    text: "* Indicates Mandatory fields while inserting a new record"
					}
				]
	        }
        ];

        this.callParent(arguments);
    }
});

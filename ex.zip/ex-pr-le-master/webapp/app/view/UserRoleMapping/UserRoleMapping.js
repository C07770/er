Ext.define("eRecon_web.view.UserRoleMapping.UserRoleMapping", {
    extend: "Ext.grid.Panel",
    alias: "widget.secadmin_userrolemapping",    
    autoScroll: true,
    forceFit: true,    
    columnLines: true,
    multiSelect:true,
    store: "eRecon_web.store.UserRoleMappingStore",
    enableColumnMove: false,  
    enableColumnHide:false,
    border: false,
    viewConfig: {
        emptyText: "No details available."},
                

    initComponent: function () {
        var me = this;
        me.stateful = false;
        
        this.RoleStore = Ext.create("eRecon_web.store.RoleStore", {});
        this.activeStore = Ext.create('Ext.data.Store', {
            fields: ['ActiveName', 'ActiveValue'],
            data: [
            {
                "ActiveName": "<--Select-->",
                "ActiveValue": ""
            },
            {
                "ActiveName": "Yes",
                "ActiveValue": "Y"
            }, {
                "ActiveName": "No",
                "ActiveValue": "N"
            }
            ]
        	});
        me.plugins= [
                     Ext.create('Ext.grid.plugin.CellEditing', {
                         clicksToEdit: 1,
                         allowBlank:false,
                         listeners:{
                        	 beforeedit: function(editor,event,opts){
                        		 if(!event.record.phantom && event.column.dataIndex=='userid')   
                        			 {
                        			 	return false;
                        			 }
                        	 }
                        	 
                         }
                     })
        ];
        
        var rowEditing = Ext.create('Ext.grid.plugin.RowEditing', {
            clicksToMoveEditor: 2,
            autoCancel: false
        });
                        
        
        var combo = new Ext.form.ComboBox({            
            store: this.RoleStore,
            valueField: "role",
            displayField: "role"
        });

        Ext.util.Format.comboRenderer = function(combo){
            return function(value){
                var record = combo.findRecord(combo.valueField, value);
                return record ? record.get(combo.displayField) : combo.valueNotFoundText;}};
                    
        
        me.dockedItems = [
             {
              	dock: "top", 
              	xtype: "toolbar", 
              	items: [
              	   {
                   	xtype: "button",
                   	tooltip: "Save",
                   	text:"Save",
                   	icon: "/static/assets/famfamfam/icons/disk.png",                   	
                   	action:"userRolemapping-save",
                   	scope:this
                   },
                   "-"
                   ,
                   {
                      	xtype: "button",
                      	tooltip: "Export to Excel",
                      	text:"Export to Excel",
                      	icon: "/static/assets/famfamfam/icons/page_white_excel.png",                   	
                      	action:"userRolemapping-excel",
                      	scope:this
                   },
                   "-"
                   ,
                   {
                   	xtype: "button",
                   	tooltip: "Delete",
                   	text:"Delete",
                   iconCls: 'iconDelete',
                   	handler : function() {
                   		var i;
                   		var selModel = this.up('grid').getSelectionModel();
                   		var selRec = selModel.getSelection();
                   		for(i=0;i<selRec.length;i++)
                   			{
                   				selRec[i].data.action = "DELETE";
                   				this.up('grid').store.remove(selRec[i]);
                   			}
                   	}
                   },"-",
                   {
                      	xtype: "button",
                      	tooltip: "Back to Previous Page",
                      	text:"Back",
                      	icon: 'resources/images/left2.gif',  
                      	action:"userRolemapping-back"
                   }
                   ]
             },                  
             {
                xtype: "pagingtoolbar",
                dock: "bottom",
                displayInfo: true,
                store: me.store,
                plugins: [Ext.create("eRecon_web.plugins.PageSize")]

            }];
        
        me.columns = [
                      
            {	header: "User Id", 
            	dataIndex: "userid"
            }
            ,
            {	header: "Role", 
            	dataIndex: "role"
            }
            ,
            {	header: "Active", 
            	dataIndex: "active",
            	editor: {
                    xtype: 'combo',
                    store: this.activeStore,
                    editable: false,
                    valueField: "ActiveName",
                    displayField: "ActiveName"
                }}
                              
        ]; 
        
        me.callParent(arguments);
        }
    });

Ext.define('eRecon_web.view.dashboard.ArcMembersGroupingSummary', {
	extend : 'Ext.grid.feature.GroupingSummary',
	alias : 'feature.arcmembersgroupingsummary',
	enableGroupingMenu: false,
	groupHeaderTpl: [
	    '{name:this.formatName}',
	    {
	        formatName: function(name) {
	    		if(name == 'grandTotal') {
	    			return ''
	    		}
	            return 'Arc Member: ' + name;
	        }
	    }
    ],
    
    generateSummaryData: function() {
		try {
			return this.callParent();
		}
		catch(e) {
			return {};
		}
	}
});

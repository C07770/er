Ext.define('eRecon_web.view.dashboard.ArcMembersBalancesInputGrid', {
	extend : 'Ext.grid.Panel',
	alias : 'widget.arcmembersbalancesinputgrid',
	store: 'eRecon_web.store.dashboard.ArcMembersBalancesStore',
	features: [{
		id: 'group',
		ftype: 'groupingsummary',
		enableGroupingMenu: false
	}],
	selModel: {
        selType: 'cellmodel'
    },
	initComponent : function() {
		var me = this;
		me.cellEditing = new Ext.grid.plugin.CellEditing({
            clicksToEdit: 1
        });
		
		me.plugins = [me.cellEditing];
		
		var totalBalanceRenderer =  function(v) {
			var s = Ext.util.Format.usMoney(Math.abs(v));
		    if (v < 0) {
		    	s = "(" + s + ")";
		    }
		    return s;
		};
		me.columns = [
	     { text: 'Region ',  dataIndex: 'arcMember', flex: 1, hidden: true}
	     ,{ text: 'Account Owner',  
	    	dataIndex: 'accountOwnerName', 
	    	flex: 1,
	        summaryType: function(records){
	    		return records.length > 0 ? records[0].get('arcMember') : " ";
	        },
	    	summaryRenderer: function(value, summaryData, dataIndex) {
	        	return 'Total for ' + value;
	    	},
	    	tdCls: 'wrap'
	     }
	     ,{ text: 'Fullkey Count',  
	    	dataIndex: 'recordCnt', 
	    	flex: 1,
	    	summaryType: 'sum'
	      }
	    ,{ text: 'Debit Balance',  
	    	dataIndex: 'debitBalance', 
	    	flex: 1, 
	    	summaryType: 'sum',
	        renderer: Ext.util.Format.usMoney,
	        summaryRenderer: Ext.util.Format.usMoney
	      }
	    ,{ text: 'Credit Balance',  
	    	dataIndex: 'creditBalance', 
	    	flex: 1,
	    	summaryType: 'sum',
	        renderer: Ext.util.Format.usMoney,
	        summaryRenderer: Ext.util.Format.usMoney
	     }
	    ,{ text: 'Total Balance',  
	    	dataIndex: 'totalBalance', 
	    	flex: 1,
	    	summaryType: 'sum',
	        renderer: totalBalanceRenderer,
	        summaryRenderer: totalBalanceRenderer
	     }
	    ,{ text: 'Has issue been resolved?',  
	    	flex: 1,
	    	dataIndex: 'resolved', 
	    	editor: new Ext.form.field.ComboBox({
                typeAhead: true,
                triggerAction: 'all',
                store: [
                    ['Yes','Yes'],
                    ['No','No']
                ]
            })
	     }
	    ,{ text: 'If No, Issue Description and Status',  
	    	dataIndex: 'description', 
	    	flex: 1,
	    	editor:{xtype:'textfield'} 
	     }
	    ,{ text: 'Date Resolved or Target Resolution Date',  
	    	dataIndex: 'resolvedDate', 
	    	flex: 1,
	    	renderer: Ext.util.Format.dateRenderer('M d, Y'),
            editor: {
                xtype: 'datefield',
                format: 'm/d/y',
                minValue: '01/01/06',
                disabledDays: [0, 6],
                disabledDaysText: 'Not available on the weekends'
            }
	     }
        ];
		me.callParent(arguments);
	}

});

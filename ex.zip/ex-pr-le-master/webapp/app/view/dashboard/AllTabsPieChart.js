Ext.define("eRecon_web.view.dashboard.AllTabsPieChart", {
	extend : "Ext.chart.Chart",
	alias : "widget.allTabsPieChart",
	animate: true,
	shadow: true,	
    store: "eRecon_web.store.chart.AllTabsPieChartStore",
	theme: 'Base',
	legend: {
	    position: 'float',
	    x: 290,
	    y: 0
	},
	 
  initComponent: function(){	   
	
	this.themeAttrs.colors = ["#115FA6"];
			
	this.axes = [
	  {
	    type: "Numeric",
	    position: "bottom",
	    fields: ["value"],
	    label: {
	        renderer: Ext.util.Format.numberRenderer("0,0")
	    }	    
	  }, 
	  {
	    type: "Category",
	    position: "left",
	    fields: ["display"],	   
	  }
	];	
	
	this.series = [
	  {
	    type: "bar",
	    axis: "bottom",
	    highlight: true,	   
	    tips: {
          trackMouse: true,
          width: 150,
          height: 35,
          renderer: function(storeItem, item) {
            this.setTitle(storeItem.get('display') + ' : ' +  storeItem.get('value'));
          }
        },
	    label: {
	      display: "insideEnd",
	      field: "value",
	      renderer: Ext.util.Format.numberRenderer("0"),
	      orientation: "horizontal",
	      color: "#FF0000"
	    },
	    xField: "display",
	    yField: "value",
	    listeners:{
	 	  "scope" : this,
	 	  "itemmousedown" : function(item, e) {
	 	     console.log(item.storeItem.data.display );
	 		 this.fireEvent("pieChartClick", {
	 	  	   display : item.storeItem.data.display, type : 'Tab', chart : 'allTabsPieChart'
	 	     });
	      }
	    }
	  }
	  
	];
	    	
	this.callParent(arguments);
	}

});

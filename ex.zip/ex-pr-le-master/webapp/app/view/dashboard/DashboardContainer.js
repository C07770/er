Ext.define("eRecon_web.view.dashboard.DashboardContainer", {
   extend: "Ext.tab.Panel",
   alias: "widget.dashboardContainer",
   layout:{type:"vbox", align:"stretch"},
   autoScroll:true,
   requires :["eRecon_web.view.dashboard.ArcMembersPieChart",
              "eRecon_web.view.dashboard.AllTabsPieChart",
              "eRecon_web.view.dashboard.AOGLBalanceDrChart",
              "eRecon_web.view.dashboard.AOGLBalanceCrChart",
              'eRecon_web.common.FilterCrumb',
              'eRecon_web.view.dashboard.ArcMembersBalancesGrid',
              "eRecon_web.view.dashboard.ArcMembersBalancesInputGrid",
              "eRecon_web.view.dashboard.form.Filters"
              ],
   items:[
     {
    	 title:"Filters",
    	 xtype:"erecon_dashboard_form_filters"
     },
     {
       title:" Arc Dashboard",
    	 xtype:"panel",
    	 hidden:true,
    	 itemId:"arcdashtab",
    	 layout:"border",
    	 items:[     
   	     {
	    	 region: 'west',
	    	 xtype: 'panel',
	    	 autoScroll:true,	    	
	       style:{"background-color":"white"},
	       layout: {type: 'vbox', align: 'stretch'},
	       width: 300,
	    	 items: [
	      	 {
    	       xtype: 'panel',    		
  	    		 layout: "fit",
  	    		 title: 'ARC Members',
  	    		 collapsible:true,
  	    		 collapseDirection:"top",
  	    		 items: [{xtype: 'arcMembersPieChart', height: 250}]  	    		 
  	    	 }, 
  	    	 {
    	    	 xtype: 'panel',
  	    		 layout: 'fit',
  	    		 title: 'KPI (Number of Fullkeys)',
  	    		 height:"auto",
  	    		 items: [{xtype: 'allTabsPieChart', height: 220}]
  	    	 },	        
	    	 ]
	     },
	     {
	       region: 'center', 
	       xtype: 'panel',
	       layout: {type: 'vbox', align: 'stretch'},
	       items: [
		       {
		         xtype: 'filtercrumb',
		         height: 40
		       },
		       {
		         xtype: 'arcmembersbalancesgrid',
		        	flex: 1
		       }
	       ]
	     },
	     {
	       region: 'east',     
		     xtype: 'panel',
		     title: "GL Balance Distribution",
		     itemId : 'distributionEastSidePanel',
		     split: true,
		     autoScroll:true,
		     collapsible: true,
		     style:{"background-color":"white"},
		     layout: {type: 'vbox', align: 'stretch'},
		     width: 305,
		     items: [
		       {
	           xtype: 'panel',
	        	 layout: 'fit',
	        	 title: 'Debit ',
	        	 items: [{xtype: 'aoGLBalanceDrChart', height: 260}]
		       }, 
		       {
		         xtype: 'panel',
		         layout: 'fit',
		         title: 'Credit',
		         items: [{xtype: 'aoGLBalanceCrChart', height: 260}]
		       }
			   ]
	     }
	   ]
   }
  ]
});

Ext.define("eRecon_web.view.dashboard.form.Filters",{
  extend:"Ext.form.Panel",
  alias:"widget.erecon_dashboard_form_filters",
  requires:["eRecon_web.view.common.ClearableCombo"],
     
  padding:"5px",
  
  initComponent: function() {
	
    this.tbar = [	  
      {  		
  	    text:"Search Arc Dashboard",
        icon:"/static/assets/famfamfam/icons/database_go.png",
        itemId:"searcharcdashbtn",
        disabled:true
  	  },
  	  "-",
  	  {
    	xtype: "button",
        text: "Clear All",
        iconCls: 'iconTableDelete',
        itemId:"arcdashclearbtn",
        scope:this,
        handler:this.resetFilters
      }  	  
    ];
    
    this.items = [      
      {
        xtype:"container",
        layout:{type:"vbox"},        
        border:false,
        defaults:{margin:8, labelAlign:"top", width:307},
        items:[
          {
		    xtype:"clearablecombobox",
		    fieldLabel:"<span class='asterisk'>*</span>Recon Period",
		    name:"reconperiod",
		    allowBlank:false,
		    matchFieldWidth:true,
		    typeAhead:true,
		    queryMode:"local",	               
		    valueField:"values",
		    displayField:"description",
		    store:Ext.create("Ext.data.Store", {
		      fields:["values", "description"]         
		    }),
		    listeners:{
		      beforerender:function(cbo_) {	        	        
		        eRecon_web.direct.action.DashboardService.getFilterValues("RECONPERIOD", function(p, response){        		
		        	cbo_.getStore().loadData(response.result);        		
		        });
		      }
		    }        
		  },	        	    
          {
	        xtype:"clearablecombobox",	        
	        fieldLabel:"ARC Member",
	        name:"arcMemberFilterCbo",
	        valueField:"values",
	        displayField:"description",	       
	        queryMode:"local",
            store:Ext.create("Ext.data.Store", {
               fields:["values", "description"]         
            }),
            listeners:{
         	  beforerender:function(cbo_) {            	
             	eRecon_web.direct.action.DashboardService.getFilterValues("ARC", function(p, response){        		
             	  cbo_.getStore().loadData(response.result);        		
             	});
              }             
            }                   	        	        
	      },
	      {
	    	xtype:"clearablecombobox",
	    	fieldLabel:"Controller",
	        name:"controller",
	        typeAhead:true,
	        queryMode:"local",		       
	        valueField:"values",
	        displayField:"description",
	        store:Ext.create("Ext.data.Store", {
	          fields:["values", "description"]         
	        }),
	        listeners:{
	    	  beforerender:function(cbo_) {
	        	var params = {userId:"cm85282", type:"RECONPERIOD"};        	
	        	eRecon_web.direct.action.DashboardService.getFilterValues("CONTROLLER", function(p, response){        		
	        	  cbo_.getStore().loadData(response.result);        		
	        	});
	          }
	        }        
	      }	        	    	      		  	     
	    ]	  
	  }
    ];
    
    this.callParent(arguments);
  },
  
  resetFilters: function(){
	this.getForm().reset();
  }

});

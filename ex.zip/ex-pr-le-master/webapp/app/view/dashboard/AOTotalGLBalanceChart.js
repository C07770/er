Ext.define("eRecon_web.view.dashboard.AOTotalGLBalanceChart", {
	extend : "Ext.chart.Chart",
	alias : "widget.aoTotalGLBalanceChart",
	style : 'background:#fff',
	animate : true,
	height: 400,
	shadow : true,
	legend : {
		position : 'right'
	},
	store : "eRecon_web.store.chart.AOTotalGLBalanceChartStore",
	initComponent : function() {
		var me = this;
		me.legend = {
				"position" : "right",
				labelFont : "10px arial"
		};

		me.axes = [ 
		           {
		        	   type: 'Numeric',
		        	   position: 'left',
		        	   fields: ['totalGlAmount'],
		        	   title: ['Total GL Amount'],
		        	   minimum: 0,
		        	   hidden: false
		           }, {
		        	   type: 'Category',
		        	   position: 'bottom',
		        	   fields: ['ao'],
		        	   label: {
		        		   renderer: function(v) {
		        			   return Ext.String.ellipsis(v, 15, false);
		        		   },
		        		   font: '9px Arial',
		        		   rotate: {
		        			   degrees: 270
		        		   },
		        		   listeners: {
		        			   "scope":me
		        			   ,"click":function(item){
		        				   console.log(item.text)
		        				   me.fireEvent("axisClick",{axis:item.text, type:'Axis', chart:'aoTotalGLBalanceChart'});
		        			   }
		        		   }
		        	   }
		           }
		           ],

		           me.series = [   {
		        	   type: 'column',
		        	   axis: 'left',
		        	   listeners: {
		        		   itemmouseup: function(item) {
		        			   console.log(item.yField);
		        			   console.log(item.storeItem.data.ao)
		        			   me.fireEvent("seriesClick",{axis:item.yField, series:item.storeItem.data.ao,  type: 'series', chart:'aoTotalGLBalanceChart'});
		        		   }
		        	   },
		        	   xField: 'ao',
		        	   yField: ['totalGlAmount'],
		        	   title: ['Total GL Amount'],
		        	   stacked: false
		           }];


		/*var store = Ext.create('Ext.data.JsonStore', {
	        fields: ['year', 'comedy', 'action', 'drama', 'thriller'],
	        data: [
	                {year: 2005, comedy: 34000000, action: 23890000, drama: 18450000, thriller: 20060000},
	                {year: 2006, comedy: 56703000, action: 38900000, drama: 12650000, thriller: 21000000},
	                {year: 2007, comedy: 42100000, action: 50410000, drama: 25780000, thriller: 23040000},
	                {year: 2008, comedy: 38910000, action: 56070000, drama: 24810000, thriller: 26940000}
	              ]
	    });

		me.store = store;
		 */

		me.callParent(arguments);


	}

});

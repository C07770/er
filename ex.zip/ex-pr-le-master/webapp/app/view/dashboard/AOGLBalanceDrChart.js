Ext.define("eRecon_web.view.dashboard.AOGLBalanceDrChart", {
	extend : "Ext.chart.Chart",
	alias : "widget.aoGLBalanceDrChart",
	style : 'background:#fff',
	animate : true,
	height : 200,
	shadow : true,
	store : "eRecon_web.store.chart.AOGLBalanceDrChartStore",
	initComponent : function() {
		var me = this;
		
		me.themeAttrs.colors = ["#009933","#FFFF00","#FF9900","#FF0000"];
		
		me.legend = {
			"position" : "top",
			labelFont : "8px arial"
		};
		me.axes = [
		           {
		        	   type : 'Numeric',
		        	   position : 'left',
		        	   highlight : true,
		        	   fields : [ 'lessThan1M', 'oneToFiveM', 'fiveToTenM','greaterThan10M' ],
    	               minimum : 0,
    	               maximim  : 500,
    	               majorTickSteps : 1,
    	               minorTickSteps : 1,
    	               hidden : false,
                       labelTitle : { 
                         font: 'bold 16px Arial'
                       },
    	               title : 'Number of Fullkeys',
    	               label: {
    	            	  renderer: function(value) {
    	            		if(value.toString().indexOf('.') == -1) {
    	            		  return value;
    	            		} 
    	            		else {
    	            		  console.log(value);
    	            		  return '';
    	            		}
    	            	  }
    	              }
		           }, {
					type : 'Category',
					position : 'bottom',
					fields : [ 'aoName' ],
					label : {
						/*renderer : function(v) {
							return Ext.String.ellipsis(v, 15, false);
						},*/
						font : '9px Arial',
						rotate : {
							degrees : 270
						},
						listeners : {
							"scope" : this,
							"click" : function(item) {
								this.fireEvent("axisClick", {
									axis : item.text,
									type : 'Axis',
									chart : 'aoGLBalanceDrChart'
								});
							}
						}
					}
				} ],

		me.series = [ {
			type : 'column',
			axis : 'left',
			gutter : '80',
			groupGutter : '50',
			style : {
				width : '80'
			},
			listeners : {
				scope: this,
				itemmouseup : function(item) {
					this.fireEvent("seriesClick", {
						axis : item.yField,
						series : item.storeItem.data.aoName,
						type : 'series',
						chart : 'AOGLBalanceDrChart'
					});
				}
			},
			xField : 'aoName',
			yField : [ 'lessThan1M', 'oneToFiveM', 'fiveToTenM',
					'greaterThan10M' ],
			title : [ 'Dr <$1M', 'Dr $1-5M', 'Dr $5-10M', 'Dr >$10M' ],
			stacked : true,
            tips: {
                trackMouse: true
               ,width: 200
               ,renderer: function(storeItem, item) {
                  var str = "";
                  str = item.value[0] + " - " +  item.value[1];
                 
                  if(!Ext.isEmpty(str)) {
                    this.setTitle("No. of fullkeys for <br>" + str);
                  }
                }
              }
		} ];

		me.callParent(arguments);

	}

});

Ext.define("eRecon_web.view.dashboard.ArcMembersPieChart", {
	extend : "Ext.chart.Chart",
	alias : "widget.arcMembersPieChart",
	width : 300,
	height : 300,
	animate : true,
	legend: true,
	store: "eRecon_web.store.chart.ArcMembersPieChartStore",
	initComponent : function() {
		var me = this;
		me.legend = {
			"position" : "right",
			labelFont : "9px arial"
		};
		me.series = [ {
			type : "pie",
			angleField : "totalAccounts",
			showInLegend : true,
			/*colorSet : this.colorSet,*/
			highlight : {
				segment : {
					margin : 20
				}
			},
			 tips: {
	                trackMouse: true,
	                width: 150,
	                height: 35,
	                renderer: function(storeItem, item) {
	                	 this.setTitle(storeItem.get('arcMember') + ' : ' +  storeItem.get('totalAccounts'));
	                }
	            },
			label : {
				field : "arcMember",
				display : "none",
				contrast : true,
				font : "11px Arial"
			},
			listeners : {
				"scope" : this,
				"itemmousedown" : function(item, e) {
					console.log(item.storeItem.data.arcMember );
					this.fireEvent("pieChartClick", {
						display : item.storeItem.data.arcMember, type : 'arc', chart : 'arcMembersPieChart'
					});
				}
			}
		} ];
		
		/*me.store = Ext.create("Ext.data.Store", {
			fields : [ "LABEL", "VALUE", "COUNT", "FILTERVALUE" ],
			 data : [
			         {LABEL: 'Ed',    VALUE: '1'},
			         {LABEL: 'Tommy', VALUE: '2'},
			         {LABEL: 'Aaron', VALUE: '3'},
			         {LABEL: 'Jamie', VALUE: '4'}
			     ],
			autoLoad : true
		});*/

		me.callParent(arguments);
	}

});

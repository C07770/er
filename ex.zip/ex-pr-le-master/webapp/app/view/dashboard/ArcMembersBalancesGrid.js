Ext.define('eRecon_web.view.dashboard.ArcMembersBalancesGrid', {
	extend : 'Ext.grid.Panel',
	alias : 'widget.arcmembersbalancesgrid',
	requires: 'eRecon_web.view.dashboard.ArcMembersGroupingSummary',
	store: 'eRecon_web.store.dashboard.ArcMembersBalancesStore',
	features: [
	{
		ftype: 'arcmembersgroupingsummary'
	}
	],
	initComponent : function() {
		var me = this;
		var bracketedRenderer =  function(v) {
			var s = Ext.util.Format.usMoney(Math.abs(v));
		    if (v < 0) {
		    	s = "(" + s + ")";
		    }
		    return s;
		};
		///change column names and datagrid.
		me.columns = [{text: ''}];
		me.availableColumnsArr = [
	     { text: 'Region',  dataIndex: 'arcmember', flex: 1, hidden: true}
	     ,{ text: 'Controller Delegate', cls:'multiline-column-header', tdCls: 'wrap',
	    	dataIndex: 'controllerdelegatename', 
	    	flex: 1,
	        summaryType: function(records){
	    		return records.length > 0 ? records[0].get('arcmember') : " ";
	        },
	        
	    	summaryRenderer: function(value, currentSumData, dataIndex) {
	        	var summaryData = this.summaryData;
	        	var groupName = '';
	        	for (key in summaryData) {
	        		if (summaryData[key] === currentSumData ) {
	        			groupName = key;
	        			break;
	        		}
	        	}
	        	if (groupName == 'grandTotal') {
	        		return 'Total';
	        	}
	        	return 'Total for ' + groupName;
	    	}
	     }
	     ,{ text: 'Fullkey Count', cls:'multiline-column-header', tdCls: 'wrap', 
	    	dataIndex: 'fullkeycount', 
	    	width: 120,
	    	summaryType: 'sum',
	    	renderer: function(v,meta) {
//	    	    meta.tdCls = 'cell-expand';
//	    	    return v;
	    	    return '<span class="cell-expand" >&nbsp</span><span>'+v+'</span>';
	        },
	        selectorFilters: [
	           {filter: 'defaults', headerText: 'Fullkey Count'},
	           {filter: 'disagreed', headerText: 'Number of Disagreed Fullkeys'},
	           {filter: 'unsubmitted', headerText: 'Number of Unsubmitted Fullkeys'},
	           {filter: 'unattested', headerText: 'Number of Unreviewed Fullkeys'},
	           {filter: '180dpd', headerText: 'Over 180 Days Fullkey Count'},
	           {filter: 'at risk', headerText: 'At Risk Fullkey Count'},
	           {filter: 'reportable red', headerText: 'Reportable Red Fullkey Count'}
	        ]   
	      }
	    ,{   
	    	dataIndex: 'reportableredamtdr', cls:'multiline-column-header', tdCls: 'wrap',
	    	flex: 1, 
	    	summaryType: 'sum',
	        renderer: bracketedRenderer,
	        summaryRenderer: bracketedRenderer,
	        selectorFilters: [
	           {filter: 'defaults', headerText: 'Reportable Red Amount DR'},
	           {filter: 'disagreed', headerText: 'Disagreed Debit Balance'},
	           {filter: 'unsubmitted', headerText: 'Unsubmitted Debit Balance'},
	           {filter: 'unattested', headerText: 'Unreviewed Debit Balance'}
	        ]   
	      }
	    ,{   
	    	dataIndex: 'reportableredamtcr', cls:'multiline-column-header', tdCls: 'wrap',
	    	flex: 1,
	    	summaryType: 'sum',
	        renderer: bracketedRenderer,
	        summaryRenderer: bracketedRenderer,
	        selectorFilters: [
	           {filter: 'defaults', headerText: 'Reportable Red Amount CR'},
	           {filter: 'disagreed', headerText: 'Disagreed Credit Balance'},
	           {filter: 'unsubmitted', headerText: 'Unsubmitted Credit Balance'},
	           {filter: 'unattested', headerText: 'Unreviewed Credit Balance'}
	        ]   
	     }
	    ,{    
	    	dataIndex: 'glbalance', cls:'multiline-column-header', tdCls: 'wrap',
	    	flex: 1,
	    	summaryType: 'sum',
	        renderer: bracketedRenderer,
	        summaryRenderer: bracketedRenderer,
	        selectorFilters: [
	           {filter: 'defaults', headerText: 'GL Balance'},
	           {filter: 'disagreed', headerText: 'Disagreed Total Balance'},
	           {filter: 'unsubmitted', headerText: 'Unsubmitted Total Balance'},
	           {filter: 'unattested', headerText: 'Unreviewed Total Balance'}
	        ]   
	     }
// at risk	    
	    ,{   
	    	dataIndex: 'atRiskDebitBalance', cls:'multiline-column-header', tdCls: 'wrap',
	    	flex: 1, 
	    	summaryType: 'sum',
	        renderer: bracketedRenderer,
	        summaryRenderer: bracketedRenderer,
	        selectorFilters: [
	           {filter: 'at risk', headerText: 'Sum of At Risk Dr (USD)'}
	        ]   
	      }
	    ,{   
	    	dataIndex: 'atRiskCreditBalance', cls:'multiline-column-header', tdCls: 'wrap',
	    	flex: 1,
	    	summaryType: 'sum',
	        renderer: bracketedRenderer,
	        summaryRenderer: bracketedRenderer,
	        selectorFilters: [
	           {filter: 'at risk', headerText: 'Sum of At Risk Cr (USD)'}
	        ]   
	     }
	    ,{    
	    	dataIndex: 'atRiskBalance', cls:'multiline-column-header', tdCls: 'wrap',
	    	flex: 1,
	    	summaryType: 'sum',
	        renderer: bracketedRenderer,
	        summaryRenderer: bracketedRenderer,
	        selectorFilters: [
	           {filter: 'at risk', headerText: 'At Risk Balance'}
	        ]   
	     }
	    ,{    
	    	dataIndex: 'reserveDebitAmt', cls:'multiline-column-header', tdCls: 'wrap',
	    	flex: 1,
	    	summaryType: 'sum',
	        renderer: bracketedRenderer,
	        summaryRenderer: bracketedRenderer,
	        selectorFilters: [
	           {filter: 'at risk', headerText: 'Reserve Debit Amt.'}
	        ]   
	     }
// end of at risk
	     
// over 180
	    ,{   
	    	dataIndex: 'gt181DebitBalance', cls:'multiline-column-header', tdCls: 'wrap',
	    	flex: 1, 
	    	summaryType: 'sum',
	        renderer: bracketedRenderer,
	        summaryRenderer: bracketedRenderer,
	        selectorFilters: [
	           {filter: '180dpd', headerText: 'Over 180 Days Dr (USD)'}
	        ]   
	      }
	    ,{   
	    	dataIndex: 'gt181CreditBalance', cls:'multiline-column-header', tdCls: 'wrap',
	    	flex: 1,
	    	summaryType: 'sum',
	        renderer: bracketedRenderer,
	        summaryRenderer: bracketedRenderer,
	        selectorFilters: [
	           {filter: '180dpd', headerText: 'Over 180 Days Cr (USD)'}
	        ]   
	     }
	    ,{    
	    	dataIndex: 'gt181Balance', cls:'multiline-column-header', tdCls: 'wrap',
	    	flex: 1,
	    	summaryType: 'sum',
	        renderer: bracketedRenderer,
	        summaryRenderer: bracketedRenderer,
	        selectorFilters: [
	           {filter: '180dpd', headerText: 'Over 180 Days Balance'}
	        ]   
	     }
// end over 180

// reportable red
	    ,{   
	    	dataIndex: 'reportableRedDebitBalance', cls:'multiline-column-header', tdCls: 'wrap',
	    	flex: 1, 
	    	summaryType: 'sum',
	        renderer: bracketedRenderer,
	        summaryRenderer: bracketedRenderer,
	        selectorFilters: [
	           {filter: 'reportable red', headerText: 'Sum of Reportable Red Amt Dr (USD)'}
	        ]   
	      }
	    ,{   
	    	dataIndex: 'reportableRedCreditBalance', cls:'multiline-column-header', tdCls: 'wrap',
	    	flex: 1,
	    	summaryType: 'sum',
	        renderer: bracketedRenderer,
	        summaryRenderer: bracketedRenderer,
	        selectorFilters: [
	           {filter: 'reportable red', headerText: 'Sum of Reportable Red Amt Cr (USD)'}
	        ]   
	     }
	    ,{    
	    	dataIndex: 'reportableRedBalance', cls:'multiline-column-header', tdCls: 'wrap',
	    	flex: 1,
	    	summaryType: 'sum',
	        renderer: bracketedRenderer,
	        summaryRenderer: bracketedRenderer,
	        selectorFilters: [
	           {filter: 'reportable red', headerText: 'Reportable Red Balance'}
	        ]   
	     }
// end of reportable red

	    ];
		me.callParent(arguments);
	},
	
	arrangeColumns: function(selectedTab) {
		var me = this;
		var colArr;
		if (!selectedTab) {
			colArr = me.prepareColumnArr('defaults');
		}
		else {
			colArr = me.prepareColumnArr(selectedTab.toLowerCase());
		}
		me.reconfigure(me.store,colArr);
	},
	
	prepareColumnArr: function(sel) {
		var me = this;
		var arr = [];
		for (var i=0; i < me.availableColumnsArr.length; i++) {
			var col = me.availableColumnsArr[i];
			if (col.hasOwnProperty('selectorFilters')) {
				var selectorFilters = col.selectorFilters;
				for (var j=0; j<selectorFilters.length; j++) {
					if (selectorFilters[j].filter == sel) {
						col.text = selectorFilters[j].headerText; 
						arr.push(col);
						break;
					}
				}
			}
			else {
				arr.push(col);
			}
		}
		return arr;
	}

});

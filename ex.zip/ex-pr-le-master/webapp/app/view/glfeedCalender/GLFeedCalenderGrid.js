Ext.define("eRecon_web.view.glfeedCalender.GLFeedCalenderGrid", {
    extend: "Ext.grid.Panel",
    alias: "widget.secadmin_glfeedCalenderGrid",    
    autoScroll: true,
    forceFit: true,    
    columnLines: true,
    multiSelect:true,
    store: "eRecon_web.store.GLFeedCalenderStore",
    enableColumnMove: true,    
    border: false,
    viewConfig: {
        emptyText: "No details available."},
                

    initComponent: function () {
        var me = this;
        me.stateful = false;
        
        me.plugins= [
	        Ext.create('Ext.grid.plugin.CellEditing', {
	            clicksToEdit: 2,
	            allowBlank:false
	        })
	    ];
        me.dockedItems = [
             {
              	dock: "top", 
              	xtype: "toolbar", 
              	items: [
              	   {
                   	xtype: "button",
                   	tooltip: "Save",
                   	text:"Save",
                   	icon: "/static/assets/famfamfam/icons/disk.png",                   	
                   	action:"feedCal-save",
                   	scope:this
                   },
                   {
                   	xtype: "button",
                   	tooltip: "Export to Excel",
                   	text:"Export to Excel",
                   	icon: "/static/assets/famfamfam/icons/page_white_excel.png",                   
                    action : "feedCal-excel",
                    id: 'feedCal-excel'
                   },
                   "-"
                   ,
                   {
                   	xtype: "button",
                   	tooltip: "Delete",
                    iconCls: 'iconDelete',
                    text:"Delete",
                   	handler : function() {
                   		var i;
                   		var selModel = this.up('grid').getSelectionModel();
                   		var selRec = selModel.getSelection();
                   		for(i=0;i<selRec.length;i++)
                   			{
                   				selRec[i].data.action = "DELETE";
                   				this.up('grid').store.remove(selRec[i]);
                   			}
                   	}
                   }]
             },                  
             {
                xtype: "pagingtoolbar",
                dock: "bottom",
                displayInfo: true,
                store: me.store,
                plugins: [Ext.create("eRecon_web.plugins.PageSize")]

            }];
        
        me.columns = [
                      
            {	header: "Recon Period", 
            	dataIndex: "reconPeriod"
            }
            ,
            {	header: "Schedule Date", 
            	dataIndex: "scheduledDate",
	            xtype: "datecolumn",
	        	format : "m/d/Y",
	            editor:{
	        		xtype: 'datefield',
	        		format : "m/d/Y"
	        	}
            }
             ,
             {	 header: "Business Day", 
            	 dataIndex: "businessDay"
            	 
             }
        ]; 
        
        me.callParent(arguments);
        }
    });

Ext.define("eRecon_web.view.glfeedCalender.GLFeedCalenderContainer",{
	extend: "Ext.container.Container", 
	alias: "widget.secadmin_glfeedCalenderContainer",   
    layout: "border",
    
 initComponent: function (config) {
    	this.glfeedcalenderGrid = Ext.create("eRecon_web.view.glfeedCalender.GLFeedCalenderGrid", {
    		title: "RCN GL FEED CALENDER",
            region: "center",
            flex: 4
            });

    	this.glfeedcalenderSearch = Ext.create("eRecon_web.view.glfeedCalender.GLFeedCalenderSearch", {
            title: "Insert/Search Feed Calender Lu",
            region: "west",
            split: true,
            flex: 1.5,
            collapsible: true,
            animCollapse: false

        });
    	
    	this.items = [    	              
    	              this.glfeedcalenderGrid,
    	              this.glfeedcalenderSearch
    	             ];
    	
    	this.listeners =
        {
        		scope: this,
                "activate": function () {              
                	var glFeedCalenderStore = this.glfeedcalenderGrid.getStore();
                	glFeedCalenderStore.directOptions = {};
                	glFeedCalenderStore.getProxy().extraParams = {
    	                0: null
    	            };
    	            glFeedCalenderStore.load({
    	                callback: function (records, operation, success) {
    	                }
    	            });
              }  
        };
    	             
    	
    	this.callParent(config);
	}
	
});

Ext.define("eRecon_web.view.glfeedCalender.GLFeedCalenderSearch", {
    extend: "Ext.form.Panel",
    alias: "widget.glfeedCalenderSearch",
    defaults: {labelAlign: "side"},
    bodyPadding: 10,

    initComponent: function () {
    	var store = Ext.create("Ext.data.Store", {
  	      fields:["key", "value","flag"],
  	      proxy:{
  	      	type:"direct",                              
  	        directFn:eRecon_web.direct.action.GLFeedCalenderService.getReconPeriod
  	      }
  	    });
        this.items = [            
            {
            	name: "reconPeriod",
		        itemId: "reconPeriod-text",
		        xtype:"combo",
		        fieldLabel: 'Recon Period <span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>',
		        store:store,
		        typeAhead:true,
		        queryMode: 'local',
				valueField: "key",
				displayField: "key",
				tpl: Ext.create('Ext.XTemplate',
				'<tpl for=".">',
				'<div class="x-boundlist-item">',
				  '<div style="{[this.getClass(values)]}">{key}</div>',
				  '</div>',
				 '</tpl>',
				    {
				        getClass: function (rec) {
				            return rec.flag == 'TRUE' ? "color: red;":''
				        }
				    }
				),
				listeners:{
				    beforerender:function(cbo_) {        		
					  cbo_.getStore().load();
				  }
				}
            },
            {
                name: "scheduledDate",
                itemId: "scheduleDate-text",
                xtype: "datefield",
                fieldLabel: "Scheduled Date"
            },
            {
            	name: "businessDay",
            	itemId: "businessDay-text",
            	xtype: "textfield",
            	fieldLabel: 'Business Day<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>'
            }
        ];

        this.dockedItems = [
            {
                dock: "top", 
                xtype: "toolbar",
                items: [
                {
                    xtype: "button",
                    text: "Insert",
                    iconCls: 'iconAdd',
                    scope: this,
                    action: "feedcal-add"
                },
                "-",
                {
                    xtype: "button",
                    text: "Search",
                    iconCls: 'iconMagnifier',
                    scope: this,
                    action: "feedcal-search"
                },
                "-",
                {
                	xtype: "button",
                    text: "Clear",
                    iconCls: 'iconTableDelete',
                    scope: this,
                    action: "feedcal-clear"
                }
            ]
            },{
				dock: "bottom", 
				xtype: "toolbar",
				items: [
					{
					    xtype: "label",
					    text: "* Indicates Mandatory fields while inserting a new record"
					}
				]
	        }
        ];

        this.callParent(arguments);
    }
});

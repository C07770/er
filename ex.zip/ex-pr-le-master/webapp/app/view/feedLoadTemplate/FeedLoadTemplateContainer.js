Ext.define("eRecon_web.view.feedLoadTemplate.FeedLoadTemplateContainer",{
	extend: "Ext.container.Container", 
	alias: "widget.secadmin_feedloadtemplatecontainer",   
    layout: "border",
    
 initComponent: function (config) {
    	this.feedLoadTemplateGrid = Ext.create("eRecon_web.view.feedLoadTemplate.FeedLoadTemplateGrid", {
    		title: "Feed Load Template",
            region: "center",
            flex: 4
            });

    	this.feedLoadTemplateSearch = Ext.create("eRecon_web.view.feedLoadTemplate.FeedLoadTemplateSearch", {
            title: "Insert/Search FeedLoad Template",
            region: "west",
            split: true,
            flex: 1.5,
            collapsible: true,
            animCollapse: false

        });
    	
    	this.items = [    	              
    	              this.feedLoadTemplateGrid,
    	              this.feedLoadTemplateSearch
    	             ];
    	
    	this.listeners =
        {
        		scope: this,
                "activate": function () {              
                	var feedloadtemplateStore = this.feedLoadTemplateGrid.getStore();
                	feedloadtemplateStore.directOptions = {};
                	feedloadtemplateStore.getProxy().extraParams = {
    	                0: null
    	            };
    	            feedloadtemplateStore.load({
    	                callback: function (records, operation, success) {
    	                }
    	            });
              }  
        };
    	             
    	
    	this.callParent(config);
	}
	
});

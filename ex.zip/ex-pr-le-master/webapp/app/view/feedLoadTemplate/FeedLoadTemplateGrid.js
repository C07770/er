Ext.define("eRecon_web.view.feedLoadTemplate.FeedLoadTemplateGrid", {
    extend: "Ext.grid.Panel",
    alias: "widget.feedloadtemplategrid",    
    autoScroll: true,
    forceFit: true,      
    store: "eRecon_web.store.FeedLoadTemplateStore",
    enableColumnMove: false, 
    multiSelect:true,
    border: false,
    viewConfig: {
        emptyText: "No details available."},
                

    initComponent: function () {
        var me = this;
        me.stateful = false;
        this.activeStore = Ext.create('Ext.data.Store', {
            fields: ['ActiveName', 'ActiveValue'],
            data: [
            {
                "ActiveName": "<--Select-->",
                "ActiveValue": "Y"
            },       
            {
                "ActiveName": "Yes",
                "ActiveValue": "Y"
            }, {
                "ActiveName": "No",
                "ActiveValue": "N"
            }
            ]
        	});
        
        me.plugins= [
            Ext.create('Ext.grid.plugin.CellEditing', {
                clicksToEdit: 2,
                allowBlank:false
            })
        ];
                                   
        me.columns = [
                      
            {	header: "Profile ID", 
            	dataIndex: "profile_id"
            }
            ,
            {	header: "Template ID", 
            	dataIndex: "template_id"
            },
            {	header: "Template Name", 
            	dataIndex: "template_name",
	            editor:{
		    		xtype: 'textfield'
		    	}
            },
            {	header: "Header", 
            	dataIndex: "header",
	            editor:{
		    		xtype: 'textfield'
		    	}
            },
            {	header: "Target Table", 
	        	dataIndex: "targetTable",
	            editor:{
		    		xtype: 'textfield'
		    	}
	        },
	        {	header: "Pre Processor", 
		    	dataIndex: "preProcessor",
		        editor:{
		    		xtype: 'textfield'
		    	}
		    },
		    {	header: "Post Processor", 
		    	dataIndex: "postProcessor",
		    	editor:{
		    		xtype: 'textfield'
		    	}
		    },
            {	header: "ACTIVE FLAG", 
            	dataIndex: "activeFlag",
	            editor:{
	        		xtype: 'combo',
		            store: this.activeStore,
	                valueField: "ActiveName",
	                displayField: "ActiveName"
				}
            }
                                          
        ];                 
        
        me.dockedItems = [
                          {
			              	dock: "top", 
			              	xtype: "toolbar", 
			              	items: [
			              	   {
			                   	xtype: "button",
			                   	tooltip: "Save",
			                   	text:"Save",
			                   	icon: "/static/assets/famfamfam/icons/disk.png",                   	
			                   	action:"feedtemplate-save",
			                   	scope:this
			                   },
			                   "-"
			                   ,
			                   {
			                   	xtype: "button",
			                   	tooltip: "Export to Excel",
			                   	text:"Export to Excel",
			                   	icon: "/static/assets/famfamfam/icons/page_white_excel.png",                   
			                    action : "feedtemplate-excel",
			                    id: 'sectorLob-excel'
			                   },
			                   "-"
			                   ,
			                   {
			                   	xtype: "button",
			                   	tooltip: "Delete",
			                   	text:"Delete",
			                   iconCls: 'iconDelete',
			                   	handler : function() {
			                   		var i;
			                   		var selModel = this.up('grid').getSelectionModel();
			                   		var selRec = selModel.getSelection();
			                   		for(i=0;i<selRec.length;i++)
			                   			{
			                   				selRec[i].data.action = "DELETE";
			                   				this.up('grid').store.remove(selRec[i]);
			                   			}
			                   	}
			                   }]
			             }, 
                          {
                        	  xtype: "pagingtoolbar",
                              dock: "bottom",
                              displayInfo: true,
                              store: me.store,
                              plugins: [Ext.create("eRecon_web.plugins.PageSize")]
                          }
                          ]

        
        me.callParent(arguments);
        }
    });

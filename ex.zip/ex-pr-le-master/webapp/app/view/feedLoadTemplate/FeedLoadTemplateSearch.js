Ext.define("eRecon_web.view.feedLoadTemplate.FeedLoadTemplateSearch", {
    extend: "Ext.form.Panel",
    alias: "widget.feedloadtemplatesearch",
    defaults: {labelAlign: "side"},
    bodyPadding: 10,

    initComponent: function () {
    	this.activeStore = Ext.create('Ext.data.Store', {
            fields: ['ActiveName', 'ActiveValue'],
            data: [
            {
                "ActiveName": "<--Select-->",
                "ActiveValue": ""
            },
            {
                "ActiveName": "Yes",
                "ActiveValue": "Y"
            }, {
                "ActiveName": "No",
                "ActiveValue": "N"
            }
            ]
        	});
        this.items = [            
            {
                name: "profile_id",
                itemId: "profile_id-text",
                xtype: "numberfield",
                allowBlank:false,
                fieldLabel:'Profile ID<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>'
            },
            {
            	 name: "template_id",
	            itemId: "template_id-text",
	            xtype: "numberfield",
	            allowBlank:false,
	            fieldLabel:'Template ID<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>'
            },
            {
            	 name: "template_name",
	            itemId: "template_name-text",
	            xtype: "textfield",
	            fieldLabel:"Template Name"
            },
            {
           	 	name: "header",
	            itemId: "header-text",
	            xtype: "textfield",
	            fieldLabel:"Header"
           },
           {
          	 	name: "targetTable",
	            itemId: "targetTable-text",
	            xtype: "textfield",
	            fieldLabel:"Target Table"
          },
          {
        	  	name: "preprocessor",
	            itemId: "preprocessor-text",
	            xtype: "textfield",
	            fieldLabel:"Pre Processor"
          },
          {
	        	 name: "postprocessor",
	            itemId: "postprocessor-text",
	            xtype: "textfield",
	            fieldLabel:"Post Processor"
          },
            {
                name: "activeFlag",
                itemId: "activeFlag-combo",
                xtype: "combo",
                fieldLabel: "ACTIVE FLAG",
	            store: this.activeStore,
	            editable: false,
	            valueField: "ActiveValue",
	            displayField: "ActiveName"
                	
            }
        ];

        this.dockedItems = [
            {
                dock: "top", 
                xtype: "toolbar",
                items: [
                {
                    xtype: "button",
                    text: "Insert",
                    iconCls: 'iconAdd',
                    scope: this,
                    action: "feedtemplate-add"
                },
                "-",
                {
                    xtype: "button",
                    text: "Search",
                    iconCls: 'iconMagnifier',
                    scope: this,
                    action: "feedtemplate-search"
                },
                "-",
                {
                	xtype: "button",
                    text: "Clear",
                    iconCls: 'iconTableDelete',
                    scope: this,
                    action: "feedtemplate-clear"
                }
            ]
            }
        ];

        this.callParent(arguments);
    }
});

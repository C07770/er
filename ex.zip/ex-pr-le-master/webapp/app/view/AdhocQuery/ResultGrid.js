Ext.define("eRecon_web.view.AdhocQuery.ResultGrid", {
    extend: "Ext.grid.Panel",
    alias: "widget.Result_Grid",    
    autoScroll: true,
    forceFit: true,    
    columnLines: true,
    multiSelect:true,
//    store: "resultGridStore",
    enableColumnMove: true,    
    border: false,    
    viewConfig: {
        emptyText: "No details available."},
    
    initComponent: function () {
    	var temp = "Test";
        var me = this;
        me.stateful = false;
        var gridHeader = new Array();
        var resultGridStore;
        
//        debugger;
        
 /*       eRecon_web.direct.action.AdhocQueryService.getAdhocResult( temp,function(p, response) {
    		
			var firstRecord;
			var fields= new Array();
			var data=new Array();
			var index = 0;			
			var gridHeaderArray = new Array();
						
			firstRecord = response.result[0];
			
			for (var header in firstRecord){				
				fields[index]=header;
				gridHeader.header = header;
				gridHeader.dataindex = header;
				gridHeaderArray[index]= gridHeader;
				index++;
			}

			for (var i=0; i < response.result.length; i++){
				var record =  response.result[i];
				var datarow=new Array;
				var j = 0;
				for(var val in record){					
					datarow[j] = record[val];
					j++;
				}

				data[i] = datarow;
			}
			           		
			  resultGridStore = new Ext.data.ArrayStore({
				fields: fields,
				data:data
				
			});
			resultGridStore.load();
			
//			debugger;
			
        }); 
        
//        debugger;
        
        me.columns = gridHeader;
        me.store = resultGridStore;

//        resultGridStore.load();*/
        /*me.columns = [{header: "FullKey" },
                      {header: "Banking Group"},
                      {header: "User Entered Red Amount DR"}
                      ];*/
        
        me.callParent(arguments);
        }
    });

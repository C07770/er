Ext.define("eRecon_web.view.AdhocQuery.SavedQueryGrid", {
    extend: "Ext.grid.Panel",
    alias: "widget.SavedQuery_Grid",    
    autoScroll: true,
    forceFit: true,
    itemId:'SavedQuery_Grid',
    columnLines: true,
    multiSelect:true,
    store: "eRecon_web.store.AdhocQueryStore",
    enableColumnMove: true,    
    border: false,     
    viewConfig: {
        emptyText: "No details available.",
        loadMask:false
        	},
                

    initComponent: function () {
        var me = this;
        me.stateful = false; 
        
        me.store = Ext.create("eRecon_web.store.AdhocQueryStore",{});
        me.store.load({
            callback: function (records, operation, success) {
            }
        });
        this.activeStore = Ext.create('Ext.data.Store', {
            fields: ['value', 'key'],
            data: [{
                "value": "Yes",
                "key": "Y"
            }, {
                "value": "No",
                "key": "N"
            }]
        	});
        
        me.plugins= [
                     Ext.create('Ext.grid.plugin.CellEditing', {
                         clicksToEdit: 1,
                         allowBlank:false,
                         listeners:{
                        	 beforeedit: function(editor,event,opts){
                        		 if(!event.record.phantom && event.column.dataIndex=='parameter')   
                        			 {
                        			 	return false;
                        			 }
                        	 }
                        	 
                         }
                     })
        ];
        
        var rowEditing = Ext.create('Ext.grid.plugin.RowEditing', {
            clicksToMoveEditor: 1,
            autoCancel: false
        });
        
          me.columns = [
			{	header: "Text", 
				dataIndex: "sqlstatement",
				width: 200,
				editor:{
            		xtype: 'textfield'
            	}
			},      
            {	header: "Description", 
            	dataIndex: "description",
            	editor:{
            		xtype: 'textfield'
            	}
            }, 
            {	header: "Saved", 
            	dataIndex: "saved",
            	width:50 ,
	            editor: 
	        	{
	        		xtype: 'combo',            	
	                store: this.activeStore,
	                valueField: "key",
	                displayField: "value"
	        	},
	        	renderer: function(val){
	                    var index = this.activeStore.findExact('key',val); 
	                    if (index != -1){
	                       var rs = this.activeStore.getAt(index).data; 
	                        return rs.value; 
	                    }else{
	                    	return val;
	                    }
	                    }
            },
            {	header: "UserId", 
            	dataIndex: "userid",
            	hidden:true
            } ,
            {	header: "Type", 
            	dataIndex: "statementtype",
            	hidden:true
            } ,
            {	header: "ID", 
            	dataIndex: "id",
            	hidden:true
            }                                            
        ];  
          
          me.dockedItems = [{
                             	dock: "top", 
                             	xtype: "toolbar", 
                             	items: [{
                             		xtype: "button",
                                   	tooltip: "Delete",
                                   	text:"Delete",
                                   	icon:"/static/assets/famfamfam/icons/application_delete.png",
                                   	handler : function() {
                                   		var i;
                                   		var selModel = this.up('grid').getSelectionModel();
                                   		var selRec = selModel.getSelection();
                                   		for(i=0;i<selRec.length;i++)
                                   			{
                                   				selRec[i].data.action = "DELETE";
                                   				this.up('grid').store.remove(selRec[i]);
                                   			}
                                   	}
                             	},{
                                   	xtype: "button",
                                   	tooltip: "Save grid changes",
                                   	text:"Save",
                                   	icon: "/static/assets/famfamfam/icons/disk.png",                   	
                                   	action:"savegridchanges",
                                   	scope:this
                                   }]
                            }];
          
        me.callParent(arguments);
        }     
    });

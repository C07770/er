Ext.define("eRecon_web.view.AdhocQuery.AdhocQueryContainer",{
	extend: "Ext.container.Container", 
	alias: "widget.AdhocQuery_Container",   
    layout: "border",
    
 initComponent: function (config) {

    	this.adhocQueryPanel = Ext.create("eRecon_web.view.AdhocQuery.AdhocQueryPanel", {
            title: "Adhoc Query",
            region: "west",
            split: true,
            flex: 3,
            collapsible: false,  
            animCollapse: false,
            collapsed: false

        });
    	
    	this.savedQueryGrid = Ext.create("eRecon_web.view.AdhocQuery.SavedQueryGrid", {
    		title: "Saved Queries",
            region: "center",
            collapsible: false,          
            collapsed: false,
            flex: 2
            });

    	
    	this.items = [    	              
    	              this.adhocQueryPanel,
    	              this.savedQueryGrid
    	             ];
    	
    	this.listeners =
        {
        		scope: this,
                "activate": function () {                        	
                	var savedQueryStore = this.savedQueryGrid.getStore();
                	savedQueryStore.directOptions = {};                	
                	savedQueryStore.load({
    	                callback: function (records, operation, success) {
    	                }
    	            });
              }  
        };
    	
    	this.callParent(config);
	}
	
});

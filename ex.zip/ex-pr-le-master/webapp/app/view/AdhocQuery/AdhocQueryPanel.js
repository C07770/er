Ext.define("eRecon_web.view.AdhocQuery.AdhocQueryPanel", {
    extend: "Ext.form.Panel",
    alias: "widget.AdhocQuery_Panel",
    defaults: {labelAlign: "side"},
    bodyPadding: 10,

    initComponent: function () {
    		    	  
    	this.statementTypeStore = Ext.create("eRecon_web.store.AdhocQueryTypeStore", {}); 
    	
        this.items = [{
                name: "statementtype",
                itemId: "statementtype",
                xtype: "combo",
                fieldLabel: "Statement Type",
                valueField: "code_value",
                displayField: "code_name",                
                store: this.statementTypeStore,
                listeners : {
                	scope : this,
                	afterRender : function(me){
                		me.setValue("SELECT");
                	}
                }                 	                
            }
            ,
            {
                name: "sqlstatement",
	            itemId: "sqlstatement",
	            xtype: "textareafield",
	            fieldLabel: "SQL Statement",
	            width:750,
	            height:200
            },
            {
                name: "reason",
	            itemId: "reason",
	            xtype: "textareafield",
	            fieldLabel: "Reason",
	            width:750
            },
            {
                name: "description",
	            itemId: "description",
	            xtype: "textareafield",
	            fieldLabel: "Description",
	            width:750
            }           
        ];
        
        this.dockedItems = [{
                           	dock: "top", 
                           	xtype: "toolbar", 
                           	items: [{
                            	xtype: "button",
                            	tooltip: "Execute",
                            	text:"Execute",
                            	icon:"/static/assets/famfamfam/icons/database_go.png",
                            	scope:this,
                            	action:"submit"
                           	},{
                            	xtype: "button",
                            	tooltip: "Execute and Save",
                            	text:"Execute and Save",
                            	icon:"/static/assets/famfamfam/icons/database_save.png",
                            	action:"save"
	                       	},{
		                    	xtype: "button",
		                    	tooltip: "Export to Excel",
		                    	text:"Export to Excel",
		                    	icon:"/static/assets/famfamfam/icons/page_white_excel.png",
		                    	action: "export"
		                   	},{
		                   		xtype: "button",
	                        	tooltip: "Clear All",
	                        	text:"Clear",
	                        	iconCls: 'iconTableDelete',
	                        	action:"clear",
	                           	scope:this
		                   	}]
                          }];

        this.callParent(arguments);
    }
});

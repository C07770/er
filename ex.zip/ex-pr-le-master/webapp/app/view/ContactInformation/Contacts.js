Ext.define("eRecon_web.view.ContactInformation.Contacts", {
    extend: "Ext.grid.Panel",
    alias: "widget.ContactInformation_Contacts",    
    autoScroll: true,
    forceFit: true,      
    store: "eRecon_web.store.ContactsStore",
    enableColumnMove: false,    
    border: false,
    viewConfig: {
        emptyText: "No details available."},
                

    initComponent: function () {
        var me = this;
        me.stateful = false;
                                   
        me.columns = [
                      
            {	header: "Name", 
            	dataIndex: "name"            	
            }
            ,
            {	header: "Role", 
            	dataIndex: "role"
            }
            ,
            {	header: "E-mail Address", 
            	dataIndex: "email"
            },
            {	header: "Phone(Office)", 
            	dataIndex: "phone"
            },
            {	header: "Location", 
            	dataIndex: "location"
            }
                              
        ]; 
        
        me.dockedItems = [
                          {
                           	dock: "bottom", 
                           	xtype: "label", 
                           	text:"You may also contact the Tampa Help Desk at 1-813-604-1234 from Sunday 7:00 PM through Friday at 7:00 PM (Eastern Standard Time), excluding certain holidays. You may also send an email to ereconhelp@citi.com "
                           	
                          }
                          ]
        
        this.listeners =
        {
        		scope: this,
                "activate": function () {                             
                	var contactStore = this.getStore();
                	contactStore.load({
    	                callback: function (records, operation, success) {
    	                }
    	            });
              }  
        };
        
        me.callParent(arguments);
        }
    });

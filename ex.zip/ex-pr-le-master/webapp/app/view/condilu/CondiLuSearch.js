Ext.define("eRecon_web.view.condilu.CondiLuSearch", {
    extend: "Ext.form.Panel",
    alias: "widget.secadmin_condilusearch",
	title: "Insert/Search Form",
	layout: 'fit',
	autoScroll:true,
	width:500,
	floating:true,
	closable:true,
    initComponent: function () {
	
    	this.activeStore = Ext.create('Ext.data.Store', {
            fields: ['ActiveName', 'ActiveValue'],
            data: [{
                "ActiveName": "Yes",
                "ActiveValue": "Y"
            }, {
                "ActiveName": "No",
                "ActiveValue": "N"
            }
            ]
        	});
        this.level3Mgr = Ext.create("eRecon_web.store.CondiLuLevel3MgrStore", {});
        this.level4Mgr = Ext.create("eRecon_web.store.CondiLuLevel4MgrStore", {});
        this.dockedItems = [
	    {
	    	xtype: 'toolbar',
	    	dock: 'bottom',
	    	items: [
	    	{
	    		xtype: 'button',
	    		text: 'Insert',
	    		iconCls: 'iconAdd',
	    		action:'CondiLu-AddRecord'
	    	},        
	    	{
	    		xtype: 'button',
	    		text: 'Search',
	    		iconCls: 'iconMagnifier',
	    		action:'CondiLu-SearchRecord'
	    	},
	    	{
	    		xtype: 'tbspacer',
	    		width: 10
	    	},
	    	{
	    		xtype: 'button',
	    		text: 'Clear',
	    		iconCls: 'iconTableDelete',
	    		action:'CondiLu-Clear'
	    	}
	    	]
	    }    
	    ];
        
	    

        this.items = [ {xtype: 'form',layout: 'fit', items: [
		    { 
		    xtype: 'container',
		    margin: '1 1 1 20',
		    layout: {
				type: 'table',
				columns: 6 
		    },
		    defaultType: 'textfield',
		    defaults: {
		        	hideLabel: true, 
		        	hideEmptyLabel: false,
		        	margin: '0 15 1 0'
		    },
		    items: [
		            {
	                xtype: "displayfield",
	                value:"FRS Business Unit",
		            width: 120
	            },
	            {
	                name: "condi",
	                itemId: "businessUnit-text",
	                xtype: "textfield"
	                , width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"DETAIL_DESCR"
	                ,width: 120
	            },
	            {
	            	name: "detaildsr",
		            itemId: "detailDescr-text",
		            xtype: "textfield"
		            , width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL1_DESCR",
	                width: 120
	            },
	            {
	            	name: "level1dsr",
		            itemId: "level1_descr-text",
		            xtype: "textfield"
		            , width: 140
	            }
	            ,
	            {
	                xtype: "displayfield",
	                value:"LEVEL1_ID",
	                width: 120
	            },
	            {
	            	name: "level1ID",
		            itemId: "level1_id-text",
		            xtype: "textfield",
		            fieldLabel:"LEVEL1_ID"
		            , width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL1_MGR",
	                width: 120
	            },
	            {
	            	name: "level1Mgr",
		            itemId: "level1_mgr-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL10_DESCR",
	                width: 120
	            },
	            {
	            	name: "level10dsr",
		            itemId: "level10_descr-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL10_ID",
	                width: 120
	            },
	            {
	            	name: "level10ID",
		            itemId: "level10_id-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL10_MGR",
	                width: 120
	            },
	            {
	            	name: "level10Mgr",
		            itemId: "level10_mgr-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL11_DESCR",
	                width: 120
	            },
	            {
	            	name: "level11dsr",
		            itemId: "level11_descr-text",
		            xtype: "textfield",
		            fieldLabel:"LEVEL11_DESCR",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL11_ID",
	                width: 120
	            },
	            {
	            	name: "level11ID",
		            itemId: "level11_id-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL11_MGR",
	                width: 120
	            },
	            {
	            	name: "level11Mgr",
		            itemId: "level11_mgr-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL12_DESCR",
	                width: 120
	            },
	            {
	            	name: "level12dsr",
		            itemId: "level12_descr-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL12_ID",
	                width: 120
	            },
	            {
	            	name: "level12ID",
		            itemId: "level12_id-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL12_MGR",
	                width: 120
	            },
	            {
	            	name: "level12Mgr",
		            itemId: "level12_mgr-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL13_DESCR",
	                width: 120
	            },
	            {
	            	name: "level13dsr",
		            itemId: "level13_descr-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL13_ID",
	                width: 120
	            },
	            {
	            	name: "level13ID",
		            itemId: "level13_id-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL13_MGR",
	                width: 120
	            },
	            {
	            	name: "level13Mgr",
		            itemId: "level13_mgr-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL14_DESCR",
	                width: 120
	            },
	            {
	            	name: "level14dsr",
		            itemId: "level14_descr-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL14_ID",
	                width: 120
	            },
	            {
	            	name: "level14ID",
		            itemId: "level14_id-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL14_MGR",
	                width: 120
	            },
	            {
	            	name: "level14Mgr",
		            itemId: "level14_mgr-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL15_DESCR",
	                width: 120
	            },
	            {
	            	name: "level15dsr",
		            itemId: "level15_descr-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL15_MGR",
	                width: 120
	            },
	            {
	            	name: "level15Mgr",
		            itemId: "level15_mgr-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL15_ID",
	                width: 120
	            },
	            {
	            	name: "level15ID",
		            itemId: "level15_id-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL2_DESCR",
	                width: 120
	            },
	            {
	            	name: "level2dsr",
		            itemId: "level2_descr-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL2_ID",
	                width: 120
	            },
	            {
	            	name: "level2ID",
		            itemId: "level2_id-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL2_MGR",
	                width: 120
	            },
	            {
	            	name: "level2Mgr",
		            itemId: "level2_mgr-text",
		            xtype: "textfield",
		            fieldLabel:"LEVEL2_MGR",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL3_DESCR",
	                width: 120
	            },
	            {
	            	name: "level3dsr",
		            itemId: "level3_descr-text",
		            xtype: "textfield",
		            width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL3_ID",width: 120
	            },
	            {
	            	name: "level3ID",
		            itemId: "level3_id-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL3_MGR",width: 120
	            },
	            {
	            	name: "level3Mgr",
		            itemId: "level3_mgr-text",
		            xtype: "combo",width: 140,
		            store: this.level3Mgr,
		            typeAhead:true,
		            valueField: "key",
		            displayField: "value"
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL4_DESCR",width: 120
	            },
	            {
	            	name: "level4dsr",
		            itemId: "level4_descr-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL4_ID",width: 120
	            },
	            {
	            	name: "level4ID",
		            itemId: "level4_id-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL4_MGR",width: 120
	            },
	            {
	            	name: "level4Mgr",
		            itemId: "level4_mgr-text",
		            xtype: "combo",width: 140,
		            store: this.level4Mgr,
		            typeAhead:true,
		            valueField: "key",
		            displayField: "value"
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL5_DESCR",width: 120
	            },
	            {
	            	name: "level5dsr",
		            itemId: "level5_descr-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL5_ID",width: 120
	            },
	            {
	            	name: "level5ID",
		            itemId: "level5_id-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL5_MGR",width: 120
	            },
	            {
	            	name: "level5Mgr",
		            itemId: "level5_mgr-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL6_DESCR",width: 120
	            },
	            {
	            	name: "level6dsr",
		            itemId: "level6_descr-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL6_ID",width: 120
	            },
	            {
	            	name: "level6ID",
		            itemId: "level6_id-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL6_MGR",width: 120
	            },
	            {
	            	name: "level6Mgr",
		            itemId: "level6_mgr-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL7_DESCR",width: 120
	            },
	            {
	            	name: "level7dsr",
		            itemId: "level7_descr-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL7_ID",width: 120
	            },
	            {
	            	name: "level7ID",
		            itemId: "level7_id-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL7_MGR",width: 120
	            },
	            {
	            	name: "level7Mgr",
		            itemId: "level7_mgr-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL8_DESCR",width: 120
	            },
	            {
	            	name: "level8dsr",
		            itemId: "level8_descr-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL8_ID",width: 120
	            },
	            {
	            	name: "level8ID",
		            itemId: "level8_id-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL8_MGR",width: 120
	            },
	            {
	            	name: "level8Mgr",
		            itemId: "level8_mgr-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL9_DESCR",width: 120
	            },
	            {
	            	name: "level9dsr",
		            itemId: "level9_descr-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL9_ID",width: 120
	            },
	            {
	            	name: "level9ID",
		            itemId: "level9_id-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL9_MGR",width: 120
	            },
	            {
	            	name: "level9Mgr",
		            itemId: "level9_mgr-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL16_DESCR",width: 120
	            },
	            {
	            	name: "level16dsr",
		            itemId: "level16_descr-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL16_ID",width: 120
	            },
	            {
	            	name: "level16ID",
		            itemId: "level16_id-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"LEVEL16_MGR",width: 120
	            },
	            {
	            	name: "level16Mgr",
		            itemId: "level16_mgr-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"TREE",width: 120
	            },
	            {
	            	name: "tree",
		            itemId: "tree-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"Change Date",width: 120
	            },
	            {
	            	name: "ChangeDate",
		            itemId: "changeDate-text",
		            xtype: "datefield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"Change Type",width: 120
	            },
	            {
	            	name: "ChangeType",
		            itemId: "changeType-text",
		            xtype: "textfield",width: 140
	            },
	            {
	                xtype: "displayfield",
	                value:"Active Flag",width: 120
	            },
				{
					xtype: 'combobox',
					searchId: 'cmbAgingOverride',
					width: 140,
					fieldLabel:'Active Flag',
					typeAhead:true,
					name:'activeFlag',
				    displayField: 'ActiveName',
				    valueField: 'ActiveValue',
		            store: this.activeStore
				}
	            ]
	        }]
	     }];

        this.callParent(arguments);
    }
});

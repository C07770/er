Ext.define("eRecon_web.view.condilu.CondiLuGrid", {
    extend: "Ext.grid.Panel",
    alias: "widget.secadmin_condiluGrid",    
    autoScroll: true,
    layout: 'fit',
    columnLines: true,
    multiSelect:true,
    store: "eRecon_web.store.CondiLuStore",
    viewConfig: {
        emptyText: "No details available."},
    initComponent: function () {
        var me = this;
        me.stateful = false;
        this.activeStore = Ext.create('Ext.data.Store', {
            fields: ['ActiveName', 'ActiveValue'],
            data: [{
                "ActiveName": "Yes",
                "ActiveValue": "Y"
            }, {
                "ActiveName": "No",
                "ActiveValue": "N"
            }
            ]
        	});
        this.level3Mgr = Ext.create("eRecon_web.store.CondiLuLevel3MgrStore", {});
        this.level4Mgr = Ext.create("eRecon_web.store.CondiLuLevel4MgrStore", {});
        me.plugins= [
            Ext.create('Ext.grid.plugin.CellEditing', {
                clicksToEdit: 2,
                allowBlank:false
            })
        ];
        me.dockedItems = [
             {
              	dock: "top", 
              	xtype: "toolbar", 
              	items: [
              	   {
                   	xtype: "button",
                   	tooltip: "Save",
                   	text:"Save",
                   	icon: "/static/assets/famfamfam/icons/disk.png",                   	
                   	action:"CondiLu-save",
                   	scope:this
                   },
                   "-"
                   ,
                   {
                   	xtype: "button",
                   	tooltip: "Export to Excel",
                   	text:"Export to Excel",
                   	icon: "/static/assets/famfamfam/icons/page_white_excel.png",                   
                    action : "CondiLu-excel",
                    id: 'CondiLu-excel-button'
                   },
                   "-"
                   ,
                   {
                   	xtype: "button",
                   	tooltip: "Delete",
                   	text:"Delete",
                   iconCls: 'iconDelete',
                   	handler : function() {
                   		var i;
                   		var selModel = this.up('grid').getSelectionModel();
                   		var selRec = selModel.getSelection();
                   		for(i=0;i<selRec.length;i++)
                   			{

                   					this.up('grid').store.remove(selRec[i]);
                       				selRec[i].data.action = "DELETE";

                   				
                   			}
                   	}
                   },
                   {
                      	xtype: "button",
                      	tooltip: "Insert/Search",
                      	iconCls: 'iconAdd',
                      	text:"Insert/Search",
                      	action:"CondiLu-add"
                   }]
             },                  
             {
                xtype: "pagingtoolbar",
                dock: "bottom",
                displayInfo: true,
                store: me.store,
                plugins: [Ext.create("eRecon_web.plugins.PageSize")]

            }];
        
        me.columns = [
                      
            {	header: "FRS Business Unit", 
            	dataIndex: "condi",
            	width:100
            }
            ,
            {	header: "DETAIL_DESCR", 
            	dataIndex: "detaildsr",
	            editor:{
	        		xtype: 'textfield'
	        	}
            }
            ,
            {	header: "LEVEL1_DESCR", 
            	dataIndex: "level1dsr",
            	editor:{
        		xtype: 'textfield'
        		}
            }
            ,
            {	header: "LEVEL1_ID", 
            	dataIndex: "level1ID",
            	editor:{
        		xtype: 'textfield'
        		}
            }
            ,
            {	header: "LEVEL1_MGR", 
            	dataIndex: "level1Mgr",
            	editor:{
            		xtype: 'textfield'
    			}
            }
            ,
            {	header: "LEVEL10_DESCR", 
            	dataIndex: "level10dsr",
            	editor:{
            		xtype: 'textfield'
    			}
            },
            {	header: "LEVEL10_ID", 
            	dataIndex: "level10ID",
            	editor:{
            		xtype: 'textfield'
    			}
            },
            {	header: "LEVEL10_MGR", 
	        	dataIndex: "level10Mgr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL11_DESCR", 
	        	dataIndex: "level11dsr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL11_ID", 
	        	dataIndex: "level11ID",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL11_MGR", 
	        	dataIndex: "level11Mgr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL12_DESCR", 
	        	dataIndex: "level12dsr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL12_ID", 
	        	dataIndex: "level12ID",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL12_MGR", 
	        	dataIndex: "level12Mgr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL13_DESCR", 
	        	dataIndex: "level13dsr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL13_ID", 
	        	dataIndex: "level13ID",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL13_MGR", 
	        	dataIndex: "level13Mgr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL14_DESCR", 
	        	dataIndex: "level14dsr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL14_ID", 
	        	dataIndex: "level14ID",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL14_MGR", 
	        	dataIndex: "level14Mgr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL15_DESCR", 
	        	dataIndex: "level15dsr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL15_ID", 
	        	dataIndex: "level15ID",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL15_MGR", 
	        	dataIndex: "level15Mgr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL2_DESCR", 
	        	dataIndex: "level2dsr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL2_ID", 
	        	dataIndex: "level2ID",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL2_MGR", 
	        	dataIndex: "level2Mgr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL3_DESCR", 
	        	dataIndex: "level3dsr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL3_ID", 
	        	dataIndex: "level3ID",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL3_MGR", 
	        	dataIndex: "level3Mgr",
	        	editor:{
		        	xtype: 'combo',
		            store: this.level3Mgr,
	                valueField: "key",
	                displayField: "value"
				}
	        },
	        {	header: "LEVEL4_DESCR", 
	        	dataIndex: "level4dsr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL4_ID", 
	        	dataIndex: "level4ID",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL4_MGR", 
	        	dataIndex: "level4Mgr",
	        	editor:{
		        	xtype: 'combo',
		            store: this.level4Mgr,
	                valueField: "key",
	                displayField: "value"
	        		
				}
	        },
	        {	header: "LEVEL5_DESCR", 
	        	dataIndex: "level5dsr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL5_ID", 
	        	dataIndex: "level5ID",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL5_MGR", 
	        	dataIndex: "level5Mgr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL6_DESCR", 
	        	dataIndex: "level6dsr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL6_ID", 
	        	dataIndex: "level6ID",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL6_MGR", 
	        	dataIndex: "level6Mgr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL7_DESCR", 
	        	dataIndex: "level7dsr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL7_ID", 
	        	dataIndex: "level7ID",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL7_MGR", 
	        	dataIndex: "level7Mgr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL8_DESCR", 
	        	dataIndex: "level8dsr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL8_ID", 
	        	dataIndex: "level8ID",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL8_MGR", 
	        	dataIndex: "level8Mgr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL9_DESCR", 
	        	dataIndex: "level9dsr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL9_ID", 
	        	dataIndex: "level9ID",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL9_MGR", 
	        	dataIndex: "level9Mgr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL16_DESCR", 
	        	dataIndex: "level16dsr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL16_ID", 
	        	dataIndex: "level16ID",
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
	        {	header: "LEVEL16_MGR", 
	        	dataIndex: "level16Mgr",
	        	editor:{
	        		xtype: 'textfield'
				}
	        }
            ,
            {	header: "Change Type", 
	        	dataIndex: "ChangeType",
	        	hidden:true,
	        	editor:{
	        		xtype: 'textfield'
				}
	        },
            {	header: "Change Date", 
	        	hidden:true,
	        	dataIndex: "ChangeDate"
	        },
            {	header: "Active Flag", 
            	dataIndex: "activeFlag",
	            editor: {
	                xtype: 'combo',
	                store: this.activeStore,
	                valueField: "ActiveValue",
	                displayField: "ActiveValue"
	            }
            },
            {	header: "Tree", 
	        	dataIndex: "tree",
	        	readOnly:true
            }
                              
        ]; 
        
        me.callParent(arguments);
        }
    });

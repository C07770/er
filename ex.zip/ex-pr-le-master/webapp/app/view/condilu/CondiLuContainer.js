Ext.define("eRecon_web.view.condilu.CondiLuContainer",{
	extend: "Ext.container.Container", 
	alias: "widget.secadmin_condilucontainer",   
    layout: "border",
    
 initComponent: function (config) {
    	this.condilugrid = Ext.create("eRecon_web.view.condilu.CondiLuGrid", {
    		title: "Condi Mgr Lu",
            region: "center",
            flex: 4
            });

    	this.items = [    	              
    	              this.condilugrid
    	             ];
    	
    	this.callParent(config);
	}
	
});

Ext.define("eRecon_web.view.lemadjustments.lemAdjustmentsPopup.lemAdjustmentsRisk",
{
	extend : "Ext.form.Panel",
	alias : "widget.lemAdjustmentsRisk_Container",
	itemId : 'lemAdjRisk-form',
	requires : [ "eRecon_web.common.CustomCreditNumericField","eRecon_web.common.CustomDebitNumericField","eRecon_web.common.CustomNumericField"],
	bodyPadding: 10,
	title: 'Controller Delegate Risk',
	border: false, 
	items:[{
			xtype : 'fieldset',
			layout : {
			columns : 7,
			type : 'table'
			},
		title : '',
		items : [ {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : ''
		}, {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'Amount At Risk'
		}, {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'Controller Delegate Adjustment'
		}, {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'Adj. Amt At Risk'
		}, {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'Reportable Amt At Risk'
		}, {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'Amt At Risk Category'
		}, {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'Target Resolution Date'
		},  
		{
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'DR'
		}, {
			xtype : 'customDebitNumericField',
			readOnly:true,
			itemId : 'rb_DrAmtAtRisk-text',
			fieldCls:'disabledTextField',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'specificAmtAtRiskDr',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		}, {
			xtype : 'customNumericField',
			itemId : 'rb_DrLemAdjustmentsRisk-text',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'lemAmtAtRiskAdjDr'
		}, {
			xtype : 'customNumericField',
			readOnly:true,
			itemId : 'rb_DrAdjAmtAtRisk-text',
			fieldCls:'disabledTextField',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'adjustedAmtAtRiskDr',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		}, {
			xtype : 'customNumericField',
			readOnly:true,
			itemId : 'rb_DrReportableAmtAtRisk-text',
			fieldCls:'disabledTextField',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'amtAtRiskRptlDr',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		}, {
			xtype : 'combobox',			
			itemId : 'rb_DrAmtAtRiskCategory-combo',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'amtAtRiskTypeDr',		
			store: Ext.create('Ext.data.Store', {                                     
                fields: ['AmtAtRiskCatName', 'AmtAtRiskCatValue'],
                data: [{
                    "AmtAtRiskCatName": "Select Category..",
                    "AmtAtRiskCatValue": "0"
                }, {
                    "AmtAtRiskCatName": "Recon Break",
                    "AmtAtRiskCatValue": "1"
                }, {
                    "AmtAtRiskCatName": "Balance Aging",
                    "AmtAtRiskCatValue": "2"
                }, {
                    "AmtAtRiskCatName": "Valuation Issues",
                    "AmtAtRiskCatValue": "3"
                }]
            	}),
             displayField:"AmtAtRiskCatName",
             valueField:"AmtAtRiskCatValue"
		}, {
			xtype : 'datefield',
			itemId : 'rb_DrTargetResolutionDate-text',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			emptyText: 'mm/dd/yyyy',			
			maskRe : /[0-9\/]/,
			name : 'amtAtRiskTargetDtDr'
		}, 	{
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'CR'
		}, {
			xtype : 'customCreditNumericField',
			readOnly:true,
			itemId : 'rb_CrAmtAtRisk-text',
			fieldCls:'disabledTextField',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'specificAmtAtRiskCr',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		}, {
			xtype : 'customNumericField',			
			itemId : 'rb_CrLemAdjustmentsRisk-text',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'lemAmtAtRiskAdjCr'
		}, {
			xtype : 'customNumericField',
			readOnly:true,
			itemId : 'rb_CrAdjAmtAtRisk-text',
			fieldCls:'disabledTextField',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'adjustedAmtAtRiskCr',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		}, {
			xtype : 'customNumericField',
			readOnly:true,
			itemId : 'rb_CrReportableAmtAtRisk-text',
			fieldCls:'disabledTextField',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'amtAtRiskRptlCr',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		},{
			xtype : 'combobox',			
			itemId : 'rb_CrAmtAtRiskCategory-combo',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'amtAtRiskTypeCr',
			store: Ext.create('Ext.data.Store', {                                     
                fields: ['AmtAtRiskCatName', 'AmtAtRiskCatValue'],
                data: [{
                    "AmtAtRiskCatName": "Select Category..",
                    "AmtAtRiskCatValue": "0"
                }, {
                    "AmtAtRiskCatName": "Recon Break",
                    "AmtAtRiskCatValue": "1"
                }, {
                    "AmtAtRiskCatName": "Balance Aging",
                    "AmtAtRiskCatValue": "2"
                }, {
                    "AmtAtRiskCatName": "Valuation Issues",
                    "AmtAtRiskCatValue": "3"
                }]
            	}),
             displayField:"AmtAtRiskCatName",
             valueField:"AmtAtRiskCatValue"
		} ]
	}, {
		xtype : 'fieldset',
		layout : {
			columns : 3,
			type : 'table'
		},
		title : '',
		items : [ {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'Reserve'
		}, {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'Controller Delegate Adjustment'
		}, {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'Adjusted Reserve'
		}, {
			xtype : 'customDebitNumericField',
			readOnly:true,
			itemId : 'rb_Reserve-text',
			fieldCls:'disabledTextField',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'amtAtRiskReserveDr',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		}, {
			xtype : 'customNumericField',
			itemId : 'rb_ReserveLemAdjustment-text',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'lemAmtReserveAdj'
		}, {
			xtype : 'customNumericField',
			readOnly:true,
			itemId : 'rb_AdjustedReserve-text',
			fieldCls:'disabledTextField',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'adjustedAmtReserve',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		}, {
			xtype : 'hiddenfield',
			itemId : 'risk_statusIndicator-hidden',
			fieldLabel : 'Label',
			name : 'statusindicator'
		}] 
		
		}]
	});

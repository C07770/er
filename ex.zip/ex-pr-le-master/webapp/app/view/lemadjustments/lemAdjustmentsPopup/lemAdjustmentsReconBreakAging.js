Ext.define("eRecon_web.view.lemadjustments.lemAdjustmentsPopup.lemAdjustmentsReconBreakAging",
{
	extend : "Ext.form.Panel",
	alias : "widget.lemAdjustmentsReconBreakAging_Container",
	itemId : 'lemAdjReconBreakUserRedAging-form',
	title : 'Recon Break Aging',
	requires : [ "eRecon_web.common.CustomCreditNumericField","eRecon_web.common.CustomDebitNumericField","eRecon_web.common.CustomNumericField"],
	bodyPadding: 10,
	tabConfig : {
		xtype : 'tab',
		itemId : ''
	},
	border: false, 
	items : [ {
		xtype : 'fieldset',
		layout : {
			columns : 7,
			type : 'table'
		},
		title : '',
		items : [ {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : ''
		}, {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'User Entered Red'
		}, {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'Controller Delegate Adjustment'
		}, {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'Adj. User Entered Red'
		}, {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'Total Red Amount'
		}, {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'Reportable Red Amount'
		}, {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'Controller Delegate Comments'
		}, {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'DR'
		}, {
			xtype : 'customDebitNumericField',
			readOnly:true,
			itemId : 'rb_DrUserEnteredRed-text',
			fieldCls:'disabledTextField',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'amtUserRedDr',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		}, {
			xtype : 'customNumericField',
			itemId : 'rb_DrLemAdjustments-text',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',			
			name : 'lemUserRedAdjDr'
		}, {
			xtype : 'customNumericField',
			readOnly:true,
			itemId : 'rb_DrAdjUserRed-text',
			fieldCls:'disabledTextField',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'adjustedUserRedDr',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		}, {
			xtype : 'customNumericField',
			readOnly:true,
			itemId : 'rb_DrTotalRedAmt-text',
			fieldCls:'disabledTextField',
			padding : '4px 5px 0px 5px',			
			fieldLabel : '',
			name : 'amtTotRedDr',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		}, {
			xtype : 'customNumericField',
			readOnly:true,
			itemId : 'rb_DrReportableRedAmt-text',
			fieldCls:'disabledTextField',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'amtRptlRedDr',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		}, {
			xtype : 'textareafield',
			rowspan : 2,
			width:170,
			itemId : 'rb_LemComments-text',
			fieldLabel : '',
			name : 'lemComments'
		}, {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'CR'
		}, {
			xtype : 'customCreditNumericField',
			readOnly:true,
			itemId : 'rb_CrUserEnteredRed-text',
			fieldCls:'disabledTextField',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'amtUserRedCr',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		}, {
			xtype : 'customNumericField',			
			itemId : 'rb_CrLemAdjustments-text',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'lemUserRedAdjCr'
		}, {
			xtype : 'customNumericField',
			readOnly:true,
			itemId : 'rb_CrAdjUserRed-text',
			fieldCls:'disabledTextField',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'adjustedUserRedCr',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		}, {
			xtype : 'customNumericField',
			readOnly:true,
			itemId : 'rb_CrTotalRedAmt-text',
			fieldCls:'disabledTextField',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'amtTotRedCr',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		}, {
			xtype : 'customNumericField',
			readOnly:true,
			itemId : 'rb_CrReportableRedAmt-text',
			fieldCls:'disabledTextField',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'amtRptlRedCr',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		}, {
			xtype : 'hiddenfield',
			itemId : 'rb_agingType-hidden',
			fieldLabel : 'Label',
			name : 'agingType'
		}, {
			xtype : 'hiddenfield',
			itemId : 'rb_statusIndicator-hidden',
			fieldLabel : 'Label',
			name : 'statusindicator'
		}]
	} ],

	initComponent : function(config) {

		this.callParent(arguments);
	}
});

Ext.define("eRecon_web.view.lemadjustments.lemAdjustmentsPopup.lemAdjustmentsDetails",
{
	extend : "Ext.form.Panel",
	alias : "widget.lemAdjustmentsDetails_container",
	fieldDefaults:{fieldCls:"disabledTextField"},
	requires : [ "eRecon_web.common.CustomCreditNumericField","eRecon_web.common.CustomDebitNumericField"],
	itemId : 'lemAdj-panel',
	bodyPadding : 10,
	title : 'My Form',

	items : [ {
		xtype : 'fieldset',
		layout : {
			columns : 3,
			type : 'table'
		},
		title : '',
		items : [ {
			xtype : 'textfield',
			itemId : 'fullkey-text',
			padding : '4px 5px 0px 5px',
			fieldLabel : 'Full Key',
			readOnly:true,
			labelWidth : 150,
			name : 'fullkey'
		}, {
			xtype : 'textfield',
			itemId : 'statusIndicator-text',			
			readOnly:true,
			padding : '4px 5px 0px 5px',
			fieldLabel : 'Red/Green Indicator',
			labelWidth : 150,
			name : 'statusindicator'
		}, {
			xtype : 'textfield',
			itemId : 'AgingBenchmark-text',			
			readOnly:true,
			padding : '4px 5px 0px 5px',
			fieldLabel : 'Aging Benchmark',
			labelWidth : 150,
			name : 'agingBenchmark'
		}, {
			xtype : 'textfield',
			itemId : 'Description-text',			
			readOnly:true,
			padding : '4px 5px 0px 5px',
			fieldLabel : 'Description',
			labelWidth : 150,
			name : 'description'
		},{
			xtype : 'textfield',
			itemId : 'BankingGroup-text',			
			readOnly:true,
			padding : '4px 5px 0px 5px',
			fieldLabel : 'Banking Group',
			labelWidth : 150,
			name : 'businessunit'
		}, {
			xtype : 'textfield',
			itemId : 'AccountAgingType-text',			
			readOnly:true,
			padding : '4px 5px 0px 5px',
			fieldLabel : 'Account Aging Type',
			labelWidth : 150,
			name : 'acctAgingType'
		}, {
			xtype : 'textfield',
			itemId : 'ProofOwner-text',			
			readOnly:true,
			padding : '4px 5px 0px 5px',
			fieldLabel : 'Proof Owner',
			labelWidth : 150,
			name : 'proofowner'
		}, {
			xtype : 'textfield',
			itemId : 'SubmittedBy-text',			
			readOnly:true,
			padding : '4px 5px 0px 5px',
			fieldLabel : 'Submitted By',
			labelWidth : 150,
			name : 'submitBy'
		}, {
			xtype : 'textfield',
			itemId : 'SubmittedStatus-text',			
			readOnly:true,
			padding : '4px 5px 0px 5px',
			fieldLabel : 'Submitted Status',
			labelWidth : 150,
			name : 'statusCode'
		}, {
			xtype : 'textareafield',
			itemId : 'POComments-text',			
			readOnly:true,
			padding : '4px 5px 0px 5px',
			fieldLabel : 'PO Comments',
			labelWidth : 150,
			name : 'comments'
		}, {
			xtype : 'textfield',
			itemId : 'AOAgreeDisagree-text',			
			readOnly:true,
			padding : '4px 5px 0px 5px',
			fieldLabel : 'AO Agree/Disagree',
			labelWidth : 150,
			name : 'agreedFlag'
		}, {
			xtype : 'textfield',
			itemId : 'AOAttestation-text',			
			readOnly:true,
			padding : '4px 5px 0px 5px',
			fieldLabel : 'AO Attestation',
			labelWidth : 150,
			name : 'attestedFlag'
		}, {
			xtype : 'textfield',
			itemId : 'AccountOwner-text',			
			readOnly:true,
			padding : '4px 5px 0px 5px',
			fieldLabel : 'Account Owner',
			labelWidth : 150,
			name : 'accountowner'
		}, {
			xtype : 'textareafield',
			itemId : 'AOComments-text',			
			readOnly:true,
			padding : '4px 5px 0px 5px',
			fieldLabel : 'AO Comments',
			labelWidth : 150,
			name : 'disagreedComments'
		}, {
			xtype : 'displayfield',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			labelWidth : 150,
			value: '',
        	name: 'agreedCnt',
        	searchId: 'agingDetailsLink',
        	listeners : {
        		afterrender : function(component) {
        			component.getEl().on('click',function() {
        				component.fireEvent('click', component);
        			});
        		}
        	},
        	renderer : function(val) {
        		return "<p class='labelLinkCls'>Aging details</p>";
        	}
		}]
	}, {
		xtype : 'fieldset',
		layout : {
			columns : 5,
			type : 'table'
		},
		title : '',
		items : [ {
			xtype : 'label',
			itemId : 'GLBalance-label',
			padding : '4px 5px 0px 5px',
			text : 'GL Balance'
		}, {
			xtype : 'label',
			itemId : 'SLBalance-label',
			padding : '4px 5px 0px 5px',
			text : 'SL Balance'
		}, {
			xtype : 'label',
			itemId : 'AmtAboveBmDr-label',
			padding : '4px 5px 0px 5px',
			text : 'Amt Above BM DR'
		}, {
			xtype : 'label',
			itemId : 'AmtAboveBmCr-label',
			padding : '4px 5px 0px 5px',
			text : 'Amt Above BM CR'
		}, {
			xtype : 'label',
			padding : '4px 5px 0px 5px',
			text : 'Local CCY Threshold'
		}, {
			xtype : 'customNumericField',
			itemId : 'GLBalance-text',			
			readOnly:true,
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'glbalance',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		}, {
			xtype : 'customNumericField',
			itemId : 'SLBalance-text',			
			readOnly:true,
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'slbalance',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		}, {
			xtype : 'customDebitNumericField',
			itemId : 'AmtAboveBmDr-text',			
			readOnly:true,
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'amtGtbmDr',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		}, {
			xtype : 'customCreditNumericField',
			itemId : 'AmtAboveBmCr-text',			
			readOnly:true,
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'amtGtbmCr',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		}, {
			xtype : 'customDebitNumericField',			
			readOnly:true,
			itemId : 'LocalCcyThreshold-text',
			padding : '4px 5px 0px 5px',
			fieldLabel : '',
			name : 'lclCcyThreshold',
			listeners : {
	  		    change: function() {
	  		    	this.onBlur();
	  		    }
	  		}
		} ]

	} ],
	initComponent : function(config) {
		this.callParent(arguments);
	}

});

Ext.define("eRecon_web.view.lemadjustments.lemAdjustmentsPopup.lemAdjustmentsAging", {
	extend: "Ext.tab.Panel",
    alias: "widget.lemAdjustmentsAging_container",  
    requires: ["eRecon_web.view.lemadjustments.lemAdjustmentsPopup.lemAdjustmentsBalanceAging","eRecon_web.view.lemadjustments.lemAdjustmentsPopup.lemAdjustmentsReconBreakAging"],
    border: false, 
    initComponent: function (config) {
    	var me = this;
    	
    	me.items = [
    	    {    	
    	    	itemId: 'lembalanceaging',
	            xtype: 'lemAdjustmentsBalanceAging_Container'
    	    },
    	    {
 	            xtype: 'lemAdjustmentsReconBreakAging_Container'
    	    }
    	    ];
    	
    	me.callParent(config);
    }
    
});

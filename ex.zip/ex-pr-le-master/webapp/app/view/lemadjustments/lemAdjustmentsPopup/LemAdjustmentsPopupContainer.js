Ext.define("eRecon_web.view.lemadjustments.lemAdjustmentsPopup.LemAdjustmentsPopupContainer",{
	extend: "Ext.panel.Panel", 
	alias: "widget.lemadjustmentspopup_container",
    requires: ["eRecon_web.view.lemadjustments.lemAdjustmentsPopup.lemAdjustmentsDetails","eRecon_web.view.lemadjustments.lemAdjustmentsPopup.lemAdjustmentsAging","eRecon_web.view.lemadjustments.lemAdjustmentsPopup.lemAdjustmentsRisk"],
    deferredRender:true,
   border: false, 
   layout: 'form',
    
 initComponent: function (config) {
	 	var me = this;    	
    	me.items = [   
					{
					    title: 'Controller Delegate Adjustment Details',
					    xtype: 'lemAdjustmentsDetails_container',
					    name: 'lemAdjustmentsDetails'
					},
					{						
					    xtype: 'lemAdjustmentsAging_container',
					    name: 'lemAdjustmentsAgingDetails'
					},
					{
						 xtype: 'lemAdjustmentsRisk_Container',
						 name: 'lemAdjustmentsRisk'
					}
    	            ];
    	 me.dockedItems = [
          {
              xtype: 'toolbar',       
              dock: 'top',            
              items: [                  
                  {
                      xtype: 'button',
                      text: 'Submit',
                      iconCls: 'iconSave',
                      action: 'submit'
                  }
              ]
          }
    	];  	     	    	
    	me.callParent(config);
	}
});

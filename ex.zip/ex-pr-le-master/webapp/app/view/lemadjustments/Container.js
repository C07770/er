Ext.define("eRecon_web.view.lemadjustments.Container",{
	extend: "Ext.container.Container", 
	alias: "widget.lemadjustments_container",
    requires: ["eRecon_web.view.lemadjustments.DetailGrid","eRecon_web.view.lemadjustments.FilterForm"],
    layout: "border",
    
 initComponent: function (config) {
    	this.detailGrid = Ext.create("eRecon_web.view.lemadjustments.DetailGrid", {
    		title: "Controller Delegate Summary Details screen",
            region: "center",
            flex: 4
            });

    	this.filterForm = Ext.create("eRecon_web.view.lemadjustments.FilterForm", {
            title: "Filter",
            region: "west",
            split: true,
            flex: 1.3,
            collapsible: true,
            animCollapse: false,
            collapsed: true

        });
    	
    	this.items = [    	              
    	              this.detailGrid,
    	              this.filterForm
    	             ];
    	
    	
    	this.listeners = {
                scope: this,
                "activate": function () {                    
                    //this.detailGrid.getStore().load();
                	var lemAdjStore = this.detailGrid.getStore();
    	        	lemAdjStore.directOptions = {};
    	        	lemAdjStore.getProxy().extraParams = {
    	                0: null,
    	                1: null,
    	                2: null,
    	                3: null
    	            };
    	        	lemAdjStore.loadPage(1,{
    	                callback: function (records, operation, success) {
    	                }
    	            });
                }
            };   
    	
    	
    	this.callParent(config);
	}
	
});

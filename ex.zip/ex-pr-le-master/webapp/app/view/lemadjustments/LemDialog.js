Ext.define("eRecon_web.view.lemadjustments.LemDialog", {
    extend: "Ext.window.Window",
    alias: "widget.lem_custom_dialog",
    modal: true,
    width: 1080,
    height: 580,
    autoScroll:true,
    
    headerPosition: 'top',
	layout: 'form',
    
    initComponent: function (config) {
        this.callParent(config);
    }
});

Ext.define("eRecon_web.view.lemadjustments.DetailGrid", {
    extend: "Ext.grid.Panel",
    alias: "widget.lemadjustments_detailgrid", 
    id: "LemDetailGrid",
    autoScroll: true,
    forceFit: true,    
    columnLines: true,
    store: "eRecon_web.store.LemAdjustmentsStore",
    enableColumnMove: true,
    border: false,
    requires: ["eRecon_web.view.lemadjustments.lemAdjustmentsPopup.LemAdjustmentsPopupContainer"],
    viewConfig: {
        emptyText: "No details available."},
   

    initComponent: function () {
        var me = this;
        me.stateful = false;
      
        me.dockedItems = [
            {
                xtype: "pagingtoolbar",
                dock: "bottom",
                displayInfo: true,
                store: me.store,
                plugins: [Ext.create("eRecon_web.plugins.PageSize")]
            }
        ];

        me.columns = [
                      
            {header: "FullKey", 
            	dataIndex: "fullKey",
            	width:300

            	}
            ,
            {
            	header: "Description",
            	dataIndex: "description",
            	align: 'left',
            	resizable:true,
            	width: 150,
	            renderer: function(val) {
	        		val = val.replace(/\n/g, '<br />');
					return '<div style="white-space:normal !important;">' + val + '</div>'
				}
            },
            {header: "Banking Group", dataIndex: "bankingGroup"}
            ,
            {
            	header: "User Entered Red Amount DR", 
	        	dataIndex: "userRedDR",
	        	renderer: eRecon_web.gbl.constants.doubleValueRenderer
            }
            ,
            {
            	header: "User Entered Red Amount CR", 
            	dataIndex: "userRedCR",
            	renderer: eRecon_web.gbl.constants.doubleValueRenderer
            }
            ,
            {
            	header: "Total Red Amount DR", 
            	dataIndex: "totalRedDR",
            	renderer: eRecon_web.gbl.constants.doubleValueRenderer
            }
            ,
            {
            	header: "Total Red Amount CR", 
            	dataIndex: "totalRedCR",
            	renderer: eRecon_web.gbl.constants.doubleValueRenderer
            }
            ,            
            {
            	header: "Amount At Risk DR", 
            	dataIndex: "amtAtRiskDR",
            	renderer: eRecon_web.gbl.constants.doubleValueRenderer
            }
            ,
            {
            	header: "Amount At Risk CR", 
            	dataIndex: "amtAtRiskCR",
            	renderer: eRecon_web.gbl.constants.doubleValueRenderer
            }
            ,
            {
            	header: "Status Indicator", 
            	dataIndex: "statusIndicator",
            	renderer: function setFontColor(value, meta, record){
            		var newvalue;
            		if(record.get('statusIndicator') == "Red")
            			{
            				newvalue = "<span style='color:red' >"+value+"</span>";
            			}
            		else if (record.get('statusIndicator') == "Green")
            			{
            			  	newvalue = "<span style='color:green' >"+value+"</span>";
            			}            		
            		return newvalue;
            	}           
            } 
            ,            
            {
            	
                header:"Adjust",
                xtype:"templatecolumn",
                tpl: '<input type="button" value="Adjust" style="height:20px">',
                align: 'center',
                listeners: {
            		click: function(grid, col, row){
            			me.fireEvent("showLEMAgingDialog", grid, col, row);   
            		}
            	}
                }                  
        ]; 
        me.callParent(arguments);
        }
    });

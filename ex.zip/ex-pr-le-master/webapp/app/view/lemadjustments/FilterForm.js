Ext.define("eRecon_web.view.lemadjustments.FilterForm", {
    extend: "Ext.form.Panel",
    alias: "widget.lemadjustments_filterform",
    defaults: {labelAlign: "side"},
    bodyPadding: 10,

    initComponent: function () {
	    	 
    	this.bankingGroupStore = Ext.create("eRecon_web.store.LemAdjustmentsBankingGroupStore", {});   
    	this.fullkeyStore = Ext.create("eRecon_web.store.LemFullkeyStore", {});
    	
    	var statusIndicator = Ext.create('Ext.data.Store', {
            fields: ['IndicatorName', 'IndicatorValue'],
            data: [{
            	"IndicatorName": "ALL"
            },
            {
                "IndicatorName": "Red",
                "IndicatorValue": "Red"
            }, {
                "IndicatorName": "Green",
                "IndicatorValue": "Green"
            }
            ]
        	});
    	var submitStatus = Ext.create('Ext.data.Store', {
            fields: ['StatusName', 'StatusValue'],
            data: [{
                "StatusName": "All"
            }, {
                "StatusName": "Submitted",
                "StatusValue": "S"
            }, {
            	"StatusName": "Unsubmitted",
                "StatusValue": "U"
            }
            ]
        	});

        this.items = [            
            {
                name: "BankingGroup",
                itemId: "bankinggroup-combo",
                xtype: "combo",
                fieldLabel: "Banking Group",
                valueField: "bankingGroup",
                displayField: "bankingGroup",
               store: this.bankingGroupStore
            }
            ,
            {
                name: "StatusIndicator",
	            itemId: "statusindicator-combo",
	            xtype: "combo",
	            fieldLabel: "Status Indicator",
	            valueField: "IndicatorValue",
	            displayField: "IndicatorName",
	            store: statusIndicator
            },
            {
                name: "Status",
	            itemId: "Status-combo",
	            xtype: "combo",
	            fieldLabel: "Status",
	            valueField: "StatusValue",
	            displayField: "StatusName",
	            store: submitStatus
            }
            ,
            {
                name: "fullKey",
                itemId: "fullKey-text",
                xtype: "combo",
                fieldLabel: "Full Key",
                valueField: "fullkey",
                hideTrigger:true,
                typeAhead:false,                              
//                queryMode:"local",
                minChars:3,
                action:"comboChange",
	            displayField: "fullkey"
            }            
        ];

        this.dockedItems = [
            {
                dock: "bottom", 
                xtype: "toolbar", 
                items: [
                "->",
                {
                    xtype: "button",
                    text: "Search",
                    scope: this,
                    action: "search"
                },
                "-",
                {
                    xtype: "button",
                    text: "Clear",
                    scope: this,
                    action: "clear"
                }
            ]
            }
        ];

        this.callParent(arguments);
    }
});

Ext.define('eRecon_web.view.common.ButtonGridColumn',
{
	extend : 'Ext.grid.column.Column',
	alias : 'widget.buttonGridColumn',
	header : true,

	constructor : function() {
		this.addEvents(
		'buttonclick');
		this.callParent(arguments);
	},

	// Process and refire events routed from the GridView's
	// processEvent method.
	processEvent : function(type, view, cell, recordIndex,
			cellIndex, e) {
		if (type == 'mousedown'
				|| (type == 'keydown' && (e.getKey() == e.ENTER || e
						.getKey() == e.SPACE))) {
			var record = view.panel.store.getAt(recordIndex);
			
			var allow = false;
			if(record.get('status') === 'U') {
				allow = true;
			}

			if (allow) {
				this.fireEvent('buttonclick', this,	recordIndex, record, view);
			}
			return false;
		} else {
			return this.callParent(arguments);
		}
	}/*,

	renderer : function(value, metaData, record) {
		var cssPrefix = Ext.baseCSSPrefix;
		var cls = cssPrefix + ' iconRunProfile';
		
		if (record.get("status") === 'N') {
			return '<div class="' + cls + '">&#160;</div>';
		} 
	}*/
});

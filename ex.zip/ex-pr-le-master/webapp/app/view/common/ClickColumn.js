/**
* @author : ss58446 - Sunil Murthy
* @Created Date : Mar 29, 2013 
*/
Ext.define('eRecon_web.view.common.ClickColumn',
{
	extend : 'Ext.grid.column.Column',
	alias : 'widget.clickColumn',
	header : true,

	constructor : function() {
		this.addEvents('clickevent');
		this.callParent(arguments);
	},

	// Process and refire events routed from the GridView's
	// processEvent method.
	processEvent : function(type, view, cell, recordIndex,
			cellIndex, e) {
		if (type == 'mousedown'
				|| (type == 'keydown' && (e.getKey() == e.ENTER || e
						.getKey() == e.SPACE))) {
			var record = view.panel.store.getAt(recordIndex);
			this.fireEvent('clickevent', this, record, recordIndex, cellIndex, e);
			return false;
		} else {
			return this.callParent(arguments);
		}
	},

	renderer : function(value, metaData, record) {
		return "<p class='gridLinkCls'>" + value + "</p>";
	}
});

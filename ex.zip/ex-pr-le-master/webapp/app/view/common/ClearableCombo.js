Ext.define("eRecon_web.view.common.ClearableCombo",{
  extend: 'Ext.form.field.ComboBox',
  alias: 'widget.clearablecombobox',
	
  trigger2Cls: 'clearTrigger',
		
  initComponent: function() {	  
	this.callParent(arguments);
   },
   
   onTrigger2Click: function(event) {	    
     this.clearValue();
   }
	
});

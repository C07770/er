Ext.define("eRecon_web.view.common.CustomDialog", {
    extend: "Ext.window.Window",
    alias: "widget.custom_dialog",
    modal: true,
    width: 910,
    height: 550,
    autoScroll: true,
    resizable: true,
    
    initComponent: function (config) {
        this.callParent(config);
    }
});

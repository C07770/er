Ext.define("eRecon_web.view.common.AOCustomDialog", {
    extend: "Ext.window.Window",
    alias: "widget.aocustom_dialog",
    modal: true,
    width: 885,
    height: 550,
    autoScroll:true,
    
    initComponent: function (config) {
        this.callParent(config);
    }
});

Ext.define("eRecon_web.view.OpenCloseCycle.OpenCloseCycle", {
    extend: "Ext.grid.Panel",
    alias: "widget.OpenCloseCycle",    
    autoScroll: true,
    forceFit: true,      
    store: "eRecon_web.store.OpenCloseCycleStore",
    enableColumnMove: false,    
    border: false,
    viewConfig: {
        emptyText: "No details available."},
                

    initComponent: function () {
        var me = this;
        me.stateful = false;
        
        //me.store = Ext.create("eRecon_web.store.OpenCloseCycleStore", {});
                                   
        me.columns = [
                      
            {	header: "RECONPERIOD", 
            	dataIndex: "reconperiod"            	
            }
            ,
            {	header: "BUSINESSUNIT", 
            	dataIndex: "businessunit"
            }
            ,
            {	header: "OPEN", 
            	dataIndex: "open"
            },
            {	header: "OPENACCOUNTS", 
            	dataIndex: "openaccounts"
            },
            {	header: "AMTOPENACCOUNTS", 
            	dataIndex: "amtopenaccounts"
            },
            {	header: "PENDINGACCOUNTS", 
            	dataIndex: "pendingaccounts"
            },
            {	header: "AMTPENDINGACCOUNTS", 
            	dataIndex: "amtpendingaccounts"
            },
            {	header: "REDACCOUNTS", 
            	dataIndex: "redaccounts"
            },
            {	header: "AMTREDACCOUNTS", 
            	dataIndex: "amtredaccounts"
            },
            {	header: "GREENACCOUNTS", 
            	dataIndex: "greenaccounts"
            },
            {	header: "AMTGREENACCOUNTS", 
            	dataIndex: "amtgreenaccounts"
            },
            {	header: "SUBMITTEDACCOUNTS", 
            	dataIndex: "submittedaccounts"
            },
            {	header: "AMTSUBMITTEDACCOUNTS", 
            	dataIndex: "amtsubmittedaccounts"
            },
            {	header: "UNSUBMITTEDACCOUNTS", 
            	dataIndex: "unsubmittedaccounts"
            },
            {	header: "AMTUNSUBMITTEDACCOUNTS", 
            	dataIndex: "amtunsubmittedaccounts"
            },
            {	header: "AGINGTYPE", 
            	dataIndex: "aging_type"
            }
                                          
        ];                 
        
        me.dockedItems = [
                          {
                        	  xtype: "pagingtoolbar",
                              dock: "bottom",
                              displayInfo: true,
                              store: me.store
                          }
                          ]

        
        me.callParent(arguments);
        }
    });

Ext.define("eRecon_web.view.OpenCloseCycle.OpenCloseCycleSearch", {
    extend: "Ext.form.Panel",
    alias: "widget.OpenCloseCycleSearch",
    defaults: {labelAlign: "side"},
    bodyPadding: 10,
    autoScroll:true,

    initComponent: function () {
	    	 
        this.items = [            
            {
                name: "reconPeriod",
                itemId: "reconPeriod",
                xtype: "textfield",
                fieldLabel: "RECON PERIOD"
            },
            {
                name: "businessUnit",
                itemId: "businessUnit",
                xtype: "textfield",
                fieldLabel: "BUSINESS UNIT"
            },
            {
                name: "openAccounts",
                itemId: "openAccounts",
                xtype: "numberfield",
                width:235,
                fieldLabel: "OPEN ACCOUNTS"
            },
            {
                name: "pendingAccounts",
                itemId: "pendingAccounts",
                xtype: "numberfield",
                width:235,
                fieldLabel: "PENDING ACCOUNTS"
            },
            {
                name: "redAccounts",
                itemId: "redAccounts",
                xtype: "numberfield",
                width:235,
                fieldLabel: "RED ACCOUNTS"
            },
            {
                name: "greenAccounts",
                itemId: "greenAccounts",
                xtype: "numberfield",
                width:235,
                fieldLabel: "GREEN ACCOUNTS"
            },
            {
                name: "submittedAccounts",
                itemId: "submittedAccounts",
                xtype: "numberfield",
                width:235,
                fieldLabel: "SUBMITTED ACCOUNTS"
            },
            {
                name: "unsubmittedAccounts",
                itemId: "unsubmittedAccounts",
                xtype: "numberfield",
                width:235,
                fieldLabel: "UNSUBMITTED ACCOUNTS"
            },
            {
                name: "agingType",
                itemId: "agingType",
                xtype: "textfield",
                fieldLabel: "AGING TYPE"
            },
            {
                name: "open",
                itemId: "open",
                xtype: "textfield",
                fieldLabel: "OPEN"
            },
            {
                name: "amtOpen",
                itemId: "amtOpen",
                xtype: "numberfield",
                width:235,
                fieldLabel: "AMTOPEN ACCOUNTS"
            },
            {
                name: "amtPending",
                itemId: "amtPending",
                xtype: "numberfield",
                width:235,
                fieldLabel: "AMTPENDING ACCOUNTS"
            },
            {
                name: "amtRed",
                itemId: "amtRed",
                xtype: "numberfield",
                width:235,
                fieldLabel: "AMTREDACCOUNTS"
            },
            {
                name: "amtGreen",
                itemId: "amtGreen",
                xtype: "numberfield",
                width:235,
                fieldLabel: "AMTGREEN ACCOUNTS"
            },
            {
                name: "amtSubmitted",
                itemId: "amtSubmitted",
                xtype: "numberfield",
                width:235,
                fieldLabel: "AMTSUBMITTED ACCOUNTS"
            },
            {
                name: "amtUnsubmitted",
                itemId: "amtUnsubmitted",
                xtype: "numberfield",
                width:235,
                fieldLabel: "AMTUNSUBMITTED ACCOUNTS"
            }
            
                       
        ];

        this.dockedItems = [
            {
                dock: "bottom", 
                xtype: "toolbar",
                items: ["->",
                {
                    xtype: "button",
                    text: "Search",
                    scope: this,
                    action: "search"
                },
                "-",
                {
                	xtype: "button",
                    text: "Clear",
                    scope: this,
                    action: "clear"
                }
            ]
            }
        ];

        this.callParent(arguments);
    }
});

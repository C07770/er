Ext.define("eRecon_web.view.OpenCloseCycle.OpenCloseCycleContainer",{
	extend: "Ext.container.Container", 
	alias: "widget.openclosecyclecontainer",   
    layout: "border",
    
 initComponent: function (config) {
    	this.openCloseGrid = Ext.create("eRecon_web.view.OpenCloseCycle.OpenCloseCycle", {
    		title: "Open Close Cycle Statistics",
            region: "center",
            flex: 4
            });

    	this.searchCycle = Ext.create("eRecon_web.view.OpenCloseCycle.OpenCloseCycleSearch", {
            title: "Search",
            region: "west",
            split: true,
            flex: 1,
            collapsible: true,
            animCollapse: false,
            collapsed: true,
            autoScroll:true

        });
    	
    	this.items = [    	              
    	              this.openCloseGrid,
    	              this.searchCycle
    	             ];
    	
    	this.listeners =
        {
        		scope: this,
                "activate": function () {  
                	
                	//this.openCloseGrid.getStore().load();
                	
                	var openCloseGrid = this.openCloseGrid.getStore();
                	openCloseGrid.directOptions = {};
                	openCloseGrid.getProxy().extraParams = {
    	                0: null,
    	                1: null,
    	                2: null,
    	                3: null,
    	                4: null,
    	                5: null,
    	                6: null,
    	                7: null,
    	                8: null,
    	                9: null,
    	                10: null,
    	                11: null,
    	                12: null,
    	                13: null,
    	                14: null,
    	                15: null,
    	                16: null
    	            };
                	openCloseGrid.load({
    	                callback: function (records, operation, success) {
    	                }
    	            });
              }  
        };
    	
    	this.callParent(config);
	}
	
});

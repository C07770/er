Ext.define("eRecon_web.view.BroadcastMessage.BroadcastMessage", {
    extend: "Ext.form.Panel",
    id:"broadcastPanel",
    alias: "widget.BroadcastMessage",  
    items: [{
                 name: "broadcastForm",
                 itemId: "broadcastForm",
                 height: 500,
                 xtype: "form",
                 html:"test html of pabel"
             } ], 

    initComponent: function (config) {
        this.callParent(arguments);
    }
});

Ext.define("eRecon_web.view.archiveBSD.ReconPeriodForm", {
    extend: "Ext.form.Panel",
    alias: "widget.archive_reconform",
    defaults: {labelAlign: "side"},
    bodyPadding: 10,
    height:50,

    initComponent: function () {
	
    	this.reconPeriodStore = Ext.create("eRecon_web.store.ArchiveBSDReconStore", {
            // autoLoad: true
        });
    	
        this.items = [
            {
            
              name: "reconperiod",
	          itemId: "reconperiod-combo",
	          xtype: "combo",
	          fieldLabel: "Select your Recon Period",
	          valueField: "key",
	          displayField: "value",
	          store: this.reconPeriodStore,
	          editable: false,
	          action:"select"
				  
			}
        ];
        
        this.dockedItems = [{
                           	dock: "top", 
                           	xtype: "toolbar", 
                           	items: [{
                            	xtype: "button",
                            	tooltip: "Run",
                            	text:"Run",
                            	icon:"/static/assets/famfamfam/icons/resultset_next.png",
                            	scope:this,
                            	action:"submit"
                           	}]
                          }];
        
        this.callParent(arguments);
}
   
});

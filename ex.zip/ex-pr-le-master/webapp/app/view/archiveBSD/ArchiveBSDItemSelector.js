Ext.define("eRecon_web.view.archiveBSD.ArchiveBSDItemSelector", {
    extend: "Ext.ux.form.ItemSelector",
    alias: "widget.archiveBSDitemselector",
    buttons: ['top', 'up', 'add','addall','remove','removeall','down', 'bottom'],
    
	buttonsText: {
	        top: "Move to Top",
	        up: "Move Up",
	        add: "Add to Selected",
	        remove: "Remove from Selected",
	        down: "Move Down",
	        bottom: "Move to Bottom",
	        addall:"Add all to Selected",
	        removeall:"Remove all from Selected"
	    },
    
    onAddBtnClick : function(){
      var me = this,
      selected = me.getSelections(me.fromField.boundList);
      me.moveRec(true, selected);
      me.toField.boundList.getSelectionModel().select(selected);
      this.fireEvent("insertdeleteArchiveBSDRecord",'add');
},
	onRemoveBtnClick : function(){
		var me = this,
	    selected = me.getSelections(me.toField.boundList);
	
		me.moveRec(false, selected);
		me.fromField.boundList.getSelectionModel().select(selected);
		this.fireEvent("insertdeleteArchiveBSDRecord",'remove');
},
	onAddallBtnClick : function(){
		 var me= this,
         selected = me.fromField.boundList.store.data.items;
         this.fireEvent("insertdeleteArchiveBSDRecord",'addall');
	    // me.moveRec(true, selected);
	     
},
	onRemoveallBtnClick : function(){
		var me= this,
        selected = me.toField.boundList.store.data.items
        this.fireEvent("insertdeleteArchiveBSDRecord",'removeall');
		//me.moveRec(false, selected);
}
	
});

Ext.define("eRecon_web.view.archiveBSD.ArchiveBSDContainer", {
    extend: "Ext.container.Container", alias: "widget.archiveBSD_container",
    requires: ["eRecon_web.view.archiveBSD.ReconPeriodForm","eRecon_web.view.archiveBSD.ArchiveBSDAssignForm"],
    layout: "border",
    defaults: {
        collapsible: true,
        split: true
    },
    initComponent: function (config) {

        this.reconPeriodForm = Ext.create("eRecon_web.view.archiveBSD.ReconPeriodForm", {
            region: "north",
            split: true,
            title:"Archive BSD",
            flex: 1,
            listeners: {
                scope: this
            }
        });
        
        this.assignSelector = Ext.create("eRecon_web.view.archiveBSD.ArchiveBSDAssignForm", {
        	region: "center",
        	flex: 5
        });
        
        this.items = [
            this.reconPeriodForm,
            this.assignSelector
        ];

        this.callParent(config);
    }
});

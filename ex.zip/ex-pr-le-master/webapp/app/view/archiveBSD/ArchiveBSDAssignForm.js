Ext.define("eRecon_web.view.archiveBSD.ArchiveBSDAssignForm", {
    extend: "Ext.form.Panel",
    alias: "widget.archiveBSD_assignForm",
    defaults: {labelAlign: "side"},
    store: "eRecon_web.store.ArchiveAssignedUnAssignedStore",
    requires: ['eRecon_web.view.archiveBSD.ArchiveBSDItemSelector'],
    bodyPadding: 10,
    height:50,

    initComponent: function () {
    	
        this.assignunassignstore = Ext.create("eRecon_web.store.ArchiveAssignedUnAssignedStore", {
            // autoLoad: true
        });

        this.items = [
            {
                name: "assignSelector",
                itemId: "assignSelector",
                xtype: "archiveBSDitemselector",
                store:this.assignunassignstore,
                valueField:'businessUnit',
                displayField:'businessUnit',
                changeTag:'itemselect',
                buttons:['addall','add','remove','removeall'],
                overflowY:'scroll',
                height:450,
                listTitle:'Selected',
                imagePath: 'ux/images/',
                fromTitle: 'BSD',
                toTitle:'ArchiveBSD'
            }
        ];
        this.callParent(arguments);
}
   
});

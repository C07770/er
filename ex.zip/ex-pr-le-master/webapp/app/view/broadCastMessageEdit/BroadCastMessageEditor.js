Ext.define("eRecon_web.view.broadCastMessageEdit.BroadCastMessageEditor", {
    extend: "Ext.form.Panel",
    alias: "widget.broadcastmessageeditform",
    id: "broadcastmessageeditform",
    title:"Broadcast Message Edit",
    defaults: {labelAlign: "side"},
    bodyPadding: 10,

    initComponent: function () {
    	this.dockedItems = [ {
    		dock : "top",
    		xtype : "toolbar",
    		width:600,
    		items : [
    		         {
    		        	xtype: 'button',
    					text: 'Save',
    					icon: "/static/assets/famfamfam/icons/disk.png",       
    					action: 'saveButton'
    		 		},
    		 		{
    		        	xtype: 'button',
    					text: 'Cancel',
    					iconCls: 'iconCancel',
    					action: 'cancelButton'
    		 		}]
    	} ];
        this.items = [
            {
        	 name: "broadmessageedit",
             itemId: "broadmessageedit-form",
             xtype: "htmleditor",
             height:600,
             width:600
            }
        ];
        
        this.callParent(arguments);
}
   
});

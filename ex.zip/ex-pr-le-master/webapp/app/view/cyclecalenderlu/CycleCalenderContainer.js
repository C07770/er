Ext.define("eRecon_web.view.cyclecalenderlu.CycleCalenderContainer",{
	extend: "Ext.container.Container", 
	alias: "widget.secadmin_cyclecalendercontainer",   
    layout: "border",
    
 initComponent: function (config) {
    	this.cyclecalendergrid = Ext.create("eRecon_web.view.cyclecalenderlu.CycleCalenderGrid", {
    		title: "Cycle Calendar Lu",
            region: "center",
            flex: 4
            });

    	this.cyclecalendersearch = Ext.create("eRecon_web.view.cyclecalenderlu.CycleCalenderSearch", {
            title: "Insert/Search Cycle Calendar Lu",
            region: "west",
            split: true,
            flex: 1.4,
            collapsible: true,
            animCollapse: false

        });
    	
    	this.items = [    	              
    	              this.cyclecalendergrid,
    	              this.cyclecalendersearch
    	             ];
    	
    	this.listeners =
        {
        		scope: this,
                "activate": function () {              
                	var cyclecalenderStore = this.cyclecalendergrid.getStore();
                	cyclecalenderStore.directOptions = {};
                	cyclecalenderStore.getProxy().extraParams = {
    	                0: null
    	            };
    	            cyclecalenderStore.load({
    	                callback: function (records, operation, success) {
    	                }
    	            });
              }  
        };
    	             
    	
    	this.callParent(config);
	}
	
});

Ext.define("eRecon_web.view.cyclecalenderlu.CycleCalenderSearch", {
    extend: "Ext.form.Panel",
    alias: "widget.secadmin_cyclecalendersearch",
    defaults: {labelAlign: "side"},
    bodyPadding: 10,

    initComponent: function () {
	
	    this.activeStore = Ext.create('Ext.data.Store', {
            fields: ['ActiveName', 'ActiveValue'],
            data: [
            {
                "ActiveName": "<--Select-->",
                "ActiveValue": ""
            },       
            {
                "ActiveName": "Yes",
                "ActiveValue": "Y"
            }, {
                "ActiveName": "No",
                "ActiveValue": "N"
            }
            ]
        	});	
	    var store = Ext.create("Ext.data.Store", {
	      fields:["key", "value","flag"],
	      proxy:{
	      	type:"direct",                              
	        directFn:eRecon_web.direct.action.CycleCalenderLuService.getReconPeriod
	      }
	    });

        this.items = [            
            {
            	name: "reconPeriod",
		        itemId: "reconPeriod-text",
		        xtype:"combo",
		        fieldLabel: 'Recon Period <span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>',
		       // fieldLabel: 'Recon Period',
		        store:store,
		        typeAhead:true,
		        queryMode: 'local',
				valueField: "key",
				displayField: "key",
				tpl: Ext.create('Ext.XTemplate',
				'<tpl for=".">',
				'<div class="x-boundlist-item">',
				  '<div style="{[this.getClass(values)]}">{key}</div>',
				  '</div>',
				 '</tpl>',
				    {
				        getClass: function (rec) {
				            return rec.flag == 'TRUE' ? "color: red;":''
				        }
				    }
				),
				listeners:{
				    beforerender:function(cbo_) {        		
					  cbo_.getStore().load();
					  
				  }
				  
				}
            	
            },
            {
                name: "openDate",
                itemId: "openDate-date",
                xtype: "datefield",
                fieldLabel: "Open Date"
            },
            {
                name: "closeDate",
                itemId: "softDate-date",
                xtype: "datefield",
                fieldLabel: "Soft Date"
            }
            ,
            {
                name: "hardDate",
                itemId: "hardDate-date",
                xtype: "datefield",
                fieldLabel: "Hard Date"
            },
			{
				xtype: 'combobox',
				searchId: 'cmbAgingOverride',
				name: 'active_flag',
				typeAhead:true,
				fieldLabel:'Active Flag',
			    displayField: 'ActiveName',
			    valueField: 'ActiveValue',
	            store: this.activeStore,
	            queryMode:'local'
			}
        ];

        this.dockedItems = [
            {
                dock: "top", 
                xtype: "toolbar",
                items: [
                {
                    xtype: "button",
                    text: "Insert",
                    iconCls: 'iconAdd',
                    scope: this,
                    action: "cycleCalender-add"
                },
                "-"
                ,
                {
                    xtype: "button",
                    text: "Search",
                    iconCls: 'iconMagnifier',
                    scope: this,
                    action: "cycleCalender-search"
                },
                "-",
                {
                	xtype: "button",
                    text: "Clear",
                    iconCls: 'iconTableDelete',
                    scope: this,
                    action: "cycleCalender-clear"
                }
            ]
            },{
				dock: "bottom", 
				xtype: "toolbar",
				items: [
					{
					    xtype: "label",
					    text: "* Indicates Mandatory fields while inserting a new record"
					}
				]
	        }
        ];

        this.callParent(arguments);
    }
});

Ext.define("eRecon_web.view.CentralizedSiteMap.CentralizedSiteMapContainer",{
	extend: "Ext.container.Container", 
	alias: "widget.CentralizedSiteMap_Container",   
    layout: "border",
    
 initComponent: function (config) {

    	this.CentralizedSiteMapGrid = Ext.create("eRecon_web.view.CentralizedSiteMap.CentralizedSiteMapGrid", {
          title: "BSS Metrics",
          region: "center"
        	//  ,
    	// collapsible: true,          
       // collapsed: false 
        });
    	this.CentralizedSiteMapSearch = Ext.create("eRecon_web.view.CentralizedSiteMap.CentralizedSiteMapSearch", {
    	  title: "BSS Metrics Search",
          region: "west",
          collapsible: true,          
          collapsed: false            
        });
        this.CentralizedSiteMapUploadGrid = Ext.create("eRecon_web.view.CentralizedSiteMap.CentralizedSiteMapUploadContainer", {
      	  title: "BSS Metrics File Upload History",
            region: "east",
            collapsible: true,          
            collapsed: true            
          });
    	
    	this.items = [    	              
          this.CentralizedSiteMapGrid,
          this.CentralizedSiteMapSearch,
          this.CentralizedSiteMapUploadGrid
        ];
    	
    	this.listeners =
          {
            scope: this,
            "activate": function () {                        	
//              var CentralizedSiteMapGridStore = this.CentralizedSiteMapGrid.getStore();
//              CentralizedSiteMapGridStore.directOptions = {};
//              CentralizedSiteMapGridStore.getProxy().extraParams = {
//    	        0: null
//    	      };
//              CentralizedSiteMapGridStore.load({
//    	        callback: function (records, operation, success) {
//    	      }
//    	    });
           }  
        };
    	
    	this.callParent(config);
	}
	
});

Ext.define("eRecon_web.view.CentralizedSiteMap.CentralizedSiteMapGrid", {
    extend: "Ext.grid.Panel",
    alias: "widget.CentralizedSiteMap_Grid",    
    autoScroll: true,       
    columnLines: true,
    multiSelect:true,
    store: "eRecon_web.store.CentralizedSiteMapStore",
    enableColumnMove: true,    
    border: false,
    
    viewConfig: {
      emptyText: "No details available."
    },
                        
    initComponent: function () {
        var me = this;
        me.stateful = false;
    
this.interAuditLogStore = Ext.create('Ext.data.Store', {
            fields: ['ActiveName', 'ActiveValue'],
			data: [
			{
			    "ActiveName": "<--Select-->",
			    "ActiveValue": ""
			}, 
			{
			    "ActiveName": "Yes",
			    "ActiveValue": "Yes"
			}, {
			    "ActiveName": "No",
			    "ActiveValue": "No"
			}
			]
        	});

       this.centralizedsiteStore = Ext.create("eRecon_web.store.CentralizedSiteTypeStore", {});
       this.proposeSiteStore = Ext.create("eRecon_web.store.ProposedSiteStore",{});
       this.StrategicPartnerStore= Ext.create("eRecon_web.store.StrategicPartnerStore",{});
       this.SodTypeStore= Ext.create("eRecon_web.store.SodTypeStore",{});
       this.McaRatingStore= Ext.create("eRecon_web.store.McaRatingStore",{});
       this.AccReiewRatingStore= Ext.create("eRecon_web.store.AccntReviewRatingStore",{});
       
function getRoleBasedAccess(columnNumber){
	var restrictedColumnsForDashboardUser=[0,1,2,3,4,5,10,11,14,15,23,24,25,33];
	 if (columnNumber==2){
		 if(Ext.util.Cookies.get('eRecon_support')=="true")
		return false;
		else
			return true;
	}	
	else if(Ext.util.Cookies.get('Dashboard_Viewer')=="true" ||Ext.util.Cookies.get('Governance_Dashboard_Viewer')=="true"){
			return true;
		}else if(Ext.util.Cookies.get('Dashboard_User')=="true"){
			if(restrictedColumnsForDashboardUser.indexOf(columnNumber)>0)
		return true;
		else
			return false;
		}else if((Ext.util.Cookies.get('Governance_Dashboard_User')=="true")){
		return false;
		}
		else{
			return true;
		}
}       

        function setColor(value, meta, record,rowIndex,colIndex){
        	
     	  if(record.get('flag')=="FALSE"|| getRoleBasedAccess(colIndex)){
     		  meta.tdAttr = 'style="background-color: #ececec ;"';
     	  }else if(colIndex==33){
     		 meta.tdAttr = 'data-qtip="' + value + '"';
     	  }
     	  
     	  if(Ext.typeOf(value)=='date')return Ext.Date.format(value,  "m/d/Y");
     	  
     	  return value;
       };
       me.plugins= [
         Ext.create('Ext.grid.plugin.CellEditing', {
           clicksToEdit: 1,
           allowBlank:false,
	         listeners: {
	             beforeedit: function(e, editor){
	                 if (editor.record.get('flag') == "FALSE"||getRoleBasedAccess(editor.colIdx))
	                     return false;
	             }
	         }
         })
        ];
        
        var rowEditing = Ext.create('Ext.grid.plugin.RowEditing', {
            clicksToMoveEditor: 1,
            autoCancel: false
        });
                                                    
        me.dockedItems = [
             {
              	dock: "top", 
              	xtype: "toolbar", 
              	items: [
              	   {
                   	xtype: "button",
                   	tooltip: "Save",
                   	text:"Save",
                   	disabled : true,
                   	icon: "/static/assets/famfamfam/icons/disk.png",                   	
                   	action:"save",
                   	scope:this
                   },
                   "-"
                   ,
                   {
                   	xtype: "button",
                   	tooltip: "Export to Excel",
                   	text:"Export to Excel",
                   	icon: "/static/assets/famfamfam/icons/page_white_excel.png",                   
                    action:"CentralizedSiteMapexcel"
                   },
                   "-",,
                   {
                	   xtype:'form',
                	   itemId:'uploadformpanel',
                	  // hidden : true,
                	   layout : 'hbox',
                	   align:'',
                	   items:[
                	          {
					                xtype: "filefield",
					                name: "uploadfile",
					//                fieldLabel: "File",
					                buttonText: "Browse...",
					                itemId: "feedfileupload-file",
					                width: 250,
					                buttonConfig :{
									iconCls :'browseIcon'
								},
					                labelWidth: 150,
					                minWidth: 150
					          },
					          {
					                xtype: "button",
					                text: "Upload",
					                margin: "0 0 0 20",
					                scope: this,
					                iconCls :'uploadIcon',
					                action:'uploadfile',
					                handler: function () {
					                	this.fireEvent("feedsuploadfile", {clientApp: this.clientApp, cmp: this});
					            	}
					       
					          }]
                   },
                   {xtype:"button", text:"Sync",hidden:true,itemId:"bssMetricsSync"} ,
                   {
                	   xtype: 'hiddenfield',
                	   width: 180
                   }
                   /*,
                   {
                   	xtype: "button",
                   	tooltip: "Delete",
                   	text:"Delete",
                    hidden:true,
                    iconCls: 'iconDelete',
                   	handler : function() {
                   		var i;
                   		var selModel = this.up('grid').getSelectionModel();
                   		var selRec = selModel.getSelection();
                   		for(i=0;i<selRec.length;i++)
                   			{
                   				selRec[i].data.action = "DELETE";
                   				this.up('grid').store.remove(selRec[i]);
                   			}
                   	}
                   }*/
                   ]
             },                  
             {
                xtype: "pagingtoolbar",
                dock: "bottom",
                displayInfo: true,
                store: me.store,
                plugins: [Ext.create("eRecon_web.plugins.PageSize")]

            }
          ];
          
        
          me.columns = {
          defaults:{align:"center"},
          items:[
	        {
	        	header: "Recon Period",
	        	dataIndex: "reconPeriod",
	        	width:90,
		        renderer:function setColor(value, meta, record){
	           	  meta.tdAttr = 'style="background-color: #ececec;"';
	           	  return value;
	            }
	        },
            {  
              header: "Fullkey", 
              dataIndex: "fullkey",
              width:240,
              renderer:function setColor(value, meta, record){
            	  var tpl = new Ext.Template('<div style="white-space:normal; word-wrap: break-word;">{value}</div>');
             	  meta.tdAttr = 'style="background-color: #ececec;"';
					return tpl.apply(
					{
					    value: value
					});
              }
            },
            {	
     	   header: "SSID GL", 
 	       dataIndex: "ssidGL",
            width:90,
            editor:{
         		xtype: 'textfield',
               validator : this.textFieldValidator
         	 },
         	renderer:setColor
         },
            {
			  header: "Strategic Site", 
	          dataIndex: "centralizedsite",	   
              width:140,
	          editor: {
                xtype: 'combo',
                store: this.centralizedsiteStore,
                editable: false,
	            valueField: "value",
	            displayField: "value",
	            typeAhead: true,
	            lazyRender:true,
	            triggerAction: 'all'
              },
              renderer:setColor
            },
            {
         	   header:"Proposed Sites",
 	           dataIndex: "nonCentralizedSiteFullkey",
 	           width:90,
         	   editor: {
 	                xtype: 'combo',
 	                store:  this.proposeSiteStore,
 	                editable: false,
 		            valueField: "key",
 		            displayField: "value"
 	              },
 	              renderer: function(value, meta, record,rowIndex,colIndex){
 	            	  if(record.get('flag')=="FALSE"|| getRoleBasedAccess(colIndex)){
 	             		  meta.tdAttr = 'style="background-color: #ececec ;"';
 	             	  }else if(colIndex==17){
 	             		 meta.tdAttr = 'data-qtip="' + value + '"';
 	             	  }
 	            	   var psStore=Ext.data.StoreManager.lookup('proposedSiteStore');
 	                    var index = psStore.findExact('key',value); 
 	                    if (index != -1){
 	                       var rs = psStore.getAt(index).data; 
 	                        return rs.value; 
 	                    }else{
 	                    	return value;
 	                    }
 	                    }
 		       // renderer:setColor
            },
            {
         	   header :"Strategic Partner",
         	   dataIndex: "strategicPartner",
         	   width:90,
         	   editor:{
 	        	   xtype: 'combo',
 	               store: this.StrategicPartnerStore,
 	               editable: false,
 		           valueField: "key",
 		           displayField: "value"
            		},
            		renderer:setColor
            		
            },
            {
              header: "Internal Audit Flag", 
        	  width:110,
              dataIndex: "intAudFlg",
        	  editor: {
                xtype: 'combo',
                store: this.interAuditLogStore,
                valueField: "ActiveName",
                editable: false,
                displayField: "ActiveName"
            	},
              renderer:setColor
            }
           ,
           {	
     	   header: "Internal Audit Report Number", 
 	       dataIndex: "intAuditRepNum",
            width:90,
           editor:{
     		xtype: 'textfield',
           validator : this.textFieldValidator
     	 }
       ,
     	 renderer:setColor
         },
           {	
        	  header: "External Audit Flag", 
    	      dataIndex: "extAudFlg",
              width:110,
              editor: {
               xtype: 'combo',
              store: this.interAuditLogStore,
               valueField: "ActiveName",
               editable: false,
               displayField: "ActiveName"
           		},
           	  renderer:setColor
            }
           ,
           {	
     	   header: "External Audit Report Number", 
 	       dataIndex: "extAuditRepNum",
            width:90,
           editor:{
     		xtype: 'textfield',
           validator : this.textFieldValidator
     	 }
       ,
     	 renderer:setColor
         },
           { 	
        	  header: "Account Review Flag", 
    	      dataIndex: "acctRevFlg",
              width:110,
	          editor: {
	               xtype: 'combo',
	               store: this.interAuditLogStore,
	               valueField: "ActiveName",
	               editable: false,
	               displayField: "ActiveName"
	           },
	           renderer:setColor
            }
           ,{	
        	  header: "Account Review Rating", 
    	      dataIndex: "acctRevRating",
              width:120,
	          editor: {
	               xtype: 'combo',
	               store: this.AccReiewRatingStore,
	               valueField: "key",
	               editable: false,
	               displayField: "value"
	           },
	           renderer:setColor
            }
           ,{	
        	  header: "MCA Flag", 
    	      dataIndex: "mcaFlg",
              width:90,
	          editor: {
	               xtype: 'combo',
	               store: this.interAuditLogStore,
	               valueField: "ActiveName",
	               editable: false,
	               displayField: "ActiveName"
	           },
	           renderer:setColor
            }
           ,{	
        	  header: "MCA Rating", 
    	      dataIndex: "mcaRating",
              width:120,
	          editor: {
	               xtype: 'combo',
	               store: this.McaRatingStore,
	               valueField: "key",
	               editable: false,
	               displayField: "value"
	           },
	           renderer:setColor
            }
           ,{	
        	  header: "SOD Flag", 
    	      dataIndex: "confEnt",
              width:110,
	          editor: {
	               xtype: 'combo',
	               store: this.interAuditLogStore,
	               valueField: "ActiveName",
	               editable: false,
	               displayField: "ActiveName"
	           },
	           renderer:setColor
            }
           ,{	
        	  header: "SOD Type", 
    	      dataIndex: "sodType",
              width:90,
	          editor: {
	               xtype: 'combo',
	               store: this.SodTypeStore,
	               valueField: "key",
	               editable: false,
	               displayField: "value"
	           },
	           renderer:setColor
            }
           ,{	
        	   header: "CAP Flag", 
    	       dataIndex: "capFlg",
               width:90,
	           editor: {
	               xtype: 'combo',
	               store: this.interAuditLogStore,
	               valueField: "ActiveName",
	               editable: false,
	               displayField: "ActiveName"
	           },
	           renderer:setColor
            }
           ,{	
        	   header: "CAP Issue Number", 
    	       dataIndex: "issueNum",
               width:90,
              editor:{
        		xtype: 'textfield',
              validator : this.textFieldValidator
        	 }
          ,
        	 renderer:setColor
            },
           {	 
        	   header: "CAP Number", 
    	       dataIndex: "capNum",
               width:90,
              editor:{
        		xtype: 'textfield',
              validator : this.textFieldValidator
        	 }
           ,
        	 renderer:setColor
           },
          {	
    	   header: "CAP Description", 
	       dataIndex: "capDesc",
           width:90,
          editor:{
    		xtype: 'textfield',
          validator : this.textFieldValidator
    	 }
      ,
    	 renderer:setColor
        } ,{	
 	   header: "CAP Initial TRD", 
	       dataIndex: "initialTrd",
        width:90
        ,xtype: "datecolumn",
    	format : "m/d/Y",
        editor:{
    		xtype: 'datefield',
    		format : "m/d/Y"
    	}
   , renderer:setColor
     } ,{	
	   header: "CAP Revised TRD", 
     dataIndex: "revisedTrd",
     width:90,
     xtype: "datecolumn",
 	format : "m/d/Y",
     editor:{
 		xtype: 'datefield',
 		format : "m/d/Y"
 	}
, renderer:setColor
  } ,{	
  header: "CAP Final TRD", 
  dataIndex: "finalTrd",
  width:90,
  xtype: "datecolumn",
	format : "m/d/Y",
  editor:{
		xtype: 'datefield',
		format : "m/d/Y"
	}
,renderer:setColor
},
{	
        	  header: "Dormant Account Flag", 
    	      dataIndex: "dormAcctFlg",
    	      width:120,
	          editor: {
	               xtype: 'combo',
	               store: this.interAuditLogStore,
	               valueField: "ActiveName",
	               editable: false,
	               displayField: "ActiveName"
	           },
	           renderer:setColor
            }
 ,{	
        	   header: "Abnormal Balance Flag", 
    	       dataIndex: "abnormalBalancFlag",
               width:90,
	           editor: {//need to set it to correct store
	               xtype: 'combo',
	               store: this.interAuditLogStore,
	               valueField: "ActiveName",
	               editable: false,
	               displayField: "ActiveName"
	           },
	           renderer:setColor
            }
,{	
        	   header: "ZBA Aging", 
    	       dataIndex: "zbaAging",
               width:90,
	           editor: {//need to set it to correct store
	               xtype: 'combo',
	               store: this.interAuditLogStore,
	               valueField: "ActiveName",
	               editable: false,
	               displayField: "ActiveName"
	           },
	           renderer:setColor
            }

,
          {	
    	   header: "Red - Part of baseline", 
	       dataIndex: "redPartBaseLine",
           width:90,
          editor: {
              xtype: 'combo',
              store: this.interAuditLogStore,
              valueField: "ActiveName",
              editable: false,
              displayField: "ActiveName"
          }
      ,
    	 renderer:setColor
        }
          ,
          {	
    	   header: "Red - Baseline Topline Reason", 
	       dataIndex: "redBaseLineTop",
           width:90,
          editor:{
    		xtype: 'textfield',
          validator : this.textFieldValidator
    	 }
      ,
    	 renderer:setColor
        }
          ,
          {	
    	   header: "Red - Reportable Red Aging", 
	       dataIndex: "redReportRedAging",
           width:90,
          editor:{
    		xtype: 'textfield',
          validator : this.textFieldValidator
    	 }
      ,
    	 renderer:setColor
        }

      ,  
      {	
	   header: "Red - Action Items", 
      dataIndex: "redActionItems",
      width:90,
     editor:{
		xtype: 'textfield',
     validator : this.textFieldValidator
	 }
 ,
	 renderer:setColor
   }

 , 
 {	
  header: "Red-Initial TRD", 
     dataIndex: "redInitialTrd",
  width:90
  ,xtype: "datecolumn",
	format : "m/d/Y",
  editor:{
		xtype: 'datefield',
		format : "m/d/Y"
	}
, renderer:setColor
} ,{	
 header: "Red-Revised TRD", 
dataIndex: "redRevisedTrd",
width:90,
xtype: "datecolumn",
format : "m/d/Y",
editor:{
	xtype: 'datefield',
	format : "m/d/Y"
}
, renderer:setColor
} ,{	
header: "Red-Final TRD", 
dataIndex: "redFinalTrd",
width:90,
xtype: "datecolumn",
format : "m/d/Y",
editor:{
	xtype: 'datefield',
	format : "m/d/Y"
}
,renderer:setColor
},  {	 
	    	   header: "Governance Commentary", 
		       dataIndex: "activeflag",
	           width:120,
	           editor:{
	    		xtype: 'textareafield',
	    		maxLength:4000,
	           validator : this.textFieldValidator,
	    		grow: true
	       	   },
	    	 renderer:setColor
	       }                                
        ]};         
        me.callParent(arguments);
        },
        textFieldValidator: function(value){
        	if(value.match('<')||value.match('>')){
        		return 'greater then & less then symbols are not allowed';
        	}else{
        		return true;
        	}
        }
    });

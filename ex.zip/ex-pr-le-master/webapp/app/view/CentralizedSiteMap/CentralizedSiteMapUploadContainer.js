Ext.define("eRecon_web.view.CentralizedSiteMap.CentralizedSiteMapUploadContainer", {
    extend: "Ext.panel.Panel",
    alias: "widget.CentralizedSiteMapUpload_Container",
    width : 1080,
    title : "BSS Metrics File Upload History",
    requires: ["eRecon_web.view.CentralizedSiteMap.CentralisedSiteMapUploadGrid", 
               "eRecon_web.view.jobstatus.JobStatusDetailsGridPanel"
             ],
    layout: {
	type:"vbox"
},
    initComponent: function (config) {
        this.jobStatusGridPanel = Ext.create("eRecon_web.view.CentralizedSiteMap.CentralisedSiteMapUploadGrid", {
//        	//title: 'Job Status',
       // height: 400,
            flex: 3
        });
//        
        this.jobStatusDetailsGridPanel = Ext.create("eRecon_web.view.jobstatus.JobStatusDetailsGridPanel", {
        	title: 'Audit Trail',
        width : 1080,
        	//region: "south",
            flex: 4
        });
        
        
        
        this.items = [
            this.jobStatusGridPanel, 
            this.jobStatusDetailsGridPanel
        ];
        
        this.callParent(config);
    }
});

Ext.define("eRecon_web.view.CentralizedSiteMap.CentralizedSiteMapSearch", {
    extend: "Ext.form.Panel",
    alias: "widget.CentralizedSiteMap_Search",
requires:["eRecon_web.view.common.ClearableCombo"],
    defaults: {labelAlign: "side"},
    bodyPadding: 10,
    width:310,
    defaults:{flex:1},
    overflowY : 'auto',
    initComponent: function () {
    	
      this.AccountTypeIDStore = Ext.create("eRecon_web.store.CentralizedSiteMapStore",{});

      this.centralizedsiteStore = Ext.create("eRecon_web.store.CentralizedSiteTypeStore", {});
      this.ereconPeriodsiteStore = Ext.create("eRecon_web.store.reconPeriodStore",{});
      this.proposeSiteStore = Ext.create("eRecon_web.store.ProposedSiteStore",{
    	  storeId : 'proposedSiteStore'
      });
     // this.StrategicPartnerStore= Ext.create("eRecon_web.store.StrategicPartnerStore",{});
     // this.SodTypeStore= Ext.create("eRecon_web.store.SodTypeStore",{});
     // this.McaRatingStore= Ext.create("eRecon_web.store.McaRatingStore",{});
     // this.AccReiewRatingStore= Ext.create("eRecon_web.store.AccntReviewRatingStore",{});
      
      var store = Ext.create("Ext.data.Store", {
      fields:["key", "value","flag"],
      proxy:{
      	type:"direct",                              
        directFn:eRecon_web.direct.action.CentralizedSiteMapService.getreconPeriod
      }
    });
    
      this.items = [
                    
        {
        	name: "reconPeriod",
	        itemId: "reconPeriod-text",
	        xtype:"clearablecombobox",
	        fieldLabel: 'Recon Period',
	        	//<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>',
	       // fieldLabel: 'Recon Period',
	        store:store,
	        editable: false,
	        queryMode: 'local',
			valueField: "key",
			displayField: "key",
			tpl: Ext.create('Ext.XTemplate',
			'<tpl for=".">',
			'<div class="x-boundlist-item">',
			  '<div style="{[this.getClass(values)]}">{key}</div>',
			  '</div>',
			 '</tpl>',
			    {
			        getClass: function (rec) {
			            return rec.flag == 'TRUE' ? "color: red;":''
			        }
			    }
			),
			listeners:{
			    beforerender:function(cbo_) {        		
				  cbo_.getStore().load();
				  
			  },
			  change:function(combo,newVal,oldVal){
				  var oRec=combo.findRecordByValue(oldVal);
				  oRec && combo.inputEl.removeCls('comboSelectedItem');
				  if(newVal==Ext.util.Cookies.get('currentReconPeriod')){var nRec=combo.findRecordByValue(newVal);
				  nRec && combo.inputEl.addCls('comboSelectedItem');}
			  }
			  
			}
        },
        {
          name: "fullkey",
          itemId: "fullkey",
//          fieldLabel: 'Fullkey <span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>',
          fieldLabel: 'Fullkey',
          maxLength:200,
          validator : this.textFieldValidator,
          xtype: "textfield"
        },
        {
            xtype:"textfield",
            fieldLabel:"SSID GL",
            name:"ssid_gl",
          validator : this.textFieldValidator,
            itemId:"ssid_gl"    
          },
        {
          name: "centralizedsite",
          itemId: "centralizedsite",
          fieldLabel: "Strategic Site",
          xtype: "clearablecombobox",
         editable: false,
        queryMode: 'local',
	      store: this.centralizedsiteStore,
	      valueField: "key",
	      displayField: "value",
        listeners:{
      	    beforerender:function(cbo_) {        		
          	  cbo_.getStore().load();	        	  
            }
          }
        }, {
        	xtype: "clearablecombobox",
        fieldLabel:"Proposed Sites",
        name:"nonCentralizedSiteFullkey",
        itemId:"nonCentralizedSiteFullkey",
        store: this.proposeSiteStore,
    queryMode: 'local',
        editable: false,
        valueField: "key",
        displayField: "value",
    listeners:{
  	    beforerender:function(cbo_) {        		
      	  cbo_.getStore().load();	        	  
        }
      }
        	
    },
    {
        xtype:"clearablecombobox",
        fieldLabel:"Strategic Partner",
        name:"strategicPartner",
        itemId:"strategicPartner",
       // store: this.StrategicPartnerStore,
        editable: false,
        valueField: "key",
        displayField: "value",
       queryMode: 'local',
    store:Ext.create("Ext.data.Store", {        	
    fields:["key", "value"],
    proxy:{
    	type:"direct",                              
      directFn:eRecon_web.direct.action.CentralizedSiteMapService.getFilterData                    
    }
  }),
  listeners:{
	    beforerender:function(cbo_) {        		
  	  cbo_.getStore().load({params:"STRATEGIC_PARTNER"});	        	  
    }
  }
    },            
//        {
//          xtype:"combo",	
//          fieldLabel:"Centralization Status",
//          name:"centralizedStatus",
//		  valueField: "key",
//		  displayField: "value",
//		  editable:false,
//		  store: this.CentralizedStatusStore
//        },
        {
          xtype:"clearablecombobox",
          fieldLabel:"Internal Audit Flag",
          name:"intAudFlg",
          itemId: "intAudFlg",
        queryMode: 'local',
        valueField: "key",
	      displayField: "value",
          editable:false,          
        store:Ext.create("Ext.data.Store", {        	
        fields:["key", "value"],
        proxy:{
        	type:"direct",                              
          directFn:eRecon_web.direct.action.CentralizedSiteMapService.getFilterData                    
        }
      }),
      listeners:{
  	    beforerender:function(cbo_) {        		
      	  cbo_.getStore().load({params:"YES_NO"});	        	  
        }
      }           	
        },
        {
            xtype:"textfield",
            fieldLabel:"Internal Audit Report Number",
            name:"intAuditRepNum",
          validator : this.textFieldValidator,
            itemId:"intAuditRepNum"    
          },
        {
          xtype:"clearablecombobox",
          fieldLabel:"External Audit Flag",
          name:"extAudFlg",
          itemId: "extAudFlg",
        queryMode: 'local',
        valueField: "key",
	      displayField: "value",
          editable:false,
        store:Ext.create("Ext.data.Store", {        	
        fields:["key", "value"],
        proxy:{
        	type:"direct",                              
          directFn:eRecon_web.direct.action.CentralizedSiteMapService.getFilterData                    
        }
      }),
      listeners:{
  	    beforerender:function(cbo_) {        		
      	  cbo_.getStore().load({params:"YES_NO"});	        	  
        }
      }            	
        },
        {
            xtype:"textfield",
            fieldLabel:"External Audit Report Number",
            name:"extAuditRepNum",
          validator : this.textFieldValidator,
            itemId:"extAuditRepNum"    
          },
        {
          xtype:"clearablecombobox",
          fieldLabel:"Account Review Flag",
          name:"acctRevFlg",
          itemId: "acctRevFlg",
        queryMode: 'local',
        valueField: "key",
	      displayField: "value",
          editable:false,
        store:Ext.create("Ext.data.Store", {        	
        fields:["key", "value"],
        proxy:{
        	type:"direct",                              
          directFn:eRecon_web.direct.action.CentralizedSiteMapService.getFilterData                    
        }
      }),
      listeners:{
  	    beforerender:function(cbo_) {        		
      	  cbo_.getStore().load({params:"YES_NO"});	        	  
        }
      }           	
        },
        {
          xtype:"clearablecombobox",
          fieldLabel:"Account Review Rating",
          name:"acctRevRating",
          itemId: "acctRevRating",
          valueField:"key",
        queryMode: 'local',
          displayField:"value",
          editable:false,
        store:Ext.create("Ext.data.Store", {        	
        fields:["key", "value"],
        proxy:{
        	type:"direct",                              
          directFn:eRecon_web.direct.action.CentralizedSiteMapService.getFilterData                    
        }
      }),
      listeners:{
  	    beforerender:function(cbo_) {        		
      	  cbo_.getStore().load({params:"ACCT_REVIEW_RATING"});	        	  
        }
      }           	
        },
        {
          xtype:"clearablecombobox",
          fieldLabel:"MCA Flag",
          name:"mcaFlg",
          itemId:"mcaFlg",
        queryMode: 'local',
        valueField: "key",
	      displayField: "value",
          editable:false,
        store:Ext.create("Ext.data.Store", {        	
        fields:["key", "value"],
        proxy:{
        	type:"direct",                              
          directFn:eRecon_web.direct.action.CentralizedSiteMapService.getFilterData                    
        }
      }),
      listeners:{
  	    beforerender:function(cbo_) {        		
      	  cbo_.getStore().load({params:"YES_NO"});	        	  
        }
      }           	
        },
        {
          xtype:"clearablecombobox",
          fieldLabel:"MCA Rating",
          name:"mcaRating",
          itemId:"mcaRating",
          valueField:"key",
        queryMode: 'local',
          displayField:"value",
          editable:false,
        store:Ext.create("Ext.data.Store", {        	
        fields:["key", "value"],
        proxy:{
        	type:"direct",                              
          directFn:eRecon_web.direct.action.CentralizedSiteMapService.getFilterData                    
        }
      }),
      listeners:{
  	    beforerender:function(cbo_) {        		
      	  cbo_.getStore().load({params:"PASS_FAIL"});	        	  
        }
      }            	
        },
        
        {
          xtype:"clearablecombobox",
          fieldLabel:"SOD Flag",
          name:"confEnt",
          itemId:"confEnt",
        valueField: "key",
	      displayField: "value",
        queryMode: 'local',
          editable:false,
        store:Ext.create("Ext.data.Store", {        	
        fields:["key", "value"],
        proxy:{
        	type:"direct",                              
          directFn:eRecon_web.direct.action.CentralizedSiteMapService.getFilterData                    
        }
      }),
      listeners:{
  	    beforerender:function(cbo_) {        		
      	  cbo_.getStore().load({params:"YES_NO"});	        	  
        }
      }            	
        },
        {
          xtype:"clearablecombobox",
          fieldLabel:"SOD Type",
          name:"sodType",
          itemId:"sodType",
          valueField:"key",
          displayField:"value",
        queryMode: 'local',
          editable:false,
        store:Ext.create("Ext.data.Store", {        	
        fields:["key", "value"],
        proxy:{
        	type:"direct",                              
          directFn:eRecon_web.direct.action.CentralizedSiteMapService.getFilterData                    
        }
      }),
      listeners:{
  	    beforerender:function(cbo_) {        		
      	  cbo_.getStore().load({params:"SOD_TYPE"});	        	  
        }
      }
        },
        {
          xtype:"clearablecombobox",
          fieldLabel:"CAP Flag",
          name:"capFlg",
          itemId:"capFlg",
        valueField: "key",
        queryMode: 'local',
	      displayField: "value",
          editable:false,
        store:Ext.create("Ext.data.Store", {        	
        fields:["key", "value"],
        proxy:{
        	type:"direct",                              
          directFn:eRecon_web.direct.action.CentralizedSiteMapService.getFilterData                    
        }
      }),
      listeners:{
  	    beforerender:function(cbo_) {        		
      	  cbo_.getStore().load({params:"YES_NO"});	        	  
        }
      }           	
        },
        {
          xtype:"textfield",
          fieldLabel:"CAP Issue Number",
          name:"issueNum",
        validator : this.textFieldValidator,
          itemId:"issueNum"    
        },
        {
          xtype:"textfield",
          fieldLabel:"CAP Number",
          name:"capNum",
        validator : this.textFieldValidator,
          itemId:"capNum" 
        },
       
        {
            xtype:"textfield",
        fieldLabel:"CAP Description",
        name:"capDesc",
        validator : this.textFieldValidator,
        itemId:"capDesc" 
      },
        {
        	name: "initialTrd",
        	fieldLabel:"CAP Initial TRD",
            itemId: "initial_trd",
            xtype: "datefield"
        },
        {
        	name: "revisedTrd",
        	fieldLabel:"CAP Revised TRD",
            itemId: "revised_trd",
            xtype: "datefield"
        },
        
        {
        	name: "finalTrd",
        	fieldLabel:"CAP Final TRD",
            itemId: "final_trd",
            xtype: "datefield"
        },
        {
            xtype:"clearablecombobox",
            fieldLabel:"Dormant Account Flag",
            name:"dormAcctFlg",
            itemId:"dormAcctFlg",
          queryMode: 'local',
          valueField: "key",
  	      displayField: "value",
            editable:false,
          store:Ext.create("Ext.data.Store", {        	
          fields:["key", "value"],
          proxy:{
          	type:"direct",                              
            directFn:eRecon_web.direct.action.CentralizedSiteMapService.getFilterData                    
          }
        }),
        listeners:{
    	    beforerender:function(cbo_) {        		
        	  cbo_.getStore().load({params:"YES_NO"});	        	  
          }
        }           	
          },
          {
              xtype:"clearablecombobox",
              fieldLabel:"Abnormal Balance Flag",
              name:"abnormalBalFlg",
              itemId:"abnormalBalFlg",
            queryMode: 'local',
            valueField: "key",
    	      displayField: "value",
              editable:false,
            store:Ext.create("Ext.data.Store", {        	
            fields:["key", "value"],
            proxy:{
            	type:"direct",                              
              directFn:eRecon_web.direct.action.CentralizedSiteMapService.getFilterData                    
            }
          }),
          listeners:{
      	    beforerender:function(cbo_) {        		
          	  cbo_.getStore().load({params:"YES_NO"});	        	  
            }
          }           	
            },
            {
                xtype:"clearablecombobox",
                fieldLabel:"ZBA Aging",
                name:"zbaAging",
                itemId:"zbaAging",
              queryMode: 'local',
              valueField: "key",
      	      displayField: "value",
                editable:false,
              store:Ext.create("Ext.data.Store", {        	
              fields:["key", "value"],
              proxy:{
              	type:"direct",                              
                directFn:eRecon_web.direct.action.CentralizedSiteMapService.getFilterData                    
              }
            }),
            listeners:{
        	    beforerender:function(cbo_) {        		
            	  cbo_.getStore().load({params:"ZBA_AGING"});	        	  
              }
            }           	
              },
        {
xtype:"clearablecombobox",
itemId:"redPartBaseLine",
fieldLabel:"Red - Part of baseline",
name:"redPartBaseLine",
valueField: "key",
queryMode: 'local',
displayField: "value",
editable:false,
store:Ext.create("Ext.data.Store", {        	
fields:["key", "value"],
proxy:{
	type:"direct",                              
directFn:eRecon_web.direct.action.CentralizedSiteMapService.getFilterData                    
}
}),
listeners:{
beforerender:function(cbo_) {        		
  cbo_.getStore().load({params:"YES_NO"});	        	  
}
}           	
    
          },
          {
              xtype:"textfield",
              fieldLabel:"Red - Baseline Topline Reason",
              name:"redBaseTopReason",
            validator : this.textFieldValidator,
              itemId:"redBaseTopReason"    
            },
            {
                xtype:"textfield",
                fieldLabel:"Red - Reportable Red Aging",
                name:"redRepRedAging",
              validator : this.textFieldValidator,
                itemId:"redRepRedAging"    
              },
              {
                  xtype:"textfield",
                  fieldLabel:"Red - Action Items",
                  name:"redActionItems",
                validator : this.textFieldValidator,
                  itemId:"redActionItems"    
                },
        {
        	name: "redInitialTrd",
        	fieldLabel:"Red Initial TRD",
            itemId: "red_initial_trd",
            xtype: "datefield"
        },
        {
        	name: "redRevisedTrd",
        	fieldLabel:"Red Revised TRD",
            itemId: "red_revised_trd",
            xtype: "datefield"
        },
        
        {
        	name: "redFinalTrd",
        	fieldLabel:"Red Final TRD	",
            itemId: "red_final_trd",
            xtype: "datefield"
        },
        {
            xtype:"textareafield",
            fieldLabel:"Governance Commentary",
            name:"governanceCommentary",
            itemId:"governanceCommentary",
            maxLength:4000
        }
      ];
        
      this.dockedItems = [
        {
            dock: "top", 
            xtype: "toolbar",
            items: [
            {
                xtype: "button",
                text: "Insert",
                iconCls: 'iconAdd',
                scope: this,
                hidden:true,
                action: "insert"
            },
          //  "-",
            {
                xtype: "button",
                text: "Search",
                iconCls: 'iconMagnifier',
                scope: this,
                action: "searchdetails"
            },
            "-",
            {
            	xtype: "button",
                text: "Clear All",
                iconCls: 'iconTableDelete',
                scope: this,
                action: "clear"
            }
        ]
        }/*,{
			dock: "bottom", 
			xtype: "toolbar",
			items: [
				{
				    xtype: "label",
				    text: "* Indicates Mandatory fields while inserting a new record"
				}
			]
         }*/
        ];

        this.callParent(arguments);
    },
    textFieldValidator: function(value){
    	if(value.match('<')||value.match('>')){
    		return 'greater then & less then symbols are not allowed';
    	}else{
    		return true;
    	}
    }
});

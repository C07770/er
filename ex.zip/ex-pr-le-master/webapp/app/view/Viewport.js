Ext.define("eRecon_web.view.Viewport", {
    extend: "Ext.container.Viewport",
    requires: [
        "eRecon_web.view.navigation.NorthPanel",
        "eRecon_web.view.navigation.ContentCards",
        "eRecon_web.view.common.StatusBar"
    ],
    border: false,
    initComponent: function () {
        this.layout = "border";
        this.items = [
            {
                region: "north",
                xtype: "navigation_northpanel",
                collapsible: false,
                animCollapse: false,
                split: false,
                border: false
            },
            {
                region: "center",
                xtype: "navigation_contentcards"
            },
            {
            	region: "south",
            	xtype: "customStatusbar",
            	id: 'my-status',

                // defaults to use when the status is cleared:
                defaultText: 'Ready',
                defaultIconCls: 'iconAccept',

                // values to set initially:
                text: 'Ready',
                iconCls: 'iconAccept'
            }
        ];

        this.callParent(arguments);
    }

});

Ext.define("eRecon_web.view.dashboard2.ManagedAccountsPieChart", {
	extend: "Ext.container.Container",
	layout: {
		type: 'vbox',
		align: 'stretch'
	},
	border: 1,
	style: {
	    borderColor: 'black',
	    borderStyle: 'solid'
	},
   alias: "widget.managedaccountspiechart",
   items:[
     {
	   xtype: 'label',
	   text: 'Number of Fullkeys By Centralization Status',
       style: 'font: bold 11px Arial; color: #444; padding:4px'
     },		  
     {
	    xtype: 'chart',
		flex: 1,
		itemId:"managedacctpiechart",
		hidden: false,		
		legend: {
		    position: "bottom",
		    boxStrokeWidth: 0
		},

     series: [{
        type: 'pie',
        angleField: 'data',
        showInLegend: true,
        tips: {
            //trackMouse: true,
            width: 140,
            renderer: function(storeItem, item) {
	        	this.setTitle(
	        		storeItem.get('name') + '<br/>' + 
	        		Ext.util.Format.number(storeItem.get('data'),'0,') + '<br/>' +
	        		Ext.util.Format.number(storeItem.get('percent'),'0.00%')
	            );
            }
        },
        highlight: {
            segment: {
                margin: 20
            }
        },
        label: {
          renderer: function(val) {
              return "";
			},
            field: 'name',
            display: 'rotate',
            contrast: true,
            font: '14px Arial',
			calloutLine: {
		        color: 'rgba(0,0,0,0)' // Transparent to hide callout line
		    }
        }
    }],
	store: Ext.create('Ext.data.JsonStore', {
	    fields: ['name', 'data', "percent"]	    
	})
   }
   ]

});

Ext.define("eRecon_web.view.dashboard2.StrategicSitesPieChart", {
  extend: "Ext.container.Container",
  alias: "widget.strategicsitespiechart",
 
  layout: {type: "vbox", align:"stretch"},
  border: 1,
  style: {
	borderColor: 'black',
	borderStyle: 'solid'	
  },

  initComponent:function() {
    this.items = [
     { 
	   xtype:"container",
       style:"background-color:white",
	   layout:{type:"vbox", align:"center"},
	   items:[ 	    
         {
	       xtype:"label",
	       itemId:this.expanded ? "strategicSitesLabel": "",
	       html:"Number of Fullkeys by Strategic Site<br><span style='margin-left:12px;'>Total Number of Fullkeys - </span><span id='total'></span>",
           style: 'font: bold 16px Arial; color: #444; padding:4px;'
         },
         {xtype:"button",hidden:true, text:"Export Pie Chart to PPt",itemId:"pptPieExportBtn", icon:"/static/assets/famfamfam/icons/email_go.png"}
       ]
     },
     {
	   xtype: 'chart',
	   flex: 1,
	   itemId:"stratsitespiechart",
	   style:"background-color:white",
	   legend:Ext.create('Ext.ux.chart.SmartLegend', {
	     position:"left",
         chart: Ext.ComponentQuery.query("chart#stratsitespiechart"),
         rebuild:true,
         boxStrokeWidth: 0,
         itemSpacing:-10,
         padding: 3
	   }),
	   hidden: false,		
       series: [{
         type: 'pie',
         angleField: 'data',
         showInLegend: true,
         tips: {       
           width: 140,
           renderer: function(storeItem, item) {
	         this.setTitle(
	           storeItem.get('name') + '<br/>' + 
	           Ext.util.Format.number(storeItem.get('data'),'0,') + '<br/>' +
	           Ext.util.Format.number(storeItem.get('percent'),'0.00%')
	         );
           }
         },
         highlight: {
           segment: {
             margin: 20
           }
         },
         label: {
           renderer: function(val) {
        	 //if(!this.expanded) return "";        	 
             var fullkeys = Ext.ComponentQuery.query("chart#stratsitespiechart")[0].store.data.items;
        	 for(var i = 0;i<fullkeys.length; i++){
        	   for(var key in fullkeys[i].data){
        	     if(fullkeys[i].data[key] == val){
        	       var fk= fullkeys[i].data["data"];
        	       return (fk.toString()).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        	     }
        	   }
        	 }
		   },
           field: 'name',
           display: 'inside',
           contrast: true,
           font: '14px Arial'
         }
       }
     ],
	 store: Ext.create('Ext.data.JsonStore', {
	   fields: ['name', 'data', "percent"]	    
	  })
     }
   ];
   
   this.callParent(arguments);
     
  }

});

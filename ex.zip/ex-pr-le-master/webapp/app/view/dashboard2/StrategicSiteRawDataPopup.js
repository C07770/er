Ext.define('eRecon_web.view.dashboard2.StrategicSiteRawDataPopup', {
    extend: "Ext.window.Window",
    alias: "widget.StrategicSiteRawDataPopup",
    width: 1000,
    height: 500,
    modal: true,
    layout: {
		type: 'vbox',
		align: 'stretch'
    },
    
    initComponent:function(){
	

	    this.tbar=[{xtype:"button", text:"Export to Excel", action:"StrategicSitesExcel", itemId:"exportexcelbtn", icon:"/static/assets/famfamfam/icons/page_white_excel.png"}],
	    this.items = [
	    {
	    	xtype: 'grid',
	    	itemId:"strategicrawdata",
	    	flex: 1,
	    	store: 'eRecon_web.store.dashboard2.StrategicSitesRawDataStore',
	    columns: [          	
	    {text: "Recon Period", dataIndex:"reconperiod", tdCls:"wrap", width:120},      
		{text: 'Fullkey', dataIndex: 'fullkey', width: 260},
		{text: 'Description', dataIndex: 'description', tdCls: 'wrap', width: 180},
		{text: "BSS Account Type", dataIndex:"bssaccounttype", tdCls:"wrap", width:130},
		{text: 'GL Balance (USD)', dataIndex: 'glbalance', width: 100, renderer: this.dollarRenderer},
		//{text: "Centralization Status", dataIndex:"centralizationstatus", tdCls:"wrap", width:120},
		{text: "Strategic Site", dataIndex:"centralizedsite", tdCls:"wrap", width:160},
		{text: "Country", dataIndex:"country", tdCls:"wrap", width:100},
		{text: "Region", dataIndex:"region", tdCls:"wrap", width:100},
		{text: 'Status', dataIndex: 'status', width: 70},
		{text: 'Proof Owner Name', dataIndex: 'poname', tdCls: 'wrap', width: 100},
		{text: 'Account Owner Name', dataIndex: 'aoname', tdCls: 'wrap', width: 115},
		{text: "Controller Delegate Name", dataIndex:"controllername", tdCls:"wrap", width:170},
		{text: "Arc Member", dataIndex:"arcmember", tdCls:"wrap", width:170},
		{text: "Red/Green Indicator", dataIndex:"redgreenind", tdCls:"wrap", width:120},
		{text: "Reportable Red Amt Dr (USD)", dataIndex:"reportableredamtdr", tdCls:"wrap", width:140, renderer:this.reportableRedAmtRenderer},
		{text: "Reporatble Red Amt Cr (USD)", dataIndex:"reportableredamtcr", tdCls:"wrap", width:140, renderer:this.reportableRedAmtRenderer}					
	  /*{text: 'Financial Controller Name', dataIndex: 'financialControllerName', tdCls: 'wrap', width: 130},
		{text: 'Source', dataIndex: 'source', width: 50},
		{text: 'Red/Green Indicator', dataIndex: 'redGreenIndicator', cls:'multiline-column-header', width: 70},
		{text: 'Aging Benchmark', dataIndex: 'agingBenchmark', cls:'multiline-column-header', width: 60},
		{text: 'PO Comments', dataIndex: 'poComments', tdCls: 'wrap', width: 400},
		{text: 'AO Comments', dataIndex: 'aoComments',  tdCls: 'wrap', width: 400},
		{text: 'LEM Comments', dataIndex: 'lemComments',  tdCls: 'wrap', width: 400},
		{text: 'AO Attestation', dataIndex: 'aoAttestation', width: 90},
		{text: 'AO Agreed/Disagreed', dataIndex: 'aoAgreedDisagreed', width: 120},
		{text: 'Amt > 181 DR(USD)', dataIndex: 'amtGt181DrUsd', renderer: Ext.util.Format.usMoney, width: 110},
		{text: 'Amt > 181 CR(USD)', dataIndex: 'amtGt181CrUsd', renderer: Ext.util.Format.usMoney, width: 110},
		{text: 'Amt > 181 (USD)', dataIndex: 'amtGt181Usd', renderer: Ext.util.Format.usMoney, width: 110},
		{text: 'Reportable Red Amt DR(USD)', dataIndex: 'reportableRedAmtDrUsd',cls:'multiline-column-header', renderer: Ext.util.Format.usMoney, width: 130},
		{text: 'Reportable Red Amt CR(USD)', dataIndex: 'reportableRedAmtCrUsd',cls:'multiline-column-header', renderer: Ext.util.Format.usMoney, width: 130},
		{text: 'Reportable Amt At Risk DR(USD)', dataIndex: 'reportableAmtAtRiskDrUsd', cls:'multiline-column-header', renderer: Ext.util.Format.usMoney, width: 130},
		{text: 'Reportable Amt At Risk CR(USD)', dataIndex: 'reportableAmtAtRiskCrUsd', cls:'multiline-column-header', renderer: Ext.util.Format.usMoney, width: 130},
		{text: 'Amt At Risk Reserve DR(USD)', dataIndex: 'amtAtRiskReserveAmtDrUsd', cls:'multiline-column-header', renderer: Ext.util.Format.usMoney, width: 130}*/
	      ]
	    }
	   ,{
		    xtype:'pagingtoolbar',
		    dock: 'bottom',
		    store: 'eRecon_web.store.dashboard2.StrategicSitesRawDataStore',
		    displayInfo: true,
	  	    displayMsg: 'Displaying topics {0} - {1} of {2}',
		    emptyMsg: "No data to display",
		    height: 30
		}
	    ];
	    
    this.callParent(arguments);
    
  },
  reportableRedAmtRenderer : function(value,meta){
	  if(Math.abs(value)>= 5000000) {
		  meta.style = "background-color:#FF8080;color:#6E0000";
		  }
	if(value<0){
      value = Math.abs(value);
	  value = Ext.util.Format.currency(value);          		    
	  return "("+value+")"	  
	}
	return Ext.util.Format.currency(value);
  },
  dollarRenderer:function(value,meta){
	if(value<0){
      value = Math.abs(value);
	  value = Ext.util.Format.currency(value);          		    
	  return "("+value+")"	  
	}
	return Ext.util.Format.currency(value);
  }  
	  	    	  	    
});

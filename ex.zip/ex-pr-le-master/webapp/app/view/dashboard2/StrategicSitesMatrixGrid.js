Ext.define('eRecon_web.view.dashboard2.StrategicSitesMatrixGrid', {
	extend : 'Ext.grid.Panel',
	alias : 'widget.strategicsitesmatrixgrid',
	store: 'eRecon_web.store.dashboard2.StrategicSitesMatrixStore',
	columnLines: true,
	features: [
	{
		ftype: 'summary'
	}
	],
	initComponent : function() {
		var me = this;    	

		me.columns = {
	    defaults:{align:"center"},
	    items:[	
		    {text: 'Period', dataIndex: 'reconperiod', width:105,hidden:true},
		    {text: 'Region', dataIndex: 'geocode',  width:105},
		    {text: "Country", dataIndex: 'country_desc', width:105},
		    {header:"Strategic Site", defaults:{align:"left"}, columns:[
			   
 {text: 'Belfast', dataIndex: 'belfast', renderer: this.expandableRenderer , summaryType: 'sum', summaryRenderer: this.summaryRenderer },		    
 {text: 'Budapest', dataIndex: 'budapest', renderer: this.expandableRenderer , summaryType: 'sum', summaryRenderer: this.summaryRenderer },
 {text: 'Buffalo', dataIndex: 'buffalo', renderer:this.expandableRenderer, summaryType: 'sum', summaryRenderer: this.summaryRenderer },
 {text: 'Dalian', dataIndex: 'dalian', renderer: this.expandableRenderer , summaryType: 'sum', summaryRenderer: this.summaryRenderer },

{text: 'Heredia', dataIndex: 'heredia', renderer: this.expandableRenderer,  summaryType: 'sum', summaryRenderer: this.summaryRenderer },
			    {text: 'Makati City', dataIndex: 'makatiCity', renderer: this.expandableRenderer,  summaryType: 'sum', summaryRenderer: this.summaryRenderer },

			    {text: 'Mexico City', dataIndex: 'mexicoCity', renderer: this.expandableRenderer , summaryType: 'sum', summaryRenderer: this.summaryRenderer },
			    {text: 'Mumbai', dataIndex: 'mumbai', renderer: this.expandableRenderer,  summaryType: 'sum', summaryRenderer: this.summaryRenderer },
			    {text: 'Shanghai', dataIndex: 'shanghai', renderer: this.expandableRenderer , summaryType: 'sum', summaryRenderer: this.summaryRenderer },
			    {text: 'Tampa', dataIndex: 'tampa', renderer: this.expandableRenderer , summaryType: 'sum', summaryRenderer: this.summaryRenderer },
			    {text: 'TCS Chennai', dataIndex: 'tcsChennai', renderer: this.expandableRenderer , summaryType: 'sum', summaryRenderer: this.summaryRenderer },
			    {text: 'TCS Gurgaon', dataIndex: 'tcsGurgaon', renderer: this.expandableRenderer , summaryType: 'sum', summaryRenderer: this.summaryRenderer },
			    {text: 'Regulatory<br>Restricted', dataIndex: 'regulatoryRestricted', renderer: this.expandableRenderer , summaryType: 'sum', summaryRenderer: this.summaryRenderer },
			    {text: 'Other (non-centralized<br>and discontinued ops)', dataIndex: 'others', renderer: this.expandableRenderer , summaryType: 'sum', summaryRenderer: this.summaryRenderer,width:120 }
			    //{text: 'nonCentralized', dataIndex: 'nonCentralized', renderer: this.expandableRenderer , summaryType: 'sum', summaryRenderer: summaryRenderer },
			    //{text: 'discontinuedOperations', dataIndex: 'discontinuedOperations', renderer: this.expandableRenderer , summaryType: 'sum', summaryRenderer: summaryRenderer },
			 ]},
			 {text: '<b>Total</b>', dataIndex: 'total',  width:105,align:"left",
			  renderer: function(v) {
					if (!v) {
						return "";
					}
		    	    return '<b><span class="cell-expand" dataIndex="total">&nbsp</span><span>'+Ext.util.Format.number(v,'0,')+'</span></b>';
			      }, 			      
			      summaryType: 'sum', summaryRenderer: this.summaryRenderer
			   }
	    ]};			
		 me.dockedItems = [
            {
                dock: "top", xtype: "toolbar", items: [
               // "<b>Recent Uploads/Downloads</b>"
                , "->"
                , {
                    xtype: "button",
                    tooltip: "Refresh Grid",
                    text: "Refresh",
                    icon : "/static/assets/famfamfam/icons/arrow_refresh.png",
                   // action: "reload_history",
                    scope: this, handler: function () {
                        //console.log("Reload Upload History");
                        this.getStore().reload();
                    }
                }
            ]}
        ];
		me.listeners= {			
	    afterlayout: function () {
			var el= this.getEl().down('.x-grid-row-summary');
			if(el!=null){
	    	el.dom.children[1].className='merge-cell';
	    	el.dom.children[1].firstChild.style.marginLeft="79px";//"font-weight:bold; border-right:0px;margin-left:67px; overflow:visible;";
	    	el.dom.children[1].firstChild.style.overflow="visible";
	    	el.dom.children[1].firstChild.innerHTML="Total";
	    	}
			  Ext.defer(function(){
			    this.mon(this.getEl().down('.x-grid-row-summary'), 'click', function (a,b,c) {
			      if(b.className =="cell-expand"){			    
			        var stratSite = b.getAttribute("dataindex");			         
  			      this.fireEvent("summaryrowclick", stratSite);
  			      return;
			    	}
			   }, this);
			 },5000,this);
	   }	
		};
      
		me.callParent(arguments);
	},
	
	expandableRenderer: function(v, meta,rec, rowIndex, colIndex) {
		if (!v) {
			return "";
		}
		var dataIndex = this.columns[3].items.items[colIndex-3].dataIndex;
	  return '<span class="cell-expand" dataIndex=' + dataIndex + '>&nbsp</span><span>'+Ext.util.Format.number(v,'0,')+'</span>';
  },
  
  summaryRenderer: function(value, currentSumData, dataIndex) {  	
    if (value > 0) {
    	return '<span class="cell-expand" dataIndex=' + dataIndex + '>&nbsp</span><span>'+Ext.util.Format.number(value,'0,')+'</span>';
    }
    else {    	
    	return '<span>'+Ext.util.Format.number(value,'0,')+'</span>';
    }
    
    }
//  },
//  regionRenderer: function(value, meta, record, rowIndex, colIdnex,store ,view) { 
//	 // if(Ext.isEmpty(value)){
//	  meta.style = "font-weight:bold; border-right:0px;margin-left:67px; overflow:visible;";
//	  meta.tdCls = 'merge-cell';
//	 // var row= view.getNode(record)
//	 // var el = Ext.fly(Ext.fly(row).query('.x-grid-cell')[colIdnex]).down('td');
//	  //el.style=' border-right: 0px;  overflow: visible;';
//	  return "Total";
//	 // }
//  }
	
});

						

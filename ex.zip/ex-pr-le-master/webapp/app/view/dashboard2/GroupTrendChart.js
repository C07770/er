Ext.define("eRecon_web.view.dashboard2.GroupTrendChart", {
   extend: "Ext.container.Container",
   alias: "widget.grouptrendchart",
	border: 1,
	style: {
	    borderColor: 'black',
	    borderStyle: 'solid'
	},
   initComponent: function() {
		var me = this;
		me.layout = {
			type: 'vbox',
			align: 'stretch'
	    };
		var titleContainer = Ext.create('Ext.container.Container',
	    {	
  		    layout: {
		   		type: 'vbox',
		   		align: 'center'
	   	    },
	 	   items: [
		   {
			   xtype: 'label',
			   text: '6 Month Trend Report by PO City',
		       style: 'font: bold 18px Arial; color: #444'
		   }
		   ]
		 });
		 chartTipsRenderer = function(storeItem, item) {
			    console.log("store:" + storeItem);
         	var title = item.series.title;
        	if (!title) {
        		title = '';
        	}
    		//title = title.replace(/\./g, '');
        	this.setTitle(
        		title + '<br/>' +
        		storeItem.get('reconperiod') + '<br/>' + 
        		Ext.util.Format.number(item.value[1],'0,')
            );
        };
		 var chart = Ext.create('Ext.chart.Chart',{
				flex: 1,
				legend: false,				
				itemId:"grouptrendchart",
				axes: 
				[
				{
				    type: "Numeric",
				    minimum: 0,
				    position: "left",
					grid: true,
					title: "Number of Fullkeys"
				}, 
				
				{
				    type: "Category",
				    position: "bottom",
				    fields: ["reconperiod"]
			//	    , title: "Group"
				    , label: {
						renderer: function(val) {
				    		return val;
				    	}
					}
				}
				],
				
				series: [
				  //dynamically created in controller 
				],
				//store:"eRecon_web.store.dashboard2.StrategicSiteTrendByPeriodDataStore"
				store:Ext.create("Ext.data.Store",{
				  fields:["reconperiod"]
				})
			});
		me.items = [titleContainer, chart];
		
	    chart.legend = Ext.create('Ext.ux.chart.SmartLegend', {
	        position:       'bottom',
	        chart:          chart,
	        rebuild:        true,
	        boxStrokeWidth: 0,
	        itemSpacing: 0,
	        pading: 0
	    });

		me.callParent(arguments);
   }

});

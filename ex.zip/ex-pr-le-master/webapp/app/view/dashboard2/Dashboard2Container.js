Ext.define("eRecon_web.view.dashboard2.Dashboard2Container", {
   extend: "Ext.tab.Panel",
   alias: "widget.dashboard2Container",
   layout: 'border',
   requires :[
              'eRecon_web.view.dashboard2.StrategicSitesMatrixGrid',
              'eRecon_web.view.dashboard2.GroupTrendChart',
              'eRecon_web.view.dashboard2.SiteTrendChart',
              'eRecon_web.view.dashboard2.ManagedAccountsPieChart',
              'eRecon_web.view.dashboard2.StrategicSitesPieChart',
              "eRecon_web.view.common.ClearableCombo"
              ],
   items:[
     {
    	 title:"Strategic Site Matrix ",
    	 flex:1,
    	 layout:{type:"fit"},
    	 items:[
          {
        	region: 'center', 
        	xtype: 'panel',
        	flex:1,
        	layout: {type: 'hbox', align: 'stretch'},
        	items: [
        	{
        		xtype: 'container',
        		layout: {type: 'vbox', align: 'stretch'},
        		flex: 1,
        		items: [
	        	{
	        		xtype: 'container',
	        		layout: {type: 'hbox', align: 'stretch'},
	        	    items: [
		        	{
		        		xtype: 'container',
		        		height: 40,
		        		layout: 'hbox',
			        	items: [
	        		      {
	        		        xtype: 'clearablecombobox', 
	        		    	padding: 10,	
	        		    	labelPad: -30,
	        		    	searchId: 'periodsCombo',
	        		    	fieldLabel: "Month-Year",
  		        		    valueField:"values",
		        		    displayField:"values",
		        		    editable:false,
		        		    queryMode:"local",
		        		    store:Ext.create("Ext.data.Store", {
	                          fields:["values", "description","flag"],
	                          proxy:{
		        		    	type:"direct",
//		        		    	directFn:eRecon_web.direct.action.DashboardService.getFilterValues
		        		    	directFn:eRecon_web.direct.action.Dashboard2Service.getSSMonthYearData
		        		    	
		        		      }
	                        }),
	        		      tpl: Ext.create('Ext.XTemplate',
	        				'<tpl for=".">',
	        				'<div class="x-boundlist-item">',
	        				  '<div style="{[this.getClass(values)]}">{values}</div>',
	        				  '</div>',
	        				 '</tpl>',
	        				    {
	        				        getClass: function (rec) {
	        				            return rec.flag == 'TRUE' ? "color: red;":''
	        				        }
	        				    }
	        				),
	                        listeners:{
	                 	      beforerender:function(cbo_) {             	        
//	                     	    cbo_.getStore().load({params:"RECONPERIOD"});
	        		    	  cbo_.getStore().load();
	                         }
	                      }
	        		    },
	        		    {
	        		      xtype: 'clearablecombobox', 
	        		      padding: 10,	
	        		      labelPad: -55,
	        		      searchId: 'regionCombo',
	        		      fieldLabel: "Region",
		        		  valueField:"values",
		        		  editable:false,
		        		  displayField:"description",
		        		  queryMode:"local",
	        		      store:Ext.create("Ext.data.Store", {
	                        fields:["values", "description"],
	                        proxy:{
		        		      type:"direct",
		        		      directFn:eRecon_web.direct.action.DashboardService.getFilterValues
		        		    }
	                      }),
	                      listeners:{
	                 	    beforerender:function(cbo_) {             	        
	                     	  cbo_.getStore().load({params:"REGION"});
	                        }
//	                     	  ,	                      
//	                        select:function(cbo_){
//	                          var countryCbo = Ext.ComponentQuery.query("clearablecombobox[searchId=countryCombo]")[0];
//	                          var params = {region:cbo_.getValue()};
//	                          Ext.ComponentQuery.query("clearablecombobox[searchId=countryCombo]")[0].setValue(null);
//	                          countryCbo.getStore().load({params:Ext.encode(params)});
//	                        }
	                      }
	        		    },
	        		    {
	        		      xtype: 'clearablecombobox', 
	        		      padding: 10,	
	        		      labelPad: -50,
                          searchId: 'countryCombo',
	        		      fieldLabel: "Country",
		        		  valueField:"values",
		        		  editable:false,
		        		  displayField:"description",
		        		  queryMode:"local",
		        		  store:Ext.create("Ext.data.Store", {
	                        fields:["values", "description"],
		        		    proxy:{
		        			  type:"direct",
		        		    directFn:eRecon_web.direct.action.DashboardService.getFilterValues
	                          //directFn:eRecon_web.direct.action.Dashboard2Service.getCountryByRegion
	                        }
	                      }),
	                      listeners:{
		                 	    beforerender:function(cbo_) {             	        
		                     	  cbo_.getStore().load({params:"COUNTRY"});
		                        }
		                      }	                      
	        		    },
	        		    
	        		     {xtype:"button",hidden:true,padding: '10 0 0 0', text:"Export Trend to PPT",itemId:"pptExportBtn"},
	        		     
	        		     {xtype:"button",hidden:true, padding: '10 0 0 0',text:"Export Pie to PPT",itemId:"pptPieExportBtn"},
//						{
//							xtype:"button", 
//							padding: '10 0 0 0',
//							border: false,
//							action:"clearSsmComboBoxBtn", 
//							itemId:"clearSsmComboBoxBtnId", 
//							iconCls : 'iconTableDelete',
//							tooltip : 'Clear All'
//						},
	        		    {
	        		    	xtype: 'label',
	        		    	text: 'Strategic Sites Matrix', 
	        		        style: 'font: bold 18px Arial; color: #444; margin-left:150px;',
	        		        padding: '10 0 0 10'
	        		    }
	        		]
		        	}
			        ]
			    },
		    
	        	{
	        		xtype: 'strategicsitesmatrixgrid',
	        		flex: 1
	        	}
		    ]
	        }           	
//        	{
//        		xtype: 'strategicsitespiechart',
//        		flex:.5
//        	},
//        	{
//        		xtype: 'splitter'
//        	},
//        	{
//        		xtype: 'managedaccountspiechart',
//        		flex:.7
//        	}
        	]
         }
         ]
         },
         {
        	 title:"Summary Charts",
             flex:1,
    	     layout:{type:"fit"},
        	 items:[
        
        {
        	region: 'south',
        	xtype: 'panel',
        	flex: 1,
        	split: true,
	        layout: {
	            type: 'hbox',
	            align: 'stretch'
	        },
	        items: [
	        {
	        	xtype: 'tbspacer',
	        	width: 5
	        },
	        {
	        	xtype: 'strategicsitespiechart',
    		    flex:1
	        },
//	        {
//	        	xtype: 'grouptrendchart',
//	        	flex: 1
//	        },
	        {
	        	xtype: 'splitter'
	        },
	        {
	        	xtype: 'sitetrendchart',
	        	flex: 1
	        },
	        {
	        	xtype: 'tbspacer',
	        	width: 5
	        }
	        ]
        }
        ]
        }

   ]
});

Ext.define("eRecon_web.view.dashboard2.SiteTrendChart", {
   extend: "Ext.container.Container",
   alias: "widget.sitetrendchart",
	border: 1,
	style: {
	    borderColor: 'black',
	    borderStyle: 'solid'
	},
  
	initComponent: function() {
		var me = this;
		me.layout = {
			type: 'vbox',
			align: 'stretch'
	  };
		
		var titleContainer = Ext.create('Ext.container.Container',{	
			style:"background-color:white",
      layout: {
  		   type: 'vbox',
  		   	align: 'center'
  	   },
  	 	 items: [        
  		  {
  			  xtype: 'label',
  			  text: '6 Month Trend Report by Strategic Site',
  		    style: 'font: bold 18px Arial; color: #444'
  		  },
  		 {xtype:"button",hidden:true, text:"Export Trend Chart to PPt",itemId:"pptTrendExportBtn", icon:"/static/assets/famfamfam/icons/email_go.png"}
		  ]
		});
		
		 chartTipsRenderer = function(storeItem, item) {
       var title = item.series.title;
       if (!title) {
         title = '';
       }
       this.setTitle(
         title + '<br/>' +
      	 storeItem.get('reconperiod') + '<br/>' + 
      	 Ext.util.Format.number(item.value[1],'0,')
       );
     }
		 ;
		 var chart = Ext.create('Ext.chart.Chart',{
		   flex: 1,
		   style:"background-color:white",
			 legend: false,
			 itemId:"sitetrendchart",
			 axes:[
				{
				  type: "Numeric",
				  minimum: 0,
				  position: "left",
					grid: true,
					title: "Number of Fullkeys"
				}, 
				{
				  type: "Category",
				  position: "bottom",
				  fields: ["reconperiod"],
				  label: {
						renderer: function(val) {
				      return val;
				    }
					}
				}
		  ],
			series: [
				  //dynamically created in controller 
			],

			store:Ext.create("Ext.data.Store",{
			  fields:["reconperiod"]
		  })
	  });
		me.items = [titleContainer, chart];
		
	  chart.legend = Ext.create('Ext.ux.chart.SmartLegend', {
	    position:"right",
	    chart:chart,
	    rebuild:true,
	    boxStrokeWidth:0,
	    itemSpacing:-10,
	    padding:0
	  });

		me.callParent(arguments);
   },
   
   siteChartExpand:function(o_){
  	 var win = Ext.create("Ext.window.Window",{
  			modal:true,
  			title:"Site Trend Chart",
  			height:600,
    	  width:850,
  			layout: {type: 'vbox',align: 'stretch'},
  			items:[{xtype:"sitetrendchart", itemId:"sitetrend", flex:1, expanded:true}]
		  });     		
		  win.show();
		  Ext.ComponentQuery.query("sitetrendchart")[0].fireEvent("sitetrendexpand", o_ ? o_ : "");
   },
   
   lineChartShot:function() {
  	 this.siteChartExpand({screenshot:true});
   }
  	 

});

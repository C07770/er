Ext.define("eRecon_web.view.AccountTypeDefaultLU.AccountTypeDefaultSearch", {
    extend: "Ext.form.Panel",
    alias: "widget.AccountTypeDefault_Search",
    defaults: {labelAlign: "side"},
    bodyPadding: 10,

    initComponent: function () {
    	
    	this.benchmarkStore = Ext.create("eRecon_web.store.AgingBenchmarkStore",{});
    	
    	  this.activeStore = Ext.create('Ext.data.Store', {
              fields: ['ActiveName', 'ActiveValue'],
              data: [{
                  "ActiveName": "Yes",
                  "ActiveValue": "Y"
              }, {
                  "ActiveName": "No",
                  "ActiveValue": "N"
              }]
          	});
    	
    	var agingType = Ext.create('Ext.data.Store', {
    		fields: ['key', 'value'],
    		data: [{
    		    "key": "G",
    		    "value": "GL"
    		}, {
    		    "key": "S",
    		    "value": "SL"
    		}
    		]
    		});
        
        var riskType = Ext.create('Ext.data.Store', {
    		fields: ['key', 'value'],
    		data: [{
    		    "key": "H",
    		    "value": "High"
    		}, {
    		    "key": "M",
    		    "value": "Medium"
    		}, {
    		    "key": "L",
    		    "value": "Low"
    		}]
    		});
	    	     	
        this.items = [ 
              {
            	  xtype:"fieldcontainer",
                  layout:'hbox',
                  items:[{
                	  	name: "acct_type_id",
		                itemId: "acct_type_id",
		                xtype: "textfield",	
		                flex:8,
		                fieldLabel: 'Sub Account Type<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>'
                  },
                  {
                	  	xtype: "button",
	                    scope: this,
	                    flex:.5,
	                    height:25,
	                    tooltip: "Select SubAccount",
	                    icon: "/static/assets/famfamfam/icons/magnifier.png",
	                    action: "openSearchTree"
                  }]
              },
            {
                name: "acct_aging_type",
                itemId: "acct_aging_type",
                fieldLabel: 'Account Aging Type<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>',
//                fieldLabel: 'Account Aging Type',
                xtype: "combo",
                typeAhead:true,
                valueField: "key",
                displayField: "value",
                store: agingType,
                queryMode:'local'
            } 
            ,
            {
                name: "risk_type",
                itemId: "risk_type",
                xtype: "combo",
                valueField: "key",
                typeAhead:true,
                displayField: "value",
                fieldLabel: 'Risk Type<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>',
//                fieldLabel: 'Risk Type',
                store: riskType,
                queryMode:'local'
            }
            ,
            {
                name: "aging_benchmark",
                itemId: "aging_benchmark",
                xtype: "combo",
                valueField: "key",
                typeAhead:true,
                displayField: "value",
                fieldLabel: 'Aging Benchmark<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>',
//                fieldLabel: 'Aging Benchmark',
                store: this.benchmarkStore
            }
            ,
            ,
            {
                name: "usd_threshold",
                itemId: "usd_threshold",
                xtype: "numberfield",
                fieldLabel: 'USD Threshold<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>'
//               	fieldLabel: 'USD Threshold'
            },
            {
                name: "active_flag",
                itemId: "active_flag",
                xtype: "combo",
                typeAhead:true,
                queryMode:'local',
                valueField: "ActiveValue",
                displayField: "ActiveName",
                fieldLabel: 'Active Flag<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>',
//                fieldLabel: 'Active Flag',
                store: this.activeStore
            }
        ];
        
        this.dockedItems = [
            {
                dock: "top", 
                xtype: "toolbar",
                items: [
                {
                    xtype: "button",
                    text: "Insert",
                    iconCls: 'iconAdd',
                    scope: this,
                    action: "insert"
                },
                "-",
                {
                    xtype: "button",
                    text: "Search",
                    iconCls: 'iconMagnifier',	
                    scope: this,
                    action: "search"
                },
                "-",
                {
                	xtype: "button",
                    text: "Clear",
                    iconCls: 'iconTableDelete',
                    scope: this,
                    action: "clear"
                }
            ]
            },{
				dock: "bottom", 
				xtype: "toolbar",
				items: [
					{
					    xtype: "label",
					    text: "* Indicates Mandatory fields while inserting a new record"
					}
				]
            }
        ];

        this.callParent(arguments);
    }
});

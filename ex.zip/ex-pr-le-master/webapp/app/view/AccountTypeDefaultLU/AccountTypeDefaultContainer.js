Ext.define("eRecon_web.view.AccountTypeDefaultLU.AccountTypeDefaultContainer",{
	extend: "Ext.container.Container", 
	alias: "widget.AccountTypeDefault_Container",   
    layout: "border",
    
 initComponent: function (config) {

    	this.AccountTypeDefaultGrid = Ext.create("eRecon_web.view.AccountTypeDefaultLU.AccountTypeDefaultGrid", {
            title: "Account Type Default LU",
            region: "center",
            flex: 4
        });
    	
    	this.AccountTypeDefaultSearch = Ext.create("eRecon_web.view.AccountTypeDefaultLU.AccountTypeDefaultSearch", {
    		title: "Search/Insert Account Type Defaults",
            region: "west",
            collapsible: true,          
            collapsed: false,
            flex: 1.5
            });

    	
    	this.items = [    	              
    	              this.AccountTypeDefaultGrid,
    	              this.AccountTypeDefaultSearch
    	             ];
    	
    	this.listeners =
        {
    			scope: this,
                "activate": function () {                        	
                	var AccountTypeDefaultGridStore = this.AccountTypeDefaultGrid.getStore();
                	AccountTypeDefaultGridStore.directOptions = {};
                	AccountTypeDefaultGridStore.getProxy().extraParams = {
    	                0: null
    	                	
    	            };
                	AccountTypeDefaultGridStore.load({
    	                callback: function (records, operation, success) {
    	                }
    	            });
              }  
        };
    	
    	this.callParent(config);
	}
	
});

Ext.define("eRecon_web.view.AccountTypeDefaultLU.SubAccountTree", {
    extend: "Ext.tree.TreePanel",
    alias: "widget.SubAccount_Tree",
    bodyPadding: 10,    
    floating:true,	
    modal:true,
//    store:AccountTypeDefaultTreeStore,

    initComponent: function () {
        
        /*this.items = [{
                      	xtype: "button",
                          text: "SelectSubAccount",
                          scope: this,
                          action: "clear"
                      }];*/
    	
    	this.treeStore = Ext.create("eRecon_web.store.AccountTypeDefaultTreeStore",{});
        this.treeStore.load({
            callback: function (records, operation, success) {
            }
        });
        
      /*  this.columns = [{
        	xtype:'treecolumn',
        	text:'Title',
        	dataIndex:'title'
        }];
           */       
        this.callParent(arguments);
        }
    });

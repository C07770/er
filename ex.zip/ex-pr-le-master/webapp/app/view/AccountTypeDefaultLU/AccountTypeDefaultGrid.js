Ext.define("eRecon_web.view.AccountTypeDefaultLU.AccountTypeDefaultGrid", {
    extend: "Ext.grid.Panel",
    alias: "widget.AccountTypeDefault_Grid",    
    autoScroll: true,
    forceFit: true,    
    columnLines: true,
    multiSelect:true,
    store: "eRecon_web.store.AccountTypeDefaultStore",
    enableColumnMove: true,    
    border: false,
    
    viewConfig: {
        emptyText: "No details available."},
                

    initComponent: function () {
        var me = this;
        me.stateful = false;  
        
        this.benchmarkStore = Ext.create("eRecon_web.store.AgingBenchmarkStore",{});
        
        var agingType = Ext.create('Ext.data.Store', {
    		fields: ['key', 'value'],
    		data: [{
    		    "key": "G",
    		    "value": "GL"
    		}, {
    		    "key": "S",
    		    "value": "SL"
    		}
    		]
    		});
        
        var riskType = Ext.create('Ext.data.Store', {
    		fields: ['key', 'value'],
    		data: [{
    		    "key": "H",
    		    "value": "High"
    		}, {
    		    "key": "M",
    		    "value": "Medium"
    		}, {
    		    "key": "L",
    		    "value": "Low"
    		}]
    		});
        
        me.store = Ext.create("eRecon_web.store.AccountTypeDefaultStore",{});
        me.store.directOptions = {};
        me.store.getProxy().extraParams = {
            0: null,
            1:null,
            2:null,
            3:null,
            4:null            	
        };
        me.store.load({
            callback: function (records, operation, success) {
            }
        });
        
        this.activeStore = Ext.create('Ext.data.Store', {
            fields: ['ActiveName', 'ActiveValue'],
            data: [{
                "ActiveName": "Yes",
                "ActiveValue": "Yes"
            }, {
                "ActiveName": "No",
                "ActiveValue": "No"
            }]
        	});
        me.plugins= [
                     Ext.create('Ext.grid.plugin.CellEditing', {
                         clicksToEdit: 1,
                         allowBlank:false
                     })
        ];
        
        var rowEditing = Ext.create('Ext.grid.plugin.RowEditing', {
            clicksToMoveEditor: 1,
            autoCancel: false,
            listeners:{
            	beforeedit:
            		function (editor,e,eOpts){
//            			debugger;
            		}
            	
            }
        });
        
        me.dockedItems = [
                          {
                           	dock: "top", 
                           	xtype: "toolbar", 
                           	items: [
                           	   {
                                	xtype: "button",
                                	tooltip: "Save",
                                	icon: "/static/assets/famfamfam/icons/disk.png",                   	
                                	action:"save",
                                	text:"Save",
                                	scope:this
                                },
                                "-"
                                ,
                                {
                                	xtype: "button",
                                	tooltip: "Export to Excel",
                                	text:"Export to Excel",
                                	icon: "/static/assets/famfamfam/icons/page_white_excel.png",  
                                	action:"acctDefaultExcel"
                                },
                                "-"
                                ,                                
                                {
                                	xtype: "button",
                                	tooltip: "Delete",
                                	text:"Delete",
                                	iconCls: 'iconDelete',
                                	handler : function() {
                                		var i;
                                		var selModel = this.up('grid').getSelectionModel();
                                		var selRec = selModel.getSelection();
                                		for(i=0;i<selRec.length;i++)
                                			{
//                                				if(Object.getOwnPropertyNames(selRec[i].modified).length==0) // Blocked delete if the record is edited his value
//                                   				{
                                   					this.up('grid').store.remove(selRec[i]);
                                       				selRec[i].data.action = "DELETE";
//                                   				}
                                			}
                                	}
                                }]
                          },                  
                          {
                             xtype: "pagingtoolbar",
                             dock: "bottom",
                             displayInfo: true,
                             store: me.store,
                             plugins: [Ext.create("eRecon_web.plugins.PageSize")]

                         }
                         ];
        
               
        me.columns = [
            {	
	        	header: "Sub Account Type", 
	            dataIndex: "description",
	            renderer: function setFontColor(value, meta, record){	            	
            		var newvalue;
            		newvalue = "<span style='color:#989898' >"+value+"</span>";            			          		            		            		
            		return newvalue;
            	}
            }
        	,
        	{	header: "Acct Aging Type", 
            	dataIndex: "acct_aging_type",
            	editor: 
            	{
            		xtype: 'combo',            	
	                store: agingType,
	                displayField: 'value',
				    valueField: 'key'
            	},
            	renderer: function(val){
	            	var index = agingType.findExact('key',val); 
	                if (index != -1){
	                   var rs = agingType.getAt(index).data; 
	                    return rs.value; 
	                }else{
	                	return val;
	                }
                }
            }
            ,
            {	header: "Risk Type", 
            	dataIndex: "risk_type",
            	editor: 
            	{
            		xtype: 'combo',            	
	                store: riskType,
	                displayField: 'value',
				    valueField: 'key'
            	},
            	renderer: function(val){
	            	var index = riskType.findExact('key',val); 
	                if (index != -1){
	                   var rs = riskType.getAt(index).data; 
	                    return rs.value; 
	                }else{
	                	return val;
	                }
                }
            }
            ,
            {	header: "Aging Benchmark", 
            	dataIndex: "aging_benchmark",
            	editor: 
            	{
            		xtype: 'combo',            	
	                store: this.benchmarkStore,
	                displayField: 'value',
	                editable:false, 
				    valueField: 'key',
				    listClass : 'x-combo-list-small'
            	},
            	renderer: function(val){
                    var index = this.benchmarkStore.findExact('key',val); 
                    if (index != -1){
                       var rs = this.benchmarkStore.getAt(index).data; 
                        return rs.value; 
                    }else{
                    	return val;
                    }
                }
            }
            ,
            {	header: "USD Threshold", 
            	dataIndex: "usd_threshold",
	            renderer: function setFontColor(value, meta, record){
            		var newvalue;
            		newvalue = "<span style='color:#989898' >"+value+"</span>";            			          		
            		return newvalue;
            	}/*,
	            editor: 
	        	{
	        		xtype: 'textfield'
	        	}*/
            },
            {	header: "ActiveFlag",
            	dataIndex: "active_flag",
            	editor: 
            	{
            		xtype: 'combo',            	
	                store: this.activeStore,
	                valueField: "ActiveValue",
	                displayField: "ActiveName"
            	}
            },
            {	header: "Change By", 
            	dataIndex: "change_by",
            	hidden:true,
	            renderer: function setFontColor(value, meta, record){
            		var newvalue;
            		newvalue = "<span style='color:#989898' >"+value+"</span>";            			          		
            		return newvalue;
            	}
            }
            ,            
            {	header: "Change Type", 
            	hidden:true,
            	dataIndex: "change_type",
	            renderer: function setFontColor(value, meta, record){
            		var newvalue;
            		newvalue = "<span style='color:#989898' >"+value+"</span>";            			          		
            		return newvalue;
            	}
            },
            {	header: "Change Dt", 
            	dataIndex: "change_dt",
            	hidden:true,
	            renderer: function setFontColor(value, meta, record){
            		var newvalue;
            		newvalue = "<span style='color:#989898' >"+value+"</span>";            			          		
            		return newvalue;
            	}
            },
            {	header: "Create Dt", 
            	hidden:true,
            	dataIndex: "create_dt",
	            renderer: function setFontColor(value, meta, record){
            		var newvalue;
            		newvalue = "<span style='color:#989898' >"+value+"</span>";            			          		
            		return newvalue;
            	}
            }   ];         
          
        me.callParent(arguments);
        }
    });

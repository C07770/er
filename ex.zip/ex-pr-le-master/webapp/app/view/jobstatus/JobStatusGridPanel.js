Ext.define('eRecon_web.view.jobstatus.JobStatusGridPanel', {
       extend : 'Ext.grid.Panel',
       store : 'eRecon_web.store.JobStatusStore',
       alias : 'widget.jobstatusgridpanel',
       autoScroll : true,
       forceFit : true,
       columnLines : true,
       enableColumnMove : true,
       border : false,
       autoLoad : false,

       initComponent : function() {

              var me = this;

              me.dockedItems = [
                                {
                                     xtype: 'toolbar',
                                     dock: 'bottom',

                                     items: [
                                             {
                                                   xtype:'pagingtoolbar',
                                                   store: 'eRecon_web.store.JobStatusStore',
                                                   displayInfo: true,
                                                   displayMsg: 'Displaying Job Statuses {0} - {1} of {2}',
                                                   emptyMsg: "No job statuses to show"
                                             }    
                                             ]

                                }
                                ];

              me.columns = [
                            {
                              header : 'Schedule ID',
                              dataIndex : 'scheduleId',
                              flex : 1
                            }, {
                              header : 'Profile Name',
                              dataIndex : 'profileName',
                              editor : {
                                     xtype : 'textfield'
                              },
                              flex : 1
                            }, {
                              header : 'File Name',
                              dataIndex : 'fileName',
                              editor : {
                                     xtype : 'textfield'
                              },
                              flex : 3,
                              renderer : me.fileNameRenderer
                            }, {
                              header : 'Job Start',
                              dataIndex : 'loadStart',
                              flex : 1
                            }, {
                              header : 'Job End',
                              dataIndex : 'loadEnd',
                              flex : 1
                            }, {
                              header : 'Status',
                              dataIndex : 'loadStatus',
                              editor : {
                                     xtype : 'textfield'
                              },
                              flex : 1,
                              renderer: me.statusColumnRenderer
                            }, {
                                header : 'Bad File',
	                            editor : {
	                                   xtype : 'textfield'
	                            },
	                            flex : 1,
	                            dataIndex: 'badFileName',
	                            renderer: me.badFileRenderer
	                          },{
                              header : 'Status Details',
                              dataIndex : 'loadStatusDetails',
                              editor : {
                                     xtype : 'textfield'
                              },
                              flex : 1,
                              hidden: true
                            }, {
                              header : 'Change By',
                              dataIndex : 'changeBy',
                              editor : {
                                     xtype : 'textfield'
                              },
                              flex : 1,
                              hidden: true
                            }, {
                              header : 'Change Date',
                              dataIndex : 'changeDt',
                              flex : 1,
                              hidden: true
                            }, {
                              header : 'Orig Filename',
                              dataIndex : 'origFilename',
                              editor : {
                                     xtype : 'textfield'
                              },
                              flex : 1,
                              hidden: true
                            },{
                                header : 'Load Type',
	                            dataIndex : 'loadType',
	                            flex : 1,
	                            hidden: true
	                         } 
                            ];

              me.stateful = false;

              me.callParent(arguments);
              
              me.getView().getSelectionModel().on('selectionchange', function(sm, selectedRows, opts) {
                     console.log("selectionchange");
                     if(selectedRows.length > 0) {
                         console.log("selectionchange2");
                            me.fireEvent('jobStatusGridRowSelectionChange', selectedRows[0].get("scheduleId"));
                     }
              },me);
       },
       fileNameRenderer: function(val, meta, rec, col, store, view) {

    	   /**
    	    * For GL Load dont show any link.
    	    */

    	   if(rec.get("profileName") === 'GL Load') { 
    		   return val;
    	   }

    	   if((rec.get("loadStatus") === 'C' && rec.get("loadType") === 'U') || (rec.get("loadStatus") === 'X' && rec.get("loadType") === 'U') || (rec.get("loadStatus") === 'F' && rec.get("loadType") === 'U') || (rec.get("loadStatus") === 'C' && rec.get("loadType") === 'D')) {
    		   if (!val) {
    			   return '';
    		   }
    		   var fileArray = val.split('|');
    		   var resp = '';
    		   for(var i = 0; i < fileArray.length; i++)
    		   {
    			   // Trim the excess whitespace.
    			   fileArray[i] = fileArray[i].replace(/^\s*/, "").replace(/\s*$/, "");
    			   // Add additional code here, such as:
    			   resp = resp + '<a target="_blank" href=\'jobstatusDownload.up?scheduleId=' + rec.get("scheduleId") + '&fileName=' + fileArray[i] + '\'>' + fileArray[i] + '</a><br>';
    		   }

    		   if(fileArray.length > 1) {
    			   return resp;
    		   } else {
    			   return '<a target="_blank" href=\'jobstatusDownload.up?scheduleId=' + rec.get("scheduleId")  + '&fileName=' + val +  '\'>' + val + '</a>';
    		   }
    	   } 

    	   return val;
       }, 
       badFileRenderer:function(val, meta, rec, col, store, view){
    	   if(val == '' || val == null) {
    		   return "";
    	   }

    	   if((rec.get("loadStatus") === 'C') || (rec.get("loadStatus") === 'E') || (rec.get("loadStatus") === 'F')){
    		   return '<a target="_blank" href=\'jobstatusDownload.up?fileType=BadFile&scheduleId=' + rec.get("scheduleId")  + '&fileName=' + val +  '\'>' + val + '</a>';
    	   }

    	   return val;
       },

       statusColumnRenderer: function(value, meta, rec, col, store, view) {
    	   if (!value) {
    		   return '';
    	   }
    	   switch(value)
    	   {
    	   case 'U':
    		   return 'Uploaded'
    		   break;
    	   case 'S':
    		   return 'Submitted'
    		   break;
    	   case 'C':
    		   return 'Completed'
    		   break;
    	   case 'R':
    		   return 'Running'
    		   break;
    	   case 'F':
    		   return 'Failed'
    		   break;
    	   case 'X': 
    		   return 'Exception'
    		   break;
    	   default:
    		   return value;
    	   }
       }

});

/**
 * @author ss58446 - Sunil Murthy
 */

Ext.define("eRecon_web.view.jobstatus.JobStatusFilterForm", {
	extend : "Ext.form.Panel",
	alias : "widget.jobstatus_filterform",
	// defaults: {labelAlign: "side"},
	bodyPadding : 10,
	items : [ {
		name : "scheduleId",
		xtype : "numberfield",
		fieldLabel : "Schedule Id",
		width: 200
	}, {
		name : "profileName",
		xtype : "textfield",
		fieldLabel : "Profile Name",
		width: 200
	} ],

	dockedItems : [ {
		dock : "bottom",
		xtype : "toolbar",
		items : [ "->", {
			xtype : "button",
			text : "Search",
			scope : this,
			action : "search"
		}, {
			xtype : "button",
			text : "Clear",
			scope : this,
			action : "reset"
		} ]
	} ],

	initComponent : function() {
		this.callParent(arguments);
	}
});

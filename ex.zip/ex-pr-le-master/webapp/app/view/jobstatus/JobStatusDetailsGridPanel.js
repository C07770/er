Ext.define('eRecon_web.view.jobstatus.JobStatusDetailsGridPanel', {

	extend : 'Ext.grid.Panel',
	store : 'eRecon_web.store.JobStatusDetailStore',
	alias : 'widget.jobstatusgriddetailspanel',
	plugins : [ {
		ptype : 'cellediting'
	} ],

	columns : [ {
		header : 'Schedule Id',
		dataIndex : 'scheduleId',
		flex : 1
	}, {
		header : 'Audit Trail Id',
		dataIndex : 'auditTrialId',
		flex : 1
	}, {
		header : 'Description',
		dataIndex : 'auditTrailDesc',
		flex : 4,
		editor : {
			xtype : 'textfield'
		}
	}, {
		header : 'Change By',
		dataIndex : 'changeBy',
		flex : 1,
		editor : {
			xtype : 'textfield'
		}
	}, {
		header : 'Change Date',
		dataIndex : 'changeDt',
		flex : 1
	}],
	
	 initComponent: function () {
	        var me = this;
	      
	        me.dockedItems = [
	            {
	                dock: "top", xtype: "toolbar", items: [
	                {
	                    xtype: "button",
	                    action: "export",
	                    text: "Export",
	                    icon: "/static/assets/famfamfam/icons/page_excel.png",
	                    tooltip: "Export to Excel"
	                    //id: "audittrail_export"
	                }
	            ]
	            }
	        ];
	        
	        me.callParent(arguments);
	 }
});

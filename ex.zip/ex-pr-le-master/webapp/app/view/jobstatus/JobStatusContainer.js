Ext.define("eRecon_web.view.jobstatus.JobStatusContainer", {
    extend: "Ext.container.Container",
    alias: "widget.jobstatus_container",
    requires: ["eRecon_web.view.jobstatus.JobStatusGridPanel", 
               "eRecon_web.view.jobstatus.JobStatusDetailsGridPanel",
               "eRecon_web.view.jobstatus.JobStatusFilterForm"],
    layout: "border",
    initComponent: function (config) {
        this.jobStatusGridPanel = Ext.create("eRecon_web.view.jobstatus.JobStatusGridPanel", {
        	title: 'Job Status',
        	region: "center",
        	/*split: true,*/
            flex: 3,
            animCollapse: false/*,
            listeners: {
                scope: 'session'
            }*/
        });
        
        this.jobStatusDetailsGridPanel = Ext.create("eRecon_web.view.jobstatus.JobStatusDetailsGridPanel", {
        	title: 'Audit Trail',
        	region: "south",
            flex: 4
        });
        
        
        this.filterForm = Ext.create("eRecon_web.view.jobstatus.JobStatusFilterForm", {
        	title: 'Filter',
        	region: "west",
        	minWidth: 100,
            maxWidth: 250,
            /*floatable: false,*/
            collapsible: true
        });
        
        this.items = [
            this.jobStatusGridPanel, 
            this.jobStatusDetailsGridPanel,
            this.filterForm
        ];
        
        this.callParent(config);
    }
});

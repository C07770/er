Ext.define('eRecon_web.view.SampleGridPanel',{

	extend: 'Ext.grid.Panel',
	store : 'eRecon_web.store.BankingGroupStore',
	alias:	'widget.samplegridpanel',
	plugins : [ 
		{ptype : 'cellediting'} 
	],
				
	columns : [
		{ 
		header:'accounts', 
		dataIndex: 'accounts',
		flex:1
		},
		{ 
		header:'bankingGroup', 
		dataIndex: 'bankingGroup',
		flex:1
		,editor:{xtype:'textfield'} 
		
		},
		{ 
		header:'bgrp', 
		dataIndex: 'bgrp',
		flex:1
		,editor:{xtype:'textfield'} 
		
		},
		{ 
		header:'partialSubmittedAccounts', 
		dataIndex: 'partialSubmittedAccounts',
		flex:1
		},
		{ 
		header:'reconPeriod', 
		dataIndex: 'reconPeriod',
		flex:1
		,editor:{xtype:'textfield'} 
		
		},
		{ 
		header:'submittedAccounts', 
		dataIndex: 'submittedAccounts',
		flex:1
		},
		{ 
		header:'unSubmittedAccounts', 
		dataIndex: 'unSubmittedAccounts',
		flex:1
		}],
		
	tbar : [ 
		{text : 'Load'}, 
		{text : 'Add'}, 
		{text : 'Delete'}, 
		{text : 'Save'} 
	]
});
	

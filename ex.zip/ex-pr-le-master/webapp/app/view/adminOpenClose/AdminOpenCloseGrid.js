Ext.define("eRecon_web.view.adminOpenClose.AdminOpenCloseGrid", {
    extend: "Ext.grid.Panel",
    alias: "widget.secadmin_adminopencyclegrid",    
    autoScroll: true,
    forceFit: true,    
    columnLines: true,
    multiSelect:true,
    store: "eRecon_web.store.AdminOpenCycleStore",
    enableColumnMove: true,    
    border: false,
    viewConfig: {
        emptyText: "No details available."},
                

    initComponent: function () {
        var me = this;
        me.stateful = false;
        this.reconStore = Ext.create("eRecon_web.store.AdminOpenCloseReconStore", {});
        this.activeStore = Ext.create('Ext.data.Store', {
            fields: ['ActiveName', 'ActiveValue'],
            data: [{
                "ActiveName": "<--Select-->",
                "ActiveValue": ""
            },
            {
                "ActiveName": "Yes",
                "ActiveValue": "Y"
            }, {
                "ActiveName": "No",
                "ActiveValue": "N"
            }]
        });
        this.openStore = Ext.create('Ext.data.Store', {
            fields: ['openName', 'openValue'],
            data: [
            {
                "openName": "<--Select-->",
                "openValue": null
            },
            {
                "openName": "Open",
                "openValue": "O"
            },{
                "openName": "Adjust",
                "openValue": "A"
            },
            {
                "openName": "Close",
                "openValue": "C"
            }
            ]
        	});
        me.plugins= [
	        Ext.create('Ext.grid.plugin.CellEditing', {
	            clicksToEdit: 2,
	            allowBlank:false
	        })
	    ];
        me.dockedItems = [
             {
              	dock: "top", 
              	xtype: "toolbar", 
              	items: [
              	   {
                   	xtype: "button",
                   	tooltip: "Save",
                   	text:"Save",
                   	icon: "/static/assets/famfamfam/icons/disk.png",                   	
                   	action:"adminOpenClose-save",
                   	scope:this
                   },
                   "-"
                   ,
                   {
                   	xtype: "button",
                   	tooltip: "Export to Excel",
                   	text:"Export to Excel",
                   	icon: "/static/assets/famfamfam/icons/page_white_excel.png",                   
                    //href:'\MaintainScreenExcelDownlaod?downloadType=UserRoleMapping',
                    action : "adminOpenClose-excel-button",
                    id: 'adminOpenClose-excel-button'
                   },
                   "-"
                   ,
                   {
                   	xtype: "button",
                   	tooltip: "Delete",
                   	text:"Delete",
                   iconCls: 'iconDelete',
                   	handler : function() {
                   		var i;
                   		var selModel = this.up('grid').getSelectionModel();
                   		var selRec = selModel.getSelection();
                   		for(i=0;i<selRec.length;i++)
                   			{
                   				selRec[i].data.action = "DELETE";
                   				this.up('grid').store.remove(selRec[i]);
                   			}
                   	}
                   }]
             },                  
             {
                xtype: "pagingtoolbar",
                dock: "bottom",
                displayInfo: true,
                store: me.store,
                plugins: [Ext.create("eRecon_web.plugins.PageSize")]

            }];
        
        me.columns = [
                      
            {	header: "Recon period", 
            	dataIndex: "reconPeriod"
            }
            ,
            {	header: "Business Unit", 
	        	dataIndex: "businessUnit"
	        },
	        {	header: "Open", 
	        	dataIndex: "open",
		        editor: 
	        	{
	        		xtype: 'combo',            	
	                store: this.openStore,
	                valueField: "openValue",
	                displayField: "openName"
	        	}
	        },
	        {	header:'Open Close Date', 
	        	dataIndex: 'openclosedate',
	        	xtype: "datecolumn",
	        	format : "m/d/Y",
	            editor:{
	        		xtype: 'datefield',
	        		format : "m/d/Y"
	        	}
	        },
	        {	header: "Active Flag", 
	        	dataIndex: "activeFlag",
		        editor: 
	        	{
	        		xtype: 'combo',            	
	                store: this.activeStore,
	                valueField: "ActiveName",
	                displayField: "ActiveName"
	        	}
	        }
                              
        ]; 
        
        me.callParent(arguments);
        }
    });

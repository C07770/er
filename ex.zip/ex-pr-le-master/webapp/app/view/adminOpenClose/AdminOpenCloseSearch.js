Ext.define("eRecon_web.view.adminOpenClose.AdminOpenCloseSearch", {
    extend: "Ext.form.Panel",
    alias: "widget.adminOpenCloseSearch",
    defaults: {labelAlign: "side"},
    bodyPadding: 10,

    initComponent: function () {
    	this.activeStore = Ext.create('Ext.data.Store', {
            fields: ['ActiveName', 'ActiveValue'],
            data: [
             {
                "ActiveName": "<--Select-->",
                "ActiveValue": null
            },      
            {
                "ActiveName": "Yes",
                "ActiveValue": "Y"
            }, {
                "ActiveName": "No",
                "ActiveValue": "N"
            }
            ]
        	});
    	
        this.openStore = Ext.create('Ext.data.Store', {
            fields: ['openName', 'openValue'],
            data: [
            {
                "openName": "<--Select>",
                "openValue": null
            },
            {
                "openName": "O",
                "openValue": "O"
            },{
                "openName": "A",
                "openValue": "A"
            },
            {
                "openName": "C",
                "openValue": "C"
            }
            ]
        	});
        this.reconStore = Ext.create("eRecon_web.store.AdminOpenCloseReconStore", {});
        this.businessStore = Ext.create("eRecon_web.store.AdminOpenCloseBusinessUnitStore", {});
        this.items = [            
            {
            	name: "reconPeriod",
	            itemId: "reconPeriod-combo",
	            xtype: "combo",
	            fieldLabel: 'Recon Period<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>',
	            store: this.reconStore,
	            typeAhead: true,
	            forceSelection: true,
	            selectOnFocus: true,
            	triggerAction: 'all',
            	editable: true,
	            queryMode: 'remote',
	            valueField: "key",
	            displayField: "value"
            },
            {
                name: "businessUnit",
                itemId: "businessunit-combo",
                xtype: "combo",
                store: this.businessStore,
                fieldLabel: 'Business Unit<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>',
                typeAhead:true,
                queryMode: 'remote',
                selectOnFocus:true,
	            valueField: "key",
	            displayField: "value"
            },
            {
                name: "open",
                itemId: "open",
                xtype: "combo",
                store: this.openStore,
                fieldLabel: "Open",
                typeAhead:true,
                queryMode: 'local',
	            valueField: "openValue",
	            displayField: "openName"
            },
            {
                name: "openclosedate",
                itemId: "openclosedate",
                xtype: "datefield",
                fieldLabel: "Open Close Date"
            },
            {
                name: "activeFlag",
                itemId: "activeFlag-combo",
                xtype: "combo",
                fieldLabel: "Active Flag",
	            store: this.activeStore,
	            typeAhead:true,
	            queryMode: 'local',
	            valueField: "ActiveValue",
	            displayField: "ActiveName"
                	
            }
        ];

        this.dockedItems = [
            {
                dock: "top", 
                xtype: "toolbar",
                items: [
                {
                    xtype: "button",
                    text: "Insert",
                    iconCls: 'iconAdd',
                    scope: this,
                    action: "AdminOpenClose-add"
                },
                "-",
                {
                    xtype: "button",
                    text: "Search",
                    iconCls: 'iconMagnifier',
                    scope: this,
                    action: "AdminOpenClose-search"
                },
                "-",
                {
                	xtype: "button",
                    text: "Clear",
                    iconCls: 'iconTableDelete',
                    scope: this,
                    action: "AdminOpenClose-clear"
                }
            ]
            },{
				dock: "bottom", 
				xtype: "toolbar",
				items: [
					{
					    xtype: "label",
					    text: "* Indicates Mandatory fields while inserting a new record"
					}
				]
	        }
        ];

        this.callParent(arguments);
    }
});

Ext.define("eRecon_web.view.adminOpenClose.AdminOpenCloseContainer",{
	extend: "Ext.container.Container", 
	alias: "widget.secadmin_openclosecontainer",   
    layout: "border",
    
 initComponent: function (config) {
    	this.openclosegrid = Ext.create("eRecon_web.view.adminOpenClose.AdminOpenCloseGrid", {
    		title: "Open Close Cycle",
            region: "center",
            flex: 4
            });

    	this.openclosesearch = Ext.create("eRecon_web.view.adminOpenClose.AdminOpenCloseSearch", {
            title: "Insert/Search Open Cycle",
            region: "west",
            split: true,
            flex: 1.4,
            collapsible: true,
            animCollapse: false

        });
    	
    	this.items = [    	              
    	              this.openclosegrid,
    	              this.openclosesearch
    	             ];
    	
    	this.listeners =
        {
        		scope: this,
                "activate": function () {              
                	var opencloseStore = this.openclosegrid.getStore();
                	opencloseStore.directOptions = {};
                	opencloseStore.getProxy().extraParams = {
    	                0: null
    	            };
    	            opencloseStore.load({
    	                callback: function (records, operation, success) {
    	                }
    	            });
              }  
        };
    	             
    	
    	this.callParent(config);
	}
	
});

Ext.define("eRecon_web.view.accountOwnerLu.AccountOwnerLuContainer",{
	extend: "Ext.container.Container", 
	alias: "widget.secadmin_accountownerlucontainer",   
    layout: "border",
    
 initComponent: function (config) {
    	this.accountownerlugrid = Ext.create("eRecon_web.view.accountOwnerLu.AccountOwnerLuGrid", {
    		title: "Account Owner Lu",
            region: "center",
            flex: 4
            });

    	this.accountownerlusearch = Ext.create("eRecon_web.view.accountOwnerLu.AccountOwnerLuSearch", {
            title: "Insert/Search Account Owner Lu",
            region: "west",
            split: true,
            flex: 1.5,
            collapsible: true,
            animCollapse: false

        });
    	
    	this.items = [    	              
    	              this.accountownerlugrid,
    	              this.accountownerlusearch
    	             ];
    	
    	this.listeners =
        {
        		scope: this,
                "activate": function () {              
                	var accountownerluStore = this.accountownerlugrid.getStore();
                	accountownerluStore.directOptions = {};
                	accountownerluStore.getProxy().extraParams = {
    	                0: null
    	            };
    	            accountownerluStore.load({
    	                callback: function (records, operation, success) {
    	                }
    	            });
              }  
        };
    	             
    	
    	this.callParent(config);
	}
	
});

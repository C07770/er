Ext.define("eRecon_web.view.accountOwnerLu.AccountOwnerLuGrid", {
    extend: "Ext.grid.Panel",
    alias: "widget.secadmin_accountownerlugrid",    
    autoScroll: true,
    forceFit: true,    
    columnLines: true,
    multiSelect:true,
    store: "eRecon_web.store.AccountOwnerLuStore",
    enableColumnMove: false,  
	enableColumnHide:false,	
    border: false,
    viewConfig: {
        emptyText: "No details available."},
                

    initComponent: function () {
        var me = this;
        me.stateful = false;
        me.dockedItems = [
             {
              	dock: "top", 
              	xtype: "toolbar", 
              	items: [
              	   {
                   	xtype: "button",
                   	tooltip: "Save",
                   	text:"Save",
                   	icon: "/static/assets/famfamfam/icons/disk.png",                   	
                   	action:"acctOwnerLu-save",
                   	scope:this
                   },
                   {
                   	xtype: "button",
                   	tooltip: "Export to Excel",
                   	text:"Export to Excel",
                   	icon: "/static/assets/famfamfam/icons/page_white_excel.png",                   
                    action : "acctOwnerLu-excel",
                    id: 'acctOwnerLu-excel'
                   },
                   "-"
                   ,
                   {
                   	xtype: "button",
                   	tooltip: "Delete",
                    iconCls: 'iconDelete',
                    text:"Delete",
                   	handler : function() {
                   		var i;
                   		var selModel = this.up('grid').getSelectionModel();
                   		var selRec = selModel.getSelection();
                   		for(i=0;i<selRec.length;i++)
                   			{
                   				selRec[i].data.action = "DELETE";
                   				this.up('grid').store.remove(selRec[i]);
                   			}
                   	}
                   }]
             },                  
             {
                xtype: "pagingtoolbar",
                dock: "bottom",
                displayInfo: true,
                store: me.store,
                plugins: [Ext.create("eRecon_web.plugins.PageSize")]

            }];
        
        me.columns = [
                      
            {	header: "Account Owner", 
            	dataIndex: "acct_owner"
            }
            ,
            {	header: "Account Owner Backup", 
            	dataIndex: "acct_owner_backup"
            }
                              
        ]; 
        
        me.callParent(arguments);
        }
    });

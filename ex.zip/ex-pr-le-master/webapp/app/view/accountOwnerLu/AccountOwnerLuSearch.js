Ext.define("eRecon_web.view.accountOwnerLu.AccountOwnerLuSearch", {
    extend: "Ext.form.Panel",
    alias: "widget.secadmin_accountownerlusearch",
    defaults: {labelAlign: "side"},
    bodyPadding: 10,

    initComponent: function () {
	    	 

        this.items = [            
            {
                name: "acct_owner",
                itemId: "accountOwner-text",
                xtype: "textfield",
                fieldLabel: 'ACCOUNT OWNER<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>'
            },
            {
                name: "acct_owner_backup",
                itemId: "accountOwnerBackup-text",
                xtype: "textfield",
                fieldLabel: 'ACCOUNT OWNER BACKUP<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>'
            }
        ];

        this.dockedItems = [
            {
                dock: "top", 
                xtype: "toolbar",
                items: [
                {
                    xtype: "button",
                    text: "Insert",
                    iconCls: 'iconAdd',
                    scope: this,
                    action: "acctOwnerLu-add"
                },
                "-",
                {
                    xtype: "button",
                    text: "Search",
                    iconCls: 'iconMagnifier',
                    scope: this,
                    action: "acctOwnerLu-search"
                },
                "-",
                {
                	xtype: "button",
                    text: "Clear",
                    iconCls: 'iconTableDelete',
                    scope: this,
                    action: "acctOwnerLu-clear"
                }
            ]
            },{
					dock: "bottom", 
					xtype: "toolbar",
					items: [
						{
						    xtype: "label",
						    text: "* Indicates Mandatory fields while inserting a new record"
						}
					]
			}
        ];

        this.callParent(arguments);
    }
});

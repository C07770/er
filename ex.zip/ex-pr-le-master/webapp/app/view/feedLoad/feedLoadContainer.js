Ext.define("eRecon_web.view.feedLoad.feedLoadContainer", {
    extend: "Ext.container.Container", alias: "widget.feedLoad_container",
    requires: ["eRecon_web.view.feedLoad.feedLoadUploadPanel", "eRecon_web.view.feedLoad.feedLoadGrid", "eRecon_web.view.feedLoad.feedLoadListPanel"],
    layout: "border",
    initComponent: function (config) {
	
    	 this.feedLoadGrid = Ext.create("eRecon_web.view.feedLoad.feedLoadGrid", {
            region: "center",
	        flex: 6,
	        solit: true
        });
    	 
    	this.uploadPanel = Ext.create("eRecon_web.view.feedLoad.feedLoadUploadPanel", {
            flex: 1,
    	autoScroll :true,
    	scrollable :true,
            title:"Upload panel"
        });
        
        this.topPanel = Ext.create('Ext.Panel', {
			layout : {
				type : 'vbox',
				align : 'stretch'
			},
			items : [
				 this.uploadPanel,
				 this.feedLoadGrid 
			],
			flex: 4,
			region: "center"
		});

        this.treePanel = Ext.create("eRecon_web.view.feedLoad.feedLoadListPanel", {
            flex: 1,
            title:"Upload Type",
            region:"west"
        });
	

        this.items = [
            this.topPanel,
            this.treePanel
        ];
        this.callParent(config);
    }
});

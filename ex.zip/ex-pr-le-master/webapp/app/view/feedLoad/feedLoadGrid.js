Ext.define("eRecon_web.view.feedLoad.feedLoadGrid", {
    extend: "Ext.grid.Panel",
    alias: "widget.feedLoad_filehistorygrid",
    autoScroll: true,
    columnLines: true,
    multiSelect:true,
    store:"eRecon_web.store.JobStatusForProfileStore",
    enableColumnMove: true,
    requires: [
               "Ext.ux.grid.FiltersFeature",
               "eRecon_web.view.common.ButtonGridColumn",
               "eRecon_web.view.common.ClickColumn"
           ],
    initComponent: function () {
        var me = this;

        me.stateful = true;


        me.features = [
            {
                ftype: "filters",
                local: true
            }
        ];

        me.dockedItems = [
            {
                dock: "top", xtype: "toolbar", items: [
                "<b>Recent Uploads</b>"
                , "->"
                , {
                    xtype: "button",
                    tooltip: "Refresh File Upload History",
                    text: "Refresh",
                    icon : "/static/assets/famfamfam/icons/arrow_refresh.png",
                    action: "reload_history",
                    scope: this, handler: function () {
                        //console.log("Reload Upload History");
                        this.getStore().load();
                    }
                }
            ]}
        ];

        me.columns = [
                       {
                    	header: "Request ID",
		                dataIndex: "scheduleId",
		                filterable: true,
		                xtype: 'clickColumn',
		                flex: 1,
		                scope: this,
		                listeners: {
		                	clickevent: function (column, record, rowIndex, colIndex, e) {
		        				me.fireEvent('clickevent', column, record, rowIndex, colIndex, e);
		        			}
		        		}
                       },
                      {header: "Profile Name",
                    	  dataIndex: "profileName",
                    	  filterable: true,
                    	  flex: 1,
                    	  filter: {type: "string"}
                      },
                      {header: "File Name <img src='/static/assets/famfamfam/icons/attach.png' style='width:16px;height:16px;' data-qtip='Download File'>",
                    	  dataIndex: "fileName",
                    	  filterable: true,
                    	  flex: 3,
                    	  filter: {type: "string"}
                      },
                      {header: "Job Start",
                    	  dataIndex: "loadStart",
                    	  filterable: true,
                    	  flex: 1,
                    	  filter: {type: "string"}
                      },
                      {header: "Job End",
                    	  dataIndex: "loadEnd",
                    	  filterable: true,
                    	  flex: 1,
                    	  filter: {type: "string"}
                      },
                      {
                    	  header: "Status",
                    	  dataIndex: "status",
                    	  filterable: true,
                    	  flex: 1,
                    	  filter: {type: "string"},
                          renderer: eRecon_web.gbl.constants.statusColumnRenderer
                      },
                      {
                    	  header: "User ID",
                    	  dataIndex: "userId",
                    	  filterable: true,
                    	  flex: 1,
                    	  filter: {type: "string"}
                      },
                      {
                          header: "Process File",
                          sortable: false,
                          xtype: 'buttonGridColumn',
                          align: 'center',
                          scope: this,
                          listeners: {
                    		  buttonclick: function (column, recordIndex, record, view) {
                          		console.log("button click");
                          		me.fireEvent('feedsFileRunProfile', column, recordIndex, record, view);
                          	}
                          },
                          renderer : function(value, metaData, record) {
                      		var cssPrefix = Ext.baseCSSPrefix;
                      		var cls = cssPrefix + ' iconRunProfile';
                      		
                      		if (record.get("status") === 'U') {
                      			return '<div class="' + cls + '">&#160;</div>';
                      		}  else {
                      			return '';
                      		}
                      	}
                      },
                      {
                          header: "Discard",
                          sortable: false,
                          xtype: 'buttonGridColumn',
                          align: 'center',
                          scope: this,
                          listeners: {
                    		  buttonclick: function (column, recordIndex, record, view) {
                          		console.log("button click for discard");
                          		me.fireEvent('feedsFileDiscardProfile', column, recordIndex, record, view);
                          	}
                          },
                          renderer : function(value, metaData, record) {
                      		var cssPrefix = Ext.baseCSSPrefix;
                      		var cls = cssPrefix + ' iconDiscard';
                      		
                      		if (record.get("status") === 'U') {
                      			return '<div class="' + cls + '">&#160;</div>';
                      		}  else {
                      			return '';
                      		}
                      	}
                      },
                      {
                    	  header: "PROFILE ID",
                    	  dataIndex: "profileId",
                    	  flex: 1,
                    	  hidden:true
                      },
                      {
                    	  header: "TEMPLATE ID",
                    	  dataIndex: "templateId",
                    	  flex: 1,
                    	  hidden:true
                      }
                      ];

        me.callParent(arguments);
    }

});

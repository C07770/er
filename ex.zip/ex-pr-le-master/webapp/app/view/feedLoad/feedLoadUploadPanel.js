Ext.define("eRecon_web.view.feedLoad.feedLoadUploadPanel", {
    extend: "Ext.form.Panel",
    alias: "widget.feedLoadupload_panel",
    border: true,
    bodyStyle: "padding:10px;",
    layout :{type:'hbox'},
    initComponent: function () {

        this.defaults = {
            labelAlign: "left",
            margin :"0 15 0 0",
            labelStyle: "font-weight:bold;"
        };
        
        this.items = [
            {
                xtype: "filefield",
                name: "uploadfile",
                fieldLabel: "File",
                buttonText: "Browse...",
            buttonConfig :{
				iconCls :'browseIcon'
			},
                itemId: "feedfileupload-file",
                width: 400,
                labelWidth: 150,
                minWidth: 150
            },
            {
                xtype: "button",
                text: "Upload",
            scope: this,
            iconCls :'uploadIcon',
                handler: function () {
                	this.fireEvent("feedsuploadfile", {clientApp: this.clientApp, cmp: this});
            	}
       
            }
        ];
        this.callParent(arguments);
    }

});

Ext.define("eRecon_web.view.feedLoad.feedLoadListPanel", {
    extend: "Ext.form.Panel",
    alias: "widget.feedLoadType_container",
    defaults: {labelAlign: "side"},
    border :false,
    bodyPadding: 10,
    requires:'Ext.ux.form.MultiSelect',
    initComponent: function () {
    	
                

    	this.items = [
            {
                name: "profile_id",
                itemId: "profile_id-text",
                xtype: "textfield",
                fieldLabel:"Profile ID",
                hidden:true
            },
            {
                name: "template_id",
                itemId: "template_id-text",
                xtype: "textfield",
                fieldLabel:"Template ID",
                hidden:true
            },
            {
                name: "template_text",
                itemId: "template_text-text",
                xtype: "textfield",
                fieldLabel:"Template Text",
                hidden:true
            }
        ];
        this.callParent(arguments);
    }
});

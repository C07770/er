Ext.define("eRecon_web.view.RollbackFeeds.RollbackFeedsSearch", {
    extend: "Ext.form.Panel",
    alias: "widget.RollbackFeeds_Search",
    defaults: {labelAlign: "side"},
    bodyPadding: 10,

    initComponent: function () { 
    	
    	 this.regionStore =  Ext.create("eRecon_web.store.AcctMaintenanceGeoCodeStore", {
         });
         
	    	     	
        this.items = [ 

            {
                name: "scheduleid",
                itemId: "scheduleid",
                fieldLabel: 'SCHEDULEID<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>',
                xtype: "numberfield"
            }
            ,
            {
            	name: "feedid",
                itemId: "feedid",
                fieldLabel: "GL Feeds ID (Genesis Only)",
                xtype: "textfield"
            }
            ,
            {
            	name: "corp",
                itemId: "corp",
                fieldLabel: "CORP",
                xtype: "textfield"
            }
            ,
            {
                name: "proof",
                itemId: "proof",
                xtype: "textfield",  
                fieldLabel: "PROOF"
            }
            ,
            {
                name: "changedate",
                itemId: "date",
                xtype: "datefield",             
                fieldLabel: "DATE",
                allowBlank : true
            }
            ,
            {
                name: "status",
                itemId: "status",
                xtype: "textfield",             
                fieldLabel: "STATUS"
            }
            ,
            {
            	name: "region",
                itemId: "region",
                xtype: "combo",
                valueField: "key",
                displayField: "value",
                fieldLabel: "Region (Genesis Only)",
                store: this.regionStore	        	
	        }
        ];
        
        this.dockedItems = [
            {
                dock: "top", 
                xtype: "toolbar",
                items: [
                {
                    xtype: "button",
                    text: "Insert",
                    iconCls: 'iconAdd',
                    scope: this,
                    action: "insert"
                },
                "-",
                {
                    xtype: "button",
                    text: "Search",
                    iconCls: 'iconMagnifier',
                    scope: this,
                    action: "searchdetails"
                },
                "-",
                {
                	xtype: "button",
                    text: "Clear",
                    iconCls: 'iconTableDelete',
                    scope: this,
                    action: "clear"
                }
            ]
            },{
				dock: "bottom", 
				xtype: "toolbar",
				items: [
					{
					    xtype: "label",
					    text: "* Indicates Mandatory fields while inserting a new record"
					}
				]
	        }
        ];

        this.callParent(arguments);
    }
});

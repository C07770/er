Ext.define("eRecon_web.view.RollbackFeeds.RollbackFeedsContainer",{
	extend: "Ext.container.Container", 
	alias: "widget.RollbackFeeds_Container",   
    layout: "border",
    
 initComponent: function (config) {

    	this.RollbackFeedsGrid = Ext.create("eRecon_web.view.RollbackFeeds.RollbackFeedsGrid", {
            title: "Rollback Feeds",
            region: "center",
            flex: 4
        });
    	
    	this.RollbackFeedsSearch = Ext.create("eRecon_web.view.RollbackFeeds.RollbackFeedsSearch", {
    		title: "Search/Insert Rollback Feeds",
            region: "west",
            collapsible: true,          
            collapsed: false,
            flex: 1.5
            });

    	
    	this.items = [    	              
    	              this.RollbackFeedsGrid,
    	              this.RollbackFeedsSearch
    	             ];
    	
   /* 	this.listeners =
        {
    			scope: this,
                "activate": function () {                        	
                	var RollbackFeedsStore = this.RollbackFeedsGrid.getStore();
                	RollbackFeedsStore.directOptions = {};
                	RollbackFeedsStore.getProxy().extraParams = {
    	                0: null,
    	                1:null,
    	                2:null,
    	                3:null,
    	                4:null,
    	                5:null
    	            };
                	RollbackFeedsStore.load({
    	                callback: function (records, operation, success) {
    	                }
    	            });
              }  
        };*/
    	
    	this.callParent(config);
	}
	
});

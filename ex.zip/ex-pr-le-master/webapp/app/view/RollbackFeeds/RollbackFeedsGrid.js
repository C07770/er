Ext.define("eRecon_web.view.RollbackFeeds.RollbackFeedsGrid", {
    extend: "Ext.grid.Panel",
    alias: "widget.RollbackFeeds_Grid",    
    autoScroll: true,
    forceFit: true,  
    columnLines: true,
    multiSelect:true,
    enableColumnMove: true,  
    enableColumnHide:false,
    store: "eRecon_web.store.RollbackFeedsStore",
    border: false,
    
    viewConfig: {
        emptyText: "No details available."},
                

    initComponent: function () {
        var me = this;
        me.stateful = false;   
        
        this.regionStore =  Ext.create("eRecon_web.store.AcctMaintenanceGeoCodeStore", {
        });
        
        me.plugins= [
                     Ext.create('Ext.grid.plugin.CellEditing', {
                         clicksToEdit: 2,
                         allowBlank:false
                     })
        ];
        
        var rowEditing = Ext.create('Ext.grid.plugin.RowEditing', {
            clicksToMoveEditor: 1,
            autoCancel: false
        });
                                                    
        me.dockedItems = [
             {
              	dock: "top", 
              	xtype: "toolbar", 
              	items: [
              	   {
                   	xtype: "button",
                   	tooltip: "Save",
                   	text:"Save",
                   	icon: "/static/assets/famfamfam/icons/disk.png",                   	
                   	action:"save",
                   	scope:this
                   },
                   "-"
                   ,
                   {
                   	xtype: "button",
                   	tooltip: "Export to Excel",
                   	text:"Export to Excel",
                   	icon: "/static/assets/famfamfam/icons/page_white_excel.png",                   
                    action:"rollBackExcel"
                   },
                   "-"                   
                   ,
                   {
                   	xtype: "button",
                   	tooltip: "Delete",
                   	text:"Delete",
                   iconCls: 'iconDelete',
                   	handler : function() {
                   		var i;
                   		var selModel = this.up('grid').getSelectionModel();
                   		var selRec = selModel.getSelection();
                   		for(i=0;i<selRec.length;i++)
                   			{
                   				selRec[i].data.action = "DELETE";
                   				this.up('grid').store.remove(selRec[i]);
                   			}
                   	}
                   }]
             },                  
             {
                xtype: "pagingtoolbar",
                dock: "bottom",
                displayInfo: true,
                store: me.store,
                plugins: [Ext.create("eRecon_web.plugins.PageSize")]

            }
            ];
        
          me.columns = [
                      
            {	header: "Schedule ID", 
            	dataIndex: "scheduleid"
            }
            ,
            {	header: "Corp", 
            	dataIndex: "corp"
            }
            ,
            {	header: "Proof", 
            	dataIndex: "proof"
            }
            ,
            {	header: "Date", 
            	dataIndex: "changedate",
	            xtype: "datecolumn",
	        	format : "m/d/Y"
            } ,
            {	header: "Change By", 
            	dataIndex: "changeby",
            	hidden:true,
            	renderer: function setFontColor(value, meta, record){	            	
            		var newvalue;
            		newvalue = "<span style='color:#989898' >"+value+"</span>";            			          		            		            		
            		return newvalue;
            	}
            } ,
            {	header: "Recon Period",
            	hidden:true,
            	dataIndex: "reconperiod",
            	renderer: function setFontColor(value, meta, record){	            	
            		var newvalue;
            		newvalue = "<span style='color:#989898' >"+value+"</span>";            			          		            		            		
            		return newvalue;
            	}
            }
            ,
            {	header: "Status", 
            	dataIndex: "status",
            	renderer: function setFontColor(value, meta, record){	            	
            		var newvalue;
            		newvalue = "<span style='color:#989898' >"+value+"</span>";            			          		            		            		
            		return newvalue;
            	}
            }
            ,
            {	header: "GL Feeds ID (Genesis Only)", 
            	dataIndex: "feedid"
            }
            ,
            {	header: "Region (Genesis Only)", 
            	dataIndex: "region"
            }
        ];         
          
        me.callParent(arguments);
        }
    });

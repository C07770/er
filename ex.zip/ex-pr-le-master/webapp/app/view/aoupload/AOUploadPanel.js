Ext.define("eRecon_web.view.aoupload.AOUploadPanel", {
    extend: "Ext.form.Panel",
    alias: "widget.aoupload_panel",
    border: true,
    bodyStyle: "padding:10px;",
    initComponent: function () {

        this.defaults = {
            labelAlign: "left",
            labelStyle: "font-weight:bold;"
        };
        
        this.items = [
            {
                xtype: "filefield",
                name: "uploadfile",
                fieldLabel: "Choose a file",
                itemId: "fileupload-file",
                buttonText: "Browse...",
                /*anchor: '50%',*/
                width: 400,
                labelWidth: 150,
                minWidth: 150
                
            },
            {
                xtype: "button",
                text: "Upload File",
                scope: this,
                handler: function () {
            	this.fireEvent("aouploadfile", {clientApp: this.clientApp, cmp: this});
        		}
            }
        ];
        
        this.callParent(arguments);
    }

});

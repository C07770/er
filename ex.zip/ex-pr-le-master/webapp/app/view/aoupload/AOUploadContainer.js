Ext.define("eRecon_web.view.aoupload.AOUploadContainer", {
    extend: "Ext.container.Container",
    alias: "widget.aoupload_container",
    id: "aoupload_container",
    requires: [
        "eRecon_web.view.aoupload.AOUploadPanel",
        "eRecon_web.view.aoupload.AODownloadPanel",
        "eRecon_web.view.aoupload.AOUploadFileHistoryGrid"
    ],
    layout: "border",
    initComponent: function (config) {

        this.uploadPanel = Ext.create("eRecon_web.view.aoupload.AOUploadPanel", {
            flex: 1
        });
        
        this.downloadPanel = Ext.create("eRecon_web.view.aoupload.AODownloadPanel", {
            flex: 1
        });
        
		this.topPanel = Ext.create('Ext.Panel', {
			layout : {
				type : 'hbox',
				align : 'stretch'
			},
			items : [
				 this.uploadPanel,
				 this.downloadPanel
			],
			dockedItems : [ {
				dock : "top",
				xtype : "toolbar",
				items : ["<b>AO Upload/Download Panel</b>", "->", "<a target='_blank' href='DocumentDownloadServlet.up?requestPage=AOUploadManual'\>AO Upload Manual-CORE</a>"]
			} ],
			flex: 2.9,
			region: "north"
		});

        this.fileHistoryPanel = Ext.create("eRecon_web.view.aoupload.AOUploadFileHistoryGrid", {
        	region: "center",
            flex: 6,
            split: true   
        });

        this.items = [
            this.topPanel,
            this.fileHistoryPanel
        ];
        
        this.callParent(config);
    }
});

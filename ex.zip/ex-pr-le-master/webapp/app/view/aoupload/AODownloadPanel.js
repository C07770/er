Ext.define("eRecon_web.view.aoupload.AODownloadPanel", {
	extend: "Ext.form.Panel",
	alias: "widget.aodownload_panel",
	border: true,
	bodyStyle: "padding:10px;",
	initComponent: function () {
		
		console.log("initComponent");
		this.bankinggroup = Ext.create("eRecon_web.store.AOUplaodBusinessUnitStore");
        this.managerList= Ext.create("eRecon_web.store.AOUplaodProofOwnerStore");
        this.acctownerList= Ext.create("eRecon_web.store.AOUplaodAcctOwnerStore");
        
        this.items = [
                  {
                	  name: "acctowner",
                	  id: 'acctowner-combo',
                	  xtype: "combo",
                	  fieldLabel: "Account Owner",
                	  store: this.acctownerList,
                	  valueField: "soeId",
                	  displayField: "soeId",
                	  mode:'local',
                	  editable: false,
                	  triggerAction: 'all',
                	  listeners: {
                		  'select' : function(cmb, rec, idx) {
                			  var bankinggroup = Ext.getCmp('bankinggroup-combo');
                			  bankinggroup.clearValue();
                			  bankinggroup.store.removeAll();
                			  var proofOwner = Ext.getCmp('proofowner-combo');
                			  proofOwner.clearValue();
                			  proofOwner.store.removeAll();
                			  var acct_owner = Ext.getCmp('acctowner-combo').getValue();
                			  if(acct_owner===''){
                				  acct_owner=null;
                			  }
                			  bankinggroup.store.load({
                				  params: {0: acct_owner}
                			  });

                		  }
                	  }

                  },
                  {
                	  name: "bankinggroup",
                	  id: 'bankinggroup-combo',
                	  xtype: "combo",
                	  fieldLabel: "Banking group",
                	  store: this.bankinggroup,
                	  valueField: "bankingGroup",
                	  displayField: "bankingGroup",
                	  queryMode:'local',
                	  triggerAction:'all',
                	  forceSelection:true,
                	  editable: false,
                	  listeners: {
                		  'select' : function(cmb, rec, idx) {
                			  var proofOwner = Ext.getCmp('proofowner-combo');
                			  proofOwner.clearValue();
                			  proofOwner.store.removeAll();
                			  var acct_owner = Ext.getCmp('acctowner-combo').getValue();
                			  var businessUnit=Ext.getCmp('bankinggroup-combo').getValue();
                			  if(acct_owner===''){
                				  acct_owner=null;
                			  }
                			  if(businessUnit===''){
                				  businessUnit=null;
                			  }
                			  proofOwner.store.load({
                				  params: {0: acct_owner,
                					  1: businessUnit
                				  }
                			  });	        	                      	           
                		  }
                	  }      	        	
                  },
                  {
                	  name: "proofowner",
                	  id: "proofowner-combo",
                	  xtype: "combo",
                	  fieldLabel: "Proof Owner",
                	  store: this.managerList,
                	  valueField: "soeId",
                	  displayField: "soeId",
                	  queryMode:'local',
                	  triggerAction:'all',
                	  forceSelection:true,
                	  editable: false 
                  },
                  {
                	  xtype: "button",
                	  text: "Download",
                	  scope: this,
                	  handler: function () {
                		  this.fireEvent("aodownloadfile", {clientApp: this.clientApp, cmp: this});
                	  }
                  },
                  {
                	  xtype: "button",
                	  text: "Reset",
                	  scope: this,
                	  handler: function () {
                		  this.getForm().reset();
                	  }
                  }
                  ];

        this.callParent(arguments);
	},
	defaults : {
		labelAlign: "left",
		labelStyle: "font-weight:bold;"
	}
	
});

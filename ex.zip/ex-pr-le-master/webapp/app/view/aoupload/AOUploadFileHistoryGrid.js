Ext.define("eRecon_web.view.aoupload.AOUploadFileHistoryGrid", {
    extend: "Ext.grid.Panel",
    alias: "widget.aoupload_filehistorygrid",
    autoScroll: true,
    columnLines: true,
    enableColumnMove: true,
    requires: [
               "Ext.ux.grid.FiltersFeature",
               "eRecon_web.view.common.ButtonGridColumn",
               "eRecon_web.view.common.ClickColumn"
           ],
    initComponent: function () {
        var me = this;

        me.stateful = true;
        	
        me.store = Ext.create("eRecon_web.store.JobStatusForProfileStore");
		
		me.store.getProxy().extraParams = {
            0: "AO"
        };

        me.features = [
            {
                ftype: "filters",
                local: true
            }
        ];

        me.dockedItems = [
            {
                dock: "top", xtype: "toolbar", items: [
                "<b>Recent Uploads/Downloads</b>"
                , "->"
                , {
                    xtype: "button",
                    tooltip: "Refresh File Upload History",
                    text: "Refresh",
                    icon : "/static/assets/famfamfam/icons/arrow_refresh.png",
                    action: "reload_history",
                    scope: this, handler: function () {
                        //console.log("Reload Upload History");
                        this.getStore().load();
                    }
                }
            ]}
        ];

        me.columns = [
            {header: "Request ID",
                dataIndex: "scheduleId",
                filterable: true,
                xtype: 'clickColumn',
                flex: 1,
                scope: this,
                listeners: {
                	clickevent: function (column, record, rowIndex, colIndex, e) {
        				me.fireEvent('clickevent', column, record, rowIndex, colIndex, e);
        			}
        		}
            },
            {header: "Process Name",
                dataIndex: "profileName",
                filterable: true,
                flex: 1,
                filter: {type: "string"}
            },
            {
            	header: "File Name <img src='/static/assets/famfamfam/icons/attach.png' style='width:16px;height:16px;' data-qtip='Download File'>",
            	dataIndex: "fileName",
            	filterable: true,
            	flex: 3,
                filter: {type: "string"},
                renderer: this.fileNameRenderer
            },
            {header: "Job Start",
                dataIndex: "loadStart",
                filterable: true,
                flex: 1,
                filter: {type: "string"}
            },
            {header: "Job End",
                dataIndex: "loadEnd",
                filterable: true,
                flex: 1,
                filter: {type: "string"}
            },
            {
                header: "Status",
                dataIndex: "status",
                filterable: true,
                flex: 1,
                filter: {type: "string"},
                renderer: eRecon_web.gbl.constants.statusColumnRenderer
            },
            {
                header: "User ID",
                dataIndex: "userId",
                filterable: true,
                flex: 1,
                filter: {type: "string"}
            },
            {
                header: "Process File",
                sortable: false,
                xtype: 'buttonGridColumn',
                align: 'center',
                scope: this,
                listeners: {
          		  buttonclick: function (column, recordIndex, record, view) {
                		console.log("button click");
                		me.fireEvent('aoFileRunProfile', column, recordIndex, record, view);
                	}
                },
                renderer : function(value, metaData, record) {
            		var cssPrefix = Ext.baseCSSPrefix;
            		var cls = cssPrefix + ' iconRunProfile';
            		
            		if (record.get("status") === 'U') {
            			return '<div class="' + cls + '">&#160;</div>';
            		}  else {
            			return '';
            		}
            	}
            },
            {
                header: "Discard",
                sortable: false,
                xtype: 'buttonGridColumn',
                align: 'center',
                scope: this,
                listeners: {
          		  buttonclick: function (column, recordIndex, record, view) {
                		console.log("button click for discard");
                		me.fireEvent('aoFileDiscardProfile', column, recordIndex, record, view);
                	}
                },
                renderer : function(value, metaData, record) {
            		var cssPrefix = Ext.baseCSSPrefix;
            		var cls = cssPrefix + ' iconDiscard';
            		
            		if (record.get("status") === 'U') {
            			return '<div class="' + cls + '">&#160;</div>';
            		}  else {
            			return '';
            		}
            	}
            },{
                header : 'Load Type',
	            dataIndex : 'loadType',
	            flex : 1,
	            hidden: true
	         } 
            
        ];

        me.callParent(arguments);
    },
    downloadFileRenderer: function (val_, meta_, rec_, col_, store_, view_) {
        return "<a href='" + eRecon_web.gbl.constants.URL_FILEDOWNLOADACTION + rec_.data.FILE_ID + "'>" + val_ + "</a>";
    },
    dmiRenderer: function (val_, meta_, rec_, col_, store_, view_) {
        var resp = "Daily";
        if (val_ === "M") {
            resp = "Monthly";
        }
        return resp;
    },
    fileNameRenderer: function (val, meta, rec, col, store, view) {
    	if((rec.get("status") === 'C' && rec.get("loadType") === 'U') || (rec.get("status") === 'X' && rec.get("loadType") === 'U') || (rec.get("status") === 'F' && rec.get("loadType") === 'U') || (rec.get("status") === 'C' && rec.get("loadType") === 'D')){
    		
    		var fileArray = val.split('|');
    		var resp = '';
    		for(var i = 0; i < fileArray.length; i++)
    		{
    		   // Trim the excess whitespace.
    			fileArray[i] = fileArray[i].replace(/^\s*/, "").replace(/\s*$/, "");
    		   // Add additional code here, such as:
    			resp = resp + '<a target="_blank" href=\'jobstatusDownload.up?scheduleId=' + rec.get("scheduleId") + '&fileName=' + fileArray[i] + '\'>' + fileArray[i] + '</a><br>';
    		}
    		
    		if(fileArray.length > 1) {
    			return resp;
    		} else {
    			return '<a target="_blank" href=\'jobstatusDownload.up?scheduleId=' + rec.get("scheduleId")  + '&fileName=' + val +  '\'>' + val + '</a>';
    		}
    	} 

    	return val;
    }
});

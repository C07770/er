Ext.define("eRecon_web.view.ExchangeRate.ExchangeRateSearch", {
    extend: "Ext.form.Panel",
    alias: "widget.ExchangeRate_Search",
    defaults: {labelAlign: "side"},
    bodyPadding: 10,

    initComponent: function () {
    	
    	this.AccountTypeIDStore = Ext.create("eRecon_web.store.AccountTypeIDStore",{});

    	  this.activeStore = Ext.create('Ext.data.Store', {
              fields: ['ActiveName', 'ActiveValue'],
              data: [{
                  "ActiveName": "Yes",
                  "ActiveValue": "Y"
              }, {
                  "ActiveName": "No",
                  "ActiveValue": "N"
              }]
          	});
    	    	
	    var store = Ext.create("Ext.data.Store", {
	      fields:["key", "value","flag"],
	      proxy:{
	      	type:"direct",                              
	        directFn:eRecon_web.direct.action.ExchangeRateService.getReconPeriod
	      }
	    });	     	
        this.items = [ 

            {
                name: "currencycode",
                itemId: "currencycode",
                maxLength:3,
                fieldLabel: 'Currency Code<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>',
                xtype: "textfield"
            } 
            ,
            {
                name: "currencydesc",
                itemId: "currencydesc",
                fieldLabel: "Currency Description",
                xtype: "textfield"
            }
            ,
            {
                name: "currentrate",
                itemId: "currentrate",
                xtype: "numberfield",  
                fieldLabel: "Current Rate"
            }
            ,
            {
                name: "previousrate",
                itemId: "previousrate",
                xtype: "numberfield",             
                fieldLabel: "Previous Rate"
            }
            ,
            {
                name: "variance",
                itemId: "variance",
                xtype: "numberfield",             
                fieldLabel: "Variance"
            },
            {
            	name: "reconperiod",
		        itemId: "reconperiod",
		        xtype:"combo",
		        typeAhead:true,
		        fieldLabel: 'Recon Period <span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>',
		        store:store,
		        queryMode: 'local',
				valueField: "key",
				displayField: "key",
				tpl: Ext.create('Ext.XTemplate',
				'<tpl for=".">',
				'<div class="x-boundlist-item">',
				  '<div style="{[this.getClass(values)]}">{key}</div>',
				  '</div>',
				 '</tpl>',
				    {
				        getClass: function (rec) {
				            return rec.flag == 'TRUE' ? "color: red;":''
				        }
				    }
				),
				listeners:{
				    beforerender:function(cbo_) {        		
					  cbo_.getStore().load();
				  }
				}
            },
            /*{
                name: "reconperiod",
                itemId: "reconperiod",
                xtype: "textfield",             
                fieldLabel: 'Recon Period<span style="color: rgb(255, 0, 0); padding-left: 2px;">*</span>'
            },*/
            {
                name: "activeflag",
                itemId: "activeflag",
                xtype: "combo",
                typeAhead:true,
                queryMode:'local',
                valueField: "ActiveValue",
                displayField: "ActiveName",
                fieldLabel: "Active Flag",
                store: this.activeStore
            }
        ];
        
        this.dockedItems = [
            {
                dock: "top", 
                xtype: "toolbar",
                items: [
                {
                    xtype: "button",
                    text: "Insert",
                    iconCls: 'iconAdd',
                    scope: this,
                    action: "insert"
                },
                "-",
                {
                    xtype: "button",
                    text: "Search",
                    iconCls: 'iconMagnifier',
                    scope: this,
                    action: "searchdetails"
                },
                "-",
                {
                	xtype: "button",
                    text: "Clear",
                    iconCls: 'iconTableDelete',
                    scope: this,
                    action: "clear"
                }
            ]
            },{
				dock: "bottom", 
				xtype: "toolbar",
				items: [
					{
					    xtype: "label",
					    text: "* Indicates Mandatory fields while inserting a new record"
					}
				]
	        }
        ];

        this.callParent(arguments);
    }
});

Ext.define("eRecon_web.view.ExchangeRate.ExchangeRateGrid", {
    extend: "Ext.grid.Panel",
    alias: "widget.ExchangeRate_Grid",    
    autoScroll: true,
    forceFit: true,    
    columnLines: true,
    multiSelect:true,
    store: "eRecon_web.store.ExchangeRateStore",
    enableColumnMove: true,    
    border: false,
    
    viewConfig: {
        emptyText: "No details available."},
                

    initComponent: function () {
        var me = this;
        me.stateful = false;      
  
        this.activeStore = Ext.create('Ext.data.Store', {
            fields: ['ActiveName', 'ActiveValue'],
            data: [{
                "ActiveName": "Yes",
                "ActiveValue": "Y"
            }, {
                "ActiveName": "No",
                "ActiveValue": "N"
            }]
        	});
        me.plugins= [
                     Ext.create('Ext.grid.plugin.CellEditing', {
                         clicksToEdit: 1,
                         allowBlank:false
                     })
        ];
        
        var rowEditing = Ext.create('Ext.grid.plugin.RowEditing', {
            clicksToMoveEditor: 1,
            autoCancel: false
        });
                                                    
        me.dockedItems = [
             {
              	dock: "top", 
              	xtype: "toolbar", 
              	items: [
              	   {
                   	xtype: "button",
                   	tooltip: "Save",
                   	text:"Save",
                   	icon: "/static/assets/famfamfam/icons/disk.png",                   	
                   	action:"save",
                   	scope:this
                   },
                   "-"
                   ,
                   {
                   	xtype: "button",
                   	tooltip: "Export to Excel",
                   	text:"Export to Excel",
                   	icon: "/static/assets/famfamfam/icons/page_white_excel.png",                   
                    action:"exchangeRateexcel"
                   },
                   "-"                   
                   ,
                   {
                   	xtype: "button",
                   	tooltip: "Delete",
                   	text:"Delete",
                   iconCls: 'iconDelete',
                   	handler : function() {
                   		var i;
                   		var selModel = this.up('grid').getSelectionModel();
                   		var selRec = selModel.getSelection();
                   		for(i=0;i<selRec.length;i++)
                   			{
                   				selRec[i].data.action = "DELETE";
                   				this.up('grid').store.remove(selRec[i]);
                   			}
                   	}
                   }]
             },                  
             {
                xtype: "pagingtoolbar",
                dock: "bottom",
                displayInfo: true,
                store: me.store,
                plugins: [Ext.create("eRecon_web.plugins.PageSize")]

            }
            ];
        
          me.columns = [
                      
            {	header: "Currency Code", 
            	dataIndex: "currencycode",
            	renderer: function setFontColor(value, meta, record){	            	
            		var newvalue;
            		newvalue = "<span style='color:#989898' >"+value+"</span>";            			          		            		            		
            		return newvalue;
            	}
            }
            ,
            {	header: "Currency Desc", 
            	dataIndex: "currencydesc",
            	editor:{
            		xtype: 'textfield'
            	}
            }
            ,
            {	header: "Current Rate", 
            	dataIndex: "currentrate",
            	editor:{
            		xtype: 'numberfield'
            	}
            }
            ,
            {	header: "Previous Rate", 
            	dataIndex: "previousrate",
            	editor:{
            		xtype: 'numberfield'
            	}
            }
            ,
            {	header: "Variance", 
            	dataIndex: "variance",
            	editor:{
            		xtype: 'numberfield'
            	}
            },
            {	header: "Recon Period", 
            	dataIndex: "reconperiod",
            	renderer: function setFontColor(value, meta, record){	            	
            		var newvalue;
            		newvalue = "<span style='color:#989898' >"+value+"</span>";            			          		            		            		
            		return newvalue;
            	}
            }
            ,
            {	header: "Active Flag",
            	dataIndex: "activeflag",
            	editor: 
            	{
            		xtype: 'combo',            	
	                store: this.activeStore,
	                valueField: "ActiveValue",
	                displayField: "ActiveName"
            	},
            	renderer: function(val){
                    var index = this.activeStore.findExact('ActiveValue',val); 
                    if (index != -1){
                       var rs = this.activeStore.getAt(index).data; 
                        return rs.ActiveName; 
                    }else{
                    	return val;
                    }
                    }
            }                       
        ];         
          
        me.callParent(arguments);
        }
    });

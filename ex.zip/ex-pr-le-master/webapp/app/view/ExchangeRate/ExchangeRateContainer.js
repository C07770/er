Ext.define("eRecon_web.view.ExchangeRate.ExchangeRateContainer",{
	extend: "Ext.container.Container", 
	alias: "widget.ExchangeRate_Container",   
    layout: "border",
    
 initComponent: function (config) {

    	this.ExchangeRateGrid = Ext.create("eRecon_web.view.ExchangeRate.ExchangeRateGrid", {
            title: "FX Rate",
            region: "center",
            flex: 4
        });
    	
    	this.ExchangeRateSearch = Ext.create("eRecon_web.view.ExchangeRate.ExchangeRateSearch", {
    		title: "Search/Insert FX Rate",
            region: "west",
            collapsible: true,          
            collapsed: false,
            flex: 1.5
            });

    	
    	this.items = [    	              
    	              this.ExchangeRateGrid,
    	              this.ExchangeRateSearch
    	             ];
    	
    	this.listeners =
        {
    			scope: this,
                "activate": function () {                        	
                	var ExchangeRateGridStore = this.ExchangeRateGrid.getStore();
                	ExchangeRateGridStore.directOptions = {};
                	ExchangeRateGridStore.getProxy().extraParams = {
    	                0: null
    	            };
                	ExchangeRateGridStore.load({
    	                callback: function (records, operation, success) {
    	                }
    	            });
              }  
        };
    	
    	this.callParent(config);
	}
	
});

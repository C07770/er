Ext.define("eRecon_web.view.detailsupload.DetailsUploadContainer", {
    extend: "Ext.container.Container",
    alias: "widget.detailsupload_container",
    requires: [
        "eRecon_web.view.detailsupload.DetailsUploadPanel",
        "eRecon_web.view.detailsupload.DetailsDownloadPanel",
        "eRecon_web.view.detailsupload.DetailsUploadFileHistoryGrid",
        "eRecon_web.view.detailsupload.DetailsUploadTemplate"
    ],
    layout: "border",
    initComponent: function (config) {
	
    	this.templatePanel = Ext.create("eRecon_web.view.detailsupload.DetailsUploadTemplate", {
    		region: "north",
    		title:"Template Type Panel",
    		flex: 1
        });

        this.uploadPanel = Ext.create("eRecon_web.view.detailsupload.DetailsUploadPanel", {
            flex: 1
        });
        
        this.downloadPanel = Ext.create("eRecon_web.view.detailsupload.DetailsDownloadPanel", {
            flex: 1
        });
        

        this.topPanel = Ext.create('Ext.Panel', {
			layout : {
				type : 'hbox',
				align : 'stretch'
			},
			items : [
				 this.uploadPanel,
				 this.downloadPanel
			],
			dockedItems : [ {
				dock : "top",
				xtype : "toolbar",
				items : ["<b>Details Upload/Download Panel</b>", "->", "<a target='_blank' href='DocumentDownloadServlet.up?requestPage=DetailsUploadManual'\>Details Upload Manual-CORE</a>"]
			} ],
			flex: 2.3,
			region: "north"
		});

        this.fileHistoryPanel = Ext.create("eRecon_web.view.detailsupload.DetailsUploadFileHistoryGrid", {
            region: "center",
            flex: 7,
            solit: true

        });

        this.items = [
            this.templatePanel,
            this.topPanel,
            this.fileHistoryPanel
        ];
        this.listeners = {
            scope: this,
            "activate": function () {
                // Lazy loading summary grid to avoid batched up front hit
                this.fileHistoryPanel.getStore().load();


            }
        };
        this.callParent(config);
    }
});

Ext.define("eRecon_web.view.detailsupload.DetailsUploadPanel", {
    extend: "Ext.form.Panel",
    alias: "widget.detailsupload_panel",
    border: true,
    bodyStyle: "padding:10px;",
    initComponent: function () {

        this.defaults = {
            labelAlign: "left",
            labelStyle: "font-weight:bold;"
        };
        
        this.items = [
            {
                xtype: "filefield",
                name: "uploadfile",
                fieldLabel: "File",
                buttonText: "Browse...",
                itemId: "fileupload-file",
                width: 400,
                labelWidth: 150,
                minWidth: 150
            },
            {
                xtype: "button",
                text: "Upload",
                scope: this,
                handler: function () {
                	this.fireEvent("detailsuploadfile", {clientApp: this.clientApp, cmp: this});
            	}
       
            }
        ];
        
       /* this.dockedItems = [
            {
                dock: "bottom", xtype: "toolbar", items: [
                {
                    xtype: "button",
                    text: "Upload",
                    scope: this,
                    handler: function () {
                    	this.fireEvent("detailsuploadfile", {clientApp: this.clientApp, cmp: this});
                	}
           
                },
                "-"
                ,
                {
                	xtype: "button",
	                text: "Download",
	                scope: this,
	                handler: function () {
                    	this.fireEvent("detailsdownloadfile", {clientApp: this.clientApp, cmp: this});
                	}
	                
                },
                "-"
                ,
                {
                	xtype: "button",
	                text: "Run Profile",
	                scope: this,
	                handler: function () {
                		this.fireEvent("detailsrunprofile", {clientApp: this.clientApp, cmp: this});
            		}
                }
            ]
            }
        ];*/
        this.callParent(arguments);
    }

});

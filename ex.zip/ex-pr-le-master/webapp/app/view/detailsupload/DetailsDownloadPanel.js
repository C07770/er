Ext.define("eRecon_web.view.detailsupload.DetailsDownloadPanel", {
    extend: "Ext.form.Panel",
    alias: "widget.detailsdownload_panel",
    border: true,
    bodyStyle: "padding:10px;",
    initComponent: function () {
	
    	var agingtype = Ext.create('Ext.data.Store', {
    		fields: ['abbr', 'name'],
    		data: [{
    			"abbr": "ALL",
    			"name": "All"
    		}
    		,   
    		{
    			"abbr": "G",
    			"name": "GL"
    		}, {
    			"abbr": "S",
    			"name": "SL"
    		}
    		]
    	});
    	
        this.defaults = {
            labelAlign: "left",
            labelStyle: "font-weight:bold;"
        };
        
        this.bankinggroup = Ext.create("eRecon_web.store.DetailsUplaodBankingGroup");
        this.items = [
                      {
                    	  name: "bankinggroup",
                    	  itemId: "bankinggroup-combo",
                    	  xtype: "combo",
                    	  fieldLabel: "Banking group",
                    	  store: this.bankinggroup,
                    	  valueField: "bankingGroup",
                    	  displayField: "bankingGroup",
	                      queryMode:'local',
	                	  triggerAction:'all',
	                	  forceSelection:true,
	                	  editable: false
                      },{
                    	  name: "agingtype",
                    	  itemId: "agingtype-combo",
                    	  xtype: "combo",
                    	  fieldLabel: "Aging type",
                    	  store : agingtype,
                    	  valueField: "abbr",
                    	  displayField: "name"
                      },{
                    	  xtype: "button",
                    	  text: "Download",
                    	  scope: this,
                    	  handler: function () {
                    		  this.fireEvent("detailsdownloadfile", {clientApp: this.clientApp, cmp: this});
                    	  }

                      },
                      {
                    	  xtype: "button",
                    	  text: "Reset",
                    	  scope: this,
                    	  handler: function () {
                    		  this.getForm().reset();
                    	  }
                      }
                      ];

        /* this.dockedItems = [
            {
                dock: "bottom", xtype: "toolbar", items: [
                {
                    xtype: "button",
                    text: "Upload",
                    scope: this,
                    handler: function () {
                    	this.fireEvent("detailsuploadfile", {clientApp: this.clientApp, cmp: this});
                	}

                },
                "-"
                ,
                {
                	xtype: "button",
	                text: "Download",
	                scope: this,
	                handler: function () {
                    	this.fireEvent("detailsdownloadfile", {clientApp: this.clientApp, cmp: this});
                	}

                },
                "-"
                ,
                {
                	xtype: "button",
	                text: "Run Profile",
	                scope: this,
	                handler: function () {
                		this.fireEvent("detailsrunprofile", {clientApp: this.clientApp, cmp: this});
            		}
                }
            ]
            }
        ];*/
        this.callParent(arguments);
    }

});

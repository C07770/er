Ext.define("eRecon_web.view.detailsupload.DetailsUploadTemplate", {
    extend: "Ext.form.Panel",
    alias: "widget.detailsupload_template",
    id: "detailsUploadTemplate",
    defaults: {labelAlign: "side"},
    bodyPadding: 10,

    initComponent: function () {
	
     
	
        this.items = [
                    {
                        xtype: 'radiogroup',
                        fieldLabel: 'Please Select Template',
                        labelWidth:150,
                        width:400,
                        action:'templateChange',
                        itemId: 'templateType',
                        items: [
                            {
                                xtype: 'radiofield',
                                boxLabel: 'Legacy',
                                name: 'template',
                                checked: true,
                                inputValue: 'legacy'
                            },
                            {
                                xtype: 'radiofield',
                                boxLabel: 'Genesis',
                                name: 'template',
                                inputValue: 'genesis'
                            }
                        ]
                    }

        ];
        
        this.callParent(arguments);
}
   
});

Ext.define("eRecon_web.view.AccountTypeLU.AccountTypeLUContainer",{
	extend: "Ext.container.Container", 
	alias: "widget.AccountTypeLU_Container",   
    layout: "border",
    
 initComponent: function (config) {

    	this.AccountTypeLUGrid = Ext.create("eRecon_web.view.AccountTypeLU.AccountTypeLUGrid", {
            title: "Account Type LU",
            region: "center",
            flex: 4
        });
    	
    	this.AccountTypeLUSearch = Ext.create("eRecon_web.view.AccountTypeLU.AccountTypeLUSearch", {
    		title: "Search/Insert Account Type LU",
            region: "west",
            collapsible: true,          
            collapsed: false,
            flex: 1.5
            });

    	
    	this.items = [    	              
    	              this.AccountTypeLUGrid,
    	              this.AccountTypeLUSearch
    	             ];
    	
    	this.listeners =
        {
    			scope: this,
                "activate": function () {                        	
                	var AccountTypeGridStore = this.AccountTypeLUGrid.getStore();
                	AccountTypeGridStore.directOptions = {};
                	AccountTypeGridStore.getProxy().extraParams = {
    	                0: null
    	            };
                	AccountTypeGridStore.load({
    	                callback: function (records, operation, success) {
    	                }
    	            });
              }  
        };
    	
    	this.callParent(config);
	}
	
});

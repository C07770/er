Ext.define("eRecon_web.view.AccountTypeLU.AccountTypeLUGrid", {
    extend: "Ext.grid.Panel",
    alias: "widget.AccountTypeLU_Grid",    
    autoScroll: true,
    forceFit: true,    
    columnLines: true,
    multiSelect:true,
//    store: "eRecon_web.store.AccountTypeLUStore",
    enableColumnMove: true,    
    border: false,
    
    viewConfig: {
        emptyText: "No details available."},
                

    initComponent: function () {
        var me = this;
        me.stateful = false;      
        
        this.AccountTypeIDStore = Ext.create("eRecon_web.store.AccountTypeIDStore",{});
        
        me.store = Ext.create("eRecon_web.store.AccountTypeLUStore",{});
        me.store.directOptions = {};
        me.store.getProxy().extraParams = {
        	 0: null,
             1:null,
             2:null,
             3:null,
             4:null,
             5:null          	
        };
        me.store.load({
            callback: function (records, operation, success) {
            }
        });
        
//        debugger;
        this.activeStore = Ext.create('Ext.data.Store', {
            fields: ['ActiveName', 'ActiveValue'],
            data: [{
                "ActiveName": "Yes",
                "ActiveValue": "Y"
            }, {
                "ActiveName": "No",
                "ActiveValue": "N"
            }]
        	});
        me.plugins= [
                     Ext.create('Ext.grid.plugin.CellEditing', {
                         clicksToEdit: 1,
                         allowBlank:false
                     })
        ];
        
        var rowEditing = Ext.create('Ext.grid.plugin.RowEditing', {
            clicksToMoveEditor: 1,
            autoCancel: false
        });
                                                    
        me.dockedItems = [
             {
              	dock: "top", 
              	xtype: "toolbar", 
              	items: [
              	   {
                   	xtype: "button",
                   	tooltip: "Save",
                   	text:"Save",
                   	icon: "/static/assets/famfamfam/icons/disk.png",                   	
                   	action:"save",
                   	scope:this
                   },
                   "-"
                   ,
                   {
                   	xtype: "button",
                   	tooltip: "Export to Excel",
                   	text:"Export to Excel",
                   	icon: "/static/assets/famfamfam/icons/page_white_excel.png",                   
                    action:"acctTypeExcel"
                   },
                   "-"                   
                   ,
                   {
                   	xtype: "button",
                   	tooltip: "Delete",
                   	text:"Delete",
                    iconCls: 'iconDelete',
                   	handler : function() {
                   		var i;
                   		var selModel = this.up('grid').getSelectionModel();
                   		var selRec = selModel.getSelection();
                   		for(i=0;i<selRec.length;i++)
                   			{
                   				selRec[i].data.action = "DELETE";
                   				this.up('grid').store.remove(selRec[i]);
                   			}
                   	}
                   }]
             },                  
             {
                xtype: "pagingtoolbar",
                dock: "bottom",
                displayInfo: true,
                store: me.store,
                plugins: [Ext.create("eRecon_web.plugins.PageSize")]

            }
            ];
        
          me.columns = [
                      
            {	header: "Account Type ID", 
            	dataIndex: "accounttypeid",
            	renderer: function setFontColor(value, meta, record){	            	
            		var newvalue;
            		newvalue = "<span style='color:#989898' >"+value+"</span>";            			          		            		            		
            		return newvalue;
            	}
            }
            ,
            {	header: "Account Parent ID", 
            	dataIndex: "accountparentid",
            	editor: 
            	{
            		xtype: 'combo',            	
	                store: this.AccountTypeIDStore,
	                valueField: "value",
	                displayField: "value"
            	},
            	renderer: function(val){
                    var index = this.AccountTypeIDStore.findExact('key',val); 
                    if (index != -1){
                       var rs = this.AccountTypeIDStore.getAt(index).data; 
                        return rs.value; 
                    }else{
                    	return val;
                    }
                    }
            }
            ,
            {	header: "Acronym", 
            	dataIndex: "acronym",
            	editor:{
            		xtype: 'textfield',
            		maxLength:1,
            		vtype:'alpha'
            	}
            }
            ,
            {	header: "Description", 
            	dataIndex: "description",
            	editor:{
            		xtype: 'textfield'
            	}
            }
            ,
            {	header: "Account Level", 
            	dataIndex: "accountlevel",
            	editor:{
            		xtype: 'numberfield'
            	}
            }
            ,
            {	header: "Active Flag",
            	dataIndex: "activeflag",
            	editor: 
            	{
            		xtype: 'combo',            	
	                store: this.activeStore,
	                valueField: "ActiveValue",
	                displayField: "ActiveName"
            	},
            	renderer: function(val){
                    var index = this.activeStore.findExact('ActiveValue',val); 
                    if (index != -1){
                       var rs = this.activeStore.getAt(index).data; 
                        return rs.ActiveName; 
                    }else{
                    	return val;
                    }
                    }
            }
            ,
            {	header: "Change Date" ,
            	hidden:true,
            	dataIndex: "changedate",
            	renderer: function setFontColor(value, meta, record){	            	
            		var newvalue;
            		newvalue = "<span style='color:#989898' >"+value+"</span>";            			          		            		            		
            		return newvalue;
            	}
            }
            ,
            {	header: "Change By",
            	hidden:true,
            	dataIndex: "changeby",
            	renderer: function setFontColor(value, meta, record){	            	
            		var newvalue;
            		newvalue = "<span style='color:#989898' >"+value+"</span>";            			          		            		            		
            		return newvalue;
            	}
            }
            ,
            {	header: "Change Type", 
            	dataIndex: "changetype",
            	hidden:true,
            	renderer: function setFontColor(value, meta, record){	            	
            		var newvalue;
            		newvalue = "<span style='color:#989898' >"+value+"</span>";            			          		            		            		
            		return newvalue;
            	}
            },
            {	header: "Create Date", 
            	hidden:true,
            	dataIndex: "createdate",
            	renderer: function setFontColor(value, meta, record){	            	
            		var newvalue;
            		newvalue = "<span style='color:#989898' >"+value+"</span>";            			          		            		            		
            		return newvalue;
            	}
            }
                              
        ];         
          
        me.callParent(arguments);
        }
    });

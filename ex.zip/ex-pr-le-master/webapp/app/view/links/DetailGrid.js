Ext.define("eRecon_web.view.links.DetailGrid", {
    extend: "Ext.grid.Panel",
    alias: "widget.linksgridpanel",
    autoScroll: true,
    forceFit: true,
    columnLines: true,
    enableColumnMove: false,
    border: false,
    autoLoad : false,
    initComponent: function () {
        var me = this;
        me.stateful = false;
        me.store = Ext.create("eRecon_web.store.LinksDetailStore", {});
        me.columns = [
                      
            {
            	 header : 'Name of the Link',
            	 dataIndex : 'link_txt',
            	 flex : 1,
            	 renderer : fileNameRenderer
            },
            {
            	header : 'Description of the Link',
            	dataIndex : 'link_url',
            	flex : 2
            }          
         ];
        me.callParent(arguments);
    }
});

function fileNameRenderer (val, meta, rec, col, store, view) {
	if(rec.get("content_type")=='D'){
		return '<a target="_blank" href=\'linksDownloadServlet.up?filePath=' + rec.get("link_url") + '\'>' + val + '</a>';
	}
	return '<a target="_blank" href=' + rec.get("link_url") + '\>' + val + '</a>';
}

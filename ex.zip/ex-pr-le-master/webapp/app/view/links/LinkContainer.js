Ext.define("eRecon_web.view.links.LinkContainer", {
    extend: "Ext.container.Container",
    alias: "widget.links_container",
    requires: ["eRecon_web.view.links.DetailGrid"],
    layout: "border",
    initComponent: function (config) {
        this.linksDetailGridPanel = Ext.create("eRecon_web.view.links.DetailGrid", {
        	title: 'Useful Links',
        	region: "center",
            flex: 3,
            animCollapse: false
        });

        this.items = [
            this.linksDetailGridPanel
        ];

        this.listeners = {
                scope: this,
                "activate": function () {
                	var linkDetailgrid = this.linksDetailGridPanel.getStore();
                	linkDetailgrid.load();
                }
         };

        this.callParent(config);
    }
});
